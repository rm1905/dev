# Tableau MCP Assistant

**Version 379** - Comprehensive Guide for Configuration and Deployment

A powerful MCP (Model Context Protocol) extension that brings AI-powered assistance to your Tableau workflows. Query data, explore content, and get insights using natural language - all within your Tableau dashboards or as a standalone application.

---

## Table of Contents

- [Authentication Methods](#authentication-methods)
- [Quick Start](#quick-start)
- [Configuration](#configuration)
- [Prompt Management](#prompt-management)
- [Dashboard Embedding](#dashboard-embedding)
- [Build & Deploy](#build--deploy)
- [Troubleshooting](#troubleshooting)
- [Security Best Practices](#security-best-practices)
- [Additional Resources](#additional-resources)

## 📚 Quick Links

- **[Local Development Setup](./documentation/LOCAL_DEVELOPMENT.md)** - Complete guide for running locally **(includes HTTPS setup with Caddy)**
- **[Configuration Guide](./documentation/CONFIGURATION_GUIDE.md)** - Environment variables and config options
- **[Database Setup Guide](./documentation/DATABASE_SETUP.md)** - Auto-creation of database tables
- **[Password Authentication Guide](./documentation/PASSWORDS.md)** - How passwords work in the app
- **[AWS Bedrock Setup Guide](./documentation/BEDROCK_SETUP.md)** - Step-by-step AWS Bedrock configuration with SSO

---

## ⚠️ HTTPS Requirement for Local Development

**IMPORTANT:** When running this application locally, you **must use HTTPS** to work with Tableau dashboard extensions. Tableau extensions require secure connections.

- ❌ `http://localhost:3000` - Will NOT work with Tableau extensions
- ✅ `https://localhost` - Required (via Caddy reverse proxy)

See [LOCAL_DEVELOPMENT.md](./documentation/LOCAL_DEVELOPMENT.md) for complete setup instructions including Caddy installation and configuration.

---

## Authentication Methods

Choose the authentication method that best fits your needs:

### Option 1: Personal Access Token (PAT)
**Best for:** Simple setup, individual users

- Simple setup process
- Works with Tableau Cloud and Tableau Server
- Supports all Tableau REST API and VizQL Data Service operations
- Can be easily revoked and regenerated
- **Note:** PATs cannot be used concurrently

### Option 2: Direct Trust (Connected App)
**Best for:** Production deployments, multi-user scenarios

- JWT-based authentication
- Supports dynamic username mapping via OAuth
- Allows concurrent usage
- More complex setup but better for multi-user scenarios
- **Recommended for production deployments**

---

## Quick Start

### Step 1: Create Authentication Credentials

#### Option A: Personal Access Token (PAT)

1. Sign in to Tableau Cloud or Tableau Server
2. Navigate to your user profile (click profile icon → "My Account Settings")
3. Go to "Personal Access Tokens" section
4. Click "Create New Token"
5. Fill in details:
   - **Token Name:** "Tableau MCP Extension" (or your preferred name)
   - **Expiration:** Set an appropriate date
6. Click "Create"
7. **IMPORTANT:** Save both credentials (secret shown only once!):
   - Token Name
   - Token Secret

#### Option B: Connected App (Direct Trust)

1. Sign in as a Tableau administrator
2. Navigate to **Settings → Connected Apps**
3. Click "New Connected App"
4. Select "Direct Trust" as authentication method
5. Fill in app details:
   - **App Name:** "Tableau MCP Extension"
   - **Enable:** ✓ Checked
   - **Domain Allowlist:** Leave empty
6. Save and note these credentials:
   - Client ID
   - Secret ID
   - Secret Value
7. Configure JWT Subject Claim:
   - Static username: Enter a Tableau username
   - Dynamic OAuth: Use `{OAUTH_USERNAME}` placeholder

### Step 2: Configure the Application

1. Deploy the MCP Extension to Heroku ([see deployment guide](#build--deploy))
2. Go to: `https://your-app-url.herokuapp.com/settings`
3. Enter password:
   - Admin: `AdminTableauMCP+` (can edit all profiles)
   - Non-Admin: `TableauMCP2025!` (limited access)
4. Create or select a profile
5. Fill in configuration fields (see [Configuration](#configuration) section)
6. Click "Save Profile"
7. (Optional) Click "Set as Default"
8. (Optional) Click "Validate Configuration" to test

### Step 3: Test the Connection

1. Go to: `https://your-app-url.herokuapp.com/ui/`
2. Select your profile
3. Click "Start Session"
4. Try a query: *"What data sources are available in my Tableau instance?"*
5. Success! You should see your datasources listed.

---

## Configuration

### LLM Provider Configuration

The application supports multiple LLM providers:

#### OpenAI
- **API Key:** Your OpenAI API key (starts with `sk-...`)
- **Default Model:** `gpt-4o-mini` (recommended) or other models
- **Setup:** Simple - just add API key

#### AWS Bedrock
- **Model:** Claude Sonnet 4.6 (via inference profile)
- **Authentication:** AWS SSO Profile (recommended) or IAM credentials
- **Setup:** See [BEDROCK_SETUP.md](./documentation/BEDROCK_SETUP.md) for detailed configuration guide
- **Best for:** Enterprise deployments with existing AWS infrastructure

#### Local LLM (Ollama, LM Studio, LocalAI)
- **Base URL:** OpenAI-compatible API endpoint
- **Model:** Any model supported by your local server
- **Setup:** Configure base URL and model name
- **Best for:** Privacy-focused deployments or offline usage

### Tableau Configuration

| Field | Description | Example |
|-------|-------------|---------|
| **Tableau Server URL** | Your Tableau instance URL | `https://10az.online.tableau.com` |
| **Site Content URL** | Your site name | Leave empty for default site |

### Authentication Configuration

Choose one method:

**PAT Authentication:**
- Authentication Type: Select "PAT"
- PAT Name: Token name from Step 1A
- PAT Secret: Token secret from Step 1A

**Direct Trust Authentication:**
- Authentication Type: Select "Direct Trust"
- JWT Subject Claim: Username or `{OAUTH_USERNAME}`
- Connected App Client ID: From Step 1B
- Connected App Secret ID: From Step 1B
- Connected App Secret Value: From Step 1B
- JWT Additional Payload: Optional JSON (e.g., `{"region": "West"}`)

### Application Settings

| Setting | Default | Description |
|---------|---------|-------------|
| **Allowed Origins** | Empty (allow all) | CORS origins |
| **Request Timeout** | 60000 ms | Request timeout in milliseconds |
| **Max Rows** | 500 | Maximum rows to return from queries |

---

## Prompt Management

Includes a powerful system for managing AI prompts without code deployment. This feature allows you to customize how the AI assistant behaves, modify tool guidance, and fine-tune responses, through an intuitive web interface.

### Access & Authentication

Navigate to: `https://your-app-url.herokuapp.com/prompts`

**Password Protection:**
- **Admin password:** `AdminTableauMCP+` (full access including deletion)
- **Non-admin password:** `TableauMCP2025!` (edit access only)

### Getting Started

1. **Access the Interface:**
   - Navigate to the `/prompts` URL
   - Enter your password (admin or non-admin)
   - The prompt management interface will load

2. **Select a Section:**
   - Browse sections in the left sidebar (organized by category)
   - Click any section to load it into the editor
   - The default `core_prompt` section loads automatically

3. **Edit & Preview:**
   - Modify prompt content in the **Edit Prompt** panel
   - View real-time interpolated results in the **Preview** panel
   - Use Ctrl+F to search within the editor

4. **Save Your Changes:**
   - Click **💾 Save Changes** for quick save with default metadata
   - Click **📝 Save with Note** to add a custom change summary and author name
   - Each save creates a new version automatically

### Key Features

#### 📋 Version Control
Every change is tracked in version history with full rollback capability:

- **Automatic Versioning:** Each save creates a new version with timestamps
- **Version History Tab:** View all versions with metadata (date, author, summary)
- **Rollback:** Restore any previous version with one click (creates a new version)
- **Delete Versions:** Admin-only capability to permanently remove outdated versions
- **Change Summaries:** Track what was changed and why for each version

#### 🔧 Variable System
Manage dynamic values that interpolate at runtime:

- **Variables Tab:** View all available variables with descriptions
- **Usage:** Reference variables in prompts using `{{VARIABLE_NAME}}` syntax
- **Examples:** `{{MAX_ROWS}}`, `{{TABLEAU_VERSION}}`, `{{REQUEST_TIMEOUT}}`
- **Runtime Interpolation:** Variables are replaced with actual values when prompts are used
- **Preview:** See interpolated results in the Preview panel before saving

#### 🔍 Search & Navigation
Powerful search tools to find content quickly:

- **Editor Search:** Press Ctrl+F or use the search box to find text in the editor
- **Navigation:** Use arrow buttons (↑/↓) or Enter/Shift+Enter to jump between matches
- **Preview Search:** Search independently in the preview panel to locate interpolated content
- **Match Counter:** Shows "X of Y" matches for easy tracking
- **Collapsible Groups:** Organize sections by category (Core Prompt, Guidance, Scope, etc.)

#### ⚡ Real-Time Updates
Changes take effect immediately without redeployment:

- **Instant Activation:** Saved prompts are used in the next AI session
- **No Deployment:** No need to rebuild or redeploy the application
- **Cache Invalidation:** Automatic cache refresh when prompts are updated
- **Side-by-side Preview:** See interpolated results while editing

### User Interface Overview

#### Left Sidebar: Section Navigator
- **Organized Categories:** Sections grouped by purpose (Core, Guidance, Scope, etc.)
- **Metadata Display:** Shows character count and last update date
- **Active Highlight:** Selected section is highlighted in purple
- **Collapsible Groups:** Click group headers to expand/collapse sections

#### Main Editor Area: Three Tabs

**1. 📝 Editor Tab (Default View)**
- **Section Info Bar:** Shows section name, description, size, version, and last update
- **Split View:** Editor on left, Preview on right
- **Character Count:** Real-time tracking of prompt length
- **Search Boxes:** Independent search for editor and preview panels
- **Action Buttons:** Save, Reload, Save with Note

**2. 🔧 Variables Tab**
- **Variable Cards:** Grid layout showing all available variables
- **Name & Value:** See variable names (e.g., `{{MAX_ROWS}}`) and current values
- **Descriptions:** Understand what each variable controls
- **Usage Info:** Learn how variables interpolate at runtime

**3. 📚 Version History Tab**
- **Version List:** All versions with metadata (version number, date, author, summary)
- **Rollback Button:** Restore any previous version (creates new version)
- **Delete Button:** Admin-only; permanently removes outdated versions
- **Chronological Order:** Newest versions appear first

### Prompt Sections Explained

#### Core System Prompts
- **`core_prompt`** - Main system instructions that define AI behavior and capabilities
- **`scope_section_dashboard`** - Instructions for dashboard-scoped mode (when embedded)
- **`scope_section_global`** - Instructions for global mode (standalone UI)
- **`scope_rules_both_modes`** - Shared rules that apply to both modes

#### Tool Guidance Sections
- **`datasource_query_guidance`** - How to query data using VizQL Data Service
- **`content_discovery_guidance`** - How to discover workbooks, views, and datasources
- **`search_content_guidance`** - Strategies for searching Tableau content
- **`pulse_planner_guidance`** - How to plan Pulse metrics
- **`pulse_presentation_guidance`** - How to present Pulse metrics to users

#### Upfront Hints
- **`datasource_lookup_upfront_hint`** - Pre-context for datasource lookups
- **`datasource_query_upfront_hint`** - Pre-context for data queries
- **`workbook_lookup_upfront_hint`** - Pre-context for workbook lookups

### How to Use the Editor

#### Basic Editing Workflow

1. **Select a Section:**
   - Click a section in the left sidebar
   - The content loads into the editor
   - Preview updates automatically

2. **Make Changes:**
   - Type directly in the editor textarea
   - Character count updates in real-time
   - Variables remain in `{{VARIABLE}}` format

3. **Preview Results:**
   - Click **🔄 Refresh** to update the preview
   - Preview shows interpolated content (variables replaced with values)
   - Search in preview to verify variable placement

4. **Save Your Work:**
   - Quick save: Click **💾 Save Changes**
   - Detailed save: Click **📝 Save with Note** and add change summary
   - A success message confirms the save and shows the new version number

#### Using Search (Ctrl+F)

1. **Activate Search:**
   - Press Ctrl+F or click the editor search box
   - Type your search term
   - Matches are highlighted in yellow (active match in orange)

2. **Navigate Matches:**
   - Click ↑ or ↓ buttons to move between matches
   - Press Enter for next match, Shift+Enter for previous
   - Match counter shows "X of Y" matches

3. **Exit Search:**
   - Click anywhere in the editor to exit search mode
   - Search highlights clear and editor becomes editable again

#### Working with Variables

1. **View Available Variables:**
   - Click the **🔧 Variables** tab
   - Browse all defined variables with descriptions
   - Note the variable names (e.g., `{{MAX_ROWS}}`)

2. **Use Variables in Prompts:**
   - Type `{{VARIABLE_NAME}}` in the editor
   - Example: "Query up to `{{MAX_ROWS}}` rows of data"
   - Variables are case-sensitive

3. **Preview Interpolation:**
   - The Preview panel shows the actual interpolated value
   - Example: `{{MAX_ROWS}}` becomes `500` in preview

#### Version Management

1. **Save a New Version:**
   - Click **📝 Save with Note**
   - Enter a meaningful change summary (e.g., "Improved error handling for VizQL queries")
   - Enter your name (defaults to "admin")
   - Click **💾 Save**

2. **View Version History:**
   - Click the **📚 Version History** tab
   - See all versions with timestamps, authors, and summaries
   - Most recent versions appear first

3. **Rollback to Previous Version:**
   - Find the version you want to restore
   - Click **↩️ Rollback** button
   - Confirm the rollback action
   - A new version is created with the old content

4. **Delete Outdated Versions (Admin Only):**
   - Admin users see a **🗑️ Delete** button next to each version
   - Click the button and confirm permanent deletion
   - Deleted versions cannot be recovered

### Common Tasks

#### Task 1: Update AI Response Tone
1. Select **`core_prompt`** section
2. Find the tone/personality instructions
3. Modify the language (e.g., more formal, more concise)
4. Save with note: "Changed tone to be more professional"
5. Test in `/ui/` to verify the change

#### Task 2: Add Custom Tool Guidance
1. Select the appropriate guidance section (e.g., `datasource_query_guidance`)
2. Add your custom instructions or examples
3. Use variables if needed (e.g., `{{MAX_ROWS}}`)
4. Preview to verify variable interpolation
5. Save with note describing the addition

#### Task 3: Fix a Mistake
1. Go to **📚 Version History** tab
2. Find the last good version (before the mistake)
3. Click **↩️ Rollback** to restore it
4. Verify in the editor that content is correct
5. No additional save needed—rollback creates a new version automatically

#### Task 4: Clean Up Old Versions (Admin)
1. Go to **📚 Version History** tab
2. Review old versions that are no longer needed
3. Click **🗑️ Delete** on obsolete versions
4. Confirm permanent deletion
5. Keep at least 5-10 recent versions for rollback capability

### Best Practices

#### ✅ Do This:
- **Meaningful Summaries:** Always add descriptive change summaries when saving
- **Test Before Committing:** Use the preview to verify variable interpolation
- **Small, Focused Changes:** Make incremental edits rather than massive rewrites
- **Version Regularly:** Save versions at logical checkpoints
- **Document Context:** Include WHY you made a change, not just WHAT changed
- **Keep Variables:** Use variables for values that change frequently (timeouts, limits, etc.)

#### ❌ Avoid This:
- **Vague Summaries:** Don't use "updated" or "changed stuff"—be specific
- **Breaking Variables:** Don't hardcode values that should be variables
- **Deleting Too Much:** Keep recent version history for rollback safety
- **Testing in Production:** Preview changes before saving to avoid breaking live sessions
- **Overwriting Without Reading:** Always review current content before editing

### Troubleshooting

#### "Changes Aren't Taking Effect"
- **Solution:** Verify the save was successful (look for success alert)
- Refresh the preview panel to see interpolated content
- Test in a new session at `/ui/` (old sessions use cached prompts)

#### "Variables Not Interpolating"
- **Solution:** Check variable syntax: must be `{{VARIABLE_NAME}}` (double braces)
- Verify variable exists in the **🔧 Variables** tab
- Variable names are case-sensitive

#### "Can't Delete Versions"
- **Solution:** Deletion requires admin password (`AdminTableauMCP+`)
- Non-admin users can view and rollback but cannot delete
- If you need admin access, contact your administrator

#### "Preview Not Updating"
- **Solution:** Click the **🔄 Refresh** button in the Preview header
- If still stale, reload the page and re-select the section

#### "Rollback Failed"
- **Solution:** Ensure the version you're rolling back to still exists
- Check that you have permission (both admin and non-admin can rollback)
- Verify network connection to the server

### Security Notes

- **Password Protection:** All access requires valid password
- **Admin vs Non-Admin:** Only admins can delete versions permanently
- **Audit Trail:** All changes are logged with timestamps and authors
- **No Code Access:** Users can edit prompts but cannot access application code
- **Version Safety:** Rollback creates new versions; old versions remain unless deleted

---

---

## Dashboard Embedding

Embed the MCP Assistant directly in Tableau dashboards for context-aware AI assistance.

### URL Parameters

| Parameter | Description | Example |
|-----------|-------------|---------|
| `?scope=dashboard` | Enables dashboard-scoped mode with auto-start | Restricts access to dashboard objects only |
| `?profile=PROFILE_NAME` | Specifies which profile to use | `?profile=default` |
| Combined | Use both parameters | `?profile=default&scope=dashboard` |

### Tableau Extension (.trex)

Create a manifest file to embed in dashboards:

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest manifest-version="0.1" xmlns="http://www.tableau.com/xml/extension_manifest">
  <dashboard-extension id="com.tableau.mcp.assistant" extension-version="1.0.0">
    <default-locale>en_US</default-locale>
    <name resource-id="name"/>
    <description>Tableau MCP AI Assistant</description>
    <author name="Your Name" email="your.email@example.com" organization="Your Org" website="https://example.com"/>
    <min-api-version>1.7</min-api-version>
    <source-location>
      <url>https://localhost/ui/?profile=default&amp;scope=dashboard</url>
    </source-location>
    <icon>
      <!-- Base64 encoded icon here -->
    </icon>
    <permissions>
      <permission>full data</permission>
    </permissions>
  </dashboard-extension>
  <resources>
    <resource id="name">
      <text locale="en_US">Tableau MCP Assistant</text>
    </resource>
  </resources>
</manifest>
```

### Features in Dashboard Scope Mode

#### Automatic Context Detection
- Worksheets: Names and view IDs collected automatically
- Data Sources: Only published datasources (embedded excluded)
- Auto-start: Session begins immediately on load

#### Scope Enforcement
- LLM restricted to dashboard objects only
- External object access blocked
- Clear messaging about available assets

#### Smart Name Resolution
- Worksheet names → viewId (automatic lookup)
- Datasource names → LUID (automatic lookup)
- Workbook names → ID (automatic lookup)
- Internal IDs never shown to users

#### Intelligent Ranking
- Objects sorted by importance (recency, usage, certification)
- Top 10 shown with ranking rationale
- Owner/author info displayed when available

### Example Questions

**Dashboard Scope Mode:**
- "What data is in this dashboard?"
- "Show me the top 10 sales by region"
- "What are the trends in the Sales by Region worksheet?"
- "Compare Q1 vs Q2 performance"
- "What fields are available in the Orders datasource?"

**Global Mode (No Scope):**
- "List all workbooks on the site"
- "What datasources are available?"
- "Search for dashboards about sales"
- "What Pulse metrics am I following?"
- "Show me workbooks owned by John Doe"

### Important Notes

- Dashboard scope requires Tableau Extensions API (Tableau 2021.4+)
- Only published datasources are included in scope
- Embedded datasources accessed via their worksheets
- Profile parameter requires valid profile name in settings
- Session auto-starts only when `scope=dashboard` is present
- Pulse metrics NOT exposed via Extensions API in dashboard mode

---

## Build & Deploy

> **📖 For detailed local development setup instructions, see [LOCAL_DEVELOPMENT.md](./LOCAL_DEVELOPMENT.md)**

### Prerequisites

- Node.js 20+ installed (24.x recommended)
- Heroku CLI installed and authenticated
- Git installed
- LLM provider credentials (OpenAI API key, AWS credentials, or Local LLM setup)
- Tableau PAT or Connected App credentials

### Development Setup

```bash
# 1. Clone or download the repository
git clone <repository-url>
cd tableau-mcp-assistant

# 2. Create .env file from template
cp .env.example .env
# Edit .env with your credentials

# 3. Install dependencies
npm install

# 4. Build TypeScript code
npm run build

# 5. Initialize database
createdb tableau_mcp

# 6. Run locally (development mode with hot reload)
# All database tables auto-create on first run
npm run dev
```

**Configuration:** For local development, use `.env` file (no `config.json` needed).

Access the application:
- UI: http://localhost:3000/ui/
- Settings: http://localhost:3000/settings
- Prompts: http://localhost:3000/prompts
- Health Check: http://localhost:3000/healthz

### Heroku Deployment

```bash
# 1. Login to Heroku
heroku login

# 2. Create new app (or use existing)
heroku create your-app-name

# 3. Add Heroku remote (if resuming)
heroku git:remote -a your-app-name

# 4. Add Postgres addon
heroku addons:create heroku-postgresql:essential-0

# 5. Set environment variables
heroku config:set CONFIG_PASSWORD=schema-required-not-used

# 6. Deploy
git add -A
git commit -m "Deploy Tableau MCP Extension v379"
git push heroku main

# 7. Verify deployment
heroku open
heroku logs --tail
```

### Environment Variables

**Required:**
- `DATABASE_URL` - PostgreSQL connection string (auto-set by Heroku addon)
- `CONFIG_PASSWORD` - Required by schema (not used for auth; set to any value)

**Application Configuration (set in .env for local dev):**
- `LLM_PROVIDER` - LLM provider (openai, bedrock, or local)
- `OPENAI_API_KEY` - OpenAI API key (if using OpenAI)
- `BEDROCK_REGION` / `BEDROCK_MODEL_ID` / `BEDROCK_PROFILE` - AWS Bedrock config (if using Bedrock)
- `TABLEAU_BASE_URL` - Tableau server URL
- `AUTHENTICATION_TYPE` - Authentication method (pat or direct-trust)
- `TABLEAU_PAT_NAME` / `TABLEAU_PAT_SECRET` - PAT credentials (if using PAT)
- `CONNECTED_APP_*` - Connected App credentials (if using Direct Trust)
- See `.env.example` for full list

**Web UI Access:**
Settings and Prompts pages use hardcoded passwords:
- Admin password: `AdminTableauMCP+` (full access)
- Non-admin password: `TableauMCP2025!` (limited access)

**Note for Local Development:**
- Use `.env` file for all configuration (recommended)
- `config/config.json` is optional and created only if using web UI at `/settings`
- Environment variables in `.env` take precedence over `config.json`

### Updating the Application

```bash
# 1. Make code changes locally

# 2. Build TypeScript
npm run build

# 3. Test locally
npm start

# 4. Commit and deploy
git add -A
git commit -m "Description of changes"
git push heroku main

# 5. Verify
heroku logs --tail
```

---

## Troubleshooting

### Common Issues

#### "Connection closed" or "MCP error -32000"
**Solution:**
- Verify authentication credentials are correct
- Check PAT hasn't expired (if using PAT)
- Ensure Tableau Server URL is correct and accessible
- Check Heroku logs: `heroku logs --tail`

#### "Failed to authenticate"
**Solution:**
- For PAT: Verify Token Name and Secret (case-sensitive)
- For Direct Trust: Verify Connected App credentials
- Check credentials are still valid and not expired
- Ensure user has necessary permissions

#### "Missing required configuration"
**Solution:**
- Ensure all authentication fields are filled in
- Check `TABLEAU_BASE_URL` is configured correctly
- Verify LLM provider credentials are configured (OpenAI API key, AWS credentials, etc.)

#### "Request timed out"
**Solution:**
- Check network connection to Tableau
- Verify Tableau Server is accessible from Heroku
- Increase `REQUEST_TIMEOUT_MS` in settings if needed

#### Pulse metrics not working (404 error)
**Solution:**
- Tableau Pulse requires Tableau Cloud or Server 2024.1+
- Verify Pulse is enabled on your instance
- Ensure user has access to Pulse metrics

#### "OPENAI_API_KEY not configured" or "Invalid API key"
**Solution:**
- Add OpenAI API key in profile settings (if using OpenAI provider)
- Verify key is valid and has sufficient credits
- Check OpenAI service status

#### AWS Bedrock authentication errors
**Solution:**
- Verify AWS SSO profile is configured: `aws configure sso`
- Login to AWS SSO: `aws sso login --profile your-profile`
- Check Claude model access is enabled in AWS Bedrock Console
- See [BEDROCK_SETUP.md](./documentation/BEDROCK_SETUP.md) for detailed troubleshooting

#### Cannot access prompt management
**Solution:**
- Ensure you're using a valid password
- Check browser console for JavaScript errors
- Contact administrator if access is needed

#### CSV parsing errors
**Solution:**
- Application uses RFC 4180 compliant csv-parse library
- Handles newlines in quoted fields correctly
- Supports Windows/Mac/Unix line endings
- Check data format and encoding if issues persist

---

## Security Best Practices

### 1. Store Credentials Securely
- Never commit secrets or API keys to version control
- Use Heroku Config Vars for sensitive environment variables
- Rotate tokens/secrets periodically
- Use strong, unique passwords for admin access

### 2. Monitor Token Usage
- Review Tableau audit logs regularly
- Check for unauthorized access attempts
- Set appropriate token expiration dates
- Monitor LLM API usage and costs (OpenAI, AWS Bedrock, etc.)

### 3. Restrict User Access
- Only grant access to users who need the extension
- Use Tableau's user management features
- Limit authentication scope to necessary permissions
- Use profile-based access control

### 4. Enable Logging
- Monitor Heroku logs for authentication failures
- Check for unusual activity patterns
- Set up log drains for long-term storage
- Review prompt management audit trail

### 5. Use HTTPS Only
- Always access via HTTPS
- Verify SSL certificates are valid
- Configure `ALLOWED_ORIGINS` to restrict CORS
- Never expose credentials in URLs

### 6. Admin Password Protection
- Two-tier system: admin (full access) and non-admin (limited)
- Admin users can delete prompt versions; non-admin cannot
- Change default passwords in production
- Store passwords securely (1Password, LastPass, etc.)

### 7. Prompt Management Security
- Password required to access `/prompts` interface
- All changes are versioned and auditable
- Deletion requires admin password confirmation
- Review prompt changes regularly for security issues

---

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                   TABLEAU DASHBOARD                          │
│  ┌────────────────────────────────────────────────────────┐ │
│  │         Tableau MCP Extension (.trex)                  │ │
│  │  URL: /ui/?profile=default&scope=dashboard             │ │
│  └───────────────────┬────────────────────────────────────┘ │
│                      │ Extensions API                       │
│                      ▼                                       │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  Frontend UI (index.html)                              │ │
│  │  • Detects URL parameters                              │ │
│  │  • Initializes Tableau Extensions API                  │ │
│  │  • Collects worksheet/datasource context              │ │
│  │  • Filters embedded datasources                        │ │
│  └───────────────────┬────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────┘
                       │ WebSocket
                       ▼
┌─────────────────────────────────────────────────────────────┐
│                  HEROKU APPLICATION                          │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  WebSocket Broker (broker.ts)                          │ │
│  │  • Receives AllowedScope context                       │ │
│  │  • Creates LLM session with system prompt              │ │
│  │  • Enforces scope-based access control                 │ │
│  │  • V3 State Machine orchestration                      │ │
│  └───────────────────┬────────────────────────────────────┘ │
│                      │                                       │
│  ┌───────────────────┴────────────────────────────────────┐ │
│  │  MCP Client (client.ts)                                │ │
│  │  • Connects to internal MCP server                     │ │
│  │  • Executes Tableau MCP tool calls                     │ │
│  └───────────────────┬────────────────────────────────────┘ │
│                      │                                       │
│  ┌───────────────────┴────────────────────────────────────┐ │
│  │  MCP Server (server.ts)                                │ │
│  │  • 15+ Tableau tools (list, query, search)             │ │
│  │  • Tableau REST API + VizQL Data Service               │ │
│  │  • PAT or Direct Trust authentication                   │ │
│  │  • RFC 4180 compliant CSV parsing                      │ │
│  └───────────────────┬────────────────────────────────────┘ │
│                      │                                       │
│  ┌───────────────────┴────────────────────────────────────┐ │
│  │  Prompt Manager (PromptManager.ts)                     │ │
│  │  • Dynamic prompt loading from PostgreSQL               │ │
│  │  • Version control and rollback                        │ │
│  │  • Variable interpolation                              │ │
│  │  • Admin-only deletion capability                      │ │
│  └───────────────────┬────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────┘
                       │ HTTPS + Auth
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              TABLEAU CLOUD / SERVER                          │
│  • Workbooks, Views, Datasources                            │
│  • Pulse Metrics (if enabled)                               │
│  • REST API + VizQL Data Service                            │
└─────────────────────────────────────────────────────────────┘
```

---

## Version History

### v379 (Current)
- Added password protection to prompts management UI
- Admin-only deletion of prompt versions
- Delete icon in Version History (admin access only)
- Enhanced security with two-tier password system

### v378
- Replaced custom CSV parser with csv-parse library
- RFC 4180 compliance for CSV parsing
- Fixed critical bug with newlines in quoted CSV fields
- Support for Windows/Mac/Unix line endings

### v377
- V3 State Machine becomes sole orchestration engine
- Removed legacy orchestration code (~2,200 lines)
- Simplified handleUserPrompt to wrapper function
- 32.5% code reduction in broker.ts

### v104+
- Dashboard embedding support
- URL parameter configuration
- Tableau Extensions API integration
- Dashboard-scoped mode

### Earlier Versions
- Multi-profile support
- Prompt management system
- Variable interpolation
- Direct Trust authentication

---

## Additional Resources

### Tableau Documentation
- [Personal Access Tokens](https://help.tableau.com/current/server/en-us/security_personal_access_tokens.htm)
- [Connected Apps (Direct Trust)](https://help.tableau.com/current/server/en-us/connected_apps_direct.htm)
- [REST API Documentation](https://help.tableau.com/current/api/rest_api/en-us/REST/rest_api.htm)
- [Tableau MCP Server (Official)](https://github.com/tableau/tableau-mcp)

### Heroku Documentation
- [Node.js Deployment](https://devcenter.heroku.com/articles/deploying-nodejs)
- [Heroku CLI Reference](https://devcenter.heroku.com/articles/heroku-cli)
- [Heroku Postgres](https://devcenter.heroku.com/articles/heroku-postgresql)

### LLM Provider Documentation
- [OpenAI API Documentation](https://platform.openai.com/docs/api-reference)
- [AWS Bedrock Setup Guide](./documentation/BEDROCK_SETUP.md) - Complete guide for AWS Bedrock configuration
- [AWS Bedrock Documentation](https://docs.aws.amazon.com/bedrock/)

---

## Support

For assistance with:

| Issue Type | Contact/Resource |
|------------|------------------|
| PAT setup | Your Tableau Administrator |
| Connected Apps | Your Tableau Administrator |
| MCP Extension | Check Heroku logs: `heroku logs --tail` |
| Deployment | Review Heroku documentation and build logs |
| LLM Provider | OpenAI: Verify API key / Bedrock: Check AWS credentials and model access |
| Prompt Management | Ensure admin password is correct |
| Database | Verify `DATABASE_URL` and Postgres addon status |

---

**Built with ❤️ for the Tableau community**
