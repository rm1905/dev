/**
 * LLM provider interface
 */

export interface Message {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string | null;
  name?: string;
  tool_call_id?: string;
  tool_calls?: Array<{
    id: string;
    type: 'function';
    function: {
      name: string;
      arguments: string;
    };
  }>;
}

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
}

export interface StreamChunk {
  type: 'delta' | 'tool_call' | 'reasoning' | 'done' | 'usage';
  content?: string;
  toolCall?: ToolCall;
  reasoning?: string;
  usage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
}

export interface ILlm {
  /**
   * Stream a completion with tool calling support
   * @param signal - Optional AbortSignal for cancelling in-flight requests (v298)
   */
  streamCompletion(
    messages: Message[],
    tools: Array<{
      name: string;
      description: string;
      parameters: Record<string, unknown>;
    }>,
    onChunk: (chunk: StreamChunk) => void | Promise<void>,
    temperature?: number,
    signal?: AbortSignal
  ): Promise<void>;
}
