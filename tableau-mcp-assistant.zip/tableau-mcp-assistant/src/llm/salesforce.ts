/**
 * Salesforce LLM Gateway provider implementation
 */

import { ILlm, Message, StreamChunk } from './ILlm.js';
import { logger } from '../util/logger.js';

export class SalesforceLlm implements ILlm {
  private sfLocation: string;
  private apiKey: string;
  private coreTenantId: string;
  private model: string;
  private temperature: number;

  constructor(
    sfLocation: string,
    apiKey: string,
    coreTenantId: string,
    model: string,
    temperature: number = 0.7
  ) {
    // Sanitize SF_LOCATION - remove trailing /generations if present
    this.sfLocation = sfLocation.replace(/\/(chat\/)?generations(\/stream)?$/, '');
    this.apiKey = apiKey;
    this.coreTenantId = coreTenantId;
    this.model = model;
    this.temperature = temperature;
    logger.info(`Initialized Salesforce LLM with model: ${model} at ${this.sfLocation}`);
  }

  /**
   * Stream a completion with tool calling support
   * Note: Tool execution is orchestrated by the MCP host (our app), not by the LLM Gateway's built-in tool mechanism
   * @param signal - Optional AbortSignal for cancelling in-flight requests (v298)
   */
  async streamCompletion(
    messages: Message[],
    tools: Array<{
      name: string;
      description: string;
      parameters: Record<string, unknown>;
    }>,
    onChunk: (chunk: StreamChunk) => void | Promise<void>,
    temperature?: number,
    signal?: AbortSignal
  ): Promise<void> {
    const effectiveTemperature = temperature ?? this.temperature;
    logger.debug(`Streaming Salesforce completion with ${messages.length} messages, ${tools.length} tools, temperature: ${effectiveTemperature}`);

    // Convert ILlm messages to Salesforce chat messages format
    const chatMessages = this.convertMessagesToSalesforceFormat(messages);

    try {
      // Use /chat/generations/stream for streaming chat responses
      const streamUrl = `${this.sfLocation}/chat/generations/stream`;

      // Build request body with tools support
      const requestBody: any = {
        messages: chatMessages,
        model: this.model,
        generation_settings: {
          temperature: effectiveTemperature,
          max_tokens: 4096,
        },
      };

      // Add tools in Salesforce format if provided
      if (tools.length > 0) {
        requestBody.tools = tools.map(tool => ({
          function: {
            name: tool.name,
            description: tool.description,
            parameters: tool.parameters,
          },
        }));

        // Enable tool calling with auto mode
        requestBody.tool_config = {
          mode: 'auto',
          allowed_tools: ['function'],
          parallel_calls: true,
        };

        // Enable reasoning for better tool orchestration
        requestBody.reasoning_settings = {
          return_reasoning: true,
          reasoning_budget: { effort: 'medium' },
        };
      }

      // v298: Support physical cancellation via AbortSignal
      const response = await fetch(streamUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `API_KEY ${this.apiKey}`,
          'x-client-feature-id': 'EinsteinDocsAnswers',
          'x-sfdc-app-context': 'EinsteinGPT',
          'x-sfdc-core-tenant-id': this.coreTenantId,
        },
        body: JSON.stringify(requestBody),
        signal,
      });

      if (!response.ok) {
        await this.handleError(response);
        return;
      }

      // Process streaming response (SSE-like format)
      await this.processStreamingResponse(response, onChunk);

    } catch (error) {
      logger.error('Salesforce streaming completion error:', error);
      throw error;
    }
  }

  /**
   * Convert ILlm messages to Salesforce chat messages format
   * Preserves tool invocations structure for native Salesforce tool calling
   */
  private convertMessagesToSalesforceFormat(
    messages: Message[]
  ): Array<any> {
    const sfMessages: Array<any> = [];

    // Process each message
    for (const msg of messages) {
      if (msg.role === 'system') {
        sfMessages.push({
          role: 'system',
          content: msg.content || '',
        });
      } else if (msg.role === 'user') {
        sfMessages.push({
          role: 'user',
          content: msg.content || '',
        });
      } else if (msg.role === 'assistant') {
        // Handle assistant messages with tool calls
        // Convert OpenAI format (tool_calls) to Salesforce format (tool_invocations)
        const sfMsg: any = {
          role: 'assistant',
          content: msg.content || null,
        };

        if (msg.tool_calls && msg.tool_calls.length > 0) {
          // Convert OpenAI tool_calls to Salesforce tool_invocations format
          sfMsg.tool_invocations = msg.tool_calls.map(tc => ({
            id: tc.id,
            function: {
              name: tc.function.name,
              arguments: tc.function.arguments,
            },
          }));
        }

        sfMessages.push(sfMsg);
      } else if (msg.role === 'tool') {
        // Tool results in Salesforce format
        sfMessages.push({
          role: 'tool',
          tool_call_id: msg.tool_call_id,
          name: msg.name,
          content: msg.content || '',
        });
      }
    }

    return sfMessages;
  }

  /**
   * Process streaming response from Salesforce LLM Gateway
   * Format: SSE-like with data: {...} lines
   */
  private async processStreamingResponse(
    response: Response,
    onChunk: (chunk: StreamChunk) => void | Promise<void>
  ): Promise<void> {
    const reader = response.body?.getReader();
    if (!reader) {
      throw new Error('No response body reader available');
    }

    const decoder = new TextDecoder();
    let buffer = '';

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        // Decode chunk and add to buffer
        buffer += decoder.decode(value, { stream: true });

        // Process complete lines
        const lines = buffer.split('\n');
        buffer = lines.pop() || ''; // Keep incomplete line in buffer

        for (const line of lines) {
          if (!line.trim()) continue;

          // Handle SSE data: lines
          const dataMatch = line.match(/^data:\s*(.+)$/);
          if (dataMatch) {
            try {
              const data = JSON.parse(dataMatch[1]);
              await this.processGenerationData(data, onChunk);
            } catch (parseError) {
              logger.warn('Failed to parse streaming chunk:', line, parseError);
            }
          } else {
            // Try parsing as raw JSON (NDJSON format)
            try {
              const data = JSON.parse(line);
              await this.processGenerationData(data, onChunk);
            } catch (parseError) {
              // Not JSON, skip
            }
          }
        }
      }

      // Signal completion
      await onChunk({ type: 'done' });

    } finally {
      reader.releaseLock();
    }
  }

  /**
   * Process generation data from Salesforce response
   * Handles text content, tool invocations, reasoning, and token usage
   */
  private async processGenerationData(
    data: any,
    onChunk: (chunk: StreamChunk) => void | Promise<void>
  ): Promise<void> {
    const generation = data.generations?.[0];
    if (!generation) return;

    // Extract reasoning if present
    const reasoning = generation.reasoning;
    if (reasoning) {
      await onChunk({
        type: 'reasoning',
        reasoning,
      });
    }

    // Extract text content
    const text = generation.text;
    if (text) {
      await onChunk({
        type: 'delta',
        content: text,
      });
    }

    // Extract tool invocations if present
    const toolInvocations = generation.tool_invocations;
    if (toolInvocations && Array.isArray(toolInvocations)) {
      for (const invocation of toolInvocations) {
        try {
          // Parse arguments string to JSON
          const args = typeof invocation.function.arguments === 'string'
            ? JSON.parse(invocation.function.arguments)
            : invocation.function.arguments;

          await onChunk({
            type: 'tool_call',
            toolCall: {
              id: invocation.id,
              name: invocation.function.name,
              arguments: args,
            },
          });
        } catch (error) {
          logger.error(`Failed to parse tool invocation: ${JSON.stringify(invocation)}`, error);
        }
      }
    }

    // v365: Extract token usage if present in Salesforce response
    // Check both top-level and generation-level usage
    const usage = data.usage || generation.usage;
    if (usage && (usage.prompt_tokens || usage.completion_tokens || usage.total_tokens)) {
      const promptTokens = usage.prompt_tokens || usage.input_tokens || 0;
      const completionTokens = usage.completion_tokens || usage.output_tokens || 0;
      const totalTokens = usage.total_tokens || (promptTokens + completionTokens);

      logger.debug(`[v365 SF_TOKEN_USAGE] prompt=${promptTokens}, completion=${completionTokens}, total=${totalTokens}`);
      await onChunk({
        type: 'usage',
        usage: {
          promptTokens,
          completionTokens,
          totalTokens,
        },
      });
    }
  }

  /**
   * Perform health check to validate Salesforce configuration
   * Uses /generations endpoint with simple prompt
   */
  async healthCheck(): Promise<{ success: boolean; error?: string }> {
    try {
      logger.info('Performing Salesforce LLM health check...');

      // Early validation
      if (!this.sfLocation || this.sfLocation.trim() === '') {
        return {
          success: false,
          error: 'SF_LOCATION is not set. Please configure it in profile settings.',
        };
      }

      if (!this.apiKey || this.apiKey.trim() === '') {
        return {
          success: false,
          error: 'SF_API_KEY is not set. Please configure it in profile settings.',
        };
      }

      if (!this.coreTenantId || this.coreTenantId.trim() === '') {
        return {
          success: false,
          error: 'SF_CORE_TENANT_ID is not set. Please configure it in profile settings.',
        };
      }

      logger.info(`SF_LOCATION: ${this.sfLocation}`);
      logger.info(`SF_CORE_TENANT_ID: ${this.coreTenantId ? '[SET]' : '[NOT SET]'}`);
      logger.info(`SF_API_KEY: ${this.apiKey ? '[SET]' : '[NOT SET]'}`);
      logger.info(`Model: ${this.model}`);

      // Validate SF_LOCATION is a valid URL
      try {
        const urlTest = new URL(this.sfLocation);
        if (!urlTest.protocol.startsWith('http')) {
          return {
            success: false,
            error: `Invalid SF_LOCATION protocol: ${urlTest.protocol}. Must be http:// or https://`,
          };
        }
      } catch (urlError) {
        return {
          success: false,
          error: `Invalid SF_LOCATION format: ${this.sfLocation}. Must be a valid URL (e.g., https://api.salesforce.com/llmgateway/v1)`,
        };
      }

      const healthUrl = `${this.sfLocation}/generations`;
      logger.info(`Health check URL: ${healthUrl}`);

      // Add timeout to prevent hanging
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout

      const response = await fetch(healthUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `API_KEY ${this.apiKey}`,
          'x-client-feature-id': 'EinsteinDocsAnswers',
          'x-sfdc-app-context': 'EinsteinGPT',
          'x-sfdc-core-tenant-id': this.coreTenantId,
        },
        body: JSON.stringify({
          model: this.model,
          temperature: 0.0,
          max_tokens: 16,
          prompt: 'Health check – reply OK.',
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({})) as any;
        const errorMessage = errorData.message || errorData.error || response.statusText;

        logger.error(`Salesforce health check failed: HTTP ${response.status} - ${errorMessage}`);

        return {
          success: false,
          error: `HTTP ${response.status}: ${this.formatErrorMessage(response.status, errorMessage)}`,
        };
      }

      const data = await response.json() as any;
      const hasText = !!data.generations?.[0]?.text;

      if (!hasText) {
        logger.error('Salesforce health check failed: No text in response');
        return {
          success: false,
          error: 'Invalid response format from Salesforce API',
        };
      }

      logger.info('✅ Salesforce health check passed');
      return { success: true };

    } catch (error) {
      // Enhanced error logging for debugging
      if (error instanceof Error) {
        logger.error(`Salesforce health check error: ${error.message}`);
        logger.error(`Error details: ${JSON.stringify({
          name: error.name,
          message: error.message,
          stack: error.stack?.split('\n')[0],
        })}`);

        // Provide more specific error messages
        if (error.name === 'AbortError') {
          return {
            success: false,
            error: `Connection timeout (10s) to Salesforce LLM Gateway. Please check network connectivity and SF_LOCATION: ${this.sfLocation}`,
          };
        } else if (error.message.includes('ENOTFOUND')) {
          return {
            success: false,
            error: `Cannot resolve Salesforce LLM Gateway hostname. Please verify SF_LOCATION: ${this.sfLocation}`,
          };
        } else if (error.message.includes('ECONNREFUSED')) {
          return {
            success: false,
            error: `Connection refused by Salesforce LLM Gateway. Please verify SF_LOCATION and network access.`,
          };
        } else if (error.message.includes('ETIMEDOUT') || error.message.includes('timeout')) {
          return {
            success: false,
            error: `Connection timeout to Salesforce LLM Gateway. Please check network connectivity and SF_LOCATION.`,
          };
        } else if (error.message.includes('certificate') || error.message.includes('SSL') || error.message.includes('TLS')) {
          return {
            success: false,
            error: `SSL/TLS certificate error. Please verify the Salesforce LLM Gateway certificate or contact your administrator.`,
          };
        }

        return {
          success: false,
          error: `Connection failed: ${error.message}. Please verify SF_LOCATION, SF_API_KEY, and SF_CORE_TENANT_ID.`,
        };
      }

      logger.error('Salesforce health check error (unknown):', error);
      return {
        success: false,
        error: 'Unknown connection error. Please verify your Salesforce configuration.',
      };
    }
  }

  /**
   * Handle HTTP errors from Salesforce API
   */
  private async handleError(response: Response): Promise<void> {
    const errorData = await response.json().catch(() => ({})) as any;
    const errorMessage = errorData.message || errorData.error || response.statusText;

    logger.error(`Salesforce API error: HTTP ${response.status} - ${errorMessage}`);

    throw new Error(`Salesforce LLM error (${response.status}): ${this.formatErrorMessage(response.status, errorMessage)}`);
  }

  /**
   * Format error messages with user-friendly guidance
   */
  private formatErrorMessage(status: number, message: string): string {
    switch (status) {
      case 400:
        return `Bad request - ${message}. Please check your model name and request parameters.`;
      case 401:
        return `Invalid API key - ${message}. Please verify your SF_API_KEY.`;
      case 403:
        return `Permission denied - ${message}. Please check your API key permissions and tenant ID.`;
      case 423:
        return `Server busy - ${message}. Please wait a moment and try again.`;
      case 429:
        return `Rate limit exceeded - ${message}. Please wait and try again later.`;
      case 500:
      case 503:
        return `Server error - ${message}. This is a temporary issue with the Salesforce API.`;
      default:
        return message;
    }
  }
}
