/**
 * LLM Factory - Creates appropriate LLM client based on provider configuration
 */

import { ILlm } from './ILlm.js';
import { OpenAiLlm } from './openai.js';
import { BedrockLlm } from './bedrock.js';
import { Settings } from '../util/schema.js';
import { logger } from '../util/logger.js';

/**
 * Create an LLM client based on the provider configuration in settings
 * @param settings - Profile settings containing LLM provider configuration
 * @param model - Model to use (overrides profile default if specified)
 * @param temperature - Temperature for generation (default: 0.7)
 * @returns ILlm instance (supports OpenAI, Local LLMs, AWS Bedrock)
 */
export function createLlm(
  settings: Settings,
  model?: string,
  temperature: number = 0.7
): ILlm {
  const provider = settings.LLM_PROVIDER || 'openai';

  logger.info(`Creating LLM client for provider: ${provider}`);

  if (provider === 'openai') {
    return createOpenAiLlm(settings, model, temperature);
  }

  if (provider === 'local') {
    return createLocalLlm(settings, model, temperature);
  }

  if (provider === 'bedrock') {
    return createBedrockLlm(settings, model, temperature);
  }

  // Future: Add support for other providers here
  // if (provider === 'anthropic') {
  //   return createAnthropicLlm(settings, model, temperature);
  // }

  throw new Error(`Unknown LLM provider: ${provider}`);
}

/**
 * Create OpenAI LLM client
 */
function createOpenAiLlm(
  settings: Settings,
  model?: string,
  temperature: number = 0.7
): OpenAiLlm {
  // Validate required fields
  if (!settings.OPENAI_API_KEY) {
    throw new Error('OPENAI_API_KEY is required for OpenAI provider');
  }

  // Determine model: use provided model, or profile default, or legacy DEFAULT_MODEL
  const effectiveModel = model || settings.OPENAI_DEFAULT_MODEL || settings.DEFAULT_MODEL || 'gpt-4o-mini';

  logger.info(`Creating OpenAI LLM with model: ${effectiveModel}`);

  return new OpenAiLlm(
    settings.OPENAI_API_KEY,
    effectiveModel,
    temperature
  );
}

/**
 * Create Local LLM client (Ollama, LM Studio, LocalAI, etc.)
 * Uses OpenAI-compatible API
 */
function createLocalLlm(
  settings: Settings,
  model?: string,
  temperature: number = 0.7
): OpenAiLlm {
  // Validate required fields
  if (!settings.LOCAL_BASE_URL) {
    throw new Error('LOCAL_BASE_URL is required for Local LLM provider (e.g., http://localhost:11434/v1)');
  }
  if (!settings.LOCAL_MODEL) {
    throw new Error('LOCAL_MODEL is required for Local LLM provider (e.g., llama3.1:8b)');
  }

  const effectiveModel = model || settings.LOCAL_MODEL;

  logger.info(`Creating Local LLM at ${settings.LOCAL_BASE_URL} with model: ${effectiveModel}`);

  // Use API key if provided, otherwise use a placeholder (many local servers don't validate it)
  const apiKey = settings.LOCAL_API_KEY || 'local-llm-no-key-needed';

  // Pass baseURL as parameter instead of setting global environment variable
  return new OpenAiLlm(
    apiKey,
    effectiveModel,
    temperature,
    settings.LOCAL_BASE_URL  // Pass baseURL directly
  );
}

/**
 * Create AWS Bedrock LLM client
 */
function createBedrockLlm(
  settings: Settings,
  model?: string,
  temperature: number = 0.7
): BedrockLlm {
  // Validate required fields
  if (!settings.BEDROCK_REGION) {
    throw new Error('BEDROCK_REGION is required for Bedrock provider (e.g., us-east-1)');
  }
  if (!settings.BEDROCK_MODEL_ID) {
    throw new Error('BEDROCK_MODEL_ID is required for Bedrock provider (e.g., anthropic.claude-3-5-sonnet-20241022-v2:0)');
  }

  const effectiveModel = model || settings.BEDROCK_MODEL_ID;

  logger.info(`Creating AWS Bedrock LLM in region ${settings.BEDROCK_REGION} with model: ${effectiveModel}`);

  return new BedrockLlm(
    settings.BEDROCK_REGION,
    effectiveModel,
    temperature,
    settings.BEDROCK_ACCESS_KEY_ID,
    settings.BEDROCK_SECRET_ACCESS_KEY,
    settings.BEDROCK_PROFILE
  );
}

/**
 * Get the default model for a provider from settings
 */
export function getDefaultModel(settings: Settings): string {
  const provider = settings.LLM_PROVIDER || 'openai';

  if (provider === 'openai') {
    return settings.OPENAI_DEFAULT_MODEL || settings.DEFAULT_MODEL || 'gpt-4o-mini';
  }

  if (provider === 'local') {
    return settings.LOCAL_MODEL || 'llama3.1:8b';
  }

  if (provider === 'bedrock') {
    return settings.BEDROCK_MODEL_ID || 'us.anthropic.claude-sonnet-4-6';
  }

  // Future: Add support for other providers here

  return 'gpt-4o-mini';
}
