/**
 * OpenAI LLM provider implementation
 */

import OpenAI from 'openai';
import { ILlm, Message, StreamChunk, ToolCall } from './ILlm.js';
import { logger } from '../util/logger.js';

export class OpenAiLlm implements ILlm {
  private client: OpenAI;
  private model: string;
  private temperature: number;

  constructor(apiKey: string, model: string = 'gpt-4o-mini', temperature: number = 0.7, baseURL?: string) {
    // Support custom base URL for local LLMs (Ollama, LM Studio, LocalAI, etc.)
    this.client = new OpenAI({
      apiKey,
      baseURL: baseURL || undefined,  // Use default OpenAI URL if not specified
    });

    this.model = model;
    this.temperature = temperature;

    if (baseURL) {
      logger.info(`Initialized OpenAI-compatible LLM at ${baseURL} with model: ${model}`);
    } else {
      logger.info(`Initialized OpenAI LLM with model: ${model}`);
    }
  }

  async streamCompletion(
    messages: Message[],
    tools: Array<{
      name: string;
      description: string;
      parameters: Record<string, unknown>;
    }>,
    onChunk: (chunk: StreamChunk) => void | Promise<void>,
    temperature?: number,
    signal?: AbortSignal
  ): Promise<void> {
    const effectiveTemperature = temperature ?? this.temperature;
    logger.debug(`Streaming completion with ${messages.length} messages, ${tools.length} tools, and temperature: ${effectiveTemperature}`);

    // Convert messages to OpenAI format
    const openaiMessages = messages.map((msg) => {
      if (msg.role === 'tool') {
        return {
          role: 'tool' as const,
          content: msg.content || '',
          tool_call_id: msg.tool_call_id!,
        };
      }
      if (msg.role === 'assistant' && msg.tool_calls) {
        return {
          role: 'assistant' as const,
          content: msg.content,
          tool_calls: msg.tool_calls,
        };
      }
      return {
        role: msg.role as 'system' | 'user' | 'assistant',
        content: msg.content || '',
      };
    });

    // Convert tools to OpenAI format
    const openaiTools = tools.map((tool) => ({
      type: 'function' as const,
      function: {
        name: tool.name,
        description: tool.description,
        parameters: tool.parameters,
      },
    }));

    try {
      // v298: Support physical cancellation via AbortSignal
      // v301: Enable actual token usage reporting
      const stream = await this.client.chat.completions.create({
        model: this.model,
        messages: openaiMessages,
        tools: openaiTools.length > 0 ? openaiTools : undefined,
        tool_choice: openaiTools.length > 0 ? 'auto' : undefined,
        temperature: effectiveTemperature,
        stream: true,
        stream_options: { include_usage: true }, // v301: Get actual token counts
      }, signal ? { signal } : undefined);

      let currentToolCall: Partial<ToolCall> | null = null;
      let toolCallArgs = '';

      for await (const chunk of stream) {
        const delta = chunk.choices[0]?.delta;

        if (!delta) continue;

        // Handle reasoning content (for models that support it like o1)
        // @ts-ignore - reasoning_content is not in the official types yet
        if (delta.reasoning_content) {
          // @ts-ignore
          const reasoningText = delta.reasoning_content;
          logger.info(`[REASONING] ${reasoningText}`);
          await onChunk({
            type: 'reasoning',
            reasoning: reasoningText,
          });
        }

        // Handle content delta
        if (delta.content) {
          await onChunk({
            type: 'delta',
            content: delta.content,
          });
        }

        // Handle tool calls
        if (delta.tool_calls && delta.tool_calls.length > 0) {
          const toolCallDelta = delta.tool_calls[0];

          // Start new tool call
          if (toolCallDelta.id) {
            // If we were building a previous tool call, emit it first
            if (currentToolCall && currentToolCall.id && currentToolCall.name) {
              let parsedArgs: Record<string, unknown> = {};
              try {
                parsedArgs = JSON.parse(toolCallArgs || '{}');
              } catch (error) {
                logger.warn(`Failed to parse tool call arguments as JSON: ${toolCallArgs}`, error);
                // Attempt to use as plain text if JSON parsing fails
                parsedArgs = { text: toolCallArgs };
              }

              await onChunk({
                type: 'tool_call',
                toolCall: {
                  id: currentToolCall.id,
                  name: currentToolCall.name,
                  arguments: parsedArgs,
                },
              });
            }

            // Start new tool call
            currentToolCall = {
              id: toolCallDelta.id,
              name: toolCallDelta.function?.name || '',
            };
            toolCallArgs = '';
          } else {
            // Accumulate function name (only if not starting a new tool call)
            if (toolCallDelta.function?.name && currentToolCall) {
              currentToolCall.name = (currentToolCall.name || '') + toolCallDelta.function.name;
            }
          }

          // Accumulate arguments
          if (toolCallDelta.function?.arguments) {
            toolCallArgs += toolCallDelta.function.arguments;
          }
        }

        // Check if stream is done
        if (chunk.choices[0]?.finish_reason) {
          // Emit final tool call if present
          if (currentToolCall && currentToolCall.id && currentToolCall.name) {
            let parsedArgs: Record<string, unknown> = {};
            try {
              parsedArgs = JSON.parse(toolCallArgs || '{}');
            } catch (error) {
              logger.warn(`Failed to parse tool call arguments as JSON: ${toolCallArgs}`, error);
              // Attempt to use as plain text if JSON parsing fails
              parsedArgs = { text: toolCallArgs };
            }

            await onChunk({
              type: 'tool_call',
              toolCall: {
                id: currentToolCall.id,
                name: currentToolCall.name,
                arguments: parsedArgs,
              },
            });
          }
        }

        // v301: Extract actual token usage from final chunk
        if (chunk.usage) {
          logger.debug(`[v301 TOKEN_USAGE] prompt=${chunk.usage.prompt_tokens}, completion=${chunk.usage.completion_tokens}, total=${chunk.usage.total_tokens}`);
          await onChunk({
            type: 'usage',
            usage: {
              promptTokens: chunk.usage.prompt_tokens,
              completionTokens: chunk.usage.completion_tokens,
              totalTokens: chunk.usage.total_tokens,
            },
          });
        }
      }

      // Stream done
      await onChunk({ type: 'done' });

      logger.debug('Streaming completion finished');
    } catch (error) {
      logger.error('OpenAI streaming error', error);
      throw new Error(`OpenAI streaming failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
}
