/**
 * AWS Bedrock LLM provider implementation
 */

import {
  BedrockRuntimeClient,
  ConverseStreamCommand,
  ConverseStreamCommandInput,
  ContentBlock,
  Message as BedrockMessage,
  Tool as BedrockTool,
  ToolConfiguration,
  SystemContentBlock,
} from '@aws-sdk/client-bedrock-runtime';
import { fromIni } from '@aws-sdk/credential-providers';
import { ILlm, Message, StreamChunk, ToolCall } from './ILlm.js';
import { logger } from '../util/logger.js';

export class BedrockLlm implements ILlm {
  private client: BedrockRuntimeClient;
  private modelId: string;
  private temperature: number;

  constructor(
    region: string = 'us-east-1',
    modelId: string = 'us.anthropic.claude-sonnet-4-6',
    temperature: number = 0.7,
    accessKeyId?: string,
    secretAccessKey?: string,
    profileName?: string
  ) {
    // Initialize Bedrock client with appropriate credential provider
    // Priority: explicit credentials > profile name > default credential chain
    let credentials;
    let credentialSource = 'default credential chain';

    if (accessKeyId && secretAccessKey) {
      // Explicit credentials provided
      credentials = { accessKeyId, secretAccessKey };
      credentialSource = 'explicit credentials';
    } else if (profileName) {
      // Use named profile (including SSO profiles)
      credentials = fromIni({ profile: profileName });
      credentialSource = `profile "${profileName}"`;
    }
    // Otherwise use default credential chain (no credentials parameter)

    this.client = new BedrockRuntimeClient({
      region,
      ...(credentials && { credentials }),
    });

    this.modelId = modelId;
    this.temperature = temperature;

    logger.info(`Initialized AWS Bedrock LLM in region ${region} with model: ${modelId} (using ${credentialSource})`);
  }

  async streamCompletion(
    messages: Message[],
    tools: Array<{
      name: string;
      description: string;
      parameters: Record<string, unknown>;
    }>,
    onChunk: (chunk: StreamChunk) => void | Promise<void>,
    temperature?: number,
    signal?: AbortSignal
  ): Promise<void> {
    const effectiveTemperature = temperature ?? this.temperature;
    logger.debug(
      `Streaming Bedrock completion with ${messages.length} messages, ${tools.length} tools, and temperature: ${effectiveTemperature}`
    );

    try {
      // Convert messages to Bedrock format
      const { bedrockMessages, systemPrompts } = this.convertMessages(messages);

      // DEBUG: Log message structure before sending to Bedrock
      logger.info('[BEDROCK DEBUG] Converting messages to Bedrock format', {
        totalMessages: messages.length,
        messageRoles: messages.map(m => m.role),
        messageDetails: messages.map((m, i) => ({
          index: i,
          role: m.role,
          hasContent: !!m.content,
          hasToolCalls: !!(m as any).tool_calls,
          toolCallId: (m as any).tool_call_id,
          toolCallsCount: (m as any).tool_calls?.length,
        })),
        bedrockMessagesCount: bedrockMessages.length,
      });

      // Convert tools to Bedrock format
      const toolConfig = this.convertTools(tools);

      // Build converse stream input
      const input: ConverseStreamCommandInput = {
        modelId: this.modelId,
        messages: bedrockMessages,
        ...(systemPrompts.length > 0 && { system: systemPrompts }),
        ...(toolConfig && { toolConfig }),
        inferenceConfig: {
          temperature: effectiveTemperature,
          maxTokens: 4096,
        },
      };

      const command = new ConverseStreamCommand(input);
      const response = await this.client.send(command, { abortSignal: signal });

      if (!response.stream) {
        throw new Error('No stream returned from Bedrock');
      }

      let currentToolCall: Partial<ToolCall> | null = null;
      let toolCallArgs = '';
      let totalInputTokens = 0;
      let totalOutputTokens = 0;

      // Process stream
      for await (const event of response.stream) {
        // Handle content deltas (text)
        if (event.contentBlockDelta?.delta?.text) {
          await onChunk({
            type: 'delta',
            content: event.contentBlockDelta.delta.text,
          });
        }

        // Handle tool use start
        if (event.contentBlockStart?.start?.toolUse) {
          const toolUse = event.contentBlockStart.start.toolUse;
          currentToolCall = {
            id: toolUse.toolUseId || `tool_${Date.now()}`,
            name: toolUse.name || '',
          };
          toolCallArgs = '';
        }

        // Handle tool use delta (accumulate input JSON)
        if (event.contentBlockDelta?.delta?.toolUse?.input) {
          toolCallArgs += event.contentBlockDelta.delta.toolUse.input;
        }

        // Handle tool use stop (emit complete tool call)
        if (event.contentBlockStop && currentToolCall && currentToolCall.id && currentToolCall.name) {
          let parsedArgs: Record<string, unknown> = {};
          try {
            parsedArgs = JSON.parse(toolCallArgs || '{}');
          } catch (error) {
            logger.warn(`Failed to parse Bedrock tool arguments: ${toolCallArgs}`, error);
            parsedArgs = { text: toolCallArgs };
          }

          await onChunk({
            type: 'tool_call',
            toolCall: {
              id: currentToolCall.id,
              name: currentToolCall.name,
              arguments: parsedArgs,
            },
          });

          currentToolCall = null;
          toolCallArgs = '';
        }

        // Handle usage metadata
        if (event.metadata?.usage) {
          totalInputTokens = event.metadata.usage.inputTokens || 0;
          totalOutputTokens = event.metadata.usage.outputTokens || 0;

          logger.debug(
            `[BEDROCK TOKEN_USAGE] input=${totalInputTokens}, output=${totalOutputTokens}, total=${totalInputTokens + totalOutputTokens}`
          );

          await onChunk({
            type: 'usage',
            usage: {
              promptTokens: totalInputTokens,
              completionTokens: totalOutputTokens,
              totalTokens: totalInputTokens + totalOutputTokens,
            },
          });
        }
      }

      // Stream done
      await onChunk({ type: 'done' });

      logger.debug('Bedrock streaming completion finished');
    } catch (error) {
      logger.error('Bedrock streaming error', error);
      throw new Error(
        `Bedrock streaming failed: ${error instanceof Error ? error.message : String(error)}`
      );
    }
  }

  /**
   * Convert internal messages to Bedrock format
   * Extracts system prompts and formats user/assistant/tool messages
   */
  private convertMessages(messages: Message[]): {
    bedrockMessages: BedrockMessage[];
    systemPrompts: SystemContentBlock[];
  } {
    const systemPrompts: SystemContentBlock[] = [];
    const bedrockMessages: BedrockMessage[] = [];

    let i = 0;
    while (i < messages.length) {
      const msg = messages[i];

      if (msg.role === 'system') {
        // Bedrock uses separate system field
        systemPrompts.push({ text: msg.content || '' } as SystemContentBlock);
        i++;
      } else if (msg.role === 'tool') {
        // Tool result message - combine consecutive tool results into single user message
        const toolResults: ContentBlock[] = [];

        while (i < messages.length && messages[i].role === 'tool') {
          const toolMsg = messages[i];
          toolResults.push({
            toolResult: {
              toolUseId: toolMsg.tool_call_id || '',
              content: [{ text: toolMsg.content || '' }],
            },
          });
          i++;
        }

        // Add all tool results as a single user message
        bedrockMessages.push({
          role: 'user',
          content: toolResults,
        });
      } else if (msg.role === 'assistant' && msg.tool_calls && msg.tool_calls.length > 0) {
        // Assistant message with tool calls
        const content: ContentBlock[] = [];

        // Add text content if present
        if (msg.content) {
          content.push({ text: msg.content });
        }

        // Add tool use blocks
        for (const toolCall of msg.tool_calls) {
          content.push({
            toolUse: {
              toolUseId: toolCall.id,
              name: toolCall.function.name,
              input: JSON.parse(toolCall.function.arguments),
            },
          });
        }

        bedrockMessages.push({
          role: 'assistant',
          content,
        });
        i++;
      } else {
        // Regular user or assistant message
        bedrockMessages.push({
          role: msg.role === 'assistant' ? 'assistant' : 'user',
          content: [{ text: msg.content || '' }],
        });
        i++;
      }
    }

    return { bedrockMessages, systemPrompts };
  }

  /**
   * Convert tools to Bedrock format
   */
  private convertTools(
    tools: Array<{
      name: string;
      description: string;
      parameters: Record<string, unknown>;
    }>
  ): ToolConfiguration | undefined {
    if (tools.length === 0) {
      return undefined;
    }

    const bedrockTools: BedrockTool[] = tools.map((tool) => ({
      toolSpec: {
        name: tool.name,
        description: tool.description,
        inputSchema: {
          json: tool.parameters,
        },
      },
    } as BedrockTool));

    return { tools: bedrockTools };
  }
}
