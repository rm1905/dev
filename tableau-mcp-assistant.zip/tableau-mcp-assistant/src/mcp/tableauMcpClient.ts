/**
 * MCP Client to connect to official Tableau MCP Server
 * Uses PAT (Personal Access Token) authentication
 */

import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';
import {
  ListToolsResultSchema,
  CallToolResultSchema,
} from '@modelcontextprotocol/sdk/types.js';
import { logger } from '../util/logger.js';
import { config } from '../util/env.js';
import { TableauValidator } from '../util/tableauValidator.js';

export class TableauMcpClient {
  private client: Client | null = null;
  private transport: StdioClientTransport | null = null;
  private connected = false;
  private profileName?: string;
  private datasourceIds?: string[];
  private workbookId?: string;
  private jwtSubClaimOverride?: string; // Override JWT sub claim for Direct Trust auth
  private connectionAttempts = 0;
  private maxRetries = 3;
  private retryDelay = 1000; // Start with 1 second
  private logHandler?: (logLine: string) => void; // Callback for MCP server logs

  constructor(profileName?: string, datasourceIds?: string[], workbookId?: string, jwtSubClaimOverride?: string) {
    this.profileName = profileName;
    this.datasourceIds = datasourceIds;
    this.workbookId = workbookId;
    this.jwtSubClaimOverride = jwtSubClaimOverride;
  }

  /**
   * Set log handler for MCP server logs (stderr)
   */
  setLogHandler(handler: (logLine: string) => void): void {
    this.logHandler = handler;
  }

  /**
   * Connect to PAT-authenticated MCP server with retry logic
   */
  async connect(): Promise<void> {
    if (this.connected) {
      logger.info(`MCP client already connected (profile: ${this.profileName || 'default'})`);
      return;
    }

    while (this.connectionAttempts < this.maxRetries) {
      try {
        await this.attemptConnection();
        this.connectionAttempts = 0; // Reset on success
        return;
      } catch (error) {
        this.connectionAttempts++;
        const errorMessage = error instanceof Error ? error.message : String(error);

        logger.warn(`Connection attempt ${this.connectionAttempts}/${this.maxRetries} failed (profile: ${this.profileName || 'default'}): ${errorMessage}`);

        if (this.connectionAttempts >= this.maxRetries) {
          logger.error(`Failed to connect after ${this.maxRetries} attempts (profile: ${this.profileName || 'default'})`);
          await this.cleanup();
          throw new Error(`Failed to connect to Tableau MCP server after ${this.maxRetries} attempts: ${errorMessage}`);
        }

        // Exponential backoff
        const delay = this.retryDelay * Math.pow(2, this.connectionAttempts - 1);
        logger.info(`Retrying connection in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }

  /**
   * Attempt a single connection
   */
  private async attemptConnection(): Promise<void> {
    try {
      const settings = await config.getSettings(this.profileName);

      // Validate configuration before attempting connection
      logger.info(`Validating Tableau configuration before connecting (profile: ${this.profileName || 'default'})...`);
      const validationResult = await TableauValidator.validateConfiguration(settings, this.profileName);

      if (!validationResult.valid) {
        const errorMessage = TableauValidator.formatValidationErrors(validationResult, this.profileName);
        logger.error(errorMessage);
        throw new Error(`Tableau configuration validation failed:\n${validationResult.errors.join('\n')}`);
      }

      // Log any warnings but proceed
      if (validationResult.warnings.length > 0) {
        logger.warn(`Configuration validation passed with ${validationResult.warnings.length} warning(s):`);
        validationResult.warnings.forEach(warning => logger.warn(`  ⚠️  ${warning}`));
      }

      // Determine authentication type (defaults to 'pat' for backward compatibility)
      const authType = settings.AUTHENTICATION_TYPE || 'pat';
      logger.info(`Starting Tableau MCP server with ${authType} authentication (profile: ${this.profileName || 'default'})...`);

      // Base environment variables (common to all auth types)
      const env: Record<string, string> = {
        ...process.env as Record<string, string>, // Inherit parent environment
        AUTH: authType,
        SERVER: settings.TABLEAU_BASE_URL!,
        SITE_NAME: settings.TABLEAU_SITE_CONTENT_URL || '',
        DEFAULT_LOG_LEVEL: process.env.DEBUG_LOG_LEVEL || 'debug',
        MAX_RESULT_LIMIT: String(settings.MAX_ROWS || 500),
        DISABLE_QUERY_DATASOURCE_VALIDATION_REQUESTS: 'false', // v393: Renamed in Tableau MCP v1.13.1
        EXCLUDE_TOOLS: 'get-view-image',
      };

      // Add debug log masking setting if specified
      if (process.env.DEBUG_DISABLE_LOG_MASKING === 'true') {
        env.DISABLE_LOG_MASKING = 'true';
      }

      // Add authentication-specific environment variables
      if (authType === 'pat') {
        // PAT Authentication
        env.PAT_NAME = settings.TABLEAU_PAT_NAME!;
        env.PAT_VALUE = settings.TABLEAU_PAT_SECRET!;
        logger.info('Using PAT authentication with token name:', settings.TABLEAU_PAT_NAME);
      } else if (authType === 'direct-trust') {
        // Direct Trust Authentication
        // Use jwtSubClaimOverride if provided (from session's effectiveSubClaim), otherwise use settings
        const jwtSubClaim = this.jwtSubClaimOverride || settings.JWT_SUB_CLAIM!;
        env.JWT_SUB_CLAIM = jwtSubClaim;
        env.CONNECTED_APP_CLIENT_ID = settings.CONNECTED_APP_CLIENT_ID!;
        env.CONNECTED_APP_SECRET_ID = settings.CONNECTED_APP_SECRET_ID!;
        env.CONNECTED_APP_SECRET_VALUE = settings.CONNECTED_APP_SECRET_VALUE!;

        // Add optional JWT additional payload if provided
        if (settings.JWT_ADDITIONAL_PAYLOAD) {
          env.JWT_ADDITIONAL_PAYLOAD = settings.JWT_ADDITIONAL_PAYLOAD;
          logger.info('JWT Additional Payload set:', settings.JWT_ADDITIONAL_PAYLOAD);
        } else {
          logger.info('No JWT Additional Payload configured');
        }

        if (this.jwtSubClaimOverride) {
          logger.info('Using Direct Trust authentication with JWT subject (from session):', jwtSubClaim);
        } else {
          logger.info('Using Direct Trust authentication with JWT subject (from config):', jwtSubClaim);
        }
        logger.info('Connected App Client ID:', settings.CONNECTED_APP_CLIENT_ID);
      }

      // Add INCLUDE_DATASOURCE_IDS if datasourceIds are provided (dashboard scope mode)
      if (this.datasourceIds && this.datasourceIds.length > 0) {
        env.INCLUDE_DATASOURCE_IDS = this.datasourceIds.join(',');
        logger.info(`Dashboard scope mode: INCLUDE_DATASOURCE_IDS set to ${env.INCLUDE_DATASOURCE_IDS}`);
      } else {
        logger.info('Global scope mode: INCLUDE_DATASOURCE_IDS not set');
      }

      // Add INCLUDE_WORKBOOK_IDS if workbookId is provided (dashboard scope mode)
      if (this.workbookId) {
        env.INCLUDE_WORKBOOK_IDS = this.workbookId;
        logger.info(`Dashboard scope mode: INCLUDE_WORKBOOK_IDS set to ${env.INCLUDE_WORKBOOK_IDS}`);
      } else {
        logger.info('Global scope mode: INCLUDE_WORKBOOK_IDS not set');
      }

      // Debug: Log environment variables being passed (excluding secrets)
      const envDebug = { ...env };
      if (envDebug.PAT_VALUE) envDebug.PAT_VALUE = '[REDACTED]';
      if (envDebug.CONNECTED_APP_SECRET_VALUE) envDebug.CONNECTED_APP_SECRET_VALUE = '[REDACTED]';
      logger.info('MCP Environment Variables passed to Tableau MCP:', JSON.stringify(envDebug, null, 2));

      // Use locally installed @tableau/mcp-server instead of npx to avoid subprocess spawn overhead
      this.transport = new StdioClientTransport({
        command: 'node',
        args: ['node_modules/@tableau/mcp-server/build/index.js'],
        env,
      });

      this.client = new Client(
        {
          name: 'tableau-mcp-extension',
          version: '1.0.0',
        },
        {
          capabilities: {},
        }
      );

      // Set connection timeout
      const connectionTimeout = setTimeout(() => {
        throw new Error('Connection timeout after 30 seconds');
      }, 30000);

      try {
        await this.client.connect(this.transport);
        clearTimeout(connectionTimeout);
        this.connected = true;

        // Capture stderr logs from MCP server if log handler is provided
        if (this.logHandler) {
          try {
            // Access the internal process from StdioClientTransport
            // Note: This accesses a private property, but it's necessary to capture stderr
            const process = (this.transport as any)._process;
            if (process && process.stderr) {
              let stderrBuffer = '';

              process.stderr.on('data', (data: Buffer) => {
                stderrBuffer += data.toString();

                // Split by newlines and process complete lines
                const lines = stderrBuffer.split('\n');
                stderrBuffer = lines.pop() || ''; // Keep the incomplete line in buffer

                lines.forEach((line: string) => {
                  if (line.trim() && this.logHandler) {
                    this.logHandler(line);
                  }
                });
              });

              process.stderr.on('error', (error: Error) => {
                logger.error('Error reading MCP server stderr:', error);
              });

              logger.info('Log handler registered - capturing MCP server stderr logs');
            } else {
              logger.warn('Could not access MCP server process stderr');
            }
          } catch (error) {
            logger.error('Failed to attach stderr listener:', error);
          }
        }

        logger.info(`Successfully connected to Tableau MCP server (profile: ${this.profileName || 'default'})`);
      } catch (error) {
        clearTimeout(connectionTimeout);
        await this.cleanup();
        throw error;
      }
    } catch (error) {
      await this.cleanup();
      throw error;
    }
  }

  /**
   * Clean up resources on connection failure
   */
  private async cleanup(): Promise<void> {
    try {
      if (this.transport) {
        await this.transport.close();
        this.transport = null;
      }
      if (this.client) {
        this.client = null;
      }
      this.connected = false;
    } catch (error) {
      logger.error('Error during cleanup', error);
    }
  }


  /**
   * List available tools with auto-reconnect
   */
  async listTools(): Promise<any[]> {
    if (!this.connected) {
      await this.connect();
    }

    if (!this.client) {
      throw new Error('MCP client not connected');
    }

    try {
      const response = await this.client.request(
        {
          method: 'tools/list',
        },
        ListToolsResultSchema,
        { timeout: 300000 }
      );

      return (response as any).tools || [];
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);

      // Handle disconnection errors with retry
      if (errorMessage.includes('Not connected') || errorMessage.includes('Connection closed')) {
        logger.warn('Detected disconnection, attempting to reconnect...');
        await this.cleanup();
        this.connected = false;

        // Attempt to reconnect (will use retry logic)
        await this.connect();

        // Retry the request once after reconnection
        if (this.client) {
          try {
            const response = await this.client.request(
              {
                method: 'tools/list',
              },
              ListToolsResultSchema,
              { timeout: 300000 }
            );
            return (response as any).tools || [];
          } catch (retryError) {
            logger.error('Failed to list tools after reconnection', retryError);
            throw retryError;
          }
        }
      }

      logger.error('Failed to list tools', error);
      throw error;
    }
  }

  /**
   * Call a tool with auto-reconnect
   */
  async callTool(name: string, args: Record<string, unknown>): Promise<any> {
    if (!this.connected) {
      await this.connect();
    }

    if (!this.client) {
      throw new Error('MCP client not connected');
    }

    // Fix tool arguments: inject default values for missing required fields
    const fixedArgs = this.fixToolArguments(name, args);

    // Track call duration
    const startTime = Date.now();

    try {
      // Log full arguments for Pulse tool
      if (name === 'generate-pulse-metric-value-insight-bundle') {
        logger.info(`Calling Pulse tool with full args: ${JSON.stringify(fixedArgs, null, 2)}`);
      } else {
        logger.info(`Calling tool "${name}"`, fixedArgs);
      }

      const response = await this.client.request(
        {
          method: 'tools/call',
          params: {
            name,
            arguments: fixedArgs,
          },
        },
        CallToolResultSchema,
        { timeout: 300000 }
      );

      // Calculate and log duration
      const duration = Date.now() - startTime;
      const durationSeconds = (duration / 1000).toFixed(2);
      logger.info(`Tool "${name}" completed in ${durationSeconds}s (profile: ${this.profileName || 'default'})`);

      // Warn if call took longer than 10 seconds
      if (duration > 10000) {
        logger.warn(`Tool "${name}" took ${durationSeconds}s to complete. This may indicate Tableau Server performance issues or network latency.`);
      }

      // Log successful response for Pulse tool
      if (name === 'generate-pulse-metric-value-insight-bundle') {
        logger.info(`Pulse tool succeeded: ${JSON.stringify(response, null, 2)}`);
      }

      return response;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);

      // Handle disconnection errors with retry
      if (errorMessage.includes('Not connected') || errorMessage.includes('Connection closed')) {
        logger.warn('Detected disconnection during tool call, attempting to reconnect...');
        await this.cleanup();
        this.connected = false;

        // Attempt to reconnect (will use retry logic)
        await this.connect();

        // Retry the tool call once after reconnection
        if (this.client) {
          try {
            const retryStartTime = Date.now();
            const response = await this.client.request(
              {
                method: 'tools/call',
                params: {
                  name,
                  arguments: fixedArgs,
                },
              },
              CallToolResultSchema,
              { timeout: 300000 }
            );

            const retryDuration = Date.now() - retryStartTime;
            const retryDurationSeconds = (retryDuration / 1000).toFixed(2);
            logger.info(`Tool "${name}" completed after reconnection in ${retryDurationSeconds}s (profile: ${this.profileName || 'default'})`);

            if (name === 'generate-pulse-metric-value-insight-bundle') {
              logger.info(`Pulse tool succeeded after reconnection: ${JSON.stringify(response, null, 2)}`);
            }

            return response;
          } catch (retryError) {
            logger.error(`Failed to call tool ${name} after reconnection`, retryError);
            throw retryError;
          }
        }
      }

      // Calculate duration even for errors
      const errorDuration = Date.now() - startTime;
      const errorDurationSeconds = (errorDuration / 1000).toFixed(2);

      // Enhanced error logging for Pulse tool
      if (name === 'generate-pulse-metric-value-insight-bundle') {
        logger.error(`Pulse tool FAILED after ${errorDurationSeconds}s: ${errorMessage}`);
        if (error instanceof Error && error.stack) {
          logger.error(`Stack trace: ${error.stack}`);
        }
        logger.error(`Arguments sent: ${JSON.stringify(fixedArgs, null, 2)}`);
      } else {
        // Concise error logging
        logger.error(`Failed to call tool ${name} after ${errorDurationSeconds}s (profile: ${this.profileName || 'default'}): ${errorMessage}`);
      }
      throw error;
    }
  }

  /**
   * Fix tool arguments by injecting default values for missing required fields
   * This is necessary because OpenAI may not generate all required fields,
   * especially for deeply nested schemas like Pulse metric tools
   */
  private fixToolArguments(name: string, args: Record<string, unknown>): Record<string, unknown> {
    // Handle generate-pulse-metric-value-insight-bundle tool
    if (name === 'generate-pulse-metric-value-insight-bundle') {
      logger.info('=== PULSE TOOL - BEFORE FIXING ===');
      logger.info('Input args from LLM:', JSON.stringify(args, null, 2));

      const fixed = JSON.parse(JSON.stringify(args)); // Deep copy to avoid mutations

      // Ensure bundleRequest exists (camelCase at top level)
      if (!fixed.bundleRequest || typeof fixed.bundleRequest !== 'object') {
        logger.warn('bundleRequest missing or invalid, cannot fix arguments');
        return fixed;
      }

      const bundleRequestTop = fixed.bundleRequest as any;

      // Ensure bundle_request exists (snake_case, nested inside bundleRequest)
      if (!bundleRequestTop.bundle_request) {
        bundleRequestTop.bundle_request = {};
        logger.debug('Created missing bundle_request');
      }

      const bundleRequest = bundleRequestTop.bundle_request as any;

      // Inject version if missing
      if (!bundleRequest.version) {
        bundleRequest.version = 1;
        logger.debug('Injected default version: 1');
      }

      // Inject options if missing
      if (!bundleRequest.options) {
        bundleRequest.options = {
          output_format: 'OUTPUT_FORMAT_HTML',
          time_zone: 'UTC',
          language: 'LANGUAGE_EN_US',
          locale: 'LOCALE_EN_US'
        };
        logger.debug('Injected default options');
      }

      // Ensure input exists
      if (!bundleRequest.input) {
        bundleRequest.input = {};
        logger.debug('Created missing input');
      }

      // Inject metadata at input level if missing
      if (!bundleRequest.input.metadata) {
        bundleRequest.input.metadata = {
          name: 'Metric',
          metric_id: '',
          definition_id: ''
        };
        logger.debug('Injected default metadata at input level');
      }

      // Ensure metric exists
      if (!bundleRequest.input.metric || typeof bundleRequest.input.metric !== 'object') {
        logger.warn('bundleRequest.bundle_request.input.metric missing or invalid - creating empty metric object');
        bundleRequest.input.metric = {};
      }

      const metric = bundleRequest.input.metric as any;

      // Inject metric_specification if missing (CRITICAL - this is REQUIRED by Tableau API)
      if (!metric.metric_specification || typeof metric.metric_specification !== 'object') {
        logger.warn('metric_specification is missing or invalid - injecting default');
        metric.metric_specification = {
          filters: [],
          measurement_period: {
            granularity: 'GRANULARITY_BY_QUARTER',
            range: 'RANGE_LAST_COMPLETE'
          },
          comparison: {
            comparison: 'TIME_COMPARISON_PREVIOUS_PERIOD'
          }
        };
        logger.info('Injected default metric_specification with GRANULARITY_BY_QUARTER and RANGE_LAST_COMPLETE');
      } else {
        logger.info('metric_specification already exists in metric object');
      }

          // Inject extension_options if missing
          if (!metric.extension_options) {
            metric.extension_options = {
              allowed_dimensions: [],
              allowed_granularities: [],
              offset_from_today: 0
            };
            logger.debug('Injected default extension_options');
          }

          // Inject insights_options if missing
          if (!metric.insights_options) {
            metric.insights_options = {
              show_insights: true,
              settings: []
            };
            logger.debug('Injected default insights_options');
          }

          // Inject representation_options if missing entirely
          if (!metric.representation_options) {
            metric.representation_options = {};
            logger.debug('Created missing representation_options');
          }

          const repOptions = metric.representation_options;

          // Inject type if missing (REQUIRED)
          if (!repOptions.type) {
            repOptions.type = 'NUMBER_FORMAT_TYPE_NUMBER';
            logger.debug('Injected default type: NUMBER_FORMAT_TYPE_NUMBER');
          }

          // Inject sentiment_type if missing
          if (!repOptions.sentiment_type) {
            repOptions.sentiment_type = 'SENTIMENT_TYPE_NONE';
            logger.debug('Injected default sentiment_type: SENTIMENT_TYPE_NONE');
          }

          // Inject number_units if missing
          if (!repOptions.number_units) {
            repOptions.number_units = {
              singular_noun: '',
              plural_noun: ''
            };
            logger.debug('Injected default number_units');
          }

          // Inject row_level_id_field if missing
          if (!repOptions.row_level_id_field) {
            repOptions.row_level_id_field = {
              identifier_col: ''
            };
            logger.debug('Injected default row_level_id_field');
          }

          // Inject row_level_entity_names if missing
          if (!repOptions.row_level_entity_names) {
            repOptions.row_level_entity_names = {
              entity_name_singular: '',
              entity_name_plural: ''
            };
            logger.debug('Injected default row_level_entity_names');
          }

          // Inject row_level_name_field if missing
          if (!repOptions.row_level_name_field) {
            repOptions.row_level_name_field = {
              name_col: ''
            };
            logger.debug('Injected default row_level_name_field');
          }

          // Inject currency_code if missing
          if (!repOptions.currency_code) {
            repOptions.currency_code = 'CURRENCY_CODE_UNSPECIFIED';
            logger.debug('Injected default currency_code');
          }

      // Inject definition if missing entirely
      if (!metric.definition) {
        metric.definition = {};
        logger.debug('Created missing definition');
      }

      const definition = metric.definition;

      // Inject datasource if missing (REQUIRED)
      if (!definition.datasource) {
        definition.datasource = {
          id: ''
        };
        logger.debug('Injected default datasource');
      }

      // Sanitize datasource.id - remove malformed JSON characters
      if (definition.datasource && definition.datasource.id && typeof definition.datasource.id === 'string') {
        const originalId = definition.datasource.id;
        // Remove trailing JSON artifacts like },", }," etc
        definition.datasource.id = definition.datasource.id
          .replace(/[}\],"'\s]+$/, '') // Remove trailing JSON characters
          .trim();

        if (originalId !== definition.datasource.id) {
          logger.warn(`Sanitized malformed datasource.id: "${originalId}" -> "${definition.datasource.id}"`);
        }
      }

      // Fix critical structure issue: basic_specification, is_running_total should NOT be inside datasource
      // They should be siblings of datasource at the definition level
      if (definition.datasource) {
        const datasource = definition.datasource as any;

        // Move basic_specification if it's incorrectly nested inside datasource
        if (datasource.basic_specification) {
          logger.warn('Found basic_specification incorrectly nested inside datasource, moving to definition level');
          definition.basic_specification = datasource.basic_specification;
          delete datasource.basic_specification;
        }

        // Move is_running_total if it's incorrectly nested inside datasource
        if (datasource.is_running_total !== undefined) {
          logger.warn('Found is_running_total incorrectly nested inside datasource, moving to definition level');
          definition.is_running_total = datasource.is_running_total;
          delete datasource.is_running_total;
        }
      }

      // Inject basic_specification if missing (REQUIRED)
      if (!definition.basic_specification) {
        logger.warn('WARNING: basic_specification is MISSING from metric.definition! This means the LLM did not pass the complete metric object from list-pulse-metrics-from-metric-ids. Injecting placeholder defaults, but this will likely cause a 400 error.');
        definition.basic_specification = {
          measure: {
            field: 'Measure',
            aggregation: 'AGGREGATION_SUM'  // Must use AGGREGATION_ prefix per Tableau API
          },
          time_dimension: {
            field: 'Date'  // Must be object with field property, not string
          },
          filters: []
        };
        logger.warn('Injected PLACEHOLDER basic_specification - real field names needed!');
      } else {
        logger.info(`basic_specification EXISTS in metric.definition with measure.field="${definition.basic_specification.measure?.field}" and time_dimension.field="${definition.basic_specification.time_dimension?.field}"`);
      }

      // Fix filters: ensure all filter objects have categorical_values array
      if (definition.basic_specification && Array.isArray(definition.basic_specification.filters)) {
        definition.basic_specification.filters.forEach((filter: any, index: number) => {
          if (filter && typeof filter === 'object') {
            if (!Array.isArray(filter.categorical_values)) {
              filter.categorical_values = [];
              logger.debug(`Injected default categorical_values for filter ${index}`);
            }
          }
        });
      }

      // Inject is_running_total if missing (REQUIRED)
      if (definition.is_running_total === undefined || definition.is_running_total === null) {
        definition.is_running_total = false;
        logger.debug('Injected default is_running_total: false');
      }

      logger.debug('Fixed args:', JSON.stringify(fixed, null, 2));
      logger.info('Successfully fixed generate-pulse-metric-value-insight-bundle arguments');
      return fixed;
    }

    // No fixes needed for other tools
    return args;
  }

  /**
   * Disconnect from MCP server with proper cleanup
   */
  async disconnect(): Promise<void> {
    try {
      if (this.client) {
        await this.client.close();
        this.client = null;
      }
      if (this.transport) {
        await this.transport.close();
        this.transport = null;
      }
      this.connected = false;
      this.connectionAttempts = 0; // Reset connection attempts
      logger.info(`Disconnected from MCP server (profile: ${this.profileName || 'default'})`);
    } catch (error) {
      logger.error(`Error during disconnect (profile: ${this.profileName || 'default'})`, error);
      // Force cleanup even if errors occur
      this.client = null;
      this.transport = null;
      this.connected = false;
      this.connectionAttempts = 0;
    }
  }
}
