/**
 * MCP Client - connects to local MCP server for tool invocation
 */

import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { Transport } from '@modelcontextprotocol/sdk/shared/transport.js';
import {
  ListToolsResultSchema,
  CallToolResultSchema,
} from '@modelcontextprotocol/sdk/types.js';
import WebSocket from 'ws';
import { logger } from '../util/logger.js';

export interface McpTool {
  name: string;
  description: string;
  inputSchema: Record<string, unknown>;
}

// Custom WebSocket Transport for MCP
class WebSocketTransport implements Transport {
  private ws: WebSocket;
  public onmessage?: (message: any) => void;
  public onclose?: () => void;
  public onerror?: (error: Error) => void;

  constructor(ws: WebSocket) {
    this.ws = ws;

    // Set up WebSocket event handlers
    this.ws.on('message', (data: Buffer) => {
      try {
        const message = JSON.parse(data.toString());
        if (this.onmessage) {
          this.onmessage(message);
        }
      } catch (error) {
        logger.error('Failed to parse WebSocket message', error);
      }
    });

    this.ws.on('close', () => {
      if (this.onclose) {
        this.onclose();
      }
    });

    this.ws.on('error', (error) => {
      if (this.onerror) {
        this.onerror(error);
      }
    });
  }

  async start(): Promise<void> {
    // WebSocket is already connected
  }

  async send(message: any): Promise<void> {
    if (this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    } else {
      throw new Error('WebSocket is not open');
    }
  }

  async close(): Promise<void> {
    this.ws.close();
  }
}

export class McpClient {
  private client: Client | null = null;
  private transport: WebSocketTransport | null = null;
  private ws: WebSocket | null = null;
  private connecting = false;
  private connected = false;
  private tools: McpTool[] = [];
  private connectionAttempts = 0;
  private maxRetries = 3;
  private retryDelay = 2000; // Start with 2 seconds

  constructor(private wsUrl: string) {}

  async connect(): Promise<void> {
    if (this.connected || this.connecting) {
      return;
    }

    while (this.connectionAttempts < this.maxRetries) {
      try {
        await this.attemptConnection();
        this.connectionAttempts = 0; // Reset on success
        return;
      } catch (error) {
        this.connectionAttempts++;
        const errorMessage = error instanceof Error ? error.message : String(error);

        logger.warn(`MCP broker connection attempt ${this.connectionAttempts}/${this.maxRetries} failed: ${errorMessage}`);

        if (this.connectionAttempts >= this.maxRetries) {
          logger.error(`Failed to connect to MCP broker after ${this.maxRetries} attempts`);
          throw new Error(`MCP connection failed after ${this.maxRetries} attempts: ${errorMessage}`);
        }

        // Exponential backoff
        const delay = this.retryDelay * Math.pow(2, this.connectionAttempts - 1);
        logger.info(`Retrying MCP broker connection in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }

  private async attemptConnection(): Promise<void> {
    this.connecting = true;
    logger.info(`Connecting to MCP server at ${this.wsUrl}`);

    try {
      this.ws = new WebSocket(this.wsUrl);

      await new Promise<void>((resolve, reject) => {
        const timeout = setTimeout(() => {
          reject(new Error('MCP connection timeout after 15 seconds'));
        }, 15000);

        this.ws!.once('open', () => {
          clearTimeout(timeout);
          resolve();
        });

        this.ws!.once('error', (error) => {
          clearTimeout(timeout);
          reject(error);
        });
      });

      // Create custom WebSocket transport
      this.transport = new WebSocketTransport(this.ws);
      this.client = new Client(
        {
          name: 'tableau-broker',
          version: '1.0.0',
        },
        {
          capabilities: {},
        }
      );

      await this.client.connect(this.transport);
      this.connected = true;
      this.connecting = false;

      // Fetch available tools
      await this.refreshTools();

      logger.info(`Connected to MCP server, ${this.tools.length} tools available`);
    } catch (error) {
      this.connecting = false;
      this.connected = false;
      await this.cleanup();
      throw error;
    }
  }

  private async cleanup(): Promise<void> {
    try {
      if (this.transport) {
        await this.transport.close();
        this.transport = null;
      }
      if (this.ws) {
        this.ws.close();
        this.ws = null;
      }
      this.client = null;
      this.connected = false;
    } catch (error) {
      logger.error('Error during MCP broker cleanup', error);
    }
  }

  async refreshTools(): Promise<void> {
    if (!this.client || !this.connected) {
      throw new Error('MCP client not connected');
    }

    try {
      const response = await this.client.request(
        { method: 'tools/list', params: {} },
        ListToolsResultSchema,
        { timeout: 300000 } // 5 minutes timeout for Tableau API calls
      );

      this.tools = (response as any).tools || [];
      logger.debug(`Refreshed MCP tools: ${this.tools.length} available`);
    } catch (error) {
      logger.error('Failed to refresh MCP tools', error);
      throw error;
    }
  }

  getTools(): McpTool[] {
    return [...this.tools];
  }

  async callTool(name: string, args: Record<string, unknown>): Promise<unknown> {
    if (!this.client || !this.connected) {
      throw new Error('MCP client not connected');
    }

    // 🔍 TRACING: Log arguments BEFORE fixToolArguments
    logger.info(`[🔍 TRACE] McpClient.callTool BEFORE fixToolArguments`, {
      toolName: name,
      originalArgs: args,
      originalArgsKeys: Object.keys(args || {}),
      originalArgsJSON: JSON.stringify(args),
    });

    // Fix tool arguments: inject default values for missing required fields
    const fixedArgs = this.fixToolArguments(name, args);

    // 🔍 TRACING: Log arguments AFTER fixToolArguments
    logger.info(`[🔍 TRACE] McpClient.callTool AFTER fixToolArguments`, {
      toolName: name,
      fixedArgs,
      fixedArgsKeys: Object.keys(fixedArgs || {}),
      fixedArgsJSON: JSON.stringify(fixedArgs),
      argsChanged: JSON.stringify(args) !== JSON.stringify(fixedArgs),
    });

    // Log full arguments for Pulse tool
    if (name === 'generate-pulse-metric-value-insight-bundle') {
      logger.info(`Calling Pulse tool with full args: ${JSON.stringify(fixedArgs, null, 2)}`);
    } else {
      logger.info(`Calling MCP tool: ${name}`, fixedArgs);
    }

    try {
      const response = await this.client.request(
        {
          method: 'tools/call',
          params: {
            name,
            arguments: fixedArgs,
          },
        },
        CallToolResultSchema,
        { timeout: 300000 } // 5 minutes timeout for Tableau API calls
      );

      const content = (response as any).content;
      if (!content || content.length === 0) {
        throw new Error('Empty response from MCP tool');
      }

      const text = content[0].text;
      const result = JSON.parse(text);

      // Log successful response for Pulse tool
      if (name === 'generate-pulse-metric-value-insight-bundle') {
        logger.info(`Pulse tool succeeded: ${JSON.stringify(result, null, 2)}`);
      }

      logger.debug(`MCP tool ${name} returned result`);
      return result;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);

      // Enhanced error logging for Pulse tool
      if (name === 'generate-pulse-metric-value-insight-bundle') {
        logger.error(`Pulse tool FAILED: ${errorMessage}`);
        if (error instanceof Error && error.stack) {
          logger.error(`Stack trace: ${error.stack}`);
        }
        logger.error(`Arguments sent: ${JSON.stringify(fixedArgs, null, 2)}`);
      } else {
        // Concise error logging - avoid dumping entire error object
        logger.error(`MCP tool call failed: ${name} - ${errorMessage}`);
      }

      // Don't wrap error if it's already an MCP error or wrapped error
      if (errorMessage.startsWith('MCP error') || errorMessage.startsWith('Tool call failed:')) {
        throw error;
      }

      throw new Error(`Tool call failed: ${errorMessage}`);
    }
  }

  /**
   * Fix tool arguments by injecting default values for missing required fields
   * This is necessary because OpenAI may not generate all required fields,
   * especially for deeply nested schemas like Pulse metric tools
   *
   * Also handles parameter name corrections for local LLMs that use incorrect names
   */
  private fixToolArguments(name: string, args: Record<string, unknown>): Record<string, unknown> {
    // Handle parameter name corrections for get-view-data (local LLMs often confuse viewId/viewLuid)
    if (name === 'get-view-data' && 'viewLuid' in args && !('viewId' in args)) {
      logger.info('[LOCAL-LLM FIX] Correcting parameter: viewLuid → viewId');
      const fixed = { ...args };
      fixed.viewId = args.viewLuid;
      delete fixed.viewLuid;
      return fixed;
    }

    // Handle generate-pulse-metric-value-insight-bundle tool
    if (name === 'generate-pulse-metric-value-insight-bundle') {
      logger.info('=== PULSE TOOL - BEFORE FIXING ===');
      logger.info('Input args from LLM:', JSON.stringify(args, null, 2));

      const fixed = JSON.parse(JSON.stringify(args)); // Deep copy to avoid mutations

      // Ensure bundleRequest exists (camelCase at top level)
      if (!fixed.bundleRequest || typeof fixed.bundleRequest !== 'object') {
        logger.warn('bundleRequest missing or invalid, cannot fix arguments');
        return fixed;
      }

      const bundleRequestTop = fixed.bundleRequest as any;

      // Ensure bundle_request exists (snake_case, nested inside bundleRequest)
      if (!bundleRequestTop.bundle_request) {
        bundleRequestTop.bundle_request = {};
        logger.debug('Created missing bundle_request');
      }

      const bundleRequest = bundleRequestTop.bundle_request as any;

      // Inject version if missing
      if (!bundleRequest.version) {
        bundleRequest.version = 1;
        logger.debug('Injected default version: 1');
      }

      // Inject options if missing
      if (!bundleRequest.options) {
        bundleRequest.options = {
          output_format: 'OUTPUT_FORMAT_HTML',
          time_zone: 'UTC',
          language: 'LANGUAGE_EN_US',
          locale: 'LOCALE_EN_US'
        };
        logger.debug('Injected default options');
      }

      // Ensure input exists
      if (!bundleRequest.input) {
        bundleRequest.input = {};
        logger.debug('Created missing input');
      }

      // Inject metadata at input level if missing
      if (!bundleRequest.input.metadata) {
        bundleRequest.input.metadata = {
          name: 'Metric',
          metric_id: '',
          definition_id: ''
        };
        logger.debug('Injected default metadata at input level');
      }

      // Ensure metric exists
      if (!bundleRequest.input.metric || typeof bundleRequest.input.metric !== 'object') {
        logger.warn('bundleRequest.bundle_request.input.metric missing or invalid - creating empty metric object');
        bundleRequest.input.metric = {};
      }

      const metric = bundleRequest.input.metric as any;

      // Inject metric_specification if missing (CRITICAL - this is REQUIRED by Tableau API)
      if (!metric.metric_specification || typeof metric.metric_specification !== 'object') {
        logger.warn('metric_specification is missing or invalid - injecting default');
        metric.metric_specification = {
          filters: [],
          measurement_period: {
            granularity: 'GRANULARITY_BY_QUARTER',
            range: 'RANGE_LAST_COMPLETE'
          },
          comparison: {
            comparison: 'TIME_COMPARISON_PREVIOUS_PERIOD'
          }
        };
        logger.info('Injected default metric_specification with GRANULARITY_BY_QUARTER and RANGE_LAST_COMPLETE');
      } else {
        logger.info('metric_specification already exists in metric object');
      }

      // Inject extension_options if missing
      if (!metric.extension_options) {
        metric.extension_options = {
          allowed_dimensions: [],
          allowed_granularities: [],
          offset_from_today: 0
        };
        logger.debug('Injected default extension_options');
      }

      // Inject insights_options if missing
      if (!metric.insights_options) {
        metric.insights_options = {
          show_insights: true,
          settings: []
        };
        logger.debug('Injected default insights_options');
      }

      // Inject representation_options if missing entirely
      if (!metric.representation_options) {
        metric.representation_options = {};
        logger.debug('Created missing representation_options');
      }

      const repOptions = metric.representation_options;

      // Inject type if missing (REQUIRED)
      if (!repOptions.type) {
        repOptions.type = 'NUMBER_FORMAT_TYPE_NUMBER';
        logger.debug('Injected default type: NUMBER_FORMAT_TYPE_NUMBER');
      }

      // Inject sentiment_type if missing
      if (!repOptions.sentiment_type) {
        repOptions.sentiment_type = 'SENTIMENT_TYPE_NONE';
        logger.debug('Injected default sentiment_type: SENTIMENT_TYPE_NONE');
      }

      // Inject number_units if missing
      if (!repOptions.number_units) {
        repOptions.number_units = {
          singular_noun: '',
          plural_noun: ''
        };
        logger.debug('Injected default number_units');
      }

      // Inject row_level_id_field if missing
      if (!repOptions.row_level_id_field) {
        repOptions.row_level_id_field = {
          identifier_col: ''
        };
        logger.debug('Injected default row_level_id_field');
      }

      // Inject row_level_entity_names if missing
      if (!repOptions.row_level_entity_names) {
        repOptions.row_level_entity_names = {
          entity_name_singular: '',
          entity_name_plural: ''
        };
        logger.debug('Injected default row_level_entity_names');
      }

      // Inject row_level_name_field if missing
      if (!repOptions.row_level_name_field) {
        repOptions.row_level_name_field = {
          name_col: ''
        };
        logger.debug('Injected default row_level_name_field');
      }

      // Inject currency_code if missing
      if (!repOptions.currency_code) {
        repOptions.currency_code = 'CURRENCY_CODE_UNSPECIFIED';
        logger.debug('Injected default currency_code');
      }

      // Inject definition if missing entirely
      if (!metric.definition) {
        metric.definition = {};
        logger.debug('Created missing definition');
      }

      const definition = metric.definition;

      // Inject datasource if missing (REQUIRED)
      if (!definition.datasource) {
        definition.datasource = {
          id: ''
        };
        logger.debug('Injected default datasource');
      }

      // Sanitize datasource.id - remove malformed JSON characters
      if (definition.datasource && definition.datasource.id && typeof definition.datasource.id === 'string') {
        const originalId = definition.datasource.id;
        // Remove trailing JSON artifacts like },", }," etc
        definition.datasource.id = definition.datasource.id
          .replace(/[}\],"'\s]+$/, '') // Remove trailing JSON characters
          .trim();

        if (originalId !== definition.datasource.id) {
          logger.warn(`Sanitized malformed datasource.id: "${originalId}" -> "${definition.datasource.id}"`);
        }
      }

      // Fix critical structure issue: basic_specification, is_running_total should NOT be inside datasource
      // They should be siblings of datasource at the definition level
      if (definition.datasource) {
        const datasource = definition.datasource as any;

        // Move basic_specification if it's incorrectly nested inside datasource
        if (datasource.basic_specification) {
          logger.warn('Found basic_specification incorrectly nested inside datasource, moving to definition level');
          definition.basic_specification = datasource.basic_specification;
          delete datasource.basic_specification;
        }

        // Move is_running_total if it's incorrectly nested inside datasource
        if (datasource.is_running_total !== undefined) {
          logger.warn('Found is_running_total incorrectly nested inside datasource, moving to definition level');
          definition.is_running_total = datasource.is_running_total;
          delete datasource.is_running_total;
        }
      }

      // Inject basic_specification if missing (REQUIRED)
      if (!definition.basic_specification) {
        logger.warn('WARNING: basic_specification is MISSING from metric.definition! This means the LLM did not pass the complete metric object from list-pulse-metrics-from-metric-ids. Injecting placeholder defaults, but this will likely cause a 400 error.');
        definition.basic_specification = {
          measure: {
            field: 'Measure',
            aggregation: 'AGGREGATION_SUM'  // Must use AGGREGATION_ prefix per Tableau API
          },
          time_dimension: {
            field: 'Date'  // Must be object with field property, not string
          },
          filters: []
        };
        logger.warn('Injected PLACEHOLDER basic_specification - real field names needed!');
      } else {
        logger.info(`basic_specification EXISTS in metric.definition with measure.field="${definition.basic_specification.measure?.field}" and time_dimension.field="${definition.basic_specification.time_dimension?.field}"`);
      }

      // Fix filters: ensure all filter objects have categorical_values array
      if (definition.basic_specification && Array.isArray(definition.basic_specification.filters)) {
        definition.basic_specification.filters.forEach((filter: any, index: number) => {
          if (filter && typeof filter === 'object') {
            if (!Array.isArray(filter.categorical_values)) {
              filter.categorical_values = [];
              logger.debug(`Injected default categorical_values for filter ${index}`);
            }
          }
        });
      }

      // Inject is_running_total if missing (REQUIRED)
      if (definition.is_running_total === undefined || definition.is_running_total === null) {
        definition.is_running_total = false;
        logger.debug('Injected default is_running_total: false');
      }

      logger.debug('Fixed args:', JSON.stringify(fixed, null, 2));
      logger.info('Successfully fixed generate-pulse-metric-value-insight-bundle arguments');
      return fixed;
    }

    // No fixes needed for other tools
    return args;
  }

  async disconnect(): Promise<void> {
    try {
      if (this.client) {
        await this.client.close();
        this.client = null;
      }
      if (this.transport) {
        await this.transport.close();
        this.transport = null;
      }
      if (this.ws) {
        this.ws.close();
        this.ws = null;
      }
      this.connected = false;
      this.connectionAttempts = 0; // Reset connection attempts
      logger.info('Disconnected from MCP server');
    } catch (error) {
      logger.error('Error during MCP broker disconnect', error);
      // Force cleanup even if errors occur
      this.client = null;
      this.transport = null;
      this.ws = null;
      this.connected = false;
      this.connectionAttempts = 0;
    }
  }

  isConnected(): boolean {
    return this.connected;
  }
}

/**
 * Create and connect a new MCP client
 */
export async function createMcpClient(wsUrl: string): Promise<McpClient> {
  const client = new McpClient(wsUrl);
  await client.connect();
  return client;
}
