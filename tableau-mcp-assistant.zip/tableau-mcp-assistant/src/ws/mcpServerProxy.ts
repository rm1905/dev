/**
 * MCP Server Proxy - forwards requests to official Tableau MCP server
 */

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { Transport } from '@modelcontextprotocol/sdk/shared/transport.js';
import {
  ListToolsRequestSchema,
  CallToolRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';
import { WebSocketServer, WebSocket } from 'ws';
import { logger } from '../util/logger.js';
import { TableauMcpClient } from '../mcp/tableauMcpClient.js';

// Custom WebSocket Transport for MCP Server
class WebSocketServerTransport implements Transport {
  private ws: WebSocket;
  public onmessage?: (message: any) => void;
  public onclose?: () => void;
  public onerror?: (error: Error) => void;

  constructor(ws: WebSocket) {
    this.ws = ws;

    this.ws.on('message', (data: Buffer) => {
      try {
        const message = JSON.parse(data.toString());
        logger.debug('MCP Server received message:', message);
        if (this.onmessage) {
          this.onmessage(message);
        }
      } catch (error) {
        logger.error('Failed to parse WebSocket message', error);
      }
    });

    this.ws.on('close', () => {
      if (this.onclose) {
        this.onclose();
      }
    });

    this.ws.on('error', (error) => {
      if (this.onerror) {
        this.onerror(error);
      }
    });
  }

  async start(): Promise<void> {
    // WebSocket is already connected
  }

  async send(message: any): Promise<void> {
    if (this.ws.readyState === WebSocket.OPEN) {
      const json = JSON.stringify(message);
      logger.debug('MCP Server sending message:', message);
      this.ws.send(json);
    } else {
      throw new Error('WebSocket is not open');
    }
  }

  async close(): Promise<void> {
    this.ws.close();
  }
}

export function createMcpServer(wss: WebSocketServer): void {
  wss.on('connection', async (ws: WebSocket, request) => {
    // Extract profile, datasource_ids, workbook_id, and jwt_sub_claim from URL query parameters
    const url = new URL(request.url || '', 'http://localhost');
    const profileName = url.searchParams.get('profile') || undefined;
    const datasourceIdsParam = url.searchParams.get('datasource_ids');
    const datasourceIds = datasourceIdsParam ? datasourceIdsParam.split(',').filter(Boolean) : undefined;
    const workbookId = url.searchParams.get('workbook_id') || undefined;
    const jwtSubClaim = url.searchParams.get('jwt_sub_claim') || undefined;

    logger.info(`MCP client connected with profile: ${profileName || 'default'}, datasourceIds: ${datasourceIds ? datasourceIds.join(',') : 'none'}, workbookId: ${workbookId || 'none'}, jwtSubClaim: ${jwtSubClaim ? '***' : 'none'}`);

    // Create per-connection Tableau MCP client with the specified profile, datasourceIds, workbookId, and jwtSubClaim
    const tableauMcpClient = new TableauMcpClient(profileName, datasourceIds, workbookId, jwtSubClaim);

    const server = new Server(
      {
        name: 'tableau-mcp-proxy',
        version: '1.0.0',
      },
      {
        capabilities: {
          tools: {},
        },
      }
    );

    // Register tools/list handler - fetch from official server
    server.setRequestHandler(ListToolsRequestSchema, async () => {
      try {
        logger.info(`Fetching tool list from official Tableau MCP server (profile: ${profileName || 'default'})`);
        const tools = await tableauMcpClient.listTools();
        logger.info(`Retrieved ${tools.length} tools from official server`);
        return { tools };
      } catch (error) {
        logger.error('Failed to list tools from official server', error);
        throw error;
      }
    });

    // Register tool call handler - proxy to official server
    server.setRequestHandler(CallToolRequestSchema, async (request) => {
      const name = request.params.name;
      const args = request.params.arguments || {};

      try {
        if (!name) {
          throw new Error('Invalid tool call request: missing name parameter');
        }

        logger.info(`Proxying tool call to official server: ${name} (profile: ${profileName || 'default'})`);
        logger.debug(`Tool arguments: ${JSON.stringify(args, null, 2)}`);

        const result = await tableauMcpClient.callTool(name, args);

        // Return result in MCP format
        return {
          content: [
            {
              type: 'text',
              text: JSON.stringify(result, null, 2),
            },
          ],
        };
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : String(error);
        logger.error(`Failed to proxy tool call ${name}: ${errorMessage}`);
        logger.error(`Arguments were: ${JSON.stringify(args, null, 2)}`);
        throw error;
      }
    });

    // Connect transport
    const transport = new WebSocketServerTransport(ws);
    await server.connect(transport);

    // Setup heartbeat
    const heartbeatInterval = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.ping();
      }
    }, 30000);

    ws.on('pong', () => {
      logger.debug('Received pong from MCP client');
    });

    ws.on('close', async () => {
      clearInterval(heartbeatInterval);
      logger.info(`MCP client disconnected (profile: ${profileName || 'default'})`);
      // Disconnect the per-connection Tableau MCP client
      await tableauMcpClient.disconnect();
    });

    ws.on('error', (error) => {
      logger.error('MCP WebSocket error', error);
    });
  });

  logger.info('MCP proxy server initialized on /mcp/ws');
}
