/**
 * Broker WebSocket handler - manages LLM sessions with MCP tool integration
 */

import { WebSocketServer, WebSocket } from 'ws';
import { ILlm, Message } from '../llm/ILlm.js';
import { createLlm } from '../llm/factory.js';
import { createMcpClient, McpClient } from '../mcp/client.js';
import { config } from '../util/env.js';
import { logger } from '../util/logger.js';
import { promptManager } from '../util/PromptManager.js';
import { UserPromptSchema } from '../util/schema.js';
import { CsvData } from '../tableau/csv.js';
import type { VdsField, VdsFilter, VdsQuery } from '../schemas/vds-schemas.js';
import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { parse as csvParse } from 'csv-parse/sync';

// v377: Interceptors and FeatureFlags are only used via dynamic imports in handleUserPromptV3


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// PROMPT LOADING UTILITIES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Load a prompt section from file as fallback when database is unavailable
 * v297: Extended to support all prompt sections, not just core_prompt
 */
function loadPromptSectionFromFile(sectionName: string): string {
  try {
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = dirname(__filename);
    const promptPath = join(__dirname, '../prompts', `${sectionName}.md`);
    const content = readFileSync(promptPath, 'utf-8');
    logger.info(`[PROMPT_FALLBACK] Loaded ${sectionName} from file successfully`);
    return content;
  } catch (error) {
    logger.error(`[PROMPT_FALLBACK] Failed to load ${sectionName}.md from file`, error);
    // Return empty string for conditional sections, throw for core_prompt
    if (sectionName === 'core_prompt') {
      throw new Error('Failed to load core_prompt fallback file');
    }
    return '';
  }
}

/**
 * Load core_prompt from file as fallback when database is unavailable
 * v270: Replaced hardcoded prompt with file-based fallback (core_prompt.md version 13)
 * v297: Now uses loadPromptSectionFromFile() for consistency
 */
function loadCorePromptFromFile(): string {
  return loadPromptSectionFromFile('core_prompt');
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// CURRENT DATE CONTEXT - Global date reference for LLM guidance
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Get current date context for LLM guidance
 * This ensures the LLM knows what "current", "this month", "this year", etc. refer to
 *
 * Returns:
 * - formattedDate: Human-readable date (e.g., "December 12, 2024")
 * - year: Current year (e.g., "2024")
 * - month: Current month name (e.g., "December")
 * - monthNumber: Current month number 1-12 (e.g., "12")
 * - quarter: Current quarter (e.g., "Q4")
 * - isoDate: ISO format YYYY-MM-DD (e.g., "2024-12-12")
 * - firstDayOfMonth: First day of current month (e.g., "2024-12-01")
 */
function getCurrentDateContext(): {
  formattedDate: string;
  year: string;
  month: string;
  monthNumber: string;
  quarter: string;
  isoDate: string;
  firstDayOfMonth: string;
} {
  const now = new Date();

  const formattedDate = now.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    timeZone: 'UTC'
  });

  const year = now.getUTCFullYear().toString();
  const monthNum = now.getUTCMonth() + 1; // 0-indexed
  const monthNumber = monthNum.toString().padStart(2, '0');
  const day = now.getUTCDate().toString().padStart(2, '0');

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  const month = monthNames[now.getUTCMonth()];

  // Calculate quarter
  const quarter = `Q${Math.ceil(monthNum / 3)}`;

  const isoDate = `${year}-${monthNumber}-${day}`;
  const firstDayOfMonth = `${year}-${monthNumber}-01`;

  return {
    formattedDate,
    year,
    month,
    monthNumber,
    quarter,
    isoDate,
    firstDayOfMonth
  };
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// TOOL REGISTRY - Profiles and Allowed Tools
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// v350: Export for v3 ActionStateHandler
export type ToolProfile = 'dashboard_qna' | 'global_qna';

const TOOL_REGISTRY: Record<ToolProfile, string[]> = {
  dashboard_qna: [
    'list-datasources',
    'get-datasource-metadata',
    'query-datasource',
    'list-views',
    'get-view-data',
  ],

  global_qna: [
    'list-datasources',
    'get-datasource-metadata',
    'query-datasource',
    'list-workbooks',
    'get-workbook',
    'list-views',
    'get-view-data',
    'get-view-image',
    // All Pulse tools
    'list-all-pulse-metric-definitions',
    'list-pulse-metric-definitions-from-definition-ids',
    'list-pulse-metrics-from-metric-definition-id',
    'list-pulse-metrics-from-metric-ids',
    'list-pulse-metric-subscriptions',
    'generate-pulse-metric-value-insight-bundle',
    'search-content',
  ],
};

/**
 * Determine which tool profile to use for a session
 * dashboard_qna: Limited tools for dashboard-scoped queries
 * global_qna: Full access including Pulse and content exploration
 */
function getToolProfileForSession(session: Session): ToolProfile {
  if (session.allowedScope?.scope === 'dashboard') {
    return 'dashboard_qna';
  }
  return 'global_qna';
}

/**
 * Check if a tool is allowed for the given profile
 */
function isToolAllowedForProfile(name: string, profile: ToolProfile): boolean {
  return TOOL_REGISTRY[profile].includes(name);
}

/**
 * Intent-based tool mapping - limits tools based on detected question intent
 * Tool profile filtering takes precedence, then intent filtering is applied
 * v192: Added view_dashboard_query intent to restrict to view-related tools only
 */
const INTENT_TOOL_MAPPING: Record<QuestionIntent, string[] | 'all'> = {
  // View/dashboard queries - only expose view-related tools
  view_dashboard_query: [
    'list-views',
    'get-view-data',
    'get-view-image',
    'list-workbooks',
    'get-workbook',
  ],

  // Datasource queries - only expose datasource-related tools
  datasource_query: [
    'list-datasources',
    'get-datasource-metadata',
    'query-datasource',
  ],

  // Pulse queries - only expose Pulse tools
  pulse_query: [
    'list-all-pulse-metric-definitions',
    'list-pulse-metric-definitions-from-definition-ids',
    'list-pulse-metrics-from-metric-definition-id',
    'list-pulse-metrics-from-metric-ids',
    'list-pulse-metric-subscriptions',
    'generate-pulse-metric-value-insight-bundle',
  ],

  // Content discovery - expose search and listing tools
  content_discovery: [
    'search-content',
    'list-workbooks',
    'list-views',
    'list-datasources',
    'get-workbook',
  ],

  // Unknown intent - allow all tools (safe fallback)
  unknown: 'all',
};

/**
 * Check if a tool is allowed for the given intent
 */
function isToolAllowedForIntent(name: string, intent: QuestionIntent): boolean {
  const allowedTools = INTENT_TOOL_MAPPING[intent];
  if (allowedTools === 'all') {
    return true;
  }
  return allowedTools.includes(name);
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// UNIFIED TOOL GATING - Policy Decision Function (v293)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * v293: Tool access decision result
 * Single source of truth for all tool gating decisions
 * v350: Exported for v3 ActionStateHandler runtime enforcement
 */
export interface ToolAccessDecision {
  /** Whether the tool is allowed */
  allowed: boolean;

  /** Reason for the decision */
  reason: 'profile' | 'intent' | 'datasource_scope' | 'view_scope' | 'allowed';

  /** User-facing error message (if denied) */
  userMessage?: string;

  /** Developer/log message with debugging details */
  logMessage?: string;

  /** Token estimation metadata (v295: implemented) */
  tokenEstimate?: {
    toolDefinition: number;
    typicalInput: number;
    typicalOutput: number;
  };
}

/**
 * v295: Per-tool token usage statistics
 */
interface ToolTokenStats {
  /** Number of times this tool was called */
  callCount: number;

  /** Total tokens used by this tool (input + output) */
  totalTokens: number;

  /** Average tokens per call */
  avgTokens: number;

  /** Total input tokens */
  inputTokens: number;

  /** Total output tokens */
  outputTokens: number;
}

/**
 * v295: Session-level token tracking
 * Comprehensive accounting of all token usage during a session
 */
interface SessionTokenTracking {
  /** Total tokens used across entire session */
  total: number;

  /** Tokens broken down by phase */
  byPhase: {
    systemPrompt: number;      // Tokens in system prompt (core + guidance + scope)
    userMessages: number;       // Cumulative tokens in all user messages
    assistantMessages: number;  // Cumulative tokens in all assistant responses
    toolDefinitions: number;    // Tokens for all tool definitions exposed to LLM
    toolInputs: number;         // Cumulative tokens in all tool call arguments
    toolOutputs: number;        // Cumulative tokens in all tool results
  };

  /** Per-tool statistics */
  byTool: Map<string, ToolTokenStats>;

  /** Tokens saved by filtering */
  saved: {
    byFiltering: number;        // Tokens saved by not exposing filtered-out tools
    byEarlyRejection: number;   // Tokens saved by rejecting tool calls at runtime
  };

  /** Timestamps for tracking */
  sessionStart: number;
  lastUpdate: number;
}

/**
 * v295: Initialize token tracking for a new session
 */
function createSessionTokenTracking(): SessionTokenTracking {
  return {
    total: 0,
    byPhase: {
      systemPrompt: 0,
      userMessages: 0,
      assistantMessages: 0,
      toolDefinitions: 0,
      toolInputs: 0,
      toolOutputs: 0,
    },
    byTool: new Map<string, ToolTokenStats>(),
    saved: {
      byFiltering: 0,
      byEarlyRejection: 0,
    },
    sessionStart: Date.now(),
    lastUpdate: Date.now(),
  };
}

/**
 * v295: Log token tracking summary
 * v301: Enhanced to show actual vs estimated usage when available
 */
function logTokenSummary(tracking: SessionTokenTracking, actualUsage?: Array<{ iteration: number; promptTokens: number; completionTokens: number; totalTokens: number }>): void {
  const duration = (Date.now() - tracking.sessionStart) / 1000;
  const totalSaved = tracking.saved.byFiltering + tracking.saved.byEarlyRejection;
  const efficiency = tracking.total > 0
    ? ((totalSaved / (tracking.total + totalSaved)) * 100).toFixed(1)
    : '0.0';

  logger.info(`[v295 TOKEN_SUMMARY] Session duration: ${duration.toFixed(1)}s`);
  logger.info(`[v295 TOKEN_SUMMARY] Total tokens used (estimated): ${tracking.total.toLocaleString()}`);

  // v301: Report actual usage if available
  if (actualUsage && actualUsage.length > 0) {
    const totalActual = actualUsage.reduce((sum, usage) => sum + usage.totalTokens, 0);
    const totalPrompt = actualUsage.reduce((sum, usage) => sum + usage.promptTokens, 0);
    const totalCompletion = actualUsage.reduce((sum, usage) => sum + usage.completionTokens, 0);
    const estimateAccuracy = tracking.total > 0
      ? ((totalActual / tracking.total) * 100).toFixed(1)
      : 'N/A';

    logger.info(`[v301 TOKEN_ACTUAL] Total tokens used (ACTUAL): ${totalActual.toLocaleString()} (prompt: ${totalPrompt.toLocaleString()}, completion: ${totalCompletion.toLocaleString()})`);
    logger.info(`[v301 TOKEN_ACTUAL] Estimate accuracy: ${estimateAccuracy}% (estimated: ${tracking.total.toLocaleString()}, actual: ${totalActual.toLocaleString()})`);
    logger.info(`[v301 TOKEN_ACTUAL] LLM calls tracked: ${actualUsage.length}`);
  }

  logger.info(`[v295 TOKEN_SUMMARY] Tokens saved: ${totalSaved.toLocaleString()} (${efficiency}% efficiency)`);
  logger.info(`[v295 TOKEN_SUMMARY] By phase - System: ${tracking.byPhase.systemPrompt}, Tools: ${tracking.byPhase.toolInputs + tracking.byPhase.toolOutputs}, Messages: ${tracking.byPhase.userMessages + tracking.byPhase.assistantMessages}`);

  if (tracking.byTool.size > 0) {
    logger.info(`[v295 TOKEN_SUMMARY] Top tools by tokens:`);
    const sortedTools = Array.from(tracking.byTool.entries())
      .sort((a, b) => b[1].totalTokens - a[1].totalTokens)
      .slice(0, 5);

    sortedTools.forEach(([toolName, stats]) => {
      logger.info(`[v295 TOKEN_SUMMARY]   ${toolName}: ${stats.totalTokens.toLocaleString()} tokens (${stats.callCount} calls, avg ${stats.avgTokens})`);
    });
  }
}

/**
 * v293: Check datasource scope restrictions
 * Helper function for dashboard_qna profile datasource tool validation
 */
function checkDatasourceScope(
  toolName: string,
  args: Record<string, unknown> | undefined,
  allowedScope: AllowedScope
): ToolAccessDecision {
  const datasourceTools = ['list-datasources', 'get-datasource-metadata', 'query-datasource'];

  // Only enforce for datasource tools when datasourceLuidMapping exists
  if (!datasourceTools.includes(toolName) || !allowedScope.datasourceLuidMapping) {
    return { allowed: true, reason: 'allowed' };
  }

  let datasourceName: string | null = null;
  let datasourceLuid: string | null = null;

  // Extract datasource identifier from args
  if (toolName === 'list-datasources' && args && typeof args === 'object') {
    // Extract datasource name from filter: "name:eq:Minimart"
    const filter = (args as any).filter;
    if (typeof filter === 'string') {
      const nameMatch = filter.match(/name:eq:(.+)/);
      if (nameMatch) {
        datasourceName = nameMatch[1];
      }
    }
  } else if ((toolName === 'get-datasource-metadata' || toolName === 'query-datasource') && args && typeof args === 'object') {
    // Extract datasourceLuid from args
    datasourceLuid = (args as any).datasourceLuid;
  }

  // Check if datasource is in AllowedScope
  const allowedDatasources = Object.keys(allowedScope.datasourceLuidMapping);
  const allowedLuids = Object.values(allowedScope.datasourceLuidMapping);

  let isAllowed = false;
  let attemptedResource = '';

  if (datasourceName) {
    isAllowed = allowedDatasources.includes(datasourceName);
    attemptedResource = datasourceName;
  } else if (datasourceLuid) {
    isAllowed = allowedLuids.includes(datasourceLuid);
    // Try to resolve LUID to name for better error message
    const luidToNameMap = new Map<string, string>();
    Object.entries(allowedScope.datasourceLuidMapping).forEach(([name, luid]) => {
      luidToNameMap.set(luid, name);
    });
    attemptedResource = luidToNameMap.get(datasourceLuid) || datasourceLuid;

    // v263: Debug logging to diagnose LUID reuse
    if (datasourceLuid) {
      const resolvedName = luidToNameMap.get(datasourceLuid) || 'UNKNOWN';
      logger.info(`[DEBUG v263] Tool ${toolName} called with datasourceLuid: ${datasourceLuid} (resolves to: ${resolvedName})`);
      logger.info(`[DEBUG v263] Available datasources in mapping: ${JSON.stringify(allowedScope.datasourceLuidMapping)}`);
    }
  }

  if (!isAllowed && (datasourceName || datasourceLuid)) {
    const errorMsg = [
      `⚠️ The datasource "${attemptedResource}" is not available in the current dashboard scope.`,
      '',
      `**Available datasources in this dashboard:**`,
      ...allowedDatasources.map(ds => `- ${ds}`),
      '',
      `I can only answer questions about datasources within this dashboard. Would you like to ask about one of the available datasources instead?`
    ].join('\n');

    return {
      allowed: false,
      reason: 'datasource_scope',
      userMessage: errorMsg,
      logMessage: `Blocked ${toolName} - datasource "${attemptedResource}" not in dashboard scope (allowed: ${allowedDatasources.join(', ')})`
    };
  }

  return { allowed: true, reason: 'allowed' };
}

/**
 * v293: Check view/worksheet scope restrictions
 * Helper function for dashboard_qna profile view tool validation
 */
function checkViewScope(
  toolName: string,
  args: Record<string, unknown> | undefined,
  allowedScope: AllowedScope
): ToolAccessDecision {
  // Only enforce for view tools
  if (toolName !== 'list-views' && toolName !== 'get-view-data') {
    return { allowed: true, reason: 'allowed' };
  }

  const argsObj = args as any;

  // For discovery questions, block unfiltered list-views calls
  if (toolName === 'list-views' && (!argsObj || !argsObj.filter)) {
    const errorMsg = [
      `⚠️ I cannot list all views in the Tableau site while in dashboard scope mode.`,
      '',
      `**The DASHBOARD SCOPE CONTEXT above already lists all available worksheets in this dashboard:**`,
      ...(allowedScope.worksheetNames || []).map(name => `- ${name}`),
      '',
      `Please refer to the scope context above for the complete list of available data, or ask a specific question about one of these worksheets.`
    ].join('\n');

    return {
      allowed: false,
      reason: 'view_scope',
      userMessage: errorMsg,
      logMessage: `Blocked unfiltered list-views call in dashboard mode (available worksheets: ${allowedScope.worksheetNames?.join(', ')})`
    };
  }

  // For filtered list-views or get-view-data, validate the view is in scope
  if (allowedScope.worksheetLuidMapping) {
    let viewName: string | null = null;
    let viewLuid: string | null = null;

    if (toolName === 'list-views' && argsObj?.filter) {
      // Extract view name from filter: "name:eq:Money Owed" or "viewUrlName:eq:MoneyOwed"
      const nameMatch = argsObj.filter.match(/(?:name|viewUrlName):eq:(.+)/);
      if (nameMatch) {
        viewName = nameMatch[1];
      }
    } else if (toolName === 'get-view-data' && argsObj?.viewId) {
      viewLuid = argsObj.viewId;
    }

    const allowedWorksheets = Object.keys(allowedScope.worksheetLuidMapping);
    const allowedViewLuids = Object.values(allowedScope.worksheetLuidMapping);

    let isAllowed = false;
    let attemptedResource = '';

    if (viewName) {
      isAllowed = allowedWorksheets.includes(viewName);
      attemptedResource = viewName;
    } else if (viewLuid) {
      isAllowed = allowedViewLuids.includes(viewLuid);
      // Try to resolve LUID to name
      const luidToNameMap = new Map<string, string>();
      Object.entries(allowedScope.worksheetLuidMapping).forEach(([name, luid]) => {
        luidToNameMap.set(luid, name);
      });
      attemptedResource = luidToNameMap.get(viewLuid) || viewLuid;
    }

    if (!isAllowed && (viewName || viewLuid)) {
      const errorMsg = [
        `⚠️ The worksheet "${attemptedResource}" is not available in the current dashboard scope.`,
        '',
        `**Available worksheets in this dashboard:**`,
        ...allowedWorksheets.map(ws => `- ${ws}`),
        '',
        `I can only answer questions about worksheets within this dashboard. Would you like to ask about one of the available worksheets instead?`
      ].join('\n');

      return {
        allowed: false,
        reason: 'view_scope',
        userMessage: errorMsg,
        logMessage: `Blocked ${toolName} - worksheet/view "${attemptedResource}" not in dashboard scope (allowed: ${allowedWorksheets.join(', ')})`
      };
    }
  }

  return { allowed: true, reason: 'allowed' };
}

/**
 * v293: Unified policy decision function for tool access control
 * Single source of truth used for both pre-loop filtering and runtime enforcement
 *
 * Decision layers (in order):
 * 1. Profile check: Is tool allowed for dashboard_qna vs global_qna?
 * 2. Intent check: Is tool allowed for current question intent?
 * 3. Dashboard scope: If dashboard_qna, check datasource/view scope
 *
 * @param toolName - Name of the tool to check
 * @param profile - Tool profile (dashboard_qna or global_qna)
 * @param intent - Current question intent
 * @param allowedScope - Optional scope restrictions (for dashboard_qna)
 * @param args - Optional tool arguments (for runtime scope validation)
 * @returns ToolAccessDecision with allowed flag, reason, and messages
 *
 * v350: Exported for use in v3 ActionStateHandler runtime enforcement
 */
export function canUseTool(
  toolName: string,
  profile: ToolProfile,
  intent: QuestionIntent,
  allowedScope?: AllowedScope | null,
  args?: Record<string, unknown>
): ToolAccessDecision {
  // Layer 1: Profile check (primary)
  if (!isToolAllowedForProfile(toolName, profile)) {
    return {
      allowed: false,
      reason: 'profile',
      userMessage: `The assistant is not allowed to use tool "${toolName}" in this context.`,
      logMessage: `Blocked tool "${toolName}" - not allowed for profile "${profile}"`
    };
  }

  // Layer 2: Intent check (secondary)
  if (!isToolAllowedForIntent(toolName, intent)) {
    return {
      allowed: false,
      reason: 'intent',
      userMessage: `The assistant cannot use tool "${toolName}" for this type of question. Please rephrase or ask a different question.`,
      logMessage: `Blocked tool "${toolName}" - not allowed for intent "${intent}"`
    };
  }

  // Layer 3: Dashboard scope checks (tertiary - only for dashboard_qna with args)
  if (profile === 'dashboard_qna' && allowedScope && args) {
    // Check datasource scope
    const datasourceDecision = checkDatasourceScope(toolName, args, allowedScope);
    if (!datasourceDecision.allowed) {
      return datasourceDecision;
    }

    // Check view scope
    const viewDecision = checkViewScope(toolName, args, allowedScope);
    if (!viewDecision.allowed) {
      return viewDecision;
    }
  }

  // All checks passed
  return {
    allowed: true,
    reason: 'allowed',
    logMessage: `Allowed tool "${toolName}" (profile: ${profile}, intent: ${intent})`
  };
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// INTENT DETECTION - Question-level routing
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Question intent types for routing tools and guidance
 * v350: Exported for v3 ActionStateHandler runtime enforcement
 */
export type QuestionIntent =
  | 'datasource_query'      // Query data from datasources
  | 'view_dashboard_query'  // View/dashboard interactions (list-views, get-view-data, get-view-image)
  | 'pulse_query'           // Pulse metrics and insights
  | 'content_discovery'     // Search, list workbooks/views/datasources
  | 'unknown';              // Fallback to full toolset

/**
 * Intent detection context for a user question
 */
interface IntentContext {
  currentIntent: QuestionIntent;
  lastStrongIntent: QuestionIntent | null;
  confidence: 'high' | 'medium' | 'low';
  detectedKeywords: string[];
}

/**
 * Weighted keyword configuration for intent detection
 * Strong signals get 3x weight, normal keywords get 1x weight
 */
const INTENT_KEYWORDS = {
  datasource_query: {
    strong: ['datasource', 'dataset', 'query data', 'aggregate', 'group by', 'sql', 'join'], // 3x weight
    normal: ['query', 'data from', 'rows', 'filter', 'sum', 'count', 'average', 'calculate',
      'where', 'select', 'show data', 'get data', 'retrieve',
      'top', 'bottom', 'rank', 'sort by', 'order by']
  },
  view_dashboard_query: {
    strong: ['worksheet', 'view', 'dashboard', 'viz', 'visualization', 'worksheets', 'sheets', 'views'], // 3x weight
    normal: ['show me the', 'display', 'render', 'image', 'screenshot',
      'what does', 'look like', 'visual']
  },
  pulse_query: {
    strong: ['pulse', 'pulse metric', 'metric definition'], // 3x weight
    normal: ['metric', 'insight', 'definition', 'subscription', 'insight bundle']
  },
  content_discovery: {
    strong: ['search', 'find', 'explore', 'browse'], // 3x weight
    normal: ['list', 'show me all', 'what workbooks', 'what views', 'what datasources',
      'available', 'catalog', 'inventory']
  }
} as const;

/**
 * Follow-up question indicators - these suggest the user is referring to a previous query
 */
const FOLLOW_UP_INDICATORS = [
  'that', 'it', 'this', 'these', 'those', 'them',
  'sort', 'filter it', 'show more', 'same', 'also',
  'what about', 'how about', 'and'
];

/**
 * v387: Create word boundary regex for keyword matching
 * Prevents false positives from substring matches (e.g., "sum" in "summary", "view" in "review")
 */
function createWordBoundaryRegex(keyword: string): RegExp {
  // Escape special regex characters
  const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  // \b matches word boundaries (transition between \w and \W)
  // Use 'i' flag for case-insensitive matching
  return new RegExp(`\\b${escaped}\\b`, 'i');
}

/**
 * Calculate weighted keyword score for an intent
 * Strong keywords get 3x weight, normal keywords get 1x weight
 * Dynamic keywords from AllowedScope also get 3x weight (strong signals)
 *
 * v387: Uses word boundary regex instead of substring matching to prevent false positives
 */
function calculateWeightedScore(
  message: string,
  keywords: { strong: readonly string[]; normal: readonly string[] },
  dynamicKeywords: string[] = []
): { score: number; matchedKeywords: string[] } {
  const matched: string[] = [];
  let score = 0;

  // v387: Check strong keywords (3x weight) with word boundary matching
  for (const keyword of keywords.strong) {
    const regex = createWordBoundaryRegex(keyword);
    if (regex.test(message)) {
      score += 3;
      matched.push(keyword);
    }
  }

  // v387: Check normal keywords (1x weight) with word boundary matching
  for (const keyword of keywords.normal) {
    const regex = createWordBoundaryRegex(keyword);
    if (regex.test(message)) {
      score += 1;
      matched.push(keyword);
    }
  }

  // v387: Check dynamic keywords from AllowedScope (3x weight) with word boundary matching
  for (const keyword of dynamicKeywords) {
    const regex = createWordBoundaryRegex(keyword);
    if (regex.test(message)) {
      score += 3;
      matched.push(`[${keyword}]`); // Mark as dynamic with brackets
    }
  }

  return { score, matchedKeywords: matched };
}

/**
 * Infer the question intent from a user message
 *
 * @param userMessage - The current user message
 * @param lastStrongIntent - The last detected strong intent (for follow-ups)
 * @param allowedScope - Optional AllowedScope for extracting dynamic keywords (dashboard_qna profile)
 * @returns IntentContext with detected intent and confidence
 */
function inferQuestionIntent(
  userMessage: string,
  lastStrongIntent: QuestionIntent | null,
  allowedScope?: AllowedScope | null
): IntentContext {
  const wordCount = userMessage.split(/\s+/).length;

  // v387: Detect ambiguous follow-up questions with word boundary matching
  const hasFollowUpIndicator = FOLLOW_UP_INDICATORS.some(indicator => {
    const regex = createWordBoundaryRegex(indicator);
    return regex.test(userMessage);
  });
  const isShortMessage = wordCount < 10;
  const isLikelyFollowUp = hasFollowUpIndicator && isShortMessage;

  // If it's a follow-up and we have a previous intent, inherit it
  if (isLikelyFollowUp && lastStrongIntent && lastStrongIntent !== 'unknown') {
    logger.info(`[INTENT] Follow-up detected, inheriting intent: ${lastStrongIntent}`);
    return {
      currentIntent: lastStrongIntent,
      lastStrongIntent,
      confidence: 'medium',
      detectedKeywords: []
    };
  }

  // Extract dynamic keywords from AllowedScope if available (dashboard_qna profile)
  const dynamicDatasourceKeywords: string[] = [];
  const dynamicViewKeywords: string[] = [];

  if (allowedScope && allowedScope.scope === 'dashboard') {
    // Add datasource names for datasource_query intent
    if (allowedScope.datasourceNames && allowedScope.datasourceNames.length > 0) {
      dynamicDatasourceKeywords.push(...allowedScope.datasourceNames);
    }

    // Add worksheet names and dashboard name for view_dashboard_query intent
    if (allowedScope.worksheetNames && allowedScope.worksheetNames.length > 0) {
      dynamicViewKeywords.push(...allowedScope.worksheetNames);
    }
    if (allowedScope.dashboardName) {
      dynamicViewKeywords.push(allowedScope.dashboardName);
    }

    logger.info(
      `[INTENT] Dynamic keywords extracted from AllowedScope - ` +
      `Datasources: [${dynamicDatasourceKeywords.join(', ')}], ` +
      `Views/Worksheets: [${dynamicViewKeywords.join(', ')}]`
    );
  }

  // Calculate weighted scores for each intent type (with dynamic keywords)
  const datasourceResult = calculateWeightedScore(
    userMessage,
    INTENT_KEYWORDS.datasource_query,
    dynamicDatasourceKeywords
  );
  const viewResult = calculateWeightedScore(
    userMessage,
    INTENT_KEYWORDS.view_dashboard_query,
    dynamicViewKeywords
  );
  const pulseResult = calculateWeightedScore(
    userMessage,
    INTENT_KEYWORDS.pulse_query
  );
  const contentResult = calculateWeightedScore(
    userMessage,
    INTENT_KEYWORDS.content_discovery
  );

  const scores = {
    datasource_query: datasourceResult.score,
    view_dashboard_query: viewResult.score,
    pulse_query: pulseResult.score,
    content_discovery: contentResult.score
  };

  const keywordMatches = {
    datasource_query: datasourceResult.matchedKeywords,
    view_dashboard_query: viewResult.matchedKeywords,
    pulse_query: pulseResult.matchedKeywords,
    content_discovery: contentResult.matchedKeywords
  };

  // Find the intent with the highest score
  const maxScore = Math.max(...Object.values(scores));

  // If no keywords matched, return unknown
  if (maxScore === 0) {
    logger.info('[INTENT] No keywords matched, intent: unknown');
    return {
      currentIntent: 'unknown',
      lastStrongIntent: lastStrongIntent,
      confidence: 'low',
      detectedKeywords: []
    };
  }

  // Find which intent(s) have the max score
  const topIntents = Object.entries(scores)
    .filter(([_, score]) => score === maxScore)
    .map(([intent, _]) => intent as QuestionIntent);

  // If multiple intents tie, use unknown (ambiguous)
  if (topIntents.length > 1) {
    logger.info(`[INTENT] Multiple intents tied (${topIntents.join(', ')}), using: unknown`);
    return {
      currentIntent: 'unknown',
      lastStrongIntent: lastStrongIntent,
      confidence: 'low',
      detectedKeywords: []
    };
  }

  // Single clear winner
  const detectedIntent = topIntents[0];

  // Confidence based on weighted score (strong keyword match = 3 points minimum)
  const confidence: 'high' | 'medium' | 'low' =
    maxScore >= 6 ? 'high' :    // At least 2 strong keywords or 1 strong + 3 normal
    maxScore >= 3 ? 'medium' :  // At least 1 strong keyword or 3 normal keywords
    'low';                       // Less than 3 points

  // Get matched keywords for logging (safe access with default empty array)
  const matchedKeywords = keywordMatches[detectedIntent as keyof typeof keywordMatches] || [];

  logger.info(
    `[INTENT] Detected: ${detectedIntent} (confidence: ${confidence}, weighted score: ${maxScore}, ` +
    `keywords: ${matchedKeywords.join(', ')})`
  );

  return {
    currentIntent: detectedIntent,
    lastStrongIntent: confidence === 'high' ? detectedIntent : lastStrongIntent,
    confidence,
    detectedKeywords: matchedKeywords
  };
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ROW LIMIT CONSTANTS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Maximum number of rows to display in UI preview
 * Used for:
 * - query-datasource: Show up to 100 rows in UI table
 */
const MAX_VIEW_ROWS_FOR_UI = 100;

/**
 * Note: MAX_VIEW_ROWS_FOR_MODEL is now configurable via profile settings
 * (MAX_VIEW_ROWS_FOR_MODEL in config.json, defaults to 30)
 * See src/util/schema.ts for the schema definition
 */

/**
 * Remove Vega-Lite visualization specs from Pulse metric results to save LLM tokens
 * Vega specs can be 5000+ characters and aren't useful for LLM analysis
 * @param text - JSON string containing Pulse metric bundle with Vega specs
 * @returns Cleaned JSON string with viz fields removed
 */
function removeVegaSpecs(text: string): string {
  try {
    const parsed = JSON.parse(text);

    // Recursively remove all "viz" fields from the object
    function stripViz(obj: any): any {
      if (Array.isArray(obj)) {
        return obj.map(stripViz);
      } else if (obj && typeof obj === 'object') {
        const cleaned: any = {};
        for (const key in obj) {
          if (key === 'viz') {
            // Replace viz with a placeholder instead of removing completely
            cleaned[key] = '[Vega chart spec removed to save tokens]';
          } else {
            cleaned[key] = stripViz(obj[key]);
          }
        }
        return cleaned;
      }
      return obj;
    }

    const cleaned = stripViz(parsed);
    return JSON.stringify(cleaned);
  } catch (e) {
    logger.warn(`[PULSE_IMAGES] Failed to parse/clean Vega specs: ${e}`);
    return text;
  }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// INSIGHT BUNDLE - Deterministic Summaries for get-view-data
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Type definitions for Insight Bundle
 */
type ColumnType = {
  name: string;
  type: 'numeric' | 'string';
  format?: 'currency' | 'percentage';
};

type InsightBundle = {
  totalRows: number;
  baseRows?: number;  // Rows without "All" (when pivots detected)
  columnTypes: ColumnType[];
  totals?: Record<string, number>;
  groupRollups?: Record<string, Record<string, number>>;
  pivotTotals?: {
    grandTotal?: number;
    byDimension?: Record<string, Record<string, number>>;
  };
  stats?: Record<string, {
    min: number;
    max: number;
    mean: number;
    median?: number;
    count: number;
  }>;
  notes: string[];
};

/**
 * Parse a value as numeric, handling currency symbols, commas, and parentheses
 */
function parseNumeric(val: any): number | null {
  if (val === null || val === undefined || val === '') return null;
  if (typeof val === 'number') return val;

  // Handle currency: "$1,234.56" → 1234.56, "(123)" → -123
  const str = String(val).trim();
  const isNegative = str.startsWith('(') && str.endsWith(')');
  const cleaned = str
    .replace(/[$£€¥,]/g, '')  // Remove currency symbols and commas
    .replace(/[()]/g, '')      // Remove parentheses
    .trim();

  const num = Number(cleaned);
  if (isNaN(num)) return null;
  return isNegative ? -num : num;
}

/**
 * Detect if a column is numeric by sampling rows
 */
function isNumericColumn(colIndex: number, rows: any[][], sampleSize = 100): boolean {
  const sample = rows.slice(0, Math.min(sampleSize, rows.length));
  let numericCount = 0;
  let nonEmptyCount = 0;

  for (const row of sample) {
    const val = row[colIndex];
    if (val === null || val === undefined || val === '') continue;
    nonEmptyCount++;
    if (parseNumeric(val) !== null) numericCount++;
  }

  // Require 80% of non-empty values to be numeric
  return nonEmptyCount > 0 && (numericCount / nonEmptyCount) >= 0.8;
}

/**
 * Detect currency format by checking for currency symbols
 */
function detectCurrencyFormat(colIndex: number, rows: any[][]): 'currency' | 'percentage' | undefined {
  const sample = rows.slice(0, Math.min(20, rows.length));
  let currencyCount = 0;
  let percentCount = 0;

  for (const row of sample) {
    const val = row[colIndex];
    if (val === null || val === undefined) continue;
    const str = String(val);
    if (/[$£€¥]/.test(str)) currencyCount++;
    if (/%/.test(str)) percentCount++;
  }

  if (currencyCount > 0) return 'currency';
  if (percentCount > 0) return 'percentage';
  return undefined;
}

/**
 * Detect pivot structure (rows containing "All" values)
 */
function detectPivotStructure(rows: any[][]): {
  hasPivots: boolean;
  allRowIndexes: number[];
  baseRowIndexes: number[];
  pivotColumns: number[];
} {
  const allRowIndexes: number[] = [];
  const baseRowIndexes: number[] = [];
  const pivotColumns = new Set<number>();

  rows.forEach((row, rowIdx) => {
    let hasAll = false;
    row.forEach((cell, colIdx) => {
      if (cell === 'All') {
        hasAll = true;
        pivotColumns.add(colIdx);
      }
    });

    if (hasAll) {
      allRowIndexes.push(rowIdx);
    } else {
      baseRowIndexes.push(rowIdx);
    }
  });

  return {
    hasPivots: allRowIndexes.length > 0,
    allRowIndexes,
    baseRowIndexes,
    pivotColumns: Array.from(pivotColumns),
  };
}

/**
 * Compute statistics for a numeric column
 */
function computeStats(values: number[]): {
  min: number;
  max: number;
  mean: number;
  median?: number;
  count: number;
} {
  if (values.length === 0) {
    return { min: 0, max: 0, mean: 0, count: 0 };
  }

  const sorted = [...values].sort((a, b) => a - b);
  const sum = values.reduce((a, b) => a + b, 0);

  const stats: {
    min: number;
    max: number;
    mean: number;
    median?: number;
    count: number;
  } = {
    min: sorted[0],
    max: sorted[sorted.length - 1],
    mean: sum / values.length,
    count: values.length,
  };

  // Only compute median for reasonable sizes
  if (values.length <= 10000) {
    const mid = Math.floor(sorted.length / 2);
    stats.median = sorted.length % 2 === 0
      ? (sorted[mid - 1] + sorted[mid]) / 2
      : sorted[mid];
  }

  return stats;
}

/**
 * Build insight bundle from tabular data
 * Computes deterministic summaries to send to LLM instead of raw rows
 */
function buildInsightBundle(table: { columns: string[]; rows: any[][] }): InsightBundle {
  const { columns, rows } = table;
  const notes: string[] = [];

  // Detect pivot structure
  const pivotInfo = detectPivotStructure(rows);
  const rowsToAnalyze = pivotInfo.hasPivots ?
    pivotInfo.baseRowIndexes.map(i => rows[i]) :
    rows;

  if (pivotInfo.hasPivots) {
    notes.push(`Contains pivot subtotals: ${pivotInfo.allRowIndexes.length} "All" rows detected`);
    notes.push(`Computing summaries from ${rowsToAnalyze.length} base rows (excluding subtotals)`);
  }

  // Infer column types
  const columnTypes: ColumnType[] = columns.map((name, idx) => {
    const isNumeric = isNumericColumn(idx, rowsToAnalyze);
    if (isNumeric) {
      const format = detectCurrencyFormat(idx, rowsToAnalyze);
      return { name, type: 'numeric', format };
    }
    return { name, type: 'string' };
  });

  const numericColumns = columnTypes.filter(c => c.type === 'numeric');
  const dimensionColumns = columnTypes.filter(c => c.type === 'string');

  logger.info(`[INSIGHT_BUNDLE] Detected ${numericColumns.length} numeric, ${dimensionColumns.length} dimension columns`);

  // Compute totals and stats for numeric columns
  const totals: Record<string, number> = {};
  const stats: Record<string, any> = {};

  for (const col of numericColumns) {
    const colIdx = columns.indexOf(col.name);
    const values: number[] = [];

    for (const row of rowsToAnalyze) {
      const val = parseNumeric(row[colIdx]);
      if (val !== null) values.push(val);
    }

    if (values.length > 0) {
      totals[col.name] = values.reduce((a, b) => a + b, 0);
      stats[col.name] = computeStats(values);
    }
  }

  // Build group rollups (dimension → SUM(measure))
  const MAX_CARDINALITY = 100;
  const MAX_TOP_K = 10;
  const groupRollups: Record<string, Record<string, number>> = {};

  if (numericColumns.length > 0 && dimensionColumns.length > 0) {
    const primaryMeasureIdx = columns.indexOf(numericColumns[0].name);

    for (const dimCol of dimensionColumns) {
      const dimIdx = columns.indexOf(dimCol.name);
      const groups = new Map<string, number>();

      // First pass: collect distinct values and check cardinality
      for (const row of rowsToAnalyze) {
        const groupKey = String(row[dimIdx] || '(empty)');
        if (!groups.has(groupKey)) groups.set(groupKey, 0);
      }

      // Skip high-cardinality dimensions
      if (groups.size > MAX_CARDINALITY) {
        notes.push(`Skipped rollup for "${dimCol.name}": high cardinality (${groups.size} distinct values)`);
        continue;
      }

      // Second pass: aggregate
      for (const row of rowsToAnalyze) {
        const groupKey = String(row[dimIdx] || '(empty)');
        const val = parseNumeric(row[primaryMeasureIdx]);
        if (val !== null) {
          groups.set(groupKey, (groups.get(groupKey) || 0) + val);
        }
      }

      // Take top K by value
      const sorted = Array.from(groups.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, MAX_TOP_K);

      groupRollups[dimCol.name] = Object.fromEntries(sorted);
    }
  }

  // Extract pivot totals if present
  let pivotTotals: InsightBundle['pivotTotals'];
  if (pivotInfo.hasPivots && numericColumns.length > 0) {
    const primaryMeasureIdx = columns.indexOf(numericColumns[0].name);
    pivotTotals = { byDimension: {} };

    // Find grand total row (all dimensions are "All")
    for (const rowIdx of pivotInfo.allRowIndexes) {
      const row = rows[rowIdx];
      const allCount = row.filter(cell => cell === 'All').length;

      // Grand total: all dimensions are "All"
      if (allCount === pivotInfo.pivotColumns.length) {
        const val = parseNumeric(row[primaryMeasureIdx]);
        if (val !== null) {
          pivotTotals.grandTotal = val;
        }
      } else {
        // Subtotal: exactly one dimension is NOT "All"
        for (let colIdx = 0; colIdx < row.length; colIdx++) {
          if (row[colIdx] !== 'All' && !pivotInfo.pivotColumns.includes(colIdx)) {
            const dimName = columns[colIdx];
            const dimValue = String(row[colIdx]);
            const val = parseNumeric(row[primaryMeasureIdx]);

            if (val !== null) {
              if (!pivotTotals.byDimension![dimName]) {
                pivotTotals.byDimension![dimName] = {};
              }
              pivotTotals.byDimension![dimName][dimValue] = val;
            }
          }
        }
      }
    }
  }

  const bundle: InsightBundle = {
    totalRows: rows.length,
    baseRows: pivotInfo.hasPivots ? rowsToAnalyze.length : undefined,
    columnTypes,
    totals: Object.keys(totals).length > 0 ? totals : undefined,
    stats: Object.keys(stats).length > 0 ? stats : undefined,
    groupRollups: Object.keys(groupRollups).length > 0 ? groupRollups : undefined,
    pivotTotals,
    notes,
  };

  logger.info(`[INSIGHT_BUNDLE] Generated bundle: ${Object.keys(totals).length} totals, ${Object.keys(groupRollups).length} rollups, ${pivotTotals ? 'with' : 'no'} pivot totals`);

  return bundle;
}

/**
 * Summarise tool results to save LLM tokens while preserving appropriate data for UI
 * For get-view-data: send small preview + insight bundle to model, 100 rows to UI
 * For query-datasource: truncate to configured rows for model, 100 rows for UI display
 * For large arrays: provide summary for model, truncated data to UI
 * @param maxViewRowsForModel - Maximum rows to show to LLM (from session settings)
 */
export function summariseToolResult(
  name: string,
  result: unknown,
  sortSummary?: string | null,
  maxViewRowsForModel: number = 30
): {
  safeForModel: unknown;
  fullForUi?: unknown;
  displayForUi?: unknown;
} {
  // NEW: SPECIAL HANDLING FOR query-datasource ERRORS
  const isQueryDatasourceError =
    name === 'query-datasource' &&
    result &&
    typeof result === 'object' &&
    (
      (result as any).isError === true ||
      typeof (result as any).error === 'string' ||
      typeof (result as any).message === 'string'
    );

  if (isQueryDatasourceError) {
    const errMsg =
      (result as any).error ||
      (result as any).message ||
      JSON.stringify(result);

    const looksLikeUnknownField =
      /field.*not found|column.*not found|unknown column|does not exist in schema/i.test(errMsg);

    const safeForModel: any = {
      tool: name,
      status: 'error',
      error_message: errMsg,
    };

    if (looksLikeUnknownField) {
      safeForModel.error_category = 'unknown_field';
      safeForModel.recommended_next_steps = [
        'Do NOT invent fields or retry the same invalid field name.',
        'Call get-datasource-metadata for this datasourceId to inspect the actual fields available.',
        'Then re-issue query-datasource using ONLY fields that actually exist in the metadata.',
      ];
    }

    return {
      safeForModel,
      fullForUi: result,
      displayForUi: undefined,
    };
  }
  // END NEW ERROR HANDLING

  // SPECIAL HANDLING FOR Pulse Metrics: Extract human-readable insights for LLM
  if (name === 'generate-pulse-metric-value-insight-bundle') {
    try {
      logger.info(`[PULSE_VEGA] Processing generate-pulse-metric-value-insight-bundle result`);

      // Extract text content from MCP wrapper format: { content: [{ text: "..." }] }
      let resultText = '';
      if (typeof result === 'string') {
        resultText = result;
      } else if (result && typeof result === 'object') {
        const obj = result as any;
        // Handle MCP wrapper format
        if (obj.content && Array.isArray(obj.content) && obj.content[0] && obj.content[0].text) {
          resultText = obj.content[0].text;
          logger.info(`[PULSE_VEGA] Extracted text from MCP wrapper, length: ${resultText.length}`);
        }
      }

      // Extract human-readable markup text and key facts for LLM
      if (resultText && typeof resultText === 'string') {
        try {
          const parsed = JSON.parse(resultText);
          const insights: string[] = [];

          // Navigate the bundle structure to extract markup text
          if (parsed?.bundle_response?.result?.insight_groups) {
            for (const group of parsed.bundle_response.result.insight_groups) {
              if (group.insights && Array.isArray(group.insights)) {
                for (const insight of group.insights) {
                  if (insight.result?.markup) {
                    // Clean HTML tags from markup
                    const cleanMarkup = insight.result.markup.replace(/<[^>]*>/g, '');
                    insights.push(cleanMarkup);
                  }
                }
              }
            }
          }

          // Create concise summary for LLM (without Vega specs or complex JSON)
          const llmSummary = insights.length > 0
            ? insights.join('\n\n')
            : 'Pulse metric insight generated. See visualization above.';

          logger.info(`[PULSE_VEGA] Extracted ${insights.length} insight(s) for LLM (${llmSummary.length} chars vs ${resultText.length} original)`);

          // Return concise summary for LLM, original for UI
          return {
            safeForModel: llmSummary,  // LLM sees clean text summary
            fullForUi: result           // UI gets original with Vega specs for chart rendering
          };
        } catch (parseError) {
          logger.warn(`[PULSE_VEGA] Failed to parse Pulse bundle, falling back to Vega removal: ${parseError}`);
          // Fallback: remove Vega specs if parsing fails
          const textWithoutVega = removeVegaSpecs(resultText);
          return {
            safeForModel: textWithoutVega,
            fullForUi: result
          };
        }
      }
    } catch (error) {
      logger.error(`[PULSE_VEGA] Error processing Pulse metric: ${error}`);
      // Fall through to normal processing on error
    }
  }
  // END PULSE METRIC VEGA HANDLING

  // DEBUG: Log tool name being processed
  logger.info(`[DEBUG] summariseToolResult called for tool: "${name}"`);

  // Helper to check if result is tabular (CsvData)
  const isTabular = (val: any): val is CsvData =>
    val &&
    typeof val === 'object' &&
    Array.isArray(val.columns) &&
    Array.isArray(val.rows);

  // Helper to unwrap MCP content wrapper format and convert to CsvData if needed
  const unwrapContent = (val: any): any => {
    // DEBUG: Log raw structure before any processing
    logger.info(`[DEBUG] unwrapContent received - type: ${typeof val}, isArray: ${Array.isArray(val)}, keys: ${val && typeof val === 'object' ? Object.keys(val).join(', ') : 'N/A'}`);

    // MCP tools may wrap results in {content: ..., isError: ...} format
    if (val && typeof val === 'object' && 'content' in val && !('columns' in val)) {
      logger.info(`[DEBUG] Unwrapping content field from MCP result wrapper`);
      let unwrapped = val.content;

      // DEBUG: Log the unwrapped content structure
      logger.info(`[DEBUG] After unwrapping content - type: ${typeof unwrapped}, isArray: ${Array.isArray(unwrapped)}, keys: ${unwrapped && typeof unwrapped === 'object' && !Array.isArray(unwrapped) ? Object.keys(unwrapped).join(', ') : 'N/A'}`);

      // DEBUG: If it's an array, log first element structure
      if (Array.isArray(unwrapped) && unwrapped.length > 0) {
        const firstElem = unwrapped[0];
        logger.info(`[DEBUG] Content is array with ${unwrapped.length} items. First element type: ${typeof firstElem}, keys: ${firstElem && typeof firstElem === 'object' ? Object.keys(firstElem).join(', ') : 'N/A'}`);
      }

      // CRITICAL FIX: Check if content has a 'data' field with an array
      // This handles the {data: [...]} wrapper format from query-datasource
      if (unwrapped && typeof unwrapped === 'object' && !Array.isArray(unwrapped)) {
        if ('data' in unwrapped && Array.isArray(unwrapped.data)) {
          logger.info(`[DEBUG] ✅ Extracting array from 'data' field (${unwrapped.data.length} items)`);
          unwrapped = unwrapped.data; // Extract the array
        } else {
          logger.info(`[DEBUG] ⚠️  Unwrapped is object but has NO 'data' field or 'data' is not an array`);
        }
      }

      // CRITICAL: Check if this is MCP content format: [{type: "text", text: "..."}]
      if (Array.isArray(unwrapped) && unwrapped.length === 1 && typeof unwrapped[0] === 'object') {
        const firstObj = unwrapped[0];
        const objKeys = Object.keys(firstObj);
        logger.info(`[DEBUG] Array has 1 object with keys: ${objKeys.join(', ')}`);

        // If it's MCP content format {type: "text", text: "..."}, parse the text field
        if (objKeys.includes('type') && objKeys.includes('text') && firstObj.type === 'text') {
          logger.info(`[DEBUG] ✅ Detected MCP content format! Parsing 'text' field...`);

          // Helper to parse CSV string into CsvData format
          // v378: Replaced custom CSV parser with csv-parse library for RFC 4180 compliance
          const parseCsvString = (csvString: string): { columns: string[], rows: string[][] } | null => {
            try {
              // Parse CSV using csv-parse library (handles quoted fields, newlines, escaped quotes, etc.)
              const records = csvParse(csvString, {
                columns: false,  // Return arrays, not objects
                skip_empty_lines: true,
                relax_quotes: true,  // More forgiving with malformed quotes
                trim: true
              }) as string[][];

              if (records.length < 2) return null; // Need at least header + 1 data row

              const columns = records[0];
              let rows = records.slice(1);
              const originalRowCount = rows.length;

              logger.info(`[DEBUG] ✅ Parsed CSV string: ${columns.length} columns, ${originalRowCount} rows (before deduplication)`);

              // Remove duplicate rows by converting to Set of JSON strings
              const uniqueRowsSet = new Set<string>();
              const uniqueRows: string[][] = [];

              for (const row of rows) {
                const rowKey = JSON.stringify(row);
                if (!uniqueRowsSet.has(rowKey)) {
                  uniqueRowsSet.add(rowKey);
                  uniqueRows.push(row);
                }
              }

              const duplicatesRemoved = originalRowCount - uniqueRows.length;
              if (duplicatesRemoved > 0) {
                logger.info(`[DEBUG] 🗑️  Removed ${duplicatesRemoved} duplicate rows`);
              }

              // Sort rows by first column (typically name or ID)
              uniqueRows.sort((a, b) => {
                const aVal = a[0] || '';
                const bVal = b[0] || '';
                return aVal.localeCompare(bVal);
              });

              logger.info(`[DEBUG] ✅ Final result: ${columns.length} columns, ${uniqueRows.length} unique rows (sorted by first column)`);
              return { columns, rows: uniqueRows };
            } catch (error) {
              logger.error(`[ERROR] Failed to parse CSV string: ${error}`);
              return null;
            }
          };

          try {
            const parsedData = JSON.parse(firstObj.text);
            logger.info(`[DEBUG] Parsed text field - type: ${typeof parsedData}, isArray: ${Array.isArray(parsedData)}, keys: ${parsedData && typeof parsedData === 'object' && !Array.isArray(parsedData) ? Object.keys(parsedData).join(', ') : 'N/A'}`);

            // Check if parsed data is a CSV string (for get-view-data)
            if (typeof parsedData === 'string' && parsedData.includes('\n') && parsedData.includes(',')) {
              logger.info(`[DEBUG] ✅ Detected CSV string format in parsed data`);
              const csvData = parseCsvString(parsedData);
              if (csvData) {
                logger.info(`[DEBUG] 🔍 ROW COUNT TRACKING: Parsed CSV has ${csvData.rows.length} rows`);
                return csvData; // Return CsvData directly from unwrapContent
              }
            }

            // Now check if parsed data has {data: [...]} wrapper
            if (parsedData && typeof parsedData === 'object' && !Array.isArray(parsedData) && 'data' in parsedData && Array.isArray(parsedData.data)) {
              logger.info(`[DEBUG] 🔍 ROW COUNT TRACKING: parsedData.data.length = ${parsedData.data.length} items extracted from MCP content`);
              logger.info(`[DEBUG] ✅ Extracting array from 'data' field in parsed content (${parsedData.data.length} items)`);
              unwrapped = parsedData.data;
            } else if (Array.isArray(parsedData)) {
              logger.info(`[DEBUG] 🔍 ROW COUNT TRACKING: parsedData.length = ${parsedData.length} items (already array)`);
              logger.info(`[DEBUG] Parsed data is already an array (${parsedData.length} items)`);
              unwrapped = parsedData;
            } else {
              logger.info(`[DEBUG] ⚠️  Parsed data is not an array or {data: [...]} format`);
              unwrapped = parsedData;
            }
          } catch (err) {
            logger.error(`[ERROR] Failed to parse text field as JSON: ${err}`);

            // If JSON.parse fails, try parsing as CSV directly
            const rawText = firstObj.text;
            if (typeof rawText === 'string' && rawText.includes('\n') && rawText.includes(',')) {
              logger.info(`[DEBUG] ✅ JSON parse failed, attempting CSV parse on raw text`);
              const csvData = parseCsvString(rawText);
              if (csvData) {
                logger.info(`[DEBUG] 🔍 ROW COUNT TRACKING: Parsed CSV has ${csvData.rows.length} rows`);
                return csvData; // Return CsvData directly from unwrapContent
              }
            }
          }
        }
      }

      // If content is an array of objects, convert to CsvData format
      if (Array.isArray(unwrapped) && unwrapped.length > 0 && typeof unwrapped[0] === 'object') {
        logger.info(`[DEBUG] Converting array of ${unwrapped.length} objects to CsvData format`);
        const columns = Object.keys(unwrapped[0]);
        const rows = unwrapped.map(obj => columns.map(col => obj[col]));
        logger.info(`[DEBUG] 🔍 ROW COUNT TRACKING: After CsvData conversion, rows.length = ${rows.length}`);
        logger.info(`[DEBUG] Converted to CsvData: ${columns.length} columns, ${rows.length} rows`);
        return { columns, rows };
      }

      return unwrapped;
    }
    return val;
  };

  // Unwrap MCP content wrapper if present
  const unwrappedResult = unwrapContent(result);

  // DEBUG: Check if result is tabular and log structure
  const isResultTabular = isTabular(unwrappedResult);
  logger.info(`[DEBUG] isTabular check: ${isResultTabular}, result type: ${typeof unwrappedResult}, is array: ${Array.isArray(unwrappedResult)}`);
  
  if (unwrappedResult && typeof unwrappedResult === 'object' && !Array.isArray(unwrappedResult)) {
    const obj = unwrappedResult as any;
    const objKeys = Object.keys(obj).slice(0, 10).join(', ');
    logger.info(`[DEBUG] Result structure - has columns: ${Array.isArray(obj.columns)}, has rows: ${Array.isArray(obj.rows)}, row count: ${Array.isArray(obj.rows) ? obj.rows.length : 'N/A'}`);
    logger.info(`[DEBUG] Result object keys: [${objKeys}]`);
    
    // Check for common alternative structures
    if (obj.data) {
      logger.info(`[DEBUG] Result has 'data' field, type: ${typeof obj.data}, isArray: ${Array.isArray(obj.data)}`);
      if (Array.isArray(obj.data) && obj.data.length > 0) {
        logger.info(`[DEBUG] data array length: ${obj.data.length}, first item keys: ${Object.keys(obj.data[0] || {}).join(', ')}`);
      }
    }
    if (obj.results) {
      logger.info(`[DEBUG] Result has 'results' field, type: ${typeof obj.results}, isArray: ${Array.isArray(obj.results)}`);
    }
    if (obj.records) {
      logger.info(`[DEBUG] Result has 'records' field, type: ${typeof obj.records}, isArray: ${Array.isArray(obj.records)}`);
    }
  }

  // Handle tabular results from get-view-data and query-datasource
  if ((name === 'get-view-data' || name === 'query-datasource') && isTabular(unwrappedResult)) {
    const table = unwrappedResult as CsvData;
    const totalRows = table.rows.length;

    logger.info(`[DEBUG] 🔍 ROW COUNT TRACKING: table.rows.length = ${totalRows} (this becomes safeForModel.totalRows)`);
    logger.info(`[DEBUG] ✅ Tabular data detected! Tool: ${name}, Total rows in result: ${totalRows}, Columns: ${table.columns.length}`);

    // Full table for reference (keep all rows with metadata)
    const fullForUi = {
      columns: table.columns,
      rows: table.rows,
      totalRows,
    };

    // Handle safeForModel and displayForUi differently for get-view-data vs query-datasource
    let safeForModel: any;
    let displayForUi: any;

    if (name === 'get-view-data') {
      // For get-view-data: send small preview + insight bundle to model, 100 rows to UI
      const insightBundle = buildInsightBundle({ columns: table.columns, rows: table.rows });

      const truncatedRowCount = totalRows > maxViewRowsForModel ? totalRows - maxViewRowsForModel : undefined;

      safeForModel = {
        columns: table.columns,
        previewRows: table.rows.slice(0, maxViewRowsForModel),
        totalRows,
        __truncatedRows: truncatedRowCount,
        insightBundle,
      };

      // UI gets 100-row preview
      displayForUi = {
        columns: table.columns,
        rows: table.rows.slice(0, MAX_VIEW_ROWS_FOR_UI),
        totalRows,
        displayedRows: Math.min(totalRows, MAX_VIEW_ROWS_FOR_UI),
      };

      logger.info(`[DEBUG] get-view-data: Model gets ${maxViewRowsForModel} preview + insight bundle (${insightBundle.notes.length} notes), UI gets ${displayForUi.displayedRows} rows`);
      logger.info(`[INSIGHT_BUNDLE] Token savings: ${totalRows} rows → ${maxViewRowsForModel} preview + computed summaries`);
    } else if (name === 'query-datasource') {
      // v179: Use configured row limit from session settings
      const truncatedRowCount = totalRows > maxViewRowsForModel ? totalRows - maxViewRowsForModel : undefined;

      safeForModel = {
        columns: table.columns,
        rows: table.rows.slice(0, maxViewRowsForModel),
        totalRows,
        __truncatedRows: truncatedRowCount,
      };

      // Attach sort metadata if provided
      if (sortSummary) {
        (safeForModel as any).__sortMetadata = {
          summary: sortSummary,
          timestamp: new Date().toISOString()
        };
      }

      // Truncate to 100 rows for UI display
      displayForUi = {
        columns: table.columns,
        rows: table.rows.slice(0, MAX_VIEW_ROWS_FOR_UI),
        totalRows,
        displayedRows: Math.min(totalRows, MAX_VIEW_ROWS_FOR_UI),
      };

      logger.info(`[DEBUG] query-datasource: safeForModel created - rows sent to LLM: ${safeForModel.rows.length}/${totalRows}`);
      logger.info(`[DEBUG] query-datasource: displayForUi created - rows sent to UI: ${displayForUi.displayedRows}/${totalRows}`);
    }

    const modelRowCount = name === 'get-view-data' ?
      (safeForModel.previewRows?.length || 0) :
      (safeForModel.rows?.length || 0);
    logger.info(`Summarised ${name}: ${totalRows} total rows -> ${modelRowCount} rows sent to LLM`);

    return { safeForModel, fullForUi, displayForUi };
  }

  // DEBUG: Log why tabular path was not taken
  if (name === 'get-view-data' || name === 'query-datasource') {
    logger.warn(`[DEBUG] ⚠️ Tool is ${name} but data is NOT tabular! Summarisation skipped. isTabular: ${isResultTabular}`);
  } else {
    logger.info(`[DEBUG] Tool "${name}" does not match get-view-data or query-datasource, checking other paths...`);
  }

  // Fallback: handle large arrays from other tools
  if (Array.isArray(unwrappedResult) && unwrappedResult.length > 200) {
    logger.info(`[DEBUG] Large array detected: ${unwrappedResult.length} items -> truncating to 50 for LLM`);
    return {
      safeForModel: {
        __summary: `Array truncated: ${unwrappedResult.length} items total`,
        items_preview: unwrappedResult.slice(0, 50),
      },
      fullForUi: unwrappedResult,
    };
  }

  // Default: no summarisation needed
  logger.info(`[DEBUG] No summarisation applied for tool "${name}" - returning original result`);
  return { safeForModel: unwrappedResult };
}


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// PULSE GUIDANCE - Only included for global_qna profile with pulse_query intent
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// v257: PULSE_PLANNER_GUIDANCE has been migrated to database (prompt_sections table)
// v296: Now uses placeholder-based replacement {{PULSE_PLANNER_GUIDANCE}} in core_prompt
// This constant is no longer needed as content is loaded dynamically

// v257: PULSE_PRESENTATION_GUIDANCE has been migrated to database (prompt_sections table)
// v296: Now uses placeholder-based replacement {{PULSE_PRESENTATION_GUIDANCE}} in core_prompt
// This constant is no longer needed as content is loaded dynamically

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// SCOPE-BASED OPERATION SECTIONS (v183 - Conditional by toolProfile)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * MODE 1: Dashboard-Scoped operation guidance
 * Only included when toolProfile = 'dashboard_qna'
 * Saves ~8KB tokens for global_qna requests
 */
// v257: MODE_1_DASHBOARD_SCOPED has been migrated to database (prompt_sections table)
// This constant is no longer needed as content is loaded dynamically

/**
 * MODE 2: Global Access operation guidance
 * Only included when toolProfile = 'global_qna'
 * Saves ~8KB tokens for dashboard_qna requests
 */
// v257: MODE_2_GLOBAL_ACCESS has been migrated to database (prompt_sections table)
// This constant is no longer needed as content is loaded dynamically

/**
 * Scope rules that apply to BOTH modes
 * Always included regardless of toolProfile
 */
// v257: SCOPE_RULES_BOTH_MODES has been migrated to database (prompt_sections table)
// This constant is no longer needed as content is loaded dynamically

/**
 * search-content tool specific guidance (v184)
 * Only included when toolProfile = 'global_qna'
 * Saves ~4-5KB tokens for dashboard_qna requests
 * search-content tool is NOT available in dashboard_qna profile
 */
// v257: SEARCH_CONTENT_GUIDANCE has been migrated to database (prompt_sections table)
// This constant is no longer needed as content is loaded dynamically

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// INTENT-SPECIFIC GUIDANCE (v190 - Conditional by QuestionIntent)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * DATASOURCE_QUERY_GUIDANCE - Extracted from corePrompt lines 1668-1987, 2450-2544, 2854-2912
 * Only included when intent = 'datasource_query' or 'unknown'
 * Saves ~12KB tokens for pulse_query and content_discovery requests
 */
// v257: DATASOURCE_QUERY_GUIDANCE has been migrated to database (prompt_sections table)
// This constant is no longer needed as content is loaded dynamically

/**
 * CONTENT_DISCOVERY_LISTING_GUIDANCE - Extracted from corePrompt lines 2661-2726
 * Only included when intent = 'content_discovery' or 'unknown'
 * Saves ~2KB tokens for datasource_query and pulse_query requests
 */
// v257: CONTENT_DISCOVERY_LISTING_GUIDANCE has been migrated to database (prompt_sections table)
// This constant is no longer needed as content is loaded dynamically

/**
 * v198: Build cached name-to-LUID mappings prompt for follow-up questions
 * Injects mappings discovered in previous turns to eliminate redundant metadata queries
 * Only relevant for global_qna sessions with follow-up questions
 */
function buildMappingsPrompt(session: Session): string {
  if (!session.resolvedMappings) return '';

  const hasDatasources = session.resolvedMappings.datasources && session.resolvedMappings.datasources.size > 0;
  const hasViews = session.resolvedMappings.views && session.resolvedMappings.views.size > 0;
  const hasWorkbooks = session.resolvedMappings.workbooks && session.resolvedMappings.workbooks.size > 0;

  if (!hasDatasources && !hasViews && !hasWorkbooks) return '';

  // Log that we're injecting mappings
  logger.info(`[MAPPINGS] Injecting cached mappings: ${hasDatasources ? session.resolvedMappings.datasources!.size + ' datasources' : ''}${hasViews ? ', ' + session.resolvedMappings.views!.size + ' views' : ''}${hasWorkbooks ? ', ' + session.resolvedMappings.workbooks!.size + ' workbooks' : ''}`);

  let prompt = '\n\n**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**\n';
  prompt += '**CACHED NAME-TO-ID MAPPINGS FROM PREVIOUS TURNS**\n';
  prompt += '**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**\n\n';
  prompt += 'You have already resolved the following names to IDs in this session.\n';
  prompt += '**🚨 CRITICAL: ALWAYS check this cache BEFORE calling any tools! Use these IDs directly:**\n\n';

  if (hasDatasources) {
    prompt += '**Datasources:**\n';
    session.resolvedMappings.datasources!.forEach((luid, name) => {
      prompt += `  • "${name}" → datasourceLuid: "${luid}"\n`;
    });
    prompt += '\n';
  }

  if (hasViews) {
    prompt += '**Views/Dashboards:**\n';
    session.resolvedMappings.views!.forEach((viewId, name) => {
      prompt += `  • "${name}" → viewId: "${viewId}"\n`;
    });
    prompt += '\n';
  }

  if (hasWorkbooks) {
    prompt += '**Workbooks:**\n';
    session.resolvedMappings.workbooks!.forEach((workbookId, name) => {
      prompt += `  • "${name}" → workbookId: "${workbookId}"\n`;
    });
    prompt += '\n';
  }

  prompt += '**🚨 DECISION LOGIC - When to use cache vs call list-datasources:**\n\n';
  prompt += '**STEP 1: Identify the datasource/view NAME in the user\'s question**\n';
  prompt += '  - Extract the exact name from the question (e.g., "Minimart", "Sales Cloud", "Accounts Receivable")\n\n';
  prompt += '**STEP 2: Check if that EXACT NAME exists in the cache above**\n';
  prompt += '  - ✅ If YES (exact match): Use the cached LUID directly\n';
  prompt += '  - ❌ If NO (no match OR different name): Call list-datasources to find the LUID\n\n';
  prompt += '**STEP 3: Name matching is STRICT - different names = different datasources**\n';
  prompt += '  - "Minimart" ≠ "Sales Cloud" → DIFFERENT datasources, call list-datasources!\n';
  prompt += '  - "Accounts Receivable" ≠ "AR" → DIFFERENT datasources, call list-datasources!\n';
  prompt += '  - Only use cache if the name is EXACTLY the same as what\'s listed above\n\n';

  prompt += '**Example 1 - Same datasource (follow-up question):**\n';
  prompt += 'Cache: "Minimart" → "abc-123-..."\n';
  prompt += 'Turn 2: "Show me top 15 products from Minimart" (mentions "Minimart")\n';
  prompt += '  → ✅ CORRECT: Use cached LUID "abc-123-..." (name matches!)\n';
  prompt += '  → ❌ WRONG: Call list-datasources again (wasteful!)\n\n';

  prompt += '**Example 2 - Different datasource (NEW question):**\n';
  prompt += 'Cache: "Minimart" → "abc-123-..."\n';
  prompt += 'Turn 2: "What fields are in Sales Cloud datasource?" (mentions "Sales Cloud", NOT "Minimart")\n';
  prompt += '  → ✅ CORRECT: Call list-datasources with filter "name:eq:Sales Cloud" (different name!)\n';
  prompt += '  → ❌ WRONG: Use "abc-123-..." from cache (that\'s Minimart, not Sales Cloud!)\n\n';

  prompt += '**🚨 CRITICAL - NEVER use datasource/view names as LUIDs:**\n';
  prompt += 'LUIDs are ALWAYS UUIDs (36 characters with dashes). They are NEVER human-readable names.\n';
  prompt += '- ❌ WRONG: `"datasourceLuid": "accounts_receivable"` ← NAME not LUID!\n';
  prompt += '- ❌ WRONG: `"datasourceLuid": "Accounts Receivable"` ← NAME not LUID!\n';
  prompt += '- ❌ WRONG: `"datasourceLuid": "AR"` ← NAME not LUID!\n';
  prompt += '- ✅ CORRECT: `"datasourceLuid": "550e8400-e29b-41d4-a716-446655440000"` ← UUID from cache!\n\n';

  return prompt;
}

/**
 * Build system prompt based on tool profile and question intent
 * global_qna: Includes PULSE guidance + MODE 2 (Global Access) + search-content guidance
 * dashboard_qna: Excludes PULSE guidance + includes MODE 1 (Dashboard-Scoped) + excludes search-content guidance
 * v183: Conditionally includes scope mode sections to save ~8KB tokens per request
 * v184: Conditionally includes search-content guidance to save ~4-5KB tokens for dashboard_qna
 * v190: Conditionally includes intent-specific guidance based on question intent
 *       - datasource_query: Includes DATASOURCE_QUERY_GUIDANCE (~12KB)
 *       - pulse_query: Excludes datasource and content discovery guidance
 *       - content_discovery: Includes CONTENT_DISCOVERY_LISTING_GUIDANCE (~2KB)
 *       - unknown: Includes all guidance blocks (safe fallback)
 * v198: Accepts optional session parameter to inject cached name-to-LUID mappings for follow-up questions
 * v296: Pulse guidance now uses placeholder-based replacement (consistent with other guidance sections)
 * @param maxViewRowsForModel - Maximum rows to show to LLM (from profile settings, defaults to 30)
 */
async function buildSystemPrompt(toolProfile: ToolProfile, intent: QuestionIntent = 'unknown', session?: Session, maxViewRowsForModel: number = 30): Promise<string> {
  // v257: Refactored to use placeholder-based replacement with all sections loaded from database
  // This enables management of ALL prompt content via the Prompt UI
  let corePrompt: string;
  let conditionalSections: Map<string, string> = new Map();

  try {
    if (promptManager.isAvailable()) {
      // Load core prompt
      corePrompt = await promptManager.getSection('core_prompt');
      logger.info('[PromptManager] Loaded core_prompt from database');

      // Load all conditional sections from database
      const sectionNames = [
        'scope_section_dashboard',
        'scope_section_global',
        'scope_rules_both_modes',
        'content_discovery_guidance',
        'search_content_guidance',
        'pulse_planner_guidance',
        'pulse_presentation_guidance'
      ];

      for (const sectionName of sectionNames) {
        try {
          const content = await promptManager.getSection(sectionName);
          conditionalSections.set(sectionName, content);
        } catch (err) {
          logger.warn(`[PromptManager] Failed to load ${sectionName}, will use empty string`, err);
          conditionalSections.set(sectionName, '');
        }
      }

      logger.info(`[PromptManager] Loaded ${conditionalSections.size} conditional sections from database`);
    } else {
      throw new Error('PromptManager not available');
    }
  } catch (error) {
    logger.warn('[PromptManager] Failed to load prompts from database, using file fallback', error);
    // v297: Load all sections from files as fallback
    corePrompt = loadCorePromptFromFile();

    // Load all conditional sections from files
    const sectionNames = [
      'scope_section_dashboard',
      'scope_section_global',
      'scope_rules_both_modes',
      'content_discovery_guidance',
      'search_content_guidance',
      'pulse_planner_guidance',
      'pulse_presentation_guidance'
    ];

    for (const sectionName of sectionNames) {
      const content = loadPromptSectionFromFile(sectionName);
      conditionalSections.set(sectionName, content);
    }

    logger.info(`[PROMPT_FALLBACK] Loaded core_prompt and ${conditionalSections.size} conditional sections from files`);
  }

  // v257: Use placeholder-based replacement instead of regex-based injection
  // Determine which guidance blocks to include based on intent and toolProfile
  logger.info(`[INTENT] Building system prompt for intent: ${intent}, toolProfile: ${toolProfile}`);

  const includeContentDiscoveryGuidance = intent === 'content_discovery' || intent === 'unknown';
  const includeSearchContentGuidance = toolProfile === 'global_qna';
  // v294: Make Pulse guidance intent-based (only include for pulse_query or unknown)
  const includePulseGuidance = (intent === 'pulse_query' || intent === 'unknown') && toolProfile === 'global_qna';

  // Build scope section based on toolProfile
  const scopeIntro = 'You operate in one of two modes based on the scope parameter in the UI URL:\n\n';
  const conditionalModeSection = toolProfile === 'dashboard_qna'
    ? conditionalSections.get('scope_section_dashboard') || ''
    : conditionalSections.get('scope_section_global') || '';
  const scopeSection = scopeIntro + conditionalModeSection + '\n\n' + (conditionalSections.get('scope_rules_both_modes') || '');

  // Build replacement map for all placeholders
  const replacements: Record<string, string> = {
    // Use the configured value from profile settings (passed as parameter)
    MAX_VIEW_ROWS_FOR_MODEL: String(maxViewRowsForModel),

    // New placeholders for conditional sections
    SCOPE_SECTION: scopeSection,

    CONTENT_DISCOVERY_GUIDANCE: includeContentDiscoveryGuidance
      ? conditionalSections.get('content_discovery_guidance') || ''
      : '<!-- CONTENT_DISCOVERY_GUIDANCE excluded for this intent -->',

    SEARCH_CONTENT_GUIDANCE: includeSearchContentGuidance
      ? (conditionalSections.get('search_content_guidance') || '') + '\n'
      : '',

    // v296: Pulse guidance placeholders (intent-based, only for global_qna)
    PULSE_PLANNER_GUIDANCE: includePulseGuidance
      ? conditionalSections.get('pulse_planner_guidance') || ''
      : '<!-- PULSE_PLANNER_GUIDANCE excluded for this intent or profile -->',

    PULSE_PRESENTATION_GUIDANCE: includePulseGuidance
      ? conditionalSections.get('pulse_presentation_guidance') || ''
      : '<!-- PULSE_PRESENTATION_GUIDANCE excluded for this intent or profile -->',
  };

  // Replace all placeholders in a single pass
  // v272: Only support {{placeholder}} syntax (standardized from both {{}} and ${})
  let finalPrompt = corePrompt;
  for (const [key, value] of Object.entries(replacements)) {
    finalPrompt = finalPrompt.replaceAll(`{{${key}}}`, value);
  }

  logger.info(`[INTENT] Included guidance - Content Discovery: ${includeContentDiscoveryGuidance}, Search Content: ${includeSearchContentGuidance}, Pulse: ${includePulseGuidance}`);

  // v198: Inject cached mappings whenever available (global_qna only)
  // v296: Always append mappingsPrompt (after all placeholders are replaced)
  let mappingsPrompt = '';
  if (toolProfile === 'global_qna' && session) {
    mappingsPrompt = buildMappingsPrompt(session);
  }

  // v296: Pulse guidance now uses placeholders (no longer appended at end)
  return finalPrompt + mappingsPrompt;
}


/**
 * Query datasource LUIDs from datasource names using Tableau MCP Server tool
 * Uses list-datasources with filter "name:eq:<datasource name>"
 * This approach supports both PAT and OAuth authentication (unlike direct REST API calls)
 */
async function getDatasourceLuids(
  mcpClient: McpClient,
  datasourceNames: string[]
): Promise<Map<string, string>> {
  const nameToLuidMap = new Map<string, string>();

  try {
    logger.info(`Querying datasource LUIDs using Tableau MCP Server tools...`);

    for (const datasourceName of datasourceNames) {
      try {
        // Use list-datasources MCP tool with filter to find exact name match
        logger.info(`Querying LUID for datasource: "${datasourceName}"`);

        const result = await mcpClient.callTool('list-datasources', {
          filter: `name:eq:${datasourceName}`
        });

        // Parse MCP tool response - format is { content: [{ type: "text", text: "JSON string" }], isError: false }
        if (result && typeof result === 'object' && 'content' in result && !('isError' in result && result.isError)) {
          const content = (result as { content: Array<{ type: string; text: string }> }).content;

          if (content && content.length > 0 && content[0].text) {
            try {
              // Parse the text field which contains a JSON array of datasources
              const datasources = JSON.parse(content[0].text);

              if (Array.isArray(datasources) && datasources.length > 0) {
                const datasource = datasources[0];
                if (datasource.id) {
                  nameToLuidMap.set(datasourceName, datasource.id);
                  logger.info(`✅ Found LUID for "${datasourceName}": ${datasource.id}`);
                } else {
                  logger.warn(`No id field in datasource for "${datasourceName}"`);
                }
              } else {
                logger.warn(`No datasource found with name "${datasourceName}"`);
              }
            } catch (parseError) {
              logger.error(`Failed to parse list-datasources text content for "${datasourceName}":`, parseError);
            }
          } else {
            logger.warn(`No content in list-datasources response for "${datasourceName}"`);
          }
        } else if (result && typeof result === 'object' && 'isError' in result && result.isError) {
          logger.error(`list-datasources returned error for "${datasourceName}"`);
        } else {
          logger.warn(`Unexpected response format from list-datasources for "${datasourceName}": ${typeof result}`);
        }
      } catch (error) {
        logger.error(`Error querying datasource "${datasourceName}":`, error);
      }
    }

  } catch (error) {
    logger.error('Error getting datasource LUIDs from MCP Server:', error);
  }

  return nameToLuidMap;
}

/**
 * Resolve workbook ID from dashboard name and worksheet names using Tableau MCP Server tools
 * Uses search-content to find candidate workbooks, then list-views to score them based on:
 * - Dashboard name match (60 points)
 * - Worksheet coverage (40 points based on percentage)
 *
 * Returns the best matching workbook ID or indicates ambiguity if confidence is too low
 */
async function resolveWorkbookId(
  mcpClient: McpClient,
  dashboardName: string,
  worksheetNames: string[]
): Promise<{ status: 'ok'; workbookId: string; workbookName: string; worksheetLuidMapping: Record<string, string> } | { status: 'ambiguous'; candidates: string[] }> {

  // Normalize strings: trim, lowercase, normalize whitespace, remove common suffixes
  const norm = (s: string): string => {
    let normalized = s.trim().toLowerCase().replace(/\s+/g, ' ');

    // Remove common suffixes that might be added by Extensions API
    const suffixes = [
      ' (upgrade)',
      ' (copy)',
      ' (draft)',
      ' (1)',
      ' (2)',
      ' (3)',
      ' - copy',
      ' - draft'
    ];

    for (const suffix of suffixes) {
      if (normalized.endsWith(suffix)) {
        normalized = normalized.slice(0, -suffix.length).trim();
        break;
      }
    }

    return normalized;
  };

  const dn = norm(dashboardName);
  const wn = worksheetNames.map(norm);

  logger.info(`Resolving workbook ID for dashboard: "${dashboardName}"`);
  logger.info(`  Normalized dashboard name: "${dn}"`);
  logger.info(`  Worksheet names (original): ${worksheetNames.join(', ')}`);
  logger.info(`  Worksheet names (normalized): ${wn.join(', ')}`);

  try {
    // Step 1: Find candidate workbooks by searching for dashboard (view) name
    logger.info(`Searching for views matching dashboard name: "${dashboardName}"`);

    const searchResult = await mcpClient.callTool('search-content', {
      terms: dashboardName,
      filter: { contentTypes: ['view'] },
      limit: 25
    });

    // Parse MCP response to get views with parentWorkbookName
    let views: Array<{ title: string; parentWorkbookName?: string }> = [];
    if (searchResult && typeof searchResult === 'object' && 'content' in searchResult) {
      const content = (searchResult as { content: Array<{ type: string; text: string }> }).content;
      if (content && content.length > 0 && content[0].text) {
        try {
          const parsed = JSON.parse(content[0].text);
          if (Array.isArray(parsed)) {
            views = parsed;
            logger.info(`search-content returned ${views.length} views`);
          }
        } catch (parseError) {
          logger.error('Failed to parse search-content response:', parseError);
        }
      }
    }

    logger.info(`Found ${views.length} views from search`);

    // Filter to exact dashboard name matches and get unique workbook names
    const exactMatches = views.filter(v => v.title && norm(v.title) === dn);
    logger.info(`Filtered to ${exactMatches.length} exact dashboard name matches`);

    // Get unique workbook names that contain this dashboard
    const workbookNames = new Set<string>();
    for (const view of exactMatches) {
      if (view.parentWorkbookName) {
        workbookNames.add(view.parentWorkbookName);
        logger.info(`  Dashboard "${view.title}" found in workbook: "${view.parentWorkbookName}"`);
      }
    }

    logger.info(`Found ${workbookNames.size} unique workbook names containing dashboard`);

    if (workbookNames.size === 0) {
      logger.warn(`No workbooks found containing dashboard "${dashboardName}"`);
      return { status: 'ambiguous', candidates: [] };
    }

    // Step 2: Get workbook IDs by querying list-workbooks for each name
    const candidates: Array<{ workbookId: string; workbookName: string; updatedAt?: string }> = [];

    for (const workbookName of workbookNames) {
      try {
        logger.info(`Looking up workbook ID for: "${workbookName}"`);

        const workbooksResult = await mcpClient.callTool('list-workbooks', {
          filter: `name:eq:${workbookName}`,
          limit: 5
        });

        // Parse workbooks response
        if (workbooksResult && typeof workbooksResult === 'object' && 'content' in workbooksResult) {
          const content = (workbooksResult as { content: Array<{ type: string; text: string }> }).content;
          if (content && content.length > 0 && content[0].text) {
            const workbooks = JSON.parse(content[0].text);

            if (Array.isArray(workbooks) && workbooks.length > 0) {
              for (const wb of workbooks) {
                if (wb.id && wb.name) {
                  candidates.push({
                    workbookId: wb.id,
                    workbookName: wb.name,
                    updatedAt: wb.updatedAt || wb.updated_at || wb.modifiedAt
                  });
                  logger.info(`  ✅ Found workbook ID: ${wb.id} for "${wb.name}"${wb.updatedAt ? ` (updated: ${wb.updatedAt})` : ''}`);
                }
              }
            }
          }
        }
      } catch (error) {
        logger.error(`Failed to lookup workbook "${workbookName}":`, error);
      }
    }

    logger.info(`Identified ${candidates.length} candidate workbooks`);

    if (candidates.length === 0) {
      logger.warn(`No candidate workbooks found for dashboard "${dashboardName}"`);
      return { status: 'ambiguous', candidates: [] };
    }

    // Step 3: Score each candidate based on worksheet coverage
    let best: null | {
      workbookId: string;
      workbookName: string;
      score: number;
      coverage: number;
      hasDashboard: boolean;
      updatedAt?: string;
      views: Array<{ name: string; id: string }>; // Store views for worksheet mapping
    } = null;

    for (const candidate of candidates) {
      logger.info(`Scoring candidate workbook: ${candidate.workbookId} ("${candidate.workbookName}")`);

      try {
        // Get all views for this workbook
        const viewsResult = await mcpClient.callTool('list-views', {
          workbookId: candidate.workbookId,
          limit: 200
        });

        // Parse views response - capture both name and id
        let workbookViews: Array<{ name: string; id: string }> = [];
        if (viewsResult && typeof viewsResult === 'object' && 'content' in viewsResult) {
          const content = (viewsResult as { content: Array<{ type: string; text: string }> }).content;
          if (content && content.length > 0 && content[0].text) {
            try {
              const parsed = JSON.parse(content[0].text);

              // CRITICAL FIX: Filter views to only include those belonging to this specific workbook
              // The list-views API may return views from multiple workbooks, so we must filter by workbook.id
              const allViews = parsed.filter((v: any) => v.name && v.id);
              workbookViews = allViews.filter((v: any) => {
                const viewWorkbookId = v.workbook?.id;
                const belongsToWorkbook = viewWorkbookId === candidate.workbookId;

                if (!belongsToWorkbook && viewWorkbookId) {
                  logger.warn(`  ⚠️  View "${v.name}" (${v.id}) belongs to workbook ${viewWorkbookId}, not ${candidate.workbookId} - excluding`);
                }

                return belongsToWorkbook;
              });

              logger.info(`  Filtered to ${workbookViews.length} views belonging to this workbook (from ${allViews.length} total)`);

              // Debug: Log first view to confirm correct workbook
              if (workbookViews.length > 0) {
                const firstView = workbookViews[0] as any;
                logger.info(`  DEBUG: First filtered view: "${firstView.name}" workbook.id=${firstView.workbook?.id}`);
              }
            } catch (parseError) {
              logger.error(`Failed to parse list-views response for workbook ${candidate.workbookId}:`, parseError);
            }
          }
        }

        // list-views returns 'name' field (not 'title' like search-content)
        const viewNames = new Set(workbookViews.map(v => v.name ? norm(v.name) : '').filter(Boolean));
        logger.info(`  Workbook has ${viewNames.size} views`);

        // Check if dashboard exists in this workbook
        const hasDashboard = viewNames.has(dn);
        logger.info(`  Has dashboard "${dashboardName}": ${hasDashboard}`);

        // Calculate worksheet coverage
        const matchedWorksheets = wn.filter(w => viewNames.has(w));
        const coverage = wn.length > 0 ? matchedWorksheets.length / wn.length : 0;
        logger.info(`  Worksheet coverage: ${matchedWorksheets.length}/${wn.length} = ${(coverage * 100).toFixed(1)}%`);

        // Calculate score
        let score = 0;
        if (hasDashboard) score += 60;
        score += Math.round(coverage * 40);

        logger.info(`  Total score: ${score} (dashboard: ${hasDashboard ? 60 : 0}, coverage: ${Math.round(coverage * 40)})`);

        // Update best if this candidate is better
        // Tie-breaking: score > coverage > most recently updated
        const shouldUpdate = !best ||
          score > best.score ||
          (score === best.score && coverage > best.coverage) ||
          (score === best.score && coverage === best.coverage && candidate.updatedAt && best.updatedAt && candidate.updatedAt > best.updatedAt) ||
          (score === best.score && coverage === best.coverage && !best.updatedAt && candidate.updatedAt) ||
          (score === best.score && coverage === best.coverage && !candidate.updatedAt && !best.updatedAt && candidate.workbookId < best.workbookId);

        if (shouldUpdate) {
          best = {
            workbookId: candidate.workbookId,
            workbookName: candidate.workbookName,
            score,
            coverage,
            hasDashboard,
            updatedAt: candidate.updatedAt,
            views: workbookViews // Store views for later mapping
          };
          const tieBreakReason = !best ? 'first' :
            score > (best?.score || 0) ? 'higher score' :
            coverage > (best?.coverage || 0) ? 'better coverage' :
            candidate.updatedAt ? 'most recently updated' : 'lexicographic';
          logger.info(`  ✅ New best candidate! (${tieBreakReason})`);
        }

      } catch (error) {
        logger.error(`Error scoring workbook ${candidate.workbookId}:`, error);
      }
    }

    // Step 4: Apply thresholds to determine if result is confident enough
    if (!best) {
      logger.warn('No workbook could be scored');
      return { status: 'ambiguous', candidates: candidates.map(c => c.workbookId) };
    }

    if (!best.hasDashboard) {
      logger.warn(`Best candidate workbook ${best.workbookId} does not contain dashboard "${dashboardName}"`);
      return { status: 'ambiguous', candidates: candidates.map(c => c.workbookId) };
    }

    if (best.coverage < 0.6) {
      logger.warn(`Best candidate workbook ${best.workbookId} has low worksheet coverage: ${(best.coverage * 100).toFixed(1)}% (threshold: 60%)`);
      return { status: 'ambiguous', candidates: candidates.map(c => c.workbookId) };
    }

    // Step 5: Create worksheet name → view LUID mapping from the winning workbook's views
    logger.info('Creating worksheet name → view LUID mapping from winning workbook...');
    const worksheetLuidMapping: Record<string, string> = {};

    for (const worksheetName of worksheetNames) {
      const normalizedWsName = norm(worksheetName);

      // Find matching view in the best workbook's views
      const matchingView = best.views.find(v => v.name && norm(v.name) === normalizedWsName);

      if (matchingView && matchingView.id) {
        worksheetLuidMapping[worksheetName] = matchingView.id;
        // Log workbook association if available
        const workbookInfo = (matchingView as any).workbook;
        if (workbookInfo && workbookInfo.id) {
          logger.info(`  ✅ Mapped worksheet "${worksheetName}" → ${matchingView.id} (workbook: ${workbookInfo.id})`);
        } else {
          logger.info(`  ✅ Mapped worksheet "${worksheetName}" → ${matchingView.id}`);
        }
      } else {
        logger.warn(`  ⚠️  Could not find LUID for worksheet "${worksheetName}"`);
      }
    }

    logger.info(`✅ Confidently resolved workbook ID: ${best.workbookId} ("${best.workbookName}") (score: ${best.score}, coverage: ${(best.coverage * 100).toFixed(1)}%)`);
    logger.info(`✅ Mapped ${Object.keys(worksheetLuidMapping).length}/${worksheetNames.length} worksheets to view LUIDs`);

    return {
      status: 'ok',
      workbookId: best.workbookId,
      workbookName: best.workbookName,
      worksheetLuidMapping
    };

  } catch (error) {
    logger.error('Error resolving workbook ID:', error);
    return { status: 'ambiguous', candidates: [] };
  }
}

// ===== BEGIN: Sort preferences + sanitizer + summary =====

const SORT_DATE_PREFS = (process.env.SORT_DATE_PREFS ?? 'invoice date,due date,posting date,created date,date')
  .split(',').map(s => s.trim().toLowerCase()).filter(Boolean);

const SORT_NUMERIC_PREFS = (process.env.SORT_NUMERIC_PREFS ??
  'sales,amount,revenue,profit,total,total revenue,total sales,margin,quantity,sum,measure,value')
  .split(',').map(s => s.trim().toLowerCase()).filter(Boolean);

const SORT_ID_PREFS = (process.env.SORT_ID_PREFS ?? 'invoice #,invoice no,invoice number,debtor,id')
  .split(',').map(s => s.trim().toLowerCase()).filter(Boolean);

// ===== VDS TYPE DEFINITIONS =====
// Types are now imported from vds-schemas.ts (Zod-inferred) for single source of truth
// See imports at top of file: import type { VdsField, VdsFilter, VdsQuery }

function chooseDefaultSortFields(fields: { fieldCaption: string }[]): { primary: number; secondary?: number } {
  const L = (s: string) => s.toLowerCase();
  const findByPrefs = (prefs: string[]) =>
    fields.findIndex(f => {
      const fc = L(f.fieldCaption || '');
      return prefs.some(p => fc === p || fc.includes(p));
    });

  const dateIdx = findByPrefs(SORT_DATE_PREFS);
  const numIdx  = findByPrefs(SORT_NUMERIC_PREFS);
  let idIdx     = -1;

  if (dateIdx < 0 && numIdx < 0) {
    idIdx = findByPrefs(SORT_ID_PREFS);
  }

  if (dateIdx >= 0 && numIdx >= 0 && numIdx !== dateIdx) return { primary: dateIdx, secondary: numIdx };
  if (dateIdx >= 0) return { primary: dateIdx };
  if (numIdx  >= 0) return { primary: numIdx };
  if (idIdx   >= 0) return { primary: idIdx };
  return { primary: 0 }; // last resort: first requested field
}

/**
 * Unified query preprocessing - combines sort sanitization, filter normalization, and DATE validation
 * v172: Optimized from separate sanitizeVdsQuery + validateAndFixDateFilters to single-pass architecture
 * v205: Removed root-level sort auto-fix - now handled by Zod validation with clear error messages
 * v338: Exported for use in v3 state machine via toolExecutionWithInterceptors
 *
 * Performance improvements over v169-v171:
 * - Single pass through filters array (was 2 separate passes in sanitizeVdsQuery + validateAndFixDateFilters)
 * - Combines filter normalization (MATCH/SET) and DATE validation in one iteration
 * - Returns warnings array for consolidated error handling
 * - Reduces function call overhead
 *
 * This function performs:
 * 1. Sort field processing (default sort if none specified, normalization)
 * 2. Filter processing in SINGLE PASS:
 *    - MATCH filter normalization (ensure contains/startsWith/endsWith)
 *    - SET filter normalization (ensure values array)
 *    - DATE filter validation (v169-v170 auto-fix features):
 *      * v170: Detect SET with date values → convert to DATE RELATIVE
 *      * v170: Detect MATCH on date fields → warn
 *      * v173: Detect single-value SET on descriptive fields → convert to MATCH for partial matching
 *      * v169: Detect invalid date filter fields (start, end) → warn
 *      * v169: Detect missing rangeN → warn
 * 3. TOP filter sort handling
 *
 * @param query - The VDS query to preprocess
 * @returns { query: preprocessed query, warnings: array of warning messages for LLM }
 */
export function preprocessVdsQuery(query: VdsQuery): { query: VdsQuery; warnings: string[] } {
  const q: VdsQuery = { ...query, fields: [...(query.fields || [])] };
  const warnings: string[] = [];

  // ===== PART 1: SORT FIELD PROCESSING =====
  // v205: Removed root-level sort auto-fix logic - now handled by Zod validation

  // Enforce default sort if none present (primary + optional secondary)
  const existingSorts = q.fields.filter(f => typeof f.sortPriority === 'number');
  if (existingSorts.length === 0 && q.fields.length > 0) {
    const picks = chooseDefaultSortFields(q.fields);
    const pIdx = picks.primary ?? 0;
    q.fields[pIdx] = { ...q.fields[pIdx], sortPriority: 1, sortDirection: 'DESC' };

    if (typeof picks.secondary === 'number' && picks.secondary !== pIdx) {
      const sIdx = picks.secondary;
      q.fields[sIdx] = { ...q.fields[sIdx], sortPriority: 2, sortDirection: 'DESC' };
    }
  }

  // ===== PART 2: FILTER PROCESSING (SINGLE PASS - OPTIMIZATION!) =====

  if (Array.isArray(q.filters)) {
    q.filters = q.filters.map((f, idx) => {
      const nf: any = { ...f };

      // Step 2a: Normalize MATCH filters
      if (nf.filterType === 'MATCH') {
        delete nf.values;
        delete nf.matchValues;
        if (!nf.startsWith && !nf.endsWith && !nf.contains) {
          const guess = (f as any).value ?? (f as any).equals ?? (f as any).like;
          if (typeof guess === 'string' && guess.length > 0) nf.contains = guess;
        }

        // v170: Check if MATCH is being used on a date field
        if (nf.field && nf.field.fieldCaption) {
          const fieldName = String(nf.field.fieldCaption).toLowerCase();
          if (fieldName.includes('date')) {
            logger.warn(`[PREPROCESS] WARNING: MATCH filter on date field "${nf.field.fieldCaption}". This will likely fail.`);
            warnings.push(`Filter #${idx + 1}: MATCH filter used on date field "${nf.field.fieldCaption}". MATCH filters cannot be used on DATE fields - use DATE filter with periodType/dateRangeType instead!`);
          }
        }
      }

      // Step 2b: Normalize SET filters
      if (nf.filterType === 'SET') {
        if (nf.values == null) {
          const singleton = (f as any).value ?? (f as any).equals;
          if (singleton != null) nf.values = [singleton];
        }
        if (!Array.isArray(nf.values) || nf.values.length === 0) {
          throw new Error('SET filter requires a non-empty values array.');
        }
        if (typeof nf.exclude !== 'boolean') nf.exclude = false;

        // v170: Check if SET has date-like values and convert to DATE filter
        const hasDateValues = nf.values.some((v: any) => isDateLikeString(v));
        if (hasDateValues) {
          logger.warn('[PREPROCESS] CRITICAL: SET filter has date-like values. Converting to DATE filter...');
          const converted = convertDateValuesToDateFilter(nf, nf.values);
          if (converted) {
            warnings.push(`Filter #${idx + 1}: Converted SET filter with date values (${nf.values.slice(0, 3).join(', ')}${nf.values.length > 3 ? '...' : ''}) to DATE RELATIVE filter. NEVER use SET filters on DATE fields - use DATE filter with periodType/dateRangeType instead!`);
            return converted as VdsFilter;
          }
        }

        // v173: NEW - Smart SET → MATCH conversion for partial matching
        // Convert single-value SET filters to MATCH when pattern suggests partial/fuzzy search intent
        if (nf.values.length === 1 && nf.exclude !== true) {
          const value = String(nf.values[0]);
          const fieldName = (nf.field?.fieldCaption || '').toLowerCase();
          
          // Pattern detection: numeric-only or short alphanumeric strings
          const isNumericOnly = /^\d+$/.test(value);
          const isShortString = value.length < 10 && /^[a-zA-Z0-9\s-]+$/.test(value);
          
          // Field type detection: descriptive vs categorical
          const descriptivePatterns = /name|description|title|customer|debtor|vendor|account|product|item/;
          const categoricalPatterns = /^(id|code|status|type|category|flag)$/;
          const isDescriptiveField = descriptivePatterns.test(fieldName) && !categoricalPatterns.test(fieldName);
          
          // Convert if heuristics match
          if ((isNumericOnly || isShortString) && isDescriptiveField) {
            logger.warn(`[PREPROCESS] Converting single-value SET to MATCH for partial matching: "${value}" on field "${nf.field.fieldCaption}"`);
            
            warnings.push(`Filter #${idx + 1}: Converted SET filter with value "${value}" to MATCH filter for partial matching on field "${nf.field.fieldCaption}". Single-value numeric/short strings on descriptive fields benefit from fuzzy matching. Use MATCH explicitly for searches, SET for exact multi-value filtering.`);
            
            return {
              filterType: 'MATCH',
              field: nf.field,
              contains: value
            } as any as VdsFilter;
          }
        }

      }

      // Step 2c: Validate and auto-fix DATE filters (v169-v170 features)
      if (nf.filterType === 'DATE') {
        const hasInvalidFields = !!(nf.start || nf.end);

        // Check for invalid fields (start/end are not supported)
        if (hasInvalidFields) {
          logger.warn('[PREPROCESS] CRITICAL: DATE filter contains invalid fields (start, end). These fields are not supported by the API.');
          warnings.push(`Filter #${idx + 1}: DATE filter contains invalid fields (start, end). Use periodType, dateRangeType, rangeN, and anchorDate instead!`);
        }

        // v169: Check for missing rangeN when using LASTN/NEXTN
        if ((nf.dateRangeType === 'LASTN' || nf.dateRangeType === 'NEXTN') && !nf.rangeN) {
          logger.warn(`[PREPROCESS] Missing rangeN for ${nf.dateRangeType}. Cannot auto-fix.`);
          warnings.push(`Filter #${idx + 1}: dateRangeType "${nf.dateRangeType}" requires rangeN field (e.g., rangeN: 5 for 5 months)`);
        }
      }

      return nf as VdsFilter;
    });
  }

  // ===== PART 3: SORT FINALIZATION =====

  // 3a) Defensive: normalize directions & ensure unique priorities (cap at 3)
  const seen = new Set<number>();
  q.fields = q.fields.map((f) => {
    if (typeof f.sortPriority === 'number') {
      let p = Math.max(1, Math.min(3, f.sortPriority));
      while (seen.has(p) && p < 3) p++;
      if (seen.has(p)) {
        const { sortPriority, sortDirection, ...rest } = f;
        return rest as VdsField;
      }
      seen.add(p);
      const dir = (f.sortDirection || 'DESC').toUpperCase();
      return { ...f, sortPriority: p, sortDirection: dir === 'ASC' ? 'ASC' : 'DESC' };
    }
    return f;
  });

  // 3b) If query includes a TOP filter, force primary sort by the TOP measure (DESC)
  // v414: Only auto-sort if fieldToMeasure uses fieldCaption (not calculation/LOD)
  if (Array.isArray(q.filters)) {
    const topFilter = q.filters.find(f => f.filterType === 'TOP' && f.fieldToMeasure?.fieldCaption);
    if (topFilter && topFilter.filterType === 'TOP' && topFilter.fieldToMeasure?.fieldCaption) {
      // v209.3: Type narrowing for discriminated union
      const fc = topFilter.fieldToMeasure.fieldCaption.toLowerCase();
      const idx = q.fields.findIndex(f => f.fieldCaption.toLowerCase() === fc);
      if (idx >= 0) {
        q.fields[idx] = { ...q.fields[idx], sortPriority: 1, sortDirection: 'DESC' };
        q.fields = q.fields.map((f, i) =>
          i === idx ? f : { ...f, sortPriority: f.sortPriority === 1 ? 2 : f.sortPriority }
        );
      }
    }
  }

  return { query: q, warnings };
}

/**
 * v384: Extract sort summary from query-datasource arguments
 * Generates human-readable summary of fields being sorted and their directions
 *
 * @param toolArgs - The arguments passed to query-datasource
 * @returns Human-readable sort summary string, or null if no sort
 *
 * @example
 * Input: { query: { fields: [
 *   { fieldCaption: "Category", sortPriority: 1 },
 *   { fieldCaption: "Sub-Category", sortPriority: 2, sortDirection: "DESC" }
 * ]}}
 *
 * Output: "Sorted by: Category ASC, then Sub-Category DESC"
 */
export function extractSortSummary(toolArgs: any): string | null {
  try {
    // Validate input structure
    if (!toolArgs || typeof toolArgs !== 'object') {
      return null;
    }

    const query = toolArgs.query;
    if (!query || !Array.isArray(query.fields)) {
      return null;
    }

    // Extract fields with sortPriority
    interface SortedField {
      caption: string;
      priority: number;
      direction: string;
    }

    const sortedFields: SortedField[] = query.fields
      .filter((f: any) => typeof f.sortPriority === 'number')
      .map((f: any) => ({
        caption: f.fieldCaption || 'Unknown Field',
        priority: f.sortPriority,
        direction: (f.sortDirection || 'ASC').toUpperCase() // Default to ASC if not specified
      }))
      .sort((a: SortedField, b: SortedField) => a.priority - b.priority); // Sort by priority

    // No sorting applied
    if (sortedFields.length === 0) {
      return null;
    }

    // Generate human-readable summary
    const sortDescriptions = sortedFields.map((field: SortedField, index: number) => {
      const prefix = index === 0 ? '' : 'then ';
      return `${prefix}${field.caption} ${field.direction}`;
    });

    const summary = `Sorted by: ${sortDescriptions.join(', ')}`;

    logger.info(`[SORT_SUMMARY] Generated: ${summary}`, {
      fieldCount: sortedFields.length,
      fields: sortedFields.map((f: SortedField) => `${f.caption}:${f.direction}`)
    });

    return summary;
  } catch (error) {
    logger.error('[SORT_SUMMARY] Failed to extract sort summary', error);
    return null;
  }
}

/**
 * Helper: Check if value looks like a date string (YYYY-MM-DD or YYYY/MM/DD)
 */
function isDateLikeString(value: any): boolean {
  if (typeof value !== 'string') return false;
  // Match YYYY-MM-DD or YYYY/MM/DD patterns
  return /^\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(value);
}

/**
 * Helper: Convert date-like values array to DATE filter range
 * Returns null if conversion isn't possible
 */
function convertDateValuesToDateFilter(filter: any, values: string[]): any | null {
  if (values.length === 0) return null;

  // Sort dates to find min and max
  const sortedDates = values
    .filter(v => isDateLikeString(v))
    .map(v => v.replace(/\//g, '-')) // Normalize to YYYY-MM-DD
    .sort();

  if (sortedDates.length === 0) return null;

  const minDate = sortedDates[0];
  const maxDate = sortedDates[sortedDates.length - 1];

  // Parse dates to calculate month range for RELATIVE mode
  const minParts = minDate.split('-').map(Number);
  const maxParts = maxDate.split('-').map(Number);

  if (minParts.length !== 3 || maxParts.length !== 3) return null;

  const [minYear, minMonth] = minParts;
  const [maxYear, maxMonth] = maxParts;

  // Calculate number of months in range
  const monthsDiff = (maxYear - minYear) * 12 + (maxMonth - minMonth) + 1;

  // Build RELATIVE mode filter
  const anchorDate = `${minYear}-${String(minMonth).padStart(2, '0')}-01`;

  return {
    filterType: 'DATE',
    field: filter.field,
    periodType: 'MONTHS',
    dateRangeType: 'NEXTN',
    rangeN: monthsDiff,
    anchorDate: anchorDate
  };
}

// v172: Old sanitizeVdsQuery function removed - merged into preprocessVdsQuery
// v377: Query context helper functions (buildSortSummary, extractQueryContext, buildQueryErrorRecoveryHint,
//       buildExecutionPhaseHint, buildFinalPresentationReminder) removed - now handled by V3 state machine
//       via QueryContextBuilder module and interceptors

// ===== END: Sort preferences + sanitizer + summary =====


/**
 * AllowedScope represents the dashboard context for scope=dashboard mode
 */
export interface AllowedScope {
  scope: 'dashboard';
  dashboardName: string;
  worksheetNames: string[];
  datasourceIds: string[];
  datasourceNames?: string[];
  datasourceLuidMapping?: Record<string, string>; // Maps datasource names to REST API LUIDs
  workbookId?: string; // Resolved workbook ID for dashboard scope (INCLUDE_WORKBOOK_IDS)
  workbookName?: string; // Resolved workbook name for dashboard scope
  worksheetLuidMapping?: Record<string, string>; // Maps worksheet names to view LUIDs (REST API)
  pulseMetricIds?: string[];
  worksheetCount?: number;
  datasourceCount?: number;
  notes?: string;
  generatedAt: string;
  version?: string;
  worksheetDatasources?: Record<string, string[]>; // Maps worksheet names to their underlying datasource names
}

/**
 * Query context tracking for dynamic presentation reminders
 * Captures what user requested vs what was actually received from query-datasource
 */
interface QueryContext {
  userRequestedRows: number | null;        // From query: "top 25 products"
  actualRowsReceived: number | null;       // From metadata.displayedRows
  totalRowsInDataset: number | null;       // From metadata.totalRows
  truncatedRows: number;                   // From metadata.truncatedRows
  isAggregated: boolean;                   // Detected from query structure (GROUP BY)
  aggregationLevel: string | null;         // e.g., "GROUP BY Product"
  metricColumns: string[];                 // e.g., ["Total Revenue", "Sum(Sales)"]
  reminderInjected: boolean;               // Flag to prevent infinite loops - only inject reminder once
  executionHintInjected: boolean;          // Flag to prevent duplicate execution-phase hints
  
  // v174: Result metadata for anti-hallucination guidance
  resultColumns?: any[];                   // Column metadata from query result
  hasNumericColumns?: boolean;             // True if result contains numeric columns
  hasMonetaryColumns?: boolean;            // True if result has monetary-looking columns
  hasCurrencyField?: boolean;              // True if result has explicit currency/currency code field
}

interface Session {
  id: string;
  llm: ILlm;
  mcpClient: McpClient;
  messages: Message[];
  toolCallCount: number;
  evidence: CsvData[];
  tabularResults?: Record<string, CsvData>; // Store full tabular results keyed by tool call id
  aborted: boolean; // Flag to cancel ongoing operations
  allowedScope?: AllowedScope;
  profile?: string; // Profile name for MCP client reconnection
  tableauUser?: string | null; // Tableau username from dashboard extension
  authenticationType?: string; // Authentication type (pat, direct-trust)
  effectiveSubClaim?: string | null; // JWT sub claim to use for Direct Trust auth
  llmProvider?: 'openai' | 'local' | 'bedrock'; // LLM provider for debugging/tracing
  maxViewRowsForModel?: number; // Maximum rows for LLM (from profile settings)

  // Multi-turn conversation history fields
  coreSystemPrompt?: string | null;   // main guardrail prompt
  scopeSystemPrompt?: string | null;  // latest scope context prompt
  history?: Message[];                // multi-turn user/assistant messages

  // Query context for dynamic presentation reminders
  lastQueryContext: QueryContext | null;

  // NEW: Error tracking and recovery for query-datasource
  lastQueryError?: {
    toolName: string;
    safeForModel: any;
    rawResult: unknown;
    args: Record<string, unknown>;
  } | null;
  lastQueryErrorRecoveryInjected?: boolean;
  firstQueryDatasourceHintInjected?: boolean;

  // v211: Lightweight repair context for validation errors (saves ~50K tokens per retry)
  pendingValidationRepair?: {
    toolCallId: string;
    originalUserPrompt: string;
    invalidArgs: unknown;
    validationErrors: Array<{ path: string; message: string }>;
    validationSummary: string;
    lastSuccessfulToolResult: string | null;
    attemptCount: number;
  };
  lastSuccessfulToolResult?: string | null; // Track last successful tool result for repair context

  // Intent tracking for question-level routing
  lastStrongIntent?: QuestionIntent | null;

  // v198: Name-to-LUID cache for global_qna sessions (eliminates redundant metadata queries)
  resolvedMappings?: {
    datasources?: Map<string, string>;     // datasource name → LUID
    views?: Map<string, string>;           // view/dashboard name → viewId
    workbooks?: Map<string, string>;       // workbook name → workbookId
  } | null;

  // v295: Token tracking for cost analysis and optimization
  tokenTracking?: SessionTokenTracking;

  // v301: Actual token usage from LLM provider (replaces estimates when available)
  actualUsage?: Array<{
    iteration: number;
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  }>;

  // v298: Physical cancellation support for aborting in-flight LLM requests
  abortController?: AbortController;
}

const sessions = new Map<string, Session>();

export interface BrokerMessage {
  type: 'user_prompt' | 'cancel' | 'context_update' | 'debug_start_session' | 'debug_stop_session' | 'debug_call_tool';
  text?: string;
  temperature?: number;
  context?: unknown;
  allowedScope?: AllowedScope;
  payload?: any;
}

/**
 * Handle context update from frontend - hydrate Pulse metrics and store in session
 */
async function handleContextUpdate(
  ws: WebSocket,
  session: Session,
  allowedScope?: AllowedScope
): Promise<void> {
  if (!allowedScope) {
    logger.warn('Context update received but allowedScope is missing');
    ws.send(JSON.stringify({
      type: 'context_updated',
      success: false,
      message: 'No scope provided'
    }));
    return;
  }

  logger.info(`Processing context update for dashboard: ${allowedScope.dashboardName}`);
  logger.info(`Worksheets: ${allowedScope.worksheetNames.join(', ')}`);
  logger.info(`Datasources: ${allowedScope.datasourceIds.join(', ')}`);
  logger.info(`WorksheetDatasources provided: ${allowedScope.worksheetDatasources ? 'YES' : 'NO'}`);
  if (allowedScope.worksheetDatasources) {
    logger.info(`WorksheetDatasources mapping: ${JSON.stringify(allowedScope.worksheetDatasources)}`);
  }

  // If datasource names are provided (dashboard scope), reconnect MCP client with INCLUDE_DATASOURCE_IDS
  // NOTE: Extension API ds.id returns internal IDs like "sqlproxy.xxx" which are NOT REST API LUIDs
  // We use the Tableau MCP Server's list-datasources tool to resolve names to LUIDs (supports PAT and OAuth)
  if (allowedScope.datasourceNames && allowedScope.datasourceNames.length > 0) {
    logger.info('Dashboard scope detected with datasource names - querying for LUIDs using MCP tools');

    try {
      // IMPORTANT: We need a CLEAN MCP client without INCLUDE_DATASOURCE_IDS to query all datasources
      // The current session.mcpClient might already have INCLUDE_DATASOURCE_IDS from a previous context_update
      // So we create a temporary client without datasource filtering to perform the lookup

      logger.info('Creating temporary MCP client without INCLUDE_DATASOURCE_IDS for datasource lookup');
      const port = config.getEnv().PORT;
      const tempProfileParam = session.profile ? `profile=${encodeURIComponent(session.profile)}` : '';
      const tempJwtSubClaimParam = session.effectiveSubClaim ? `jwt_sub_claim=${encodeURIComponent(session.effectiveSubClaim)}` : '';
      const tempQueryParams = [tempProfileParam, tempJwtSubClaimParam].filter(Boolean).join('&');
      const tempMcpWsUrl = tempQueryParams ? `ws://127.0.0.1:${port}/mcp/ws?${tempQueryParams}` : `ws://127.0.0.1:${port}/mcp/ws`;

      // v386: Wrap temporary MCP client in try...finally to ensure cleanup
      const tempMcpClient = await createMcpClient(tempMcpWsUrl);
      let datasourceLuids: string[] = [];  // v386: Declare outside try block for scope access
      try {
        // Query datasource LUIDs using the temporary clean client
        logger.info(`Querying datasource LUIDs for: ${allowedScope.datasourceNames.join(', ')}`);
        const nameToLuidMap = await getDatasourceLuids(
          tempMcpClient,
          allowedScope.datasourceNames
        );

        datasourceLuids = Array.from(nameToLuidMap.values());

        if (datasourceLuids.length === 0) {
          logger.error('❌ Failed to resolve datasource LUIDs - cannot set INCLUDE_DATASOURCE_IDS');
          logger.error(`   Requested datasources: ${allowedScope.datasourceNames.join(', ')}`);
          logger.error('   Dashboard scope mode requires valid datasource LUIDs to function properly');

          ws.send(JSON.stringify({
            type: 'context_updated',
            success: false,
            message: `Failed to resolve datasource LUIDs for: ${allowedScope.datasourceNames.join(', ')}. Dashboard scope mode cannot be enabled without valid datasource identifiers.`
          }));
          return;
        }

        // Successfully resolved LUIDs - proceed with datasource scope mode
        logger.info(`Successfully retrieved ${datasourceLuids.length} datasource LUIDs: ${datasourceLuids.join(', ')}`);

        // Log the name-to-LUID mapping for debugging
        const mappingObj: Record<string, string> = {};
        for (const [name, luid] of nameToLuidMap.entries()) {
          mappingObj[name] = luid;
          logger.info(`  "${name}" → ${luid}`);
        }

        // Store the name-to-LUID mapping in allowedScope for system prompt
        allowedScope.datasourceLuidMapping = mappingObj;
      } finally {
        // v386: Guaranteed cleanup - ensures disconnect even if error thrown or early return
        await tempMcpClient.disconnect();
        logger.info('Disconnected temporary MCP client (datasource resolution)');
      }

      // Resolve workbook ID for dashboard scope (INCLUDE_WORKBOOK_IDS)
      // This ensures tools only query/return data from views within the correct workbook
      logger.info('Resolving workbook ID for dashboard scope...');

      // v386: Wrap temporary MCP client in try...finally to ensure cleanup
      // Create another temporary clean MCP client for workbook ID resolution
      const tempMcpClient2 = await createMcpClient(tempMcpWsUrl);
      let workbookId: string | undefined;  // v386: Declare outside try block for scope access
      let workbookName: string | undefined;  // v386: Declare outside try block for scope access
      try {
        const workbookResult = await resolveWorkbookId(
          tempMcpClient2,
          allowedScope.dashboardName,
          allowedScope.worksheetNames
        );

        if (workbookResult.status === 'ok') {
          workbookId = workbookResult.workbookId;
          workbookName = workbookResult.workbookName;
          logger.info(`✅ Successfully resolved workbook ID: ${workbookId} ("${workbookName}")`);
          allowedScope.workbookId = workbookId;
          allowedScope.workbookName = workbookName;

          // Store worksheet name → view LUID mapping from resolveWorkbookId result
          allowedScope.worksheetLuidMapping = workbookResult.worksheetLuidMapping;
          logger.info(`✅ Stored worksheet LUID mapping: ${Object.keys(workbookResult.worksheetLuidMapping).length}/${allowedScope.worksheetNames.length} worksheets mapped`);
        } else {
          logger.error('❌ Failed to resolve workbook ID - ambiguous result');
          logger.error(`   Dashboard: "${allowedScope.dashboardName}"`);
          logger.error(`   Worksheets: ${allowedScope.worksheetNames.join(', ')}`);
          logger.error(`   Candidate workbooks: ${workbookResult.candidates.join(', ') || 'none'}`);

          ws.send(JSON.stringify({
            type: 'context_updated',
            success: false,
            message: `Failed to uniquely identify workbook for dashboard "${allowedScope.dashboardName}". This may be because:\n` +
                     `- Multiple workbooks have dashboards with the same name\n` +
                     `- Less than 60% of worksheets were found in the candidate workbook\n` +
                     `- No matching workbooks were found\n\n` +
                     `Dashboard scope mode cannot be enabled without a unique workbook identifier.`
          }));
          return;
        }
      } finally {
        // v386: Guaranteed cleanup - consolidates disconnect from both success/error branches
        await tempMcpClient2.disconnect();
        logger.info('Disconnected temporary MCP client (workbook resolution)');
      }

      // Disconnect existing MCP client
      await session.mcpClient.disconnect();

      // Reconnect with both datasource LUIDs and workbook ID
      const datasourceLuidsParam = `datasource_ids=${encodeURIComponent(datasourceLuids.join(','))}`;
      const workbookIdParam = workbookId ? `workbook_id=${encodeURIComponent(workbookId)}` : '';
      const reconnectProfileParam = session.profile ? `profile=${encodeURIComponent(session.profile)}` : '';
      const reconnectJwtSubClaimParam = session.effectiveSubClaim ? `jwt_sub_claim=${encodeURIComponent(session.effectiveSubClaim)}` : '';
      const reconnectQueryParams = [reconnectProfileParam, datasourceLuidsParam, workbookIdParam, reconnectJwtSubClaimParam].filter(Boolean).join('&');
      const mcpWsUrl = `ws://127.0.0.1:${port}/mcp/ws?${reconnectQueryParams}`;

      logger.info(`Reconnecting to MCP server with dashboard scope (datasource LUIDs + workbook ID): ${mcpWsUrl}`);
      session.mcpClient = await createMcpClient(mcpWsUrl);
      logger.info('MCP client reconnected successfully with dashboard scope');
    } catch (error) {
      logger.error('⚠️  Failed to query datasource LUIDs or reconnect MCP client with datasource scope', error);
      logger.warn('   Continuing in GLOBAL SCOPE mode (INCLUDE_DATASOURCE_IDS not set)');
      // Don't return - continue with global scope mode
    }
  }

  // Hydrate Pulse metrics from datasources
  try {
    const pulseMetricIds: string[] = [];

    // Get all Pulse metric subscriptions for the user
    const subscriptions = await session.mcpClient.callTool('list-pulse-metric-subscriptions', {});

    if (subscriptions && typeof subscriptions === 'object' && 'metric_ids' in subscriptions) {
      const metricIds = (subscriptions as { metric_ids: string[] }).metric_ids;

      if (metricIds.length > 0) {
        // Get metric details to find datasource associations
        const metrics = await session.mcpClient.callTool('list-pulse-metrics-from-metric-ids', {
          metric_ids: metricIds
        });

        if (metrics && typeof metrics === 'object' && 'metrics' in metrics) {
          const metricsList = (metrics as { metrics: Array<{ id: string; definition?: { datasource?: { id: string } } }> }).metrics;

          // Filter metrics that belong to datasources in this dashboard
          for (const metric of metricsList) {
            const datasourceId = metric.definition?.datasource?.id;
            if (datasourceId && allowedScope.datasourceIds.includes(datasourceId)) {
              pulseMetricIds.push(metric.id);
            }
          }

          logger.info(`Hydrated ${pulseMetricIds.length} Pulse metrics for dashboard scope`);
        }
      }
    }

    // Store hydrated scope in session
    const hydratedScope: AllowedScope = {
      ...allowedScope,
      pulseMetricIds,
      worksheetCount: allowedScope.worksheetNames.length,
      datasourceCount: allowedScope.datasourceIds.length,
      version: 'v1'
    };

    session.allowedScope = hydratedScope;

    // Store scope context (will be injected fresh each turn, not pushed to messages)
    const scopeMessage = buildScopeContextMessage(hydratedScope);
    session.scopeSystemPrompt = scopeMessage;

    // Build greeting message with available objects
    const greeting = buildGreetingMessage(hydratedScope);

    ws.send(JSON.stringify({
      type: 'context_updated',
      success: true,
      scope: hydratedScope,
      greeting: greeting
    }));

    logger.info(`Context updated successfully for session: ${session.id}`);
  } catch (error) {
    logger.error('Failed to hydrate Pulse metrics', error);

    // Store scope without Pulse metrics
    const partialScope: AllowedScope = {
      ...allowedScope,
      pulseMetricIds: [],
      worksheetCount: allowedScope.worksheetNames.length,
      datasourceCount: allowedScope.datasourceIds.length,
      notes: 'Pulse metrics could not be hydrated',
      version: 'v1'
    };

    session.allowedScope = partialScope;

    // Store scope context (will be injected fresh each turn, not pushed to messages)
    const scopeMessage = buildScopeContextMessage(partialScope);
    session.scopeSystemPrompt = scopeMessage;

    // Build greeting message with available objects
    const greeting = buildGreetingMessage(partialScope);

    ws.send(JSON.stringify({
      type: 'context_updated',
      success: true,
      scope: partialScope,
      warning: 'Pulse metrics could not be hydrated',
      greeting: greeting
    }));
  }
}

/**
 * Build greeting message for LLM to introduce available dashboard objects
 * NOTE: Pulse Metrics are NOT exposed via Extensions API, so we exclude them from the greeting
 */
function buildGreetingMessage(scope: AllowedScope): string {
  let greeting = `Hello! I'm your Tableau assistant for the **${scope.dashboardName}** dashboard`;

  // Add workbook name if available (dashboard scope mode)
  if (scope.workbookName) {
    greeting += ` in the **${scope.workbookName}** workbook`;
  }

  greeting += `.\n\n`;

  // Add a note about workbook scope
  if (scope.workbookId && scope.workbookName) {
    greeting += `📘 All queries will use workbook: **${scope.workbookName}** (ID: \`${scope.workbookId}\`)\n\n`;
  }

  greeting += `I can help you analyze data from the following objects:\n\n`;

  if (scope.worksheetNames && scope.worksheetNames.length > 0) {
    greeting += `**Worksheets** (${scope.worksheetCount}):\n`;
    scope.worksheetNames.forEach(name => {
      greeting += `• ${name}`;

      // Show underlying datasources if available
      if (scope.worksheetDatasources && scope.worksheetDatasources[name] && scope.worksheetDatasources[name].length > 0) {
        const datasources = scope.worksheetDatasources[name];
        if (datasources.length === 1) {
          greeting += ` → uses datasource: ${datasources[0]}`;
        } else {
          greeting += ` → uses datasources: ${datasources.join(', ')}`;
        }
      }

      greeting += `\n`;
    });
    greeting += `\n`;
  }

  if (scope.datasourceNames && scope.datasourceNames.length > 0) {
    greeting += `**Published Data Sources** (${scope.datasourceCount}):\n`;
    scope.datasourceNames.forEach(name => {
      greeting += `• ${name}\n`;
    });
    greeting += `\n`;
  }

  greeting += `Feel free to ask me questions about this data! I can:\n`;
  greeting += `• Analyze data from these worksheets\n`;
  greeting += `• Query fields and values from the published data sources or underlying datasources\n`;
  greeting += `• Compare trends and identify patterns\n\n`;
  greeting += `What would you like to know?`;

  return greeting;
}

/**
 * Build scope context message for LLM
 */
function buildScopeContextMessage(scope: AllowedScope): string {
  let message = `**DASHBOARD SCOPE CONTEXT**
You are now scoped to dashboard: "${scope.dashboardName}"

Allowed Worksheets (${scope.worksheetCount}):
${scope.worksheetNames.map(name => {
  let line = `- ${name}`;
  // Include view LUID if available
  if (scope.worksheetLuidMapping && scope.worksheetLuidMapping[name]) {
    line += ` (View LUID: ${scope.worksheetLuidMapping[name]})`;
  }
  // Include underlying datasources if available
  if (scope.worksheetDatasources && scope.worksheetDatasources[name] && scope.worksheetDatasources[name].length > 0) {
    const datasources = scope.worksheetDatasources[name];
    line += ` (uses: ${datasources.join(', ')})`;
  }
  return line;
}).join('\n')}

${scope.worksheetLuidMapping && Object.keys(scope.worksheetLuidMapping).length > 0 ? `
⚠️ CRITICAL: When calling view-related tools (get-view-data, list-views, etc.), you MUST use the view LUID (not the worksheet name) to avoid scope errors.

Worksheet Name → View LUID Mapping:
${Object.entries(scope.worksheetLuidMapping).map(([name, luid]) => `  "${name}" → ${luid}`).join('\n')}

Example: To query data from "Invoice Vs Outstanding Receivables" worksheet, use:
  { "viewLuid": "${Object.values(scope.worksheetLuidMapping)[0]}" }
NOT:
  { "viewName": "Invoice Vs Outstanding Receivables" }
` : ''}

Allowed Data Sources (${scope.datasourceCount}):
${scope.datasourceLuidMapping && Object.keys(scope.datasourceLuidMapping).length > 0
  ? Object.entries(scope.datasourceLuidMapping).map(([name, luid]) => `- ${name} (LUID: ${luid})`).join('\n')
  : scope.datasourceNames && scope.datasourceNames.length > 0
    ? scope.datasourceNames.map(name => `- ${name}`).join('\n')
    : scope.datasourceIds.map(id => `- ${id}`).join('\n')}

${scope.datasourceLuidMapping && Object.keys(scope.datasourceLuidMapping).length > 0 ? `
⚠️ CRITICAL: When calling datasource-related tools (get-datasource-metadata, query-datasource, etc.), you MUST use the datasource LUID, NOT the datasource name.

⚠️ ANTI-REUSE RULE: NEVER reuse a datasourceLuid from a previous query!
   - Each query MUST look up the correct LUID for the datasource name mentioned
   - Example: If user asks about "Accounts Receivable" after querying "Minimart", you MUST find "Accounts Receivable" → LUID mapping, NOT reuse Minimart's LUID
   - Even within the same conversation, always look up the datasource name in the mapping below

Datasource Name → LUID Mapping:
${Object.entries(scope.datasourceLuidMapping).map(([name, luid]) => `  "${name}" → ${luid}`).join('\n')}

Example workflow for datasource query:
1. User asks: "Query the Accounts Receivable datasource"
2. You lookup: "Accounts Receivable" in the mapping above → get its LUID
3. You call: query-datasource with { "datasourceLuid": "<Accounts Receivable LUID>" }

WRONG (will query wrong datasource):
  - Using a LUID from a previous query about a different datasource
  - Using the datasource name directly: { "datasourceLuid": "Accounts Receivable" }
` : ''}

${scope.pulseMetricIds && scope.pulseMetricIds.length > 0 ? `Allowed Pulse Metrics (${scope.pulseMetricIds.length}):
${scope.pulseMetricIds.map(id => `- ${id}`).join('\n')}` : ''}

${scope.notes ? `Notes: ${scope.notes}` : ''}

You MUST reference ONLY these objects in tool calls. Any reference to objects outside this scope will be rejected.`;

  return message;
}

export function createBrokerServer(wss: WebSocketServer): void {
  wss.on('connection', async (ws: WebSocket, request) => {
    const url = new URL(request.url || '', `http://localhost`);
    const sessionId = url.searchParams.get('sid');

    if (!sessionId) {
      ws.send(JSON.stringify({ type: 'error', message: 'Missing session ID' }));
      ws.close();
      return;
    }

    const session = sessions.get(sessionId);
    if (!session) {
      ws.send(JSON.stringify({ type: 'error', message: 'Invalid session ID' }));
      ws.close();
      return;
    }

    // Conditional history debug logging (enable with HISTORY_DEBUG_LOGS=1)
    if (process.env.HISTORY_DEBUG_LOGS === '1') {
      logger.info(`[HISTORY DEBUG] Broker client connected for session: ${sessionId}`);
      logger.info(`[HISTORY DEBUG] Session has ${session.history?.length || 0} messages in history (${(session.history?.length || 0) / 2} turns)`);
    } else {
      logger.info(`Broker client connected for session: ${sessionId}`);
    }

    // Setup heartbeat to keep connection alive (Heroku timeout is 55 seconds)
    const heartbeatInterval = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.ping();
        logger.debug(`Sent ping to session: ${sessionId}`);
      }
    }, 30000); // Ping every 30 seconds

    // Handle pong responses
    ws.on('pong', () => {
      logger.debug(`Received pong from session: ${sessionId}`);
    });

    ws.on('message', async (data: Buffer) => {
      try {
        const message = JSON.parse(data.toString()) as BrokerMessage;

        if (message.type === 'user_prompt') {
          const parsed = UserPromptSchema.parse(message);
          session.aborted = false; // Reset abort flag
          // v298: Create new AbortController for this request
          session.abortController = new AbortController();

          // v377: Execute user prompt using V3 state machine (only code path)
          await handleUserPrompt(ws, session, parsed.text, parsed.temperature);
        } else if (message.type === 'cancel') {
          logger.info(`Cancelling request for session: ${sessionId}`);
          session.aborted = true;
          // v298: Physically abort the in-flight LLM request
          if (session.abortController) {
            session.abortController.abort();
            logger.info('[v298 CANCEL] Aborted in-flight LLM request');
          }
          ws.send(JSON.stringify({
            type: 'cancelled',
            message: 'Request cancelled by user'
          }));
        } else if (message.type === 'context_update') {
          logger.info(`Received context update for session: ${sessionId}`);
          await handleContextUpdate(ws, session, message.allowedScope);
        } else if (message.type === 'debug_start_session') {
          logger.info(`Debug: Starting MCP session for profile: ${message.payload?.profile}`);
          await handleDebugStartSession(ws, session, message.payload);
        } else if (message.type === 'debug_stop_session') {
          logger.info(`Debug: Stopping MCP session`);
          await handleDebugStopSession(ws, session, message.payload);
        } else if (message.type === 'debug_call_tool') {
          logger.info(`Debug: Calling tool: ${message.payload?.toolName}`);
          await handleDebugCallTool(ws, session, message.payload);
        } else {
          ws.send(JSON.stringify({ type: 'error', message: 'Unknown message type' }));
        }
      } catch (error) {
        logger.error('Broker message error', error);
        ws.send(JSON.stringify({
          type: 'error',
          message: error instanceof Error ? error.message : String(error),
        }));
      }
    });

    ws.on('close', async () => {
      clearInterval(heartbeatInterval);
      logger.info(`Broker client disconnected: ${sessionId}`);
      // v298: Clean up session to prevent memory/connection leaks
      await deleteSession(sessionId);
    });

    ws.on('error', (error) => {
      logger.error('Broker WebSocket error', error);
    });
  });

  logger.info('Broker server initialized on /broker/ws');
}

async function handleUserPrompt(ws: WebSocket, session: Session, text: string, temperature?: number): Promise<void> {
  logger.info(`Processing user prompt for session: ${session.id} with temperature: ${temperature ?? 'default'}`);
  
  // v377: V3 state machine is now the only code path (old orchestration removed)
  return await handleUserPromptV3(ws, session, text, temperature);
}


/**
 * Create a new session
 */
export async function createSession(
  model: string,
  temperature?: number | null,
  systemPrompt?: string | null,
  profileName?: string,
  tableauUser?: string | null
): Promise<string> {
  const settings = await config.getSettings(profileName);

  // Validate provider-specific requirements
  const provider = settings.LLM_PROVIDER || 'openai';
  if (provider === 'openai' && !settings.OPENAI_API_KEY) {
    throw new Error('OpenAI API key not configured');
  }
  if (provider === 'local') {
    if (!settings.LOCAL_BASE_URL) {
      throw new Error('Local LLM Base URL not configured');
    }
    if (!settings.LOCAL_MODEL) {
      throw new Error('Local LLM Model not configured');
    }
  }
  if (provider === 'bedrock') {
    if (!settings.BEDROCK_REGION) {
      throw new Error('AWS Bedrock region not configured');
    }
    if (!settings.BEDROCK_MODEL_ID) {
      throw new Error('AWS Bedrock model ID not configured');
    }
  }

  const sessionId = generateSessionId();

  // Determine authentication type and effective JWT sub claim
  const authenticationType = settings.AUTHENTICATION_TYPE || 'pat';
  let effectiveSubClaim: string | null = null;

  if (authenticationType === 'direct-trust') {
    // For Direct Trust, use Tableau user if available, otherwise fallback to configured JWT_SUB_CLAIM
    if (tableauUser && tableauUser.trim() !== '') {
      effectiveSubClaim = tableauUser;
      logger.info(`Using Tableau username from worksheet: ${tableauUser}`);
    } else {
      effectiveSubClaim = settings.JWT_SUB_CLAIM || null;
      logger.info(`Using fallback JWT_SUB_CLAIM from settings: ${effectiveSubClaim || '(not set)'}`);
    }
  } else {
    // For PAT or other auth types, ignore tableauUser (JWT not used)
    if (tableauUser) {
      logger.info(`Ignoring tableauUser for non-Direct-Trust authentication (authType: ${authenticationType})`);
    }
    effectiveSubClaim = null; // Not applicable for PAT
  }

  logger.info(`Creating session: ${sessionId} with model: ${model}`);
  logger.info(`Session auth details - authType: ${authenticationType}, tableauUser: ${tableauUser || '(not provided)'}, effectiveSubClaim: ${effectiveSubClaim || '(not applicable)'}`);


  // Create LLM instance using factory (supports OpenAI and Salesforce providers)
  const llm = createLlm(settings, model, temperature ?? 0.7);

  // Connect to local MCP server with profile parameter and jwt_sub_claim (if applicable)
  const port = config.getEnv().PORT;
  const profileParam = profileName ? `profile=${encodeURIComponent(profileName)}` : '';
  const jwtSubClaimParam = effectiveSubClaim ? `jwt_sub_claim=${encodeURIComponent(effectiveSubClaim)}` : '';
  const queryParams = [profileParam, jwtSubClaimParam].filter(Boolean).join('&');
  const mcpWsUrl = queryParams ? `ws://127.0.0.1:${port}/mcp/ws?${queryParams}` : `ws://127.0.0.1:${port}/mcp/ws`;

  logger.info(`Connecting to MCP server at: ${mcpWsUrl} (profile: ${profileName || 'default'}, jwtSubClaim: ${effectiveSubClaim ? '***' : 'none'})`);
  const mcpClient = await createMcpClient(mcpWsUrl);

  // Get MAX_VIEW_ROWS_FOR_MODEL from settings (defaults to 30 if not configured)
  const maxViewRowsForModel = settings.MAX_VIEW_ROWS_FOR_MODEL ?? 30;
  logger.info(`Session MAX_VIEW_ROWS_FOR_MODEL: ${maxViewRowsForModel}`);

  // Compute core system prompt (guardrails) - store once, reuse each turn
  // v212: buildSystemPrompt is now async (loads from database)
  const coreSystemPrompt = systemPrompt ?? await buildSystemPrompt('global_qna', 'unknown', undefined, maxViewRowsForModel);

  const session: Session = {
    id: sessionId,
    llm,
    mcpClient,
    messages: [
      {
        role: 'system',
        content: coreSystemPrompt,
      },
    ],
    toolCallCount: 0,
    evidence: [],
    aborted: false,
    profile: profileName,
    tableauUser,
    authenticationType,
    effectiveSubClaim,
    llmProvider: settings.LLM_PROVIDER || 'openai', // Store LLM provider for debugging/tracing
    maxViewRowsForModel, // Store for use in data truncation

    // Multi-turn conversation history fields
    coreSystemPrompt,
    scopeSystemPrompt: null,
    history: [],

    // Query context for dynamic presentation reminders
    lastQueryContext: null,

    // Error tracking and recovery for query-datasource
    lastQueryError: null,
    lastQueryErrorRecoveryInjected: false,
    firstQueryDatasourceHintInjected: false,

    // v211: Lightweight repair context for validation errors
    pendingValidationRepair: undefined,
    lastSuccessfulToolResult: undefined,

    // v295: Initialize token tracking
    tokenTracking: createSessionTokenTracking(),
  };

  sessions.set(sessionId, session);

  logger.info(`Session created: ${sessionId}`);

  return sessionId;
}

/**
 * Cleanup session
 */
export async function deleteSession(sessionId: string): Promise<void> {
  const session = sessions.get(sessionId);
  if (session) {
    // v295: Log final token tracking summary
    // v301: Pass actual usage when available
    if (session.tokenTracking) {
      logger.info(`[v295] Final token summary for session ${sessionId}:`);
      logTokenSummary(session.tokenTracking, session.actualUsage);
    }

    await session.mcpClient.disconnect();
    sessions.delete(sessionId);
    logger.info(`Session deleted: ${sessionId}`);
  }
}

/**
 * handleUserPromptV3 - Phase 3 state machine implementation
 *
 * Orchestrates agent execution using StateHandler pattern:
 * INIT → REASONING → ACTION/RECOVERY → FINALIZE → COMPLETED
 */
async function handleUserPromptV3(
  ws: WebSocket,
  session: Session,
  text: string,
  temperature?: number
): Promise<void> {
  logger.info('[v323 PHASE3] Starting state machine execution');

  // Import handlers and dependencies
  const { InitStateHandler } = await import('../agent/handlers/InitStateHandler.js');
  const { ReasoningStateHandler } = await import('../agent/handlers/ReasoningStateHandler.js');
  const { ActionStateHandler } = await import('../agent/handlers/ActionStateHandler.js');
  const { RecoveryStateHandler } = await import('../agent/handlers/RecoveryStateHandler.js');
  const { FinalizeStateHandler } = await import('../agent/handlers/FinalizeStateHandler.js');
  const { PulseHintInterceptor } = await import('../agent/interceptors/PulseHintInterceptor.js');
  const { DatasourceLuidHintInterceptor } = await import('../agent/interceptors/DatasourceLuidHintInterceptor.js');
  const { WorkbookIdHintInterceptor } = await import('../agent/interceptors/WorkbookIdHintInterceptor.js');
  const { ExecutionPhaseHintInterceptor } = await import('../agent/interceptors/ExecutionPhaseHintInterceptor.js');
  const { InterceptorManager } = await import('../agent/InterceptorManager.js');

  // Import types
  type StateContext = import('../agent/types.js').StateContext;
  type Message = import('../agent/types.js').Message;
  type AgentStateType = import('../agent/types.js').AgentStateType;

  // Initialize handlers
  // v342-343: Register interceptors for Pulse, Datasource, and Workbook workflows
  // v344: Add ExecutionPhaseHintInterceptor for truncation/aggregation hints
  const interceptorManager = new InterceptorManager([
    new PulseHintInterceptor(),
    new DatasourceLuidHintInterceptor(),
    new WorkbookIdHintInterceptor(),
    new ExecutionPhaseHintInterceptor(),
  ]);
  const initHandler = new InitStateHandler();
  const reasoningHandler = new ReasoningStateHandler();
  const actionHandler = new ActionStateHandler({
    mcpClient: session.mcpClient,
    interceptorManager,
    ws, // v334: Pass WebSocket for UI updates (tool_call, tool_result, data_table)
  });
  const recoveryHandler = new RecoveryStateHandler({ maxRecoveryAttempts: 10 }); // v363: Increased to match maxIterations
  const finalizeHandler = new FinalizeStateHandler();

  logger.info('[v323 PHASE3] Handlers initialized');

  // Clear query context
  session.lastQueryContext = null;

  // Detect intent and rebuild system prompts (reuse existing logic)
  const intentContext = inferQuestionIntent(text, session.lastStrongIntent || null, session.allowedScope);
  if (intentContext.lastStrongIntent) {
    session.lastStrongIntent = intentContext.lastStrongIntent;
  }

  const toolProfile: ToolProfile = getToolProfileForSession(session);
  const intentSpecificPrompt = await buildSystemPrompt(toolProfile, intentContext.currentIntent, session, session.maxViewRowsForModel ?? 30);
  session.coreSystemPrompt = intentSpecificPrompt;

  logger.info('[v323 PHASE3] System prompts built', {
    intent: intentContext.currentIntent,
    corePromptLength: intentSpecificPrompt.length,
    hasScopePrompt: !!session.scopeSystemPrompt,
  });

  // Initialize state context
  const context: StateContext = {
    coreSystemPrompt: session.coreSystemPrompt,
    scopeSystemPrompt: session.scopeSystemPrompt || undefined,
    intent: intentContext.currentIntent || undefined,
    profileId: session.profile || undefined,
    llmProvider: session.llmProvider, // Add LLM provider for debugging/tracing
    toolProfile, // v350: Add for runtime tool access control
    allowedScope: session.allowedScope || undefined, // v350: Add for scope checking
    maxViewRowsForModel: session.maxViewRowsForModel ?? 30, // Pass configured value to handlers
    systemHints: [],
    iterationCount: 0,
    maxIterations: 10, // v353: Changed from 30 to 10 to match old broker.ts (line 4132) - prevents excessive token usage
    executionStartTime: Date.now(), // v359: Track execution start for quality metrics
    recoveryAttempts: 0,
    tokenUsage: { system: 0, user: 0, assistant: 0, tools: 0, total: 0 },
  };

  // v351: Initialize session.history and load recent conversation context
  // This ensures follow-up questions have context from previous turns
  const MAX_TURNS = 8; // number of user↔assistant turns to retain (matches old broker.ts)

  if (!session.history) {
    session.history = [];
  }

  // Load recent conversation history (last MAX_TURNS * 2 messages)
  const recentHistory = session.history.length > 0
    ? session.history.slice(-MAX_TURNS * 2)
    : [];

  logger.info('[v351 HISTORY] Loading conversation context', {
    sessionId: session.id,
    historySize: session.history.length,
    recentHistorySize: recentHistory.length,
    previousTurns: Math.floor(recentHistory.length / 2),
  });

  // Initialize message history with recent history + new user prompt
  const messages: Message[] = [
    ...recentHistory,  // v351: Include previous conversation turns
    {
      role: 'user',
      content: text,
    },
  ];

  // v343: Inject upfront keyword-based hints (proactive guidance based on user query)
  // These hints are injected BEFORE the state machine runs to guide LLM behavior from the start

  // v434: Datasource keyword detection - force fresh list-datasources lookup
  // Now loads datasource_lookup_upfront_hint from database
  if (/datasource/i.test(text)) {
    logger.info(`[v434 UPFRONT-HINT] User mentioned 'datasource' keyword, loading datasource_lookup_upfront_hint from database`);

    let datasourceLookupHint = '';

    try {
      // Load datasource_lookup_upfront_hint from database
      datasourceLookupHint = await promptManager.getSection('datasource_lookup_upfront_hint');
      logger.info(`[v434 UPFRONT-HINT] Loaded datasource_lookup_upfront_hint from database (${datasourceLookupHint.length} chars)`);
    } catch (error) {
      logger.error(`[v434 UPFRONT-HINT] Failed to load datasource_lookup_upfront_hint from database, trying file fallback`, error);
      // Fallback: Load from file
      try {
        datasourceLookupHint = loadPromptSectionFromFile('datasource_lookup_upfront_hint');
        logger.info(`[v434 UPFRONT-HINT] Loaded datasource_lookup_upfront_hint from file fallback (${datasourceLookupHint.length} chars)`);
      } catch (fileError) {
        logger.error(`[v434 UPFRONT-HINT] Failed to load datasource_lookup_upfront_hint from file fallback`, fileError);
        datasourceLookupHint = '';
      }
    }

    // Inject the upfront hint AFTER user message
    if (datasourceLookupHint) {
      messages.push({
        role: 'system',
        content: datasourceLookupHint,
      });

      logger.info(`[v434 UPFRONT-HINT] Injected datasource_lookup_upfront_hint as upfront hint`);
    }
  }

  // v427: Query-datasource mandatory workflow - inject when intent is datasource_query
  // Now loads unified datasource_query_upfront_hint from database (merged datasource_query_guidance + queryVerificationHint)
  if (intentContext.currentIntent === 'datasource_query') {
    logger.info(`[v427 UPFRONT-HINT] Intent is datasource_query, loading datasource_query_upfront_hint from database`);

    let queryVerificationHint = '';

    try {
      // Load unified datasource_query_upfront_hint from database
      queryVerificationHint = await promptManager.getSection('datasource_query_upfront_hint');
      logger.info(`[v427 UPFRONT-HINT] Loaded datasource_query_upfront_hint from database (${queryVerificationHint.length} chars)`);
    } catch (error) {
      logger.error(`[v427 UPFRONT-HINT] Failed to load datasource_query_upfront_hint from database, trying file fallback`, error);
      // Fallback: Load from file
      try {
        queryVerificationHint = loadPromptSectionFromFile('datasource_query_upfront_hint');
        logger.info(`[v427 UPFRONT-HINT] Loaded datasource_query_upfront_hint from file fallback (${queryVerificationHint.length} chars)`);
      } catch (fileError) {
        logger.error(`[v427 UPFRONT-HINT] Failed to load datasource_query_upfront_hint from file fallback`, fileError);
        queryVerificationHint = '';
      }
    }

    // Inject the upfront hint AFTER user message (Position 3)
    if (queryVerificationHint) {
      messages.push({
        role: 'system',
        content: queryVerificationHint,
      });

      logger.info(`[v427 UPFRONT-HINT] Injected datasource_query_upfront_hint as upfront hint`);
    }
  }

  // v434: Workbook keyword detection - force fresh list-workbooks lookup
  // Now loads workbook_lookup_upfront_hint from database
  if (/workbook/i.test(text)) {
    logger.info(`[v434 UPFRONT-HINT] User mentioned 'workbook' keyword, loading workbook_lookup_upfront_hint from database`);

    let workbookLookupHint = '';

    try {
      // Load workbook_lookup_upfront_hint from database
      workbookLookupHint = await promptManager.getSection('workbook_lookup_upfront_hint');
      logger.info(`[v434 UPFRONT-HINT] Loaded workbook_lookup_upfront_hint from database (${workbookLookupHint.length} chars)`);
    } catch (error) {
      logger.error(`[v434 UPFRONT-HINT] Failed to load workbook_lookup_upfront_hint from database, trying file fallback`, error);
      // Fallback: Load from file
      try {
        workbookLookupHint = loadPromptSectionFromFile('workbook_lookup_upfront_hint');
        logger.info(`[v434 UPFRONT-HINT] Loaded workbook_lookup_upfront_hint from file fallback (${workbookLookupHint.length} chars)`);
      } catch (fileError) {
        logger.error(`[v434 UPFRONT-HINT] Failed to load workbook_lookup_upfront_hint from file fallback`, fileError);
        workbookLookupHint = '';
      }
    }

    // Inject the upfront hint AFTER user message
    if (workbookLookupHint) {
      messages.push({
        role: 'system',
        content: workbookLookupHint,
      });

      logger.info(`[v434 UPFRONT-HINT] Injected workbook_lookup_upfront_hint as upfront hint`);
    }
  }

  // Date keyword detection - provide DATE filter syntax guidance
  const dateRelatedPattern = /(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec|q1|q2|q3|q4|quarter|month|year|\d{4}|between|from|to|range|current|this)/i;

  if (dateRelatedPattern.test(text)) {
    logger.info(`[v343 UPFRONT-HINT] User query contains date-related terms`);

    const dateContext = getCurrentDateContext();

    const dateFilterHint = [
      '',
      '⚠️  CRITICAL: Before querying, review DATE filter syntax carefully',
      '',
      `**📅 CURRENT DATE REFERENCE:** Today is ${dateContext.formattedDate}`,
      `   - Current Year: ${dateContext.year}`,
      `   - Current Month: ${dateContext.month} (${dateContext.monthNumber})`,
      `   - Current Quarter: ${dateContext.quarter}`,
      `   - When user says "current month" or "this month", they mean ${dateContext.month} ${dateContext.year}`,
      `   - When user says "current year" or "this year", they mean ${dateContext.year}`,
      `   - When user says "current quarter" or "this quarter", they mean ${dateContext.quarter} ${dateContext.year}`,
      '',
      `**🔥 EXAMPLE - Current Month (${dateContext.month} ${dateContext.year}):**`,
      '```',
      '{',
      '  "filterType": "DATE",',
      '  "field": {"fieldCaption": "Order Date"},',
      '  "periodType": "MONTHS",',
      '  "dateRangeType": "CURRENT",',
      `  "anchorDate": "${dateContext.firstDayOfMonth}"  // ← Use this EXACT date for current month`,
      '}',
      '```',
      `⚠️  When user says "current month" or "this month", use anchorDate: "${dateContext.firstDayOfMonth}"`,
      '',
      '**Historical Month (e.g., "November 2025"):**',
      '```',
      '{',
      '  "filterType": "DATE",',
      '  "field": {"fieldCaption": "Order Date"},',
      '  "periodType": "MONTHS",',
      '  "dateRangeType": "CURRENT",',
      '  "anchorDate": "2025-11-01"',
      '}',
      '```',
      '',
      '**Multi-Month Range (e.g., "February to June 2025" = 5 months, "February to November 2025" = 10 months):**',
      '```',
      '{',
      '  "filterType": "DATE",',
      '  "field": {"fieldCaption": "Order Date"},',
      '  "periodType": "MONTHS",',
      '  "dateRangeType": "NEXTN",',
      '  "rangeN": 5,  // Count of months in range',
      '  "anchorDate": "2025-02-01"  // First day of START month',
      '}',
      '```',
      '',
      `**Month to Date / Year to Date (e.g., "Month to date", "MTD", "Year to date", "YTD"):**`,
      '```',
      '{',
      '  "filterType": "DATE",',
      '  "field": {"fieldCaption": "Order Date"},',
      '  "periodType": "MONTHS",  // Use "MONTHS" for MTD, "YEARS" for YTD',
      '  "dateRangeType": "TODATE"  // From start of period to today',
      '}',
      '```',
      `⚠️  TODATE is for PARTIAL periods (up to today). NO anchorDate needed.`,
      `⚠️  For COMPLETE periods (entire month/year), use dateRangeType: "CURRENT" instead.`,
      '',
      '**CRITICAL RULES:**',
      '❌ NEVER use invalid fields (start, end) in DATE filters',
      '❌ NEVER use multiple DATE filters on same field - use ONE filter with correct range',
      '❌ anchorDate format: YYYY-MM-01 (first day of month)',
      '❌ NEVER use anchorDate with TODATE (TODATE is always relative to current date)',
      '',
      'Choose ONE approach and follow it exactly.',
    ].join('\n');

    messages.push({
      role: 'system',
      content: dateFilterHint,
    });

    logger.info(`[v343 UPFRONT-HINT] Injected DATE filter guidance`);
  }

  // Run INIT handler
  logger.info('[v323 PHASE3] → INIT');
  const initResult = await initHandler.handle(context, messages);
  let currentState: AgentStateType = initResult.nextState;
  logger.info(`[v323 PHASE3] INIT complete → ${currentState}`);

  // Main state machine loop
  let continueLoop = true;
  const allToolCalls: Array<{ name: string; args: Record<string, unknown>; result: unknown }> = [];

  while (continueLoop && context.iterationCount < context.maxIterations) {
    logger.info(`[v323 PHASE3] State: ${currentState}, Iteration: ${context.iterationCount}`);

    switch (currentState) {
      case 'REASONING': {
        // Build full message array with system prompts
        const systemMessages: Message[] = [];

        if (context.coreSystemPrompt) {
          systemMessages.push({ role: 'system', content: context.coreSystemPrompt });
        }
        if (context.scopeSystemPrompt) {
          systemMessages.push({ role: 'system', content: context.scopeSystemPrompt });
        }

        const fullMessages = [...systemMessages, ...messages];

        // DEBUG: Log messages being sent to LLM
        logger.info('[BEDROCK DEBUG] Messages before sending to LLM', {
          totalMessages: fullMessages.length,
          messagesBreakdown: fullMessages.map((m, i) => ({
            index: i,
            role: m.role,
            hasContent: !!m.content,
            contentLength: m.content?.length || 0,
            hasToolCalls: !!(m as any).tool_calls,
            toolCallsCount: (m as any).tool_calls?.length,
            toolCallId: (m as any).tool_call_id,
          })),
        });

        // Call LLM with streaming
        logger.info('[v323 PHASE3] Calling LLM');
        let assistantMessage = '';
        let assistantToolCalls: any[] | undefined;

        // Get and filter tools
        const mcpTools = session.mcpClient.getTools();
        logger.info(`[v329 DEBUG] mcpTools count: ${mcpTools?.length || 'NULL'}, sample: ${mcpTools?.slice(0, 2).map(t => t?.name || 'UNDEF').join(', ')}`);

        const allowedTools = mcpTools.filter((tool) => {
          // v327: Guard against undefined tools
          if (!tool || !tool.name) {
            logger.warn('[v327 PHASE3] Skipping undefined or invalid tool in mcpTools array', {
              toolType: typeof tool,
              isNull: tool === null,
              isUndefined: tool === undefined,
            });
            return false;
          }

          const decision = canUseTool(
            tool.name,
            toolProfile,
            intentContext.currentIntent,
            session.allowedScope,
            undefined
          );
          return decision.allowed;
        });

        logger.info(`[v329 DEBUG] allowedTools count: ${allowedTools.length}`);
        if (allowedTools.length > 0) {
          logger.info(`[v329 DEBUG] First 3 tools: ${allowedTools.slice(0, 3).map((t, i) => `[${i}]=${t?.name || 'UNDEFINED'}`).join(', ')}`);
        }

        const tools = allowedTools.map((tool) => {
          if (!tool) {
            logger.error('[v329 CRITICAL] Undefined tool in allowedTools during map!');
            throw new Error('Undefined tool passed filter check');
          }
          return {
            name: tool.name,
            description: tool.description,
            parameters: tool.inputSchema,
          };
        });

        await session.llm.streamCompletion(
          fullMessages,
          tools,
          async (chunk) => {
            if (chunk.type === 'reasoning' && chunk.reasoning) {
              ws.send(JSON.stringify({ type: 'reasoning', reasoning: chunk.reasoning }));
            } else if (chunk.type === 'delta' && chunk.content) {
              assistantMessage += chunk.content;
              ws.send(JSON.stringify({ type: 'delta', chunk: chunk.content }));
            } else if (chunk.type === 'tool_call' && chunk.toolCall) {
              // Accumulate tool calls
              // v331: Transform chunk.toolCall format { id, name, arguments }
              // to OpenAI format { id, function: { name, arguments } }
              const { id, name, arguments: args } = chunk.toolCall;

              if (!assistantToolCalls) {
                assistantToolCalls = [];
              }

              assistantToolCalls.push({
                id,
                type: 'function',
                function: {
                  name,
                  arguments: typeof args === 'string' ? args : JSON.stringify(args),
                },
              });
            } else if (chunk.type === 'usage' && chunk.usage) {
              // v362: Track token usage for execution metrics
              context.tokenUsage.total += chunk.usage.totalTokens;
              context.tokenUsage.assistant += chunk.usage.completionTokens;
              context.tokenUsage.user += chunk.usage.promptTokens;
              logger.info(`[v362 TOKEN] LLM usage: ${chunk.usage.promptTokens} prompt + ${chunk.usage.completionTokens} completion = ${chunk.usage.totalTokens} total (cumulative: ${context.tokenUsage.total})`);
            }
          },
          temperature,
          session.abortController?.signal
        );

        // Add assistant response to messages
        if (assistantToolCalls && assistantToolCalls.length > 0) {
          // v330: Filter out any undefined/invalid tool calls
          const validToolCalls = assistantToolCalls.filter((tc: any) => {
            if (!tc || !tc.function || !tc.function.name) {
              logger.warn('[v330 PHASE3] Filtering out invalid tool call', {
                hasToolCall: !!tc,
                hasFunction: !!(tc?.function),
                hasFunctionName: !!(tc?.function?.name),
              });
              return false;
            }
            return true;
          });

          if (validToolCalls.length === 0) {
            logger.error('[v330 PHASE3] All tool calls were invalid!');
            // Treat as text-only response
            messages.push({
              role: 'assistant',
              content: assistantMessage || 'Error: LLM returned invalid tool calls',
            });
          } else {
            messages.push({
              role: 'assistant',
              content: assistantMessage || '',
              tool_calls: validToolCalls,
            } as any);
            logger.info('[v323 PHASE3] LLM requested tool calls', {
              count: validToolCalls.length,
              filtered: assistantToolCalls.length - validToolCalls.length,
              tools: validToolCalls.map((tc: any) => tc.function.name),
            });
          }
        } else if (assistantMessage) {
          messages.push({
            role: 'assistant',
            content: assistantMessage,
          });
          logger.info('[v323 PHASE3] LLM provided text response');
        }

        // Call REASONING handler to determine next state
        const reasoningResult = await reasoningHandler.handle(context, messages);
        currentState = reasoningResult.nextState;

        logger.info(`[v323 PHASE3] REASONING → ${currentState}`);
        break;
      }

      case 'ACTION': {
        // Call ACTION handler to execute tools
        logger.info('[v323 PHASE3] → ACTION');
        const actionResult = await actionHandler.handle(context, messages);

        // Add tool result messages
        if (actionResult.messages) {
          messages.push(...actionResult.messages);
        }

        // Track tool calls for grounding
        // v331: Find the most recent assistant message with tool_calls (search backwards)
        let lastAssistantMsg: any = null;
        for (let i = messages.length - 1; i >= 0; i--) {
          const msg = messages[i];
          if (msg.role === 'assistant' && (msg as any).tool_calls) {
            lastAssistantMsg = msg;
            break;
          }
        }

        if (lastAssistantMsg && lastAssistantMsg.tool_calls) {
          logger.info(`[v331 GROUNDING] Tracking ${lastAssistantMsg.tool_calls.length} tool calls for grounding`);
          for (const tc of lastAssistantMsg.tool_calls) {
            const args = typeof tc.function.arguments === 'string'
              ? JSON.parse(tc.function.arguments)
              : tc.function.arguments;

            allToolCalls.push({
              name: tc.function.name,
              args,
              result: {}, // Result is in the tool message
            });
          }
        } else {
          logger.warn('[v331 GROUNDING] No assistant message with tool_calls found after ACTION');
        }

        currentState = actionResult.nextState;
        logger.info(`[v323 PHASE3] ACTION → ${currentState}`);

        // v347: After successful ACTION, inject presentation reminder to prevent duplicate queries
        // If LLM is going back to REASONING and we have QueryContext with data, guide it to present answer
        // v389: Skip if sortVerificationPending is true - LLM needs to verify/correct sort first
        if (currentState === 'REASONING' && context.queryContext && !context.queryContext.reminderInjected) {
          // v389: Check if sort verification is pending - if so, skip presentation reminder
          if (context.queryContext.sortVerificationPending) {
            logger.info('[v389 BROKER] Skipping v347 presentation reminder - sort verification is pending');
          } else {
            const { buildFinalPresentationReminder } = await import('../agent/utils/QueryContextBuilder.js');
            const presentationReminder = buildFinalPresentationReminder(context.queryContext);

            if (presentationReminder) {
              logger.info('[v347 PRESENTATION-REMINDER] Injecting presentation guidance to prevent duplicate queries');

              // Inject as user message (higher authority than system)
              messages.push({
                role: 'user',
                content: presentationReminder,
              });

              // Mark as injected to prevent infinite loops
              context.queryContext.reminderInjected = true;

              logger.info('[v347 PRESENTATION-REMINDER] Presentation reminder injected - LLM will refine answer and stop querying');
            }
          }
        }

        break;
      }

      case 'RECOVERY': {
        // Call RECOVERY handler for error recovery
        logger.info('[v323 PHASE3] → RECOVERY');
        const recoveryResult = await recoveryHandler.handle(context, messages);

        // Add recovery messages
        if (recoveryResult.messages) {
          messages.push(...recoveryResult.messages);
        }

        // Store final answer if recovery gave up
        if (recoveryResult.finalAnswer) {
          context.finalAnswer = recoveryResult.finalAnswer;
        }

        currentState = recoveryResult.nextState;
        logger.info(`[v323 PHASE3] RECOVERY → ${currentState}`);
        break;
      }

      case 'FINALIZE': {
        // Call FINALIZE handler to extract answer
        logger.info('[v323 PHASE3] → FINALIZE');
        const finalizeResult = await finalizeHandler.handle(context, messages);

        currentState = finalizeResult.nextState;
        logger.info(`[v323 PHASE3] FINALIZE → ${currentState}`);
        continueLoop = false;
        break;
      }

      case 'COMPLETED':
      case 'ABORTED': {
        logger.info(`[v323 PHASE3] Terminal state reached: ${currentState}`);
        continueLoop = false;
        break;
      }

      default: {
        logger.error(`[v323 PHASE3] Unknown state: ${currentState}`);
        continueLoop = false;
        break;
      }
    }

    // Safety check: prevent infinite loops
    if (context.iterationCount >= context.maxIterations) {
      logger.warn('[v323 PHASE3] Max iterations reached');
      context.finalAnswer = context.finalAnswer ||
        'I apologize, but I reached the maximum number of reasoning iterations. Please try rephrasing your question.';
      continueLoop = false;
    }
  }

  // v385: Smart warning for responses without tool calls
  // Changed from blocking error to non-blocking informational message
  if (allToolCalls.length === 0) {
    const questionRequiresData = /\b(show|list|get|fetch|query|find|what are|how many|total|sum|count|display|retrieve)\b/i.test(text);

    if (questionRequiresData) {
      ws.send(JSON.stringify({
        type: 'warning',
        message: '⚠️ No new data was queried for this response. The answer may be based on previous context or general knowledge. If you need current data from your Tableau environment, please rephrase your question to be more specific.',
      }));
      logger.info('[v385] Warning sent: question requires data but no tools called');
    } else {
      // For follow-ups, clarifications, summaries - no warning needed
      logger.info('[v385] No tool calls, but question does not require fresh data');
    }
    // Continue execution - don't block the LLM's answer
  }

  // If we don't have a final answer yet, force one
  if (!context.finalAnswer) {
    logger.info('[v323 PHASE3] No final answer, forcing LLM to provide one');

    const systemMessages: Message[] = [];
    if (context.coreSystemPrompt) {
      systemMessages.push({ role: 'system', content: context.coreSystemPrompt });
    }
    if (context.scopeSystemPrompt) {
      systemMessages.push({ role: 'system', content: context.scopeSystemPrompt });
    }

    const fullMessages = [...systemMessages, ...messages];
    let finalAnswer = '';

    await session.llm.streamCompletion(
      fullMessages,
      [], // No tools - force text response
      async (chunk) => {
        if (chunk.type === 'delta' && chunk.content) {
          finalAnswer += chunk.content;
          ws.send(JSON.stringify({ type: 'delta', chunk: chunk.content }));
        }
      },
      temperature,
      session.abortController?.signal
    );

    context.finalAnswer = finalAnswer;
  }

  // v333: Use finalAnswer from state machine instead of generating new answer
  // The FINALIZE handler already extracted the proper answer from the LLM's reasoning
  logger.info('[v333 PHASE3] Using final answer from state machine', {
    answerLength: context.finalAnswer?.length || 0,
  });

  // v358: Build grounded answer structure from context and tool calls
  // Removed confidence score (was arbitrary 0.9) and fake validation (was always 'pass')
  const groundedAnswer = {
    final_answer_md: context.finalAnswer || 'No answer generated',
    queries_run: allToolCalls.map(tc => ({ tool: tc.name, args: tc.args })),
    evidence: [], // Evidence extraction can be added later if needed
  };

  // v359: Send execution quality metrics (Phase 1)
  // v361: Added token usage tracking
  const executionTimeMs = context.executionStartTime ? Date.now() - context.executionStartTime : 0;
  const uniqueTools = new Set(allToolCalls.map(tc => tc.name));

  ws.send(JSON.stringify({
    type: 'execution_metrics',
    metrics: {
      iterations: context.iterationCount,
      maxIterations: context.maxIterations,
      toolCalls: allToolCalls.length,
      uniqueTools: uniqueTools.size,
      toolNames: Array.from(uniqueTools),
      recoveryAttempts: context.recoveryAttempts,
      executionTimeMs,
      executionTimeSec: (executionTimeMs / 1000).toFixed(1),
      tokenUsage: context.tokenUsage.total, // v361: Include token count
    }
  }));

  logger.info('[v359 QUALITY] Sent execution metrics', {
    iterations: context.iterationCount,
    toolCalls: allToolCalls.length,
    uniqueTools: uniqueTools.size,
    executionTimeSec: (executionTimeMs / 1000).toFixed(1),
    tokens: context.tokenUsage.total, // v361: Log token count
  });

  // v359: Detect uncertainty in final answer (Phase 4)
  const uncertaintyAnalysis = detectUncertainty(context.finalAnswer || '');
  if (uncertaintyAnalysis.found) {
    ws.send(JSON.stringify({
      type: 'uncertainty_indicator',
      level: uncertaintyAnalysis.level,
      phrases: uncertaintyAnalysis.phrases,
      count: uncertaintyAnalysis.count,
    }));

    logger.info('[v359 QUALITY] Uncertainty detected in answer', {
      level: uncertaintyAnalysis.level,
      phraseCount: uncertaintyAnalysis.count,
      phrases: uncertaintyAnalysis.phrases.slice(0, 3), // Log first 3 phrases
    });
  }

  // v358: Send final answer directly (no validation step)
  ws.send(JSON.stringify({
    type: 'final',
    json: groundedAnswer,
  }));

  // v351: Store in session history (reuse existing session.history mechanism)
  if (!session.history) {
    session.history = [];
  }
  session.history.push({ role: 'user', content: text });
  session.history.push({ role: 'assistant', content: context.finalAnswer || '' });

  // v351: Trim to last MAX_TURNS turns to prevent unbounded growth (matches old broker.ts)
  const maxMessages = MAX_TURNS * 2; // MAX_TURNS already declared above
  if (session.history.length > maxMessages) {
    const trimmed = session.history.length - maxMessages;
    session.history = session.history.slice(-maxMessages);
    logger.info(`[v351 HISTORY] Trimmed ${trimmed} old messages, keeping last ${MAX_TURNS} turns`);
  }

  logger.info('[v351 HISTORY] Stored conversation turn in session.history', {
    totalMessages: session.history.length,
    totalTurns: Math.floor(session.history.length / 2),
  });

  ws.send(JSON.stringify({ type: 'done' }));
  logger.info('[v323 PHASE3] Execution complete', {
    iterations: context.iterationCount,
    recoveryAttempts: context.recoveryAttempts,
    toolCalls: allToolCalls.length,
  });
}

/**
 * v359: Detect uncertainty markers in LLM response (Phase 4)
 *
 * Analyzes the final answer for phrases indicating uncertainty or limitations.
 * Returns level (low/medium/high) based on severity and frequency.
 */
function detectUncertainty(answer: string): {
  found: boolean;
  level: 'low' | 'medium' | 'high';
  phrases: string[];
  count: number;
} {
  const answerLower = answer.toLowerCase();

  // Define uncertainty phrase categories by severity
  const lowUncertainty = [
    'based on available data',
    'based on the data',
    'from the data shown',
    'from what i can see',
    'according to the data',
    'as shown in',
  ];

  const mediumUncertainty = [
    'might',
    'may',
    'possibly',
    'perhaps',
    'seems to',
    'appears to',
    'could be',
    'likely',
    'probably',
    'suggests that',
  ];

  const highUncertainty = [
    'unable to determine',
    'cannot confirm',
    'cannot verify',
    'unclear',
    'uncertain',
    'insufficient data',
    'not enough information',
    'no data available',
    'cannot find',
    'could not find',
  ];

  // Find all matching phrases
  const foundLow = lowUncertainty.filter(phrase => answerLower.includes(phrase));
  const foundMedium = mediumUncertainty.filter(phrase => answerLower.includes(phrase));
  const foundHigh = highUncertainty.filter(phrase => answerLower.includes(phrase));

  const allFound = [...foundHigh, ...foundMedium, ...foundLow];

  if (allFound.length === 0) {
    return { found: false, level: 'low', phrases: [], count: 0 };
  }

  // Determine level based on highest severity found
  let level: 'low' | 'medium' | 'high' = 'low';
  if (foundHigh.length > 0) {
    level = 'high';
  } else if (foundMedium.length >= 3) {
    // Multiple medium uncertainty phrases = high overall uncertainty
    level = 'high';
  } else if (foundMedium.length > 0) {
    level = 'medium';
  }

  return {
    found: true,
    level,
    phrases: allFound,
    count: allFound.length,
  };
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// DEBUG MODE HANDLERS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

interface DebugSession {
  sessionId: string;
  mcpClient: any; // TableauMcpClient instance
  profile: string;
  logLevel: string;
  disableLogMasking: boolean;
  tools: any[];
}

const debugSessions = new Map<string, DebugSession>();

/**
 * Handle debug_start_session message
 */
async function handleDebugStartSession(ws: WebSocket, _session: Session, payload: any): Promise<void> {
  try {
    const { profile, logLevel, disableLogMasking } = payload;

    if (!profile) {
      ws.send(JSON.stringify({
        type: 'debug_error',
        payload: { message: 'Profile is required' }
      }));
      return;
    }

    // Get settings for the profile
    const settings = await config.getSettings(profile);

    // Import TableauMcpClient
    const { TableauMcpClient } = await import('../mcp/tableauMcpClient.js');

    // Create TableauMcpClient instance with custom environment variables
    const mcpClient = new TableauMcpClient(profile);

    // Set up log handler to forward MCP server logs to WebSocket
    mcpClient.setLogHandler((logLine: string) => {
      // Forward MCP server stderr logs to debug UI in real-time
      if (ws.readyState === ws.OPEN) {
        ws.send(JSON.stringify({
          type: 'debug_mcp_log',
          payload: { logLine }
        }));
      }
    });

    // Store original env vars and inject debug settings
    const originalEnv = { ...process.env };
    if (logLevel) {
      process.env.DEBUG_LOG_LEVEL = logLevel;
    }
    if (disableLogMasking) {
      process.env.DEBUG_DISABLE_LOG_MASKING = 'true';
    }

    // Connect to MCP server
    await mcpClient.connect();

    // Restore original env vars
    process.env = originalEnv;

    // List available tools
    const tools = await mcpClient.listTools();

    // Generate debug session ID
    const debugSessionId = `debug_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Store debug session
    debugSessions.set(debugSessionId, {
      sessionId: debugSessionId,
      mcpClient,
      profile,
      logLevel: logLevel || 'info',
      disableLogMasking: disableLogMasking || false,
      tools
    });

    // Get environment variables that were passed to MCP (with secrets redacted)
    const envVars: Record<string, string> = {
      AUTH: settings.AUTHENTICATION_TYPE || 'pat',
      SERVER: settings.TABLEAU_BASE_URL || '',
      SITE_NAME: settings.TABLEAU_SITE_CONTENT_URL || '',
      DEFAULT_LOG_LEVEL: logLevel || 'info',
      DISABLE_LOG_MASKING: disableLogMasking ? 'true' : 'false',
      MAX_RESULT_LIMIT: String(settings.MAX_ROWS || 500),
      DISABLE_QUERY_DATASOURCE_VALIDATION_REQUESTS: 'false',
      EXCLUDE_TOOLS: 'get-view-image',
    };

    // Add auth-specific env vars (redacted)
    if (settings.AUTHENTICATION_TYPE === 'pat') {
      envVars.PAT_NAME = settings.TABLEAU_PAT_NAME || '';
      envVars.PAT_VALUE = '[REDACTED]';
    } else if (settings.AUTHENTICATION_TYPE === 'direct-trust') {
      envVars.JWT_SUB_CLAIM = settings.JWT_SUB_CLAIM || '';
      envVars.CONNECTED_APP_CLIENT_ID = settings.CONNECTED_APP_CLIENT_ID || '';
      envVars.CONNECTED_APP_SECRET_ID = settings.CONNECTED_APP_SECRET_ID || '';
      envVars.CONNECTED_APP_SECRET_VALUE = '[REDACTED]';

      if (settings.JWT_ADDITIONAL_PAYLOAD) {
        envVars.JWT_ADDITIONAL_PAYLOAD = settings.JWT_ADDITIONAL_PAYLOAD;
      }
    }

    // Send session started message with environment variables
    ws.send(JSON.stringify({
      type: 'debug_session_started',
      payload: {
        sessionId: debugSessionId,
        profile,
        tools,
        environmentVariables: envVars
      }
    }));

    logger.info(`Debug session started: ${debugSessionId} (profile: ${profile}, logLevel: ${logLevel}, disableLogMasking: ${disableLogMasking})`);
  } catch (error) {
    logger.error('Failed to start debug session', error);
    ws.send(JSON.stringify({
      type: 'debug_error',
      payload: {
        message: error instanceof Error ? error.message : String(error)
      }
    }));
  }
}

/**
 * Handle debug_stop_session message
 */
async function handleDebugStopSession(ws: WebSocket, _session: Session, payload: any): Promise<void> {
  try {
    const { sessionId } = payload;

    if (!sessionId) {
      ws.send(JSON.stringify({
        type: 'debug_error',
        payload: { message: 'Session ID is required' }
      }));
      return;
    }

    const debugSession = debugSessions.get(sessionId);

    if (!debugSession) {
      ws.send(JSON.stringify({
        type: 'debug_error',
        payload: { message: 'Debug session not found' }
      }));
      return;
    }

    // Disconnect MCP client
    await debugSession.mcpClient.disconnect();

    // Remove session
    debugSessions.delete(sessionId);

    // Send session stopped message
    ws.send(JSON.stringify({
      type: 'debug_session_stopped',
      payload: { sessionId }
    }));

    logger.info(`Debug session stopped: ${sessionId}`);
  } catch (error) {
    logger.error('Failed to stop debug session', error);
    ws.send(JSON.stringify({
      type: 'debug_error',
      payload: {
        message: error instanceof Error ? error.message : String(error)
      }
    }));
  }
}

/**
 * Handle debug_call_tool message
 */
async function handleDebugCallTool(ws: WebSocket, _session: Session, payload: any): Promise<void> {
  try {
    const { sessionId, toolName, arguments: args } = payload;

    if (!sessionId) {
      ws.send(JSON.stringify({
        type: 'debug_error',
        payload: { message: 'Session ID is required' }
      }));
      return;
    }

    if (!toolName) {
      ws.send(JSON.stringify({
        type: 'debug_error',
        payload: { message: 'Tool name is required' }
      }));
      return;
    }

    const debugSession = debugSessions.get(sessionId);

    if (!debugSession) {
      ws.send(JSON.stringify({
        type: 'debug_error',
        payload: { message: 'Debug session not found' }
      }));
      return;
    }

    // Call the tool
    logger.info(`Debug: Calling tool ${toolName} with args:`, args);
    const result = await debugSession.mcpClient.callTool(toolName, args || {});

    // Send tool result
    ws.send(JSON.stringify({
      type: 'debug_tool_result',
      payload: {
        toolName,
        arguments: args || {},
        result
      }
    }));

    logger.info(`Debug: Tool ${toolName} completed successfully`);
  } catch (error) {
    logger.error(`Failed to call debug tool`, error);
    ws.send(JSON.stringify({
      type: 'debug_error',
      payload: {
        message: error instanceof Error ? error.message : String(error)
      }
    }));
  }
}

function generateSessionId(): string {
  return `sess_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}
