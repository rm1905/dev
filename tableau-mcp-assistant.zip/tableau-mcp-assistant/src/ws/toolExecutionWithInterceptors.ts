/**
 * Tool Execution with Interceptors - Phase 2A helper
 *
 * This module provides a wrapper for tool execution that fires interceptors
 * before and after tool calls. This allows us to gradually migrate hint logic
 * (like v308 Pulse hints) from inline code to testable interceptor classes.
 *
 * Usage:
 *   const result = await executeToolWithInterceptors({
 *     session,
 *     toolName,
 *     toolArgs,
 *     interceptorManager,
 *     iterationMessages
 *   });
 */

import { McpClient } from '../mcp/client.js';
import { InterceptorManager } from '../agent/InterceptorManager.js';
import { ToolResult, StateContext } from '../agent/types.js';
import { Message } from '../llm/ILlm.js';
import { logger } from '../util/logger.js';
import {
  validateQueryDatasourceArgs,
  validateSearchContentArgs,
  validatePulseMetricDefinitionsArgs,
  validateListAllPulseMetricDefinitionsArgs,
} from '../utils/validate-tool-args.js';
import { preprocessVdsQuery } from './broker.js';
import { VdsQuery } from '../schemas/vds-schemas.js';

export interface ToolExecutionOptions {
  mcpClient: McpClient;
  toolName: string;
  toolArgs: Record<string, any>;
  interceptorManager: InterceptorManager;
  /**
   * Messages array for the current iteration
   * Interceptors can add system hints to this array
   */
  iterationMessages: Message[];
  /**
   * v348: Optional StateContext from calling handler
   * If provided, interceptors can access shared state like queryContext
   * If not provided, a minimal context will be created (backward compatibility)
   */
  context?: StateContext;
}

/**
 * Execute a tool with interceptor lifecycle hooks
 *
 * This function:
 * 1. Calls interceptorManager.beforeAction()
 * 2. Executes the MCP tool
 * 3. Converts result to ToolResult format
 * 4. Calls interceptorManager.afterAction()
 * 5. Injects any system hints from context into iterationMessages
 * 6. Returns the tool result
 */
export async function executeToolWithInterceptors(
  options: ToolExecutionOptions
): Promise<any> {
  const { mcpClient, toolName, toolArgs, interceptorManager, iterationMessages } = options;

  const startTime = Date.now();

  // v348: Use provided context if available, otherwise create minimal one
  const context: StateContext = options.context || {
    systemHints: [],
    iterationCount: 0, // Will be set by caller if needed
    maxIterations: 10, // v353: Changed from 30 to 10 to match old broker.ts MAX_ITERATIONS
    recoveryAttempts: 0,
    tokenUsage: {
      system: 0,
      user: 0,
      assistant: 0,
      tools: 0,
      total: 0,
    },
  };

  logger.info(`[v348 TOOL-EXEC] Using ${options.context ? 'provided' : 'minimal'} StateContext`, {
    hasQueryContext: !!context.queryContext,
    toolName,
  });

  try {
    // 1. Call beforeAction interceptors
    await interceptorManager.beforeAction(toolName, toolArgs, context);

    // v335: Validate tool arguments before execution
    // v338: Add preprocessing for query-datasource (MATCH/SET conversion, DATE validation)
    let validatedArgs = toolArgs; // Use validated args if validation succeeds

    if (toolName === 'query-datasource') {
      const validation = validateQueryDatasourceArgs(toolArgs);
      if (!validation.success) {
        logger.error(`[v335 VALIDATION] query-datasource args validation failed: ${validation.errors.length} error(s)`);
        validation.errors.forEach((err) => {
          logger.error(`[v335 VALIDATION]   - ${err.path}: ${err.message}`);
        });
        throw validation.validationError;
      }
      logger.info('[v335 VALIDATION] query-datasource args validation succeeded');
      validatedArgs = validation.data;

      // v338: Apply preprocessing to query (MATCH/SET conversion, DATE validation, sort defaults)
      if (validatedArgs.query) {
        const { query: preprocessed, warnings } = preprocessVdsQuery(validatedArgs.query as VdsQuery);

        if (warnings.length > 0) {
          logger.info(`[v338 PREPROCESSING] query-datasource preprocessing generated ${warnings.length} warning(s)`);
          warnings.forEach((warning, idx) => {
            logger.info(`[v338 PREPROCESSING]   Warning ${idx + 1}: ${warning}`);
          });

          // Inject preprocessing warnings as system hint
          iterationMessages.push({
            role: 'system',
            content: `⚠️ Query Preprocessing Adjustments:\n${warnings.map(w => `• ${w}`).join('\n')}\n\nThese are informational - the query has been automatically adjusted for optimal results.`,
          });
        }

        validatedArgs = { ...validatedArgs, query: preprocessed };
        logger.info('[v338 PREPROCESSING] query-datasource preprocessing complete', {
          hadWarnings: warnings.length > 0,
          warningCount: warnings.length,
        });
      }
    } else if (toolName === 'search-content') {
      const validation = validateSearchContentArgs(toolArgs);
      if (!validation.success) {
        logger.error(`[v335 VALIDATION] search-content args validation failed: ${validation.errors.length} error(s)`);
        validation.errors.forEach((err) => {
          logger.error(`[v335 VALIDATION]   - ${err.path}: ${err.message}`);
        });
        throw validation.validationError;
      }
      logger.info('[v335 VALIDATION] search-content args validation succeeded');
      validatedArgs = validation.data;
    } else if (toolName === 'list-pulse-metric-definitions-from-definition-ids') {
      const validation = validatePulseMetricDefinitionsArgs(toolArgs);
      if (!validation.success) {
        logger.error(`[v335 VALIDATION] Pulse metric definitions args validation failed: ${validation.errors.length} error(s)`);
        validation.errors.forEach((err) => {
          logger.error(`[v335 VALIDATION]   - ${err.path}: ${err.message}`);
        });
        throw validation.validationError;
      }
      logger.info('[v335 VALIDATION] Pulse metric definitions args validation succeeded');
      validatedArgs = validation.data;
    } else if (toolName === 'list-all-pulse-metric-definitions') {
      const validation = validateListAllPulseMetricDefinitionsArgs(toolArgs);
      if (!validation.success) {
        logger.error(`[v335 VALIDATION] list-all-pulse-metric-definitions args validation failed: ${validation.errors.length} error(s)`);
        validation.errors.forEach((err) => {
          logger.error(`[v335 VALIDATION]   - ${err.path}: ${err.message}`);
        });
        throw validation.validationError;
      }
      logger.info('[v335 VALIDATION] list-all-pulse-metric-definitions args validation succeeded');
      validatedArgs = validation.data;
    }

    // 2. Execute the tool (delegate to MCP client) with validated args
    logger.info(`[v314 INTERCEPTOR] Executing tool: ${toolName}`);

    // 🔍 TRACING: Log arguments being sent to MCP client
    logger.info(`[🔍 TRACE] Calling MCP client`, {
      toolName,
      validatedArgs,
      validatedArgsType: typeof validatedArgs,
      validatedArgsKeys: Object.keys(validatedArgs || {}),
      validatedArgsJSON: JSON.stringify(validatedArgs),
    });

    const result = await mcpClient.callTool(toolName, validatedArgs);

    // 3. Convert to ToolResult format for interceptors
    const executionTime = Date.now() - startTime;
    const toolResult: ToolResult = {
      toolName,
      arguments: validatedArgs, // v335: Use validated args
      result,
      isError: false, // TODO: Detect errors from result
      executionTime,
    };

    // 4. Call afterAction interceptors
    logger.info(`[v314 INTERCEPTOR] Calling afterAction interceptors for: ${toolName}`);
    await interceptorManager.afterAction(toolResult, context);

    // 5. Inject any system hints from interceptors into iteration messages
    if (context.systemHints.length > 0) {
      logger.info(`[v314 INTERCEPTOR] Injecting ${context.systemHints.length} system hints from interceptors`);
      for (const hint of context.systemHints) {
        iterationMessages.push({
          role: 'system',
          content: hint.message,
        });
        logger.info(`[v314 INTERCEPTOR] Injected hint: ${hint.type} (${hint.priority})`);
      }

      // v357: Clear hints after injection to prevent re-injection in subsequent tool calls
      // This prevents: (1) accumulation within same iteration, (2) persistence across iterations
      context.systemHints = [];
      logger.info(`[v357 INTERCEPTOR] Cleared systemHints to prevent re-injection`);
    }

    // 6. Return the original result (not ToolResult wrapper)
    return result;
  } catch (error) {
    // Call error interceptors
    logger.error(`[v314 INTERCEPTOR] Tool execution error: ${toolName}`, error);
    await interceptorManager.onError(error as Error, context);

    // Re-throw the error so existing error handling works
    throw error;
  }
}
