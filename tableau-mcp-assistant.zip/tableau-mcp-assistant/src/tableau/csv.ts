/**
 * CSV data type definition
 */

export interface CsvData {
  columns: string[];
  rows: unknown[][];
}
