/**
 * InitStateHandler - Phase 3B
 *
 * Handles the INIT state: system prompt assembly, intent detection, and context preparation
 *
 * Responsibilities:
 * - Store core and scope system prompts in context
 * - Prepare for LLM invocation
 * - Transition to REASONING state
 *
 * Note: In Phase 3B, we're keeping this simple and delegating complex logic
 * to the adapter. Future phases can extract more logic here.
 */

import { StateHandler, StateHandlerResult } from '../StateHandler.js';
import { StateContext, Message } from '../types.js';
import { logger } from '../../util/logger.js';

export class InitStateHandler implements StateHandler {
  /**
   * Handle INIT state
   *
   * In Phase 3B, this is a minimal handler that:
   * 1. Logs initialization
   * 2. Validates that prompts are set in context
   * 3. Transitions to REASONING
   *
   * The actual prompt building happens in the handleUserPromptV3 adapter
   * before AgentExecutor.execute() is called.
   */
  async handle(context: StateContext, _messages: Message[]): Promise<StateHandlerResult> {
    logger.info('[v317 INIT-HANDLER] Initializing agent context', {
      hasCorePrompt: !!context.coreSystemPrompt,
      hasScopePrompt: !!context.scopeSystemPrompt,
      intent: context.intent || 'unknown',
      profileId: context.profileId,
    });

    // Validate that required prompts are present
    if (!context.coreSystemPrompt) {
      logger.warn('[v317 INIT-HANDLER] No core system prompt set - this may cause issues');
    }

    // Log context preparation complete
    logger.info('[v317 INIT-HANDLER] Context initialization complete', {
      systemPromptsReady: !!context.coreSystemPrompt,
      hintsCount: context.systemHints.length,
    });

    // Transition to REASONING state
    return {
      nextState: 'REASONING',
      metadata: {
        reason: 'Initialization complete',
        intent: context.intent,
      },
    };
  }

  /**
   * Called when entering INIT state
   */
  async onEnter(_context: StateContext): Promise<void> {
    logger.info('[v317 INIT-HANDLER] Entering INIT state');
  }

  /**
   * Called when exiting INIT state
   */
  async onExit(_context: StateContext): Promise<void> {
    logger.info('[v317 INIT-HANDLER] Exiting INIT state → REASONING');
  }
}
