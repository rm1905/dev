/**
 * RecoveryStateHandler - Phase 3E
 *
 * Handles the RECOVERY state: error recovery and retry logic
 *
 * Responsibilities:
 * - Check recovery attempt limits
 * - Prepare recovery context messages for LLM
 * - Increment recovery attempt counter
 * - Transition back to REASONING for retry (if attempts remain)
 * - Transition to FINALIZE if max recovery attempts exceeded
 *
 * Recovery Strategy:
 * - First recovery: Simple error context injection
 * - Second recovery: More explicit guidance
 * - Third+ recovery: Give up and finalize with error
 */

import { StateHandler, StateHandlerResult } from '../StateHandler.js';
import { StateContext, Message, SystemHint } from '../types.js';
import { logger } from '../../util/logger.js';

export interface RecoveryStateHandlerOptions {
  maxRecoveryAttempts?: number; // Default: 2
}

export class RecoveryStateHandler implements StateHandler {
  private maxRecoveryAttempts: number;

  constructor(options: RecoveryStateHandlerOptions = {}) {
    this.maxRecoveryAttempts = options.maxRecoveryAttempts ?? 2;
    logger.info('[v320 RECOVERY-HANDLER] Initialized', {
      maxRecoveryAttempts: this.maxRecoveryAttempts,
    });
  }

  /**
   * Handle RECOVERY state
   *
   * 1. Check if max recovery attempts exceeded
   * 2. If not exceeded:
   *    - Create recovery context system message
   *    - Increment recovery attempts
   *    - Transition back to REASONING
   * 3. If exceeded:
   *    - Log recovery failure
   *    - Transition to FINALIZE with error context
   */
  async handle(context: StateContext, _messages: Message[]): Promise<StateHandlerResult> {
    const currentAttempt = context.recoveryAttempts;
    const errorMessage = context.lastQueryError || 'Unknown error occurred';

    logger.info('[v320 RECOVERY-HANDLER] Attempting error recovery', {
      currentAttempt,
      maxAttempts: this.maxRecoveryAttempts,
      error: errorMessage,
      iterationCount: context.iterationCount,
    });

    // Check if we've exceeded max recovery attempts
    if (currentAttempt >= this.maxRecoveryAttempts) {
      logger.warn('[v320 RECOVERY-HANDLER] Max recovery attempts exceeded → FINALIZE', {
        attempts: currentAttempt,
        maxAttempts: this.maxRecoveryAttempts,
      });

      // Prepare error message for final answer
      const errorAnswer = this._buildMaxAttemptsErrorMessage(errorMessage, currentAttempt);

      return {
        nextState: 'FINALIZE',
        metadata: {
          reason: 'Max recovery attempts exceeded',
          recoveryAttempts: currentAttempt,
          finalError: errorMessage,
        },
        finalAnswer: errorAnswer,
      };
    }

    // Increment recovery attempts
    context.recoveryAttempts++;

    // Build recovery context message based on attempt number
    const recoveryMessage = this._buildRecoveryMessage(errorMessage, context.recoveryAttempts);

    // Inject recovery context as system message
    const recoverySystemMessage: Message = {
      role: 'system',
      content: recoveryMessage,
    };

    logger.info('[v320 RECOVERY-HANDLER] Injecting recovery context', {
      attempt: context.recoveryAttempts,
      messageLength: recoveryMessage.length,
    });

    // Also add to system hints for tracking
    const recoveryHint: SystemHint = {
      type: 'ERROR_RECOVERY',
      message: `Recovery attempt ${context.recoveryAttempts}/${this.maxRecoveryAttempts}`,
      priority: 'HIGH',
      metadata: {
        attempt: context.recoveryAttempts,
        error: errorMessage,
      },
    };
    context.systemHints.push(recoveryHint);

    // Transition back to REASONING to retry with recovery context
    logger.info('[v320 RECOVERY-HANDLER] Recovery context prepared → REASONING', {
      attempt: context.recoveryAttempts,
    });

    return {
      nextState: 'REASONING',
      messages: [recoverySystemMessage],
      metadata: {
        reason: `Recovery attempt ${context.recoveryAttempts}/${this.maxRecoveryAttempts}`,
        error: errorMessage,
        recoveryAttempt: context.recoveryAttempts,
      },
    };
  }

  /**
   * Build recovery message based on attempt number
   *
   * First attempt: Simple error context
   * Second attempt: More explicit guidance
   * Third+ attempt: Shouldn't happen (we'll finalize instead)
   */
  private _buildRecoveryMessage(errorMessage: string, attemptNumber: number): string {
    if (attemptNumber === 1) {
      // First recovery: Simple error context
      return `⚠️ ERROR RECOVERY (Attempt 1/${this.maxRecoveryAttempts})

The previous action encountered an error:
${errorMessage}

Please analyze the error and try a different approach. Consider:
- Using different tool parameters
- Breaking the task into smaller steps
- Verifying the context or data you're working with`;
    } else if (attemptNumber === 2) {
      // Second recovery: More explicit guidance
      return `⚠️ ERROR RECOVERY (Attempt 2/${this.maxRecoveryAttempts}) - FINAL ATTEMPT

The previous action failed again with error:
${errorMessage}

This is your final attempt. Please:
1. Carefully review what went wrong
2. Try a fundamentally different approach
3. If the task is impossible with available tools, explain why and provide alternatives`;
    } else {
      // Fallback (shouldn't reach here)
      return `⚠️ ERROR RECOVERY (Attempt ${attemptNumber})

Previous error: ${errorMessage}

Please try a different approach to complete the task.`;
    }
  }

  /**
   * Build error message for final answer when max attempts exceeded
   */
  private _buildMaxAttemptsErrorMessage(errorMessage: string, attempts: number): string {
    return `I apologize, but I encountered repeated errors while trying to complete your request.

**Error details:**
${errorMessage}

**Recovery attempts:** ${attempts}

I've tried multiple approaches but was unable to resolve the issue. This could be due to:
- Insufficient permissions or access rights
- Temporary service unavailability
- Invalid data or parameters
- Limitations of the available tools

Please try rephrasing your request, providing more context, or breaking it down into smaller tasks.`;
  }

  /**
   * Called when entering RECOVERY state
   */
  async onEnter(context: StateContext): Promise<void> {
    logger.info('[v320 RECOVERY-HANDLER] Entering RECOVERY state', {
      recoveryAttempts: context.recoveryAttempts,
      lastError: context.lastQueryError,
      iteration: context.iterationCount,
    });
  }

  /**
   * Called when exiting RECOVERY state
   */
  async onExit(context: StateContext): Promise<void> {
    logger.info('[v320 RECOVERY-HANDLER] Exiting RECOVERY state', {
      recoveryAttempts: context.recoveryAttempts,
      willRetry: context.recoveryAttempts < this.maxRecoveryAttempts,
    });
  }
}
