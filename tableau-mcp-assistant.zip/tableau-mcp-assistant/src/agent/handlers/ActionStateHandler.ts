/**
 * ActionStateHandler - Phase 3D
 *
 * Handles the ACTION state: executing MCP tools via interceptors
 *
 * Responsibilities:
 * - Extract tool calls from last assistant message
 * - Execute each tool using Phase 2A's executeToolWithInterceptors()
 * - Collect results and add tool result messages to history
 * - Transition back to REASONING for next iteration
 * - Handle errors by transitioning to RECOVERY state
 *
 * Note: This handler reuses the proven tool execution infrastructure from Phase 2A,
 * ensuring interceptors (like PulseHintInterceptor) continue to work correctly.
 */

import { StateHandler, StateHandlerResult } from '../StateHandler.js';
import { StateContext, Message, ToolResult } from '../types.js';
import { McpClient } from '../../mcp/client.js';
import { InterceptorManager } from '../InterceptorManager.js';
import { executeToolWithInterceptors } from '../../ws/toolExecutionWithInterceptors.js';
import { logger } from '../../util/logger.js';
import type { WebSocket } from 'ws';
import { MAX_VIEW_ROWS_FOR_MODEL } from '../../utils/constants.js';
import { summariseToolResult, extractSortSummary } from '../../ws/broker.js';
import { extractQueryContext } from '../utils/QueryContextBuilder.js';

/**
 * v359: Analyze tool result quality (Phase 2)
 */
interface ToolQualityAnalysis {
  status: 'good' | 'warning' | 'error';
  issues: string[];
  metrics: {
    hasData: boolean;
    rowCount: number;
    isTruncated: boolean;
    isError: boolean;
  };
}

/**
 * v366: Summarize validation errors for UI display
 * Extracts concise, user-friendly error descriptions from verbose validation messages
 *
 * Strategy:
 * 1. Extract first sentence from **ERROR:** markers (most specific)
 * 2. Extract key phrases from bullet point messages (after the colon)
 * 3. Pattern match for common validation issues
 * 4. Limit to 3 concise, actionable issues
 */
function summarizeValidationError(errorMessage: string): string[] {
  const issues: string[] = [];

  // Strategy 1: Extract text after **ERROR:** markers (most specific context)
  const errorMarkerRegex = /\*\*ERROR:\*\*\s+([^*\n]+)/gi;
  let match;
  while ((match = errorMarkerRegex.exec(errorMessage)) !== null) {
    const errorText = match[1].trim();
    // Extract first sentence or clause (up to period, newline, or 100 chars)
    const firstSentence = errorText.match(/^([^.\n]{1,100})/)?.[1]?.trim();
    if (firstSentence && firstSentence.length > 10) {
      issues.push(firstSentence);
    }
  }

  // Strategy 2: Extract messages from bullet points (after path: message format)
  // Format: "  • path: message" or "  • path: message\n    → context"
  if (issues.length < 3) {
    const bulletRegex = /•\s+[^:]+:\s*([^\n→]+)/g;
    while ((match = bulletRegex.exec(errorMessage)) !== null && issues.length < 3) {
      const message = match[1].trim();
      // Filter out redundant/technical messages
      if (message.length > 15 &&
          !message.startsWith('Required') &&
          !message.match(/^Must be one of:/i)) {
        // Simplify long messages - take first clause
        const simplified = message.split(/[,;]|(?:\.(?:\s|$))/)[0].trim();
        if (simplified.length > 10 && !issues.includes(simplified)) {
          issues.push(simplified);
        }
      }
    }
  }

  // Strategy 3: Pattern matching for common validation issues
  if (issues.length === 0) {
    // Check for specific error patterns
    if (errorMessage.includes('sortDirection') && errorMessage.includes('inside field objects')) {
      issues.push('Sort properties must be inside field objects');
    } else if (errorMessage.includes('"sorts" array')) {
      issues.push('Remove "sorts" array, add sort properties to fields');
    } else if (errorMessage.includes('TOP filter properties') && errorMessage.includes('query level')) {
      issues.push('Move TOP filter from query level to filters array');
    } else if (errorMessage.includes('groupBy') && errorMessage.includes('does NOT support')) {
      issues.push('Remove "groupBy" parameter (not supported)');
    } else if (errorMessage.includes('filterType') && errorMessage.includes('SET, MATCH, QUANTITATIVE')) {
      issues.push('Invalid filter type');
    } else if (errorMessage.includes('field or column reference')) {
      issues.push('Filter missing field or column reference');
    } else if (errorMessage.includes('VALIDATION ERROR')) {
      issues.push('Invalid tool arguments');
    } else {
      // Last resort: extract first meaningful line
      const lines = errorMessage.split('\n').filter(line =>
        line.trim() &&
        !line.match(/^[❌✅🚨📊🏆🔤📈📅]/u) && // Skip emoji-only lines
        !line.match(/^\*\*/) && // Skip markdown headers
        !line.match(/^```/) && // Skip code blocks
        line.length > 20
      );
      if (lines.length > 0) {
        const firstLine = lines[0].trim().substring(0, 80);
        issues.push(firstLine);
      }
    }
  }

  // Deduplicate and limit to 3 concise issues
  const uniqueIssues = Array.from(new Set(issues));
  return uniqueIssues.slice(0, 3);
}

function analyzeToolResult(
  toolName: string,
  result: any,
  isError: boolean,
  _args?: Record<string, any> // v359: Prefixed with _ to indicate intentionally unused (for future use)
): ToolQualityAnalysis {
  const issues: string[] = [];
  let status: 'good' | 'warning' | 'error' = 'good';

  // Metrics
  let hasData = false;
  let rowCount = 0;
  let isTruncated = false;

  if (isError) {
    status = 'error';
    issues.push('Tool execution failed');
    return {
      status,
      issues,
      metrics: { hasData: false, rowCount: 0, isTruncated: false, isError: true },
    };
  }

  // Analyze result structure for data tools
  if ((toolName === 'query-datasource' || toolName === 'get-view-data') && result) {
    const resultObj = result as any;

    // Check for data presence - handle both structures:
    // - query-datasource uses 'rows'
    // - get-view-data uses 'previewRows'
    const dataRows = resultObj.rows || resultObj.previewRows;

    if (dataRows && Array.isArray(dataRows)) {
      hasData = dataRows.length > 0;
      rowCount = dataRows.length;

      // Check for truncation using totalRows metadata
      const totalRows = resultObj.totalRows;
      if (typeof totalRows === 'number' && totalRows > rowCount) {
        isTruncated = true;
        issues.push(`Data truncated: showing ${rowCount} of ${totalRows} rows`);
        status = 'warning';
      }

      // Check for empty results
      if (!hasData) {
        issues.push('No data returned');
        status = 'warning';
      } else if (rowCount < 5 && totalRows === undefined) {
        // Only warn about small datasets if we don't have totalRows info
        issues.push(`Only ${rowCount} row${rowCount > 1 ? 's' : ''} returned (dataset may be small)`);
        status = 'warning';
      }
    } else {
      // No rows or previewRows field - unexpected structure
      issues.push('Result does not contain expected data structure');
      status = 'warning';
    }
  }

  // For non-data tools, just check if result exists
  if (toolName !== 'query-datasource' && toolName !== 'get-view-data') {
    hasData = !!result;
    if (!result) {
      issues.push('Tool returned empty result');
      status = 'warning';
    }
  }

  return {
    status,
    issues,
    metrics: { hasData, rowCount, isTruncated, isError: false },
  };
}

export interface ActionStateHandlerOptions {
  mcpClient: McpClient;
  interceptorManager: InterceptorManager;
  ws?: WebSocket; // v334: Optional WebSocket for sending UI updates
}

export class ActionStateHandler implements StateHandler {
  private mcpClient: McpClient;
  private interceptorManager: InterceptorManager;
  private ws?: WebSocket; // v334: WebSocket for UI updates

  constructor(options: ActionStateHandlerOptions) {
    this.mcpClient = options.mcpClient;
    this.interceptorManager = options.interceptorManager;
    this.ws = options.ws; // v334: Store WebSocket for UI updates
    logger.info('[v319 ACTION-HANDLER] Initialized', {
      hasWebSocket: !!this.ws,
    });
  }

  /**
   * Handle ACTION state
   *
   * 1. Extract tool calls from last assistant message
   * 2. Execute each tool with interceptors (reusing Phase 2A infrastructure)
   * 3. Collect results and build tool result messages
   * 4. Return messages to add to history
   * 5. Transition back to REASONING (or RECOVERY on error)
   */
  async handle(context: StateContext, messages: Message[]): Promise<StateHandlerResult> {
    logger.info('[v319 ACTION-HANDLER] Executing tools', {
      iterationCount: context.iterationCount,
      messageCount: messages.length,
    });

    // Extract tool calls from last assistant message
    const lastMessage = messages[messages.length - 1];

    if (!lastMessage || lastMessage.role !== 'assistant' || !lastMessage.tool_calls) {
      logger.error('[v319 ACTION-HANDLER] No tool calls found in last message');
      return {
        nextState: 'RECOVERY',
        metadata: {
          reason: 'No tool calls found in last assistant message',
          error: 'MISSING_TOOL_CALLS',
        },
      };
    }

    const toolCalls = lastMessage.tool_calls;
    logger.info(`[v319 ACTION-HANDLER] Found ${toolCalls.length} tool calls to execute`, {
      tools: toolCalls.map(tc => tc.function.name),
    });

    // Execute all tools and collect results
    const toolResultMessages: Message[] = []; // v332: Separate array for tool results only
    const systemHintMessages: Message[] = []; // v332: Separate array for system hints
    const toolResults: ToolResult[] = [];
    let hasErrors = false;

    // v343: Inject first query-datasource schema policy hint (session-wide, one-time)
    const hasQueryDatasourceCall = toolCalls.some(tc => tc.function.name === 'query-datasource');

    if (hasQueryDatasourceCall && !context.firstQueryDatasourceHintInjected) {
      context.firstQueryDatasourceHintInjected = true;

      const schemaHint = [
        'FOR THIS SESSION (IMPORTANT SCHEMA POLICY):',
        '- Never invent or assume field/column names when using query-datasource.',
        '- If a query-datasource call fails due to an unknown or invalid field/column, you MUST:',
        '  1) Call get-datasource-metadata for that datasourceId to inspect the actual schema;',
        '  2) Re-issue query-datasource using ONLY fields that actually exist in the metadata;',
        '  3) Only then answer the user, clearly explaining what you found.',
      ].join('\n');

      systemHintMessages.push({
        role: 'system',
        content: schemaHint,
      });

      logger.info('[v343 ACTION-HANDLER] Injected first query-datasource schema policy hint');
    }

    for (const toolCall of toolCalls) {
      const toolName = toolCall.function.name;
      const toolCallId = toolCall.id;
      let toolArgs: Record<string, any> = {}; // Initialize to empty object

      try {
        // Parse tool arguments
        toolArgs = typeof toolCall.function.arguments === 'string'
          ? JSON.parse(toolCall.function.arguments)
          : toolCall.function.arguments;

        // 🔍 TRACING: Log raw tool call from LLM before any processing (LOCAL LLM only)
        if (context.llmProvider === 'local') {
          logger.info(`[🔍 LOCAL-LLM TRACE] Tool call from LLM`, {
            toolName,
            toolCallId,
            rawArguments: toolCall.function.arguments,
            argumentsType: typeof toolCall.function.arguments,
            parsedArgs: toolArgs,
            parsedArgsKeys: Object.keys(toolArgs || {}),
            parsedArgsJSON: JSON.stringify(toolArgs, null, 2),
          });
        }

        logger.info(`[v319 ACTION-HANDLER] Executing tool: ${toolName}`, {
          toolCallId,
          args: toolArgs,
        });

        // v350: Runtime tool access control - check scope before execution
        if (context.toolProfile && context.intent) {
          const { canUseTool } = await import('../../ws/broker.js');
          const decision = canUseTool(
            toolName,
            context.toolProfile,
            context.intent as any, // QuestionIntent type
            context.allowedScope,
            toolArgs
          );

          if (!decision.allowed) {
            // Tool is blocked - send error and skip execution
            logger.warn(`[v350 RUNTIME] ${decision.logMessage}`);

            const errorResult = {
              error: 'TOOL_ACCESS_DENIED',
              message: decision.userMessage || `Tool "${toolName}" is not allowed in this context`,
              reason: decision.reason,
            };

            // Send error to UI
            if (this.ws) {
              this.ws.send(JSON.stringify({
                type: 'error',
                message: decision.userMessage || errorResult.message,
              }));

              // Send tool_result with error
              this.ws.send(JSON.stringify({
                type: 'tool_result',
                name: toolName,
                result: errorResult,
              }));
            }

            // Add error as tool result so LLM sees the rejection
            const resultMessage: Message = {
              role: 'tool',
              tool_call_id: toolCallId,
              content: JSON.stringify(errorResult, null, 2),
            };
            toolResultMessages.push(resultMessage);

            toolResults.push({
              toolName,
              arguments: toolArgs,
              result: errorResult,
              isError: true,
              error: errorResult.message,
              executionTime: 0,
            });

            logger.info(`[v350 RUNTIME] Blocked tool "${toolName}" - added rejection to conversation context`);
            continue; // Skip to next tool call
          }

          logger.info(`[v350 RUNTIME] Tool "${toolName}" allowed by access control`);
        }

        // v391: Duplicate query detection - prevent LLM from re-executing identical query-datasource
        // when sort verification is pending
        if (toolName === 'query-datasource' && toolArgs) {
          const currentDatasourceLuid = toolArgs.datasourceLuid;
          const currentSortSummary = extractSortSummary(toolArgs);

          // Check if this is a duplicate query during sort verification
          if (context.queryContext?.sortVerificationPending &&
              context.queryContext?.lastQueryDatasourceLuid === currentDatasourceLuid &&
              context.queryContext?.lastQuerySortSummary === currentSortSummary) {

            logger.warn('[v391 ACTION-HANDLER] DUPLICATE QUERY DETECTED - blocking re-execution', {
              datasourceLuid: currentDatasourceLuid,
              sortSummary: currentSortSummary,
              message: 'Same query attempted during sort verification',
            });

            // Build a special result message telling LLM to finalize instead
            const duplicateResult = {
              blocked: true,
              reason: 'DUPLICATE_QUERY_DETECTED',
              message: `This query is identical to the one you just executed. The sort order "${currentSortSummary}" has already been verified. You already have the correct results - proceed directly to finalize your answer without re-executing the query.`,
              previousSortSummary: currentSortSummary,
            };

            // Send to UI
            if (this.ws) {
              this.ws.send(JSON.stringify({
                type: 'tool_result',
                name: toolName,
                result: duplicateResult,
              }));
            }

            // Add as tool result so LLM sees the message
            const resultMessage: Message = {
              role: 'tool',
              tool_call_id: toolCallId,
              content: JSON.stringify(duplicateResult, null, 2),
            };
            toolResultMessages.push(resultMessage);

            toolResults.push({
              toolName,
              arguments: toolArgs,
              result: duplicateResult,
              isError: false,
              executionTime: 0,
            });

            // Clear sortVerificationPending flag since we're forcing finalization
            context.queryContext.sortVerificationPending = false;

            logger.info('[v391 ACTION-HANDLER] Blocked duplicate query - instructed LLM to finalize');
            continue; // Skip to next tool call
          }
        }

        // v344: Extract QueryContext for query-datasource to enable execution phase hints
        if (toolName === 'query-datasource' && toolArgs && toolArgs.query) {
          try {
            context.queryContext = extractQueryContext(toolArgs.query);
            logger.info('[v344 ACTION-HANDLER] Extracted QueryContext for query-datasource', {
              isAggregated: context.queryContext.isAggregated,
              userRequestedRows: context.queryContext.userRequestedRows,
              aggregationLevel: context.queryContext.aggregationLevel,
            });
          } catch (error) {
            logger.warn('[v344 ACTION-HANDLER] Failed to extract QueryContext:', error);
          }
        } else if (toolName === 'get-view-data') {
          // For get-view-data, initialize a basic QueryContext (will be updated by interceptor)
          context.queryContext = {
            userRequestedRows: null,
            actualRowsReceived: null,
            totalRowsInDataset: null,
            truncatedRows: 0,
            isAggregated: false,
            aggregationLevel: null,
            metricColumns: [],
            executionHintInjected: false,
            reminderInjected: false,
          };
          logger.info('[v344 ACTION-HANDLER] Initialized QueryContext for get-view-data');
        }

        // v334: Send tool_call to UI before execution
        if (this.ws) {
          this.ws.send(JSON.stringify({
            type: 'tool_call',
            name: toolName,
            args: toolArgs,
          }));
        }

        // Array to collect any system hints from interceptors
        const iterationMessages: Message[] = [];

        // Execute tool with Phase 2A interceptor infrastructure
        const startTime = Date.now();
        const result = await executeToolWithInterceptors({
          mcpClient: this.mcpClient,
          toolName,
          toolArgs,
          interceptorManager: this.interceptorManager,
          iterationMessages, // Interceptors can inject hints here
          context, // v348: Pass StateContext so interceptors can access queryContext
        });
        const executionTime = Date.now() - startTime;

        // v334: Send tool_result to UI after execution
        if (this.ws) {
          this.ws.send(JSON.stringify({
            type: 'tool_result',
            name: toolName,
            result,
          }));

          // v334: Send data_table for query results (get-view-data, query-datasource)
          // v341: Use summariseToolResult to get properly formatted displayForUi with MAX_VIEW_ROWS_FOR_UI
          if ((toolName === 'get-view-data' || toolName === 'query-datasource') &&
              result && typeof result === 'object') {

            // Call summariseToolResult to extract and format data properly
            const { displayForUi } = summariseToolResult(toolName, result, null, context.maxViewRowsForModel ?? 30);

            if (displayForUi && typeof displayForUi === 'object') {
              const dataForUi = displayForUi as any;

              // Build display name with row count
              const totalRows = dataForUi.totalRows || (Array.isArray(dataForUi.rows) ? dataForUi.rows.length : 0);
              const displayedRows = dataForUi.displayedRows || (Array.isArray(dataForUi.rows) ? dataForUi.rows.length : 0);
              const isTruncated = displayedRows < totalRows;
              const recordCountText = isTruncated
                ? `${displayedRows} of ${totalRows} record${totalRows !== 1 ? 's' : ''}`
                : `${totalRows} record${totalRows !== 1 ? 's' : ''}`;

              const displayName = `Data from ${toolName} (${recordCountText})`;

              // Build data_table message
              const dataTableMessage = {
                type: 'data_table',
                id: toolCallId,
                name: displayName,
                data: displayForUi,
              };

              // v392: Buffer data_table during sort verification instead of sending immediately
              // This prevents showing multiple tables with wrong sorts before the correct one
              if (toolName === 'query-datasource' && context.queryContext?.sortVerificationPending) {
                // Don't send immediately - buffer it for later
                context.queryContext.bufferedDataTable = dataTableMessage;
                logger.info('[v392 ACTION-HANDLER] Buffered data_table during sort verification', {
                  sortSummary: context.queryContext.sortSummary,
                  columns: Array.isArray(dataForUi.columns) ? dataForUi.columns.length : 0,
                  displayedRows,
                  totalRows,
                });
              } else {
                // Normal path - send immediately
                this.ws.send(JSON.stringify(dataTableMessage));
                logger.info(`[v341 ACTION-HANDLER] Sent data_table to UI`, {
                  tool: toolName,
                  columns: Array.isArray(dataForUi.columns) ? dataForUi.columns.length : 0,
                  displayedRows,
                  totalRows,
                });
              }
            } else {
              logger.warn(`[v341 ACTION-HANDLER] summariseToolResult did not return displayForUi for ${toolName}`);
            }
          }

          // v334: Send evidence for get-view-data
          // v338: Use MAX_VIEW_ROWS_FOR_MODEL constant instead of hardcoded 10
          if (toolName === 'get-view-data' && result && typeof result === 'object') {
            const resultObj = result as any;

            if (resultObj.columns && Array.isArray(resultObj.columns) &&
                resultObj.rows && Array.isArray(resultObj.rows)) {

              // Send evidence sample (first MAX_VIEW_ROWS_FOR_MODEL rows)
              this.ws.send(JSON.stringify({
                type: 'evidence',
                sample: {
                  columns: resultObj.columns,
                  rows: resultObj.rows.slice(0, MAX_VIEW_ROWS_FOR_MODEL),
                },
              }));

              logger.info(`[v338 ACTION-HANDLER] Sent evidence to UI`, {
                tool: toolName,
                sampleRows: Math.min(MAX_VIEW_ROWS_FOR_MODEL, resultObj.rows.length),
                maxRows: MAX_VIEW_ROWS_FOR_MODEL,
              });
            }
          }

          // v337: Send pulse_bundle for generate-pulse-metric-value-insight-bundle
          if (toolName === 'generate-pulse-metric-value-insight-bundle' && result && typeof result === 'object') {
            // Extract metric name from args
            let metricName = 'Unknown Metric';
            if (toolArgs && typeof toolArgs === 'object') {
              const argsObj = toolArgs as any;
              metricName = argsObj?.bundleRequest?.bundle_request?.input?.metadata?.name || metricName;
            }

            // Extract bundle from MCP tool response
            const resultAny = result as any;
            let bundleToSend = null;

            if (resultAny.content && Array.isArray(resultAny.content) && resultAny.content.length > 0) {
              const contentItem = resultAny.content[0];
              if (contentItem.type === 'text' && typeof contentItem.text === 'string') {
                try {
                  bundleToSend = JSON.parse(contentItem.text);
                } catch (parseError) {
                  logger.error('[v337 ACTION-HANDLER] Failed to parse pulse bundle', {
                    error: (parseError as Error).message,
                  });
                }
              }
            }

            if (bundleToSend) {
              // Send pulse bundle to UI for rendering vega charts
              this.ws.send(JSON.stringify({
                type: 'pulse_bundle',
                name: `Pulse Metric ${metricName}`,
                bundle: bundleToSend,
              }));

              logger.info(`[v337 ACTION-HANDLER] Sent pulse_bundle to UI`, {
                tool: toolName,
                metricName,
                hasSummary: !!bundleToSend?.summary,
                hasSpec: !!bundleToSend?.spec,
              });
            }
          }
        }

        // v332: Collect system hints separately (will be added AFTER all tool results)
        if (iterationMessages.length > 0) {
          logger.info(`[v332 ACTION-HANDLER] Collected ${iterationMessages.length} system hints from interceptors (will add after all tool results)`);
          systemHintMessages.push(...iterationMessages);
        }

        // v349: Call summariseToolResult to get LLM-friendly version with metadata
        // This ensures LLM gets truncated data with totalRows/__truncatedRows metadata
        // v384: Extract sort summary for query-datasource to help LLM verify sort correctness
        let sortSummary: string | null = null;
        if (toolName === 'query-datasource') {
          sortSummary = extractSortSummary(toolArgs);
          if (sortSummary) {
            logger.info(`[v384 ACTION-HANDLER] Attaching sort summary to query-datasource result: ${sortSummary}`);
            // v389: Store sortSummary in queryContext for v347 presentation reminder control
            if (context.queryContext) {
              context.queryContext.sortSummary = sortSummary;
            }
          }

          // v391: Store query details for duplicate detection
          if (context.queryContext) {
            context.queryContext.lastQueryDatasourceLuid = toolArgs.datasourceLuid;
            context.queryContext.lastQuerySortSummary = sortSummary || undefined;
            logger.info(`[v391 ACTION-HANDLER] Stored query details for duplicate detection`, {
              datasourceLuid: toolArgs.datasourceLuid,
              sortSummary: sortSummary || 'none',
            });
          }
        }

        const { safeForModel } = summariseToolResult(toolName, result, sortSummary, context.maxViewRowsForModel ?? 30);

        logger.info(`[v349 ACTION-HANDLER] Using summariseToolResult for ${toolName}`, {
          rawResultSize: JSON.stringify(result).length,
          safeForModelSize: JSON.stringify(safeForModel).length,
        });

        // v384: Add system hint for sort verification when sortSummary is present
        // v388: Strengthened hint to be more directive and explicit
        // v389: Set sortVerificationPending flag to disable v347 presentation reminder
        // v390: Clarify that verification is logical check, not re-execution
        // v391: Add programmatic duplicate detection to prevent re-execution
        if (toolName === 'query-datasource' && sortSummary) {
          const verificationHint: Message = {
            role: 'system',
            content: `⚠️ CRITICAL SORT VERIFICATION REQUIRED ⚠️

The query was executed with this sort order: "${sortSummary}"

IMPORTANT: The query has ALREADY been executed with the sort order shown above.
You are verifying the sort fields that were USED in that execution.
This is a LOGICAL CHECK - compare the sort fields to the user's request.
DO NOT call query-datasource again UNLESS the sort fields are actually wrong.

YOU MUST NOW VERIFY THIS SORT ORDER:

1. **Analyze the user's original request**: What specific field did they ask to sort by?
   - Example: "top 10 by revenue" means PRIMARY sort must be revenue/sales field
   - Example: "highest sales" means PRIMARY sort must be sales field DESC
   - Example: "sort by category" means PRIMARY sort must be category field

2. **Check if the PRIMARY (first) sort field matches the user's request**:
   - The PRIMARY sort field is the FIRST field in "${sortSummary}"
   - If the user asked for results ranked by field X, then field X MUST be the PRIMARY sort

3. **If the sort does NOT match the user's explicit request:**
   - DO NOT finalize the answer
   - DO NOT present these results to the user
   - You MUST call query-datasource again with the correct sort order
   - Only finalize once the sort order is correct

4. **If the sort DOES match the user's request:**
   - ✅ The sort is CORRECT - verification complete
   - DO NOT call query-datasource again (you already have the correct results)
   - Proceed directly to finalize your answer
   - Present the results you already received with confidence

REMEMBER: When a user asks for "top 10 by X", field X must be the PRIMARY (first) sort field, not a secondary sort field.`
          };
          systemHintMessages.push(verificationHint);
          logger.info(`[v391 ACTION-HANDLER] Added sort verification hint for query-datasource`);

          // v389: Flag that sort verification is pending - this will disable v347 presentation reminder
          // v390: With clarified hint, LLM should only re-query if sort is actually wrong
          // v391: Programmatic duplicate detection will block re-execution if query is identical
          // v392: Buffer data_table messages until verification completes
          if (context.queryContext) {
            context.queryContext.sortVerificationPending = true;
            logger.info(`[v392 ACTION-HANDLER] Set sortVerificationPending=true (data table will be buffered)`);

            // v392: Send status message to inform user that verification is happening
            if (this.ws) {
              this.ws.send(JSON.stringify({
                type: 'status',
                message: 'Verifying sort order for query results...',
              }));
            }
          }
        }

        // Build tool result message with safeForModel (not raw result)
        const resultMessage: Message = {
          role: 'tool',
          tool_call_id: toolCallId,
          content: JSON.stringify(safeForModel, null, 2),
        };
        toolResultMessages.push(resultMessage); // v332: Add to tool results array

        // Track tool result for metadata
        toolResults.push({
          toolName,
          arguments: toolArgs,
          result,
          isError: false,
          executionTime,
        });

        // v359: Analyze tool result quality and send to UI (Phase 2)
        // v360: Use safeForModel (extracted data) instead of raw result for accurate quality analysis
        const qualityAnalysis = analyzeToolResult(toolName, safeForModel, false, toolArgs);

        if (this.ws) {
          this.ws.send(JSON.stringify({
            type: 'tool_quality',
            toolName,
            toolCallId,
            status: qualityAnalysis.status,
            issues: qualityAnalysis.issues,
            metrics: qualityAnalysis.metrics,
          }));

          logger.info(`[v359 ACTION-HANDLER] Sent tool_quality for ${toolName}`, {
            status: qualityAnalysis.status,
            issueCount: qualityAnalysis.issues.length,
          });
        }

        logger.info(`[v319 ACTION-HANDLER] Tool ${toolName} completed successfully`, {
          executionTime,
          resultSize: JSON.stringify(result).length,
          qualityStatus: qualityAnalysis.status,
        });
      } catch (error) {
        hasErrors = true;
        const errorMessage = (error as Error).message || 'Unknown error';
        logger.error(`[v319 ACTION-HANDLER] Tool ${toolName} failed`, {
          error: errorMessage,
          toolCallId,
        });

        // v334: Send error result to UI
        if (this.ws) {
          this.ws.send(JSON.stringify({
            type: 'tool_result',
            name: toolName,
            result: { error: errorMessage },
          }));
        }

        // Build error result message
        const errorResultMessage: Message = {
          role: 'tool',
          tool_call_id: toolCallId,
          content: JSON.stringify({
            error: errorMessage,
            toolName,
            arguments: toolArgs || {},
          }, null, 2),
        };
        toolResultMessages.push(errorResultMessage); // v332: Add to tool results array

        // Track error for metadata
        toolResults.push({
          toolName,
          arguments: toolArgs || {},
          result: null,
          isError: true,
          error: errorMessage,
          executionTime: 0,
        });

        // v359: Analyze error quality and send to UI (Phase 2)
        // v367: Use structured error summaries from ValidationError if available
        const errorQualityAnalysis = analyzeToolResult(toolName, null, true, toolArgs);

        // v367: Extract error summaries from ValidationError if available, otherwise fallback to parsing
        let summarizedErrors: string[];
        if ((error as any).errorSummaries && Array.isArray((error as any).errorSummaries)) {
          // ValidationError with structured summaries
          summarizedErrors = (error as any).errorSummaries;
          logger.info(`[v367 ACTION-HANDLER] Using structured error summaries from ValidationError`, {
            summaries: summarizedErrors,
          });
        } else {
          // Fallback to parsing error message (for non-validation errors)
          summarizedErrors = summarizeValidationError(errorMessage);
          logger.info(`[v367 ACTION-HANDLER] Fallback error summarization`, {
            summaries: summarizedErrors,
          });
        }

        if (this.ws) {
          this.ws.send(JSON.stringify({
            type: 'tool_quality',
            toolName,
            toolCallId,
            status: errorQualityAnalysis.status,
            issues: [...errorQualityAnalysis.issues, ...summarizedErrors],
            metrics: errorQualityAnalysis.metrics,
          }));

          logger.info(`[v367 ACTION-HANDLER] Sent tool_quality for failed ${toolName}`, {
            status: errorQualityAnalysis.status,
            summarizedIssues: summarizedErrors,
            isValidationError: !!(error as any).errorSummaries,
          });
        }

        // Store error context for potential recovery
        context.lastQueryError = `Tool ${toolName} failed: ${errorMessage}`;
      }
    }

    // Log execution summary
    const successCount = toolResults.filter(r => !r.isError).length;
    const errorCount = toolResults.filter(r => r.isError).length;
    logger.info('[v319 ACTION-HANDLER] Tool execution complete', {
      total: toolResults.length,
      success: successCount,
      errors: errorCount,
    });

    // v332: Combine messages in correct order: tool results FIRST, then system hints
    // This ensures OpenAI format compliance: assistant with tool_calls → ALL tool responses → system hints
    const resultMessages = [...toolResultMessages, ...systemHintMessages];
    logger.info(`[v332 ACTION-HANDLER] Combined ${toolResultMessages.length} tool results + ${systemHintMessages.length} system hints`);

    // Decide next state based on results
    if (hasErrors && errorCount === toolResults.length) {
      // All tools failed - transition to RECOVERY
      logger.warn('[v319 ACTION-HANDLER] All tools failed → RECOVERY');
      return {
        nextState: 'RECOVERY',
        messages: resultMessages,
        metadata: {
          reason: 'All tool executions failed',
          errorCount,
          toolResults,
        },
      };
    }

    // At least some tools succeeded - transition back to REASONING
    logger.info('[v319 ACTION-HANDLER] Tool execution complete → REASONING');
    return {
      nextState: 'REASONING',
      messages: resultMessages,
      metadata: {
        reason: 'Tool execution complete',
        successCount,
        errorCount,
        toolResults,
      },
    };
  }

  /**
   * Called when entering ACTION state
   */
  async onEnter(context: StateContext): Promise<void> {
    logger.info('[v319 ACTION-HANDLER] Entering ACTION state', {
      iteration: context.iterationCount,
    });
  }

  /**
   * Called when exiting ACTION state
   */
  async onExit(context: StateContext): Promise<void> {
    logger.info('[v319 ACTION-HANDLER] Exiting ACTION state', {
      iteration: context.iterationCount,
    });
  }
}
