/**
 * FinalizeStateHandler - Phase 3F
 *
 * Handles the FINALIZE state: extract final answer and prepare for completion
 *
 * Responsibilities:
 * - Extract final answer from last assistant message or context
 * - Store final answer in context
 * - Transition to COMPLETED state
 *
 * Note: Complex grounding logic (generateGroundedAnswer, validateAnswer) will remain
 * in the adapter initially. This handler focuses on simple finalization.
 * Future phases can move grounding logic into this handler if needed.
 */

import { StateHandler, StateHandlerResult } from '../StateHandler.js';
import { StateContext, Message } from '../types.js';
import { logger } from '../../util/logger.js';

export class FinalizeStateHandler implements StateHandler {
  constructor() {
    logger.info('[v321 FINALIZE-HANDLER] Initialized');
  }

  /**
   * Handle FINALIZE state
   *
   * 1. Extract final answer from last assistant message or context
   * 2. Store in context.finalAnswer
   * 3. Transition to COMPLETED
   */
  async handle(context: StateContext, messages: Message[]): Promise<StateHandlerResult> {
    logger.info('[v321 FINALIZE-HANDLER] Finalizing answer', {
      iterationCount: context.iterationCount,
      messageCount: messages.length,
      hasContextAnswer: !!context.finalAnswer,
    });

    // Check if finalAnswer already set in context (e.g., from RECOVERY handler)
    let finalAnswer = context.finalAnswer;

    // If not already set, extract from last assistant message
    if (!finalAnswer && messages.length > 0) {
      const lastMessage = messages[messages.length - 1];

      if (lastMessage.role === 'assistant' && lastMessage.content) {
        finalAnswer = lastMessage.content;
        logger.info('[v321 FINALIZE-HANDLER] Extracted answer from last assistant message', {
          contentLength: finalAnswer.length,
        });
      } else {
        logger.warn('[v321 FINALIZE-HANDLER] Last message is not an assistant text response', {
          lastMessageRole: lastMessage.role,
          hasToolCalls: !!(lastMessage.role === 'assistant' && (lastMessage as any).tool_calls),
        });

        // Fallback: search backwards for last assistant text message
        for (let i = messages.length - 1; i >= 0; i--) {
          const msg = messages[i];
          if (msg.role === 'assistant' && msg.content && !(msg as any).tool_calls) {
            finalAnswer = msg.content;
            logger.info('[v321 FINALIZE-HANDLER] Found assistant text in earlier message', {
              messageIndex: i,
              contentLength: finalAnswer.length,
            });
            break;
          }
        }
      }
    }

    // Store final answer in context
    if (finalAnswer) {
      context.finalAnswer = finalAnswer;
      logger.info('[v321 FINALIZE-HANDLER] Final answer stored in context', {
        answerLength: finalAnswer.length,
        answerPreview: finalAnswer.substring(0, 100) + (finalAnswer.length > 100 ? '...' : ''),
      });
    } else {
      // No final answer found - this shouldn't happen in normal flow
      logger.error('[v321 FINALIZE-HANDLER] No final answer found in messages or context');
      context.finalAnswer = 'I apologize, but I was unable to generate a response. Please try rephrasing your question.';
    }

    // Log completion summary
    logger.info('[v321 FINALIZE-HANDLER] Agent execution complete', {
      totalIterations: context.iterationCount,
      recoveryAttempts: context.recoveryAttempts,
      systemHints: context.systemHints.length,
      tokenUsage: context.tokenUsage.total,
    });

    // Transition to COMPLETED terminal state
    return {
      nextState: 'COMPLETED',
      metadata: {
        reason: 'Final answer extracted and stored',
        iterations: context.iterationCount,
        recoveryAttempts: context.recoveryAttempts,
        answerLength: context.finalAnswer?.length || 0,
      },
    };
  }

  /**
   * Called when entering FINALIZE state
   */
  async onEnter(context: StateContext): Promise<void> {
    logger.info('[v321 FINALIZE-HANDLER] Entering FINALIZE state', {
      iteration: context.iterationCount,
      hasContextAnswer: !!context.finalAnswer,
    });
  }

  /**
   * Called when exiting FINALIZE state
   */
  async onExit(context: StateContext): Promise<void> {
    logger.info('[v321 FINALIZE-HANDLER] Exiting FINALIZE state → COMPLETED', {
      finalAnswerLength: context.finalAnswer?.length || 0,
    });
  }
}
