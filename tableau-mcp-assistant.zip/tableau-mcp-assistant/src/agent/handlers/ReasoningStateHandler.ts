/**
 * ReasoningStateHandler - Phase 3C
 *
 * Handles the REASONING state: LLM invocation, tool call parsing, and state transitions
 *
 * Responsibilities:
 * - Decide next state based on LLM response (ACTION if tool calls, FINALIZE if final answer)
 * - Increment iteration count
 * - Manage reasoning loop state
 *
 * Note: In Phase 3C, the actual LLM streaming call is delegated to the adapter.
 * Future phases can extract the full LLM streaming logic here.
 */

import { StateHandler, StateHandlerResult } from '../StateHandler.js';
import { StateContext, Message } from '../types.js';
import { logger } from '../../util/logger.js';

/**
 * Extended context with LLM dependencies
 *
 * The adapter will set this before calling AgentExecutor.execute()
 */
export interface ReasoningContext extends StateContext {
  // LLM response state (set by adapter during LLM call)
  hasPendingToolCalls?: boolean;
  pendingToolCallCount?: number;
  hasAssistantResponse?: boolean;
}

export class ReasoningStateHandler implements StateHandler {
  /**
   * Handle REASONING state
   *
   * In Phase 3C, this is a minimal handler that:
   * 1. Logs reasoning state entry
   * 2. Assumes adapter has called LLM and populated messages
   * 3. Analyzes messages to determine next state:
   *    - If tool calls detected → ACTION
   *    - If assistant response (no tool calls) → FINALIZE
   * 4. Increments iteration count
   *
   * The actual LLM streaming happens in the handleUserPromptV3 adapter.
   */
  async handle(context: StateContext, messages: Message[]): Promise<StateHandlerResult> {
    logger.info('[v318 REASONING-HANDLER] Processing LLM response', {
      iterationCount: context.iterationCount,
      maxIterations: context.maxIterations,
      messageCount: messages.length,
    });

    // Increment iteration count (one full reasoning cycle)
    context.iterationCount++;
    logger.info(`[v318 REASONING-HANDLER] Iteration ${context.iterationCount}/${context.maxIterations}`);

    // Analyze messages to determine next state
    const lastMessage = messages[messages.length - 1];

    if (!lastMessage) {
      logger.error('[v318 REASONING-HANDLER] No messages in history - cannot determine next state');
      return {
        nextState: 'ABORTED',
        metadata: {
          reason: 'No messages to process',
          error: 'EMPTY_MESSAGE_HISTORY',
        },
      };
    }

    // Check if LLM made tool calls
    const hasToolCalls = lastMessage.role === 'assistant' && lastMessage.tool_calls && lastMessage.tool_calls.length > 0;

    if (hasToolCalls) {
      const toolCount = lastMessage.tool_calls!.length;
      logger.info(`[v318 REASONING-HANDLER] LLM requested ${toolCount} tool calls → ACTION`, {
        tools: lastMessage.tool_calls!.map(tc => tc.function.name),
      });

      return {
        nextState: 'ACTION',
        metadata: {
          reason: `LLM requested ${toolCount} tool calls`,
          toolCount,
        },
      };
    }

    // Check if LLM provided a final answer (assistant message with content, no tool calls)
    const hasFinalAnswer = lastMessage.role === 'assistant' && lastMessage.content && !lastMessage.tool_calls;

    if (hasFinalAnswer) {
      logger.info('[v318 REASONING-HANDLER] LLM provided final answer → FINALIZE', {
        contentPreview: typeof lastMessage.content === 'string'
          ? lastMessage.content.substring(0, 100)
          : '[non-string content]',
      });

      // v389: Warn if sort verification was pending but LLM finalized anyway
      // v392: Send buffered data_table now that verification is complete
      if (context.queryContext?.sortVerificationPending) {
        logger.warn('[v389 REASONING-HANDLER] ⚠️ LLM finalized while sortVerificationPending=true', {
          sortSummary: context.queryContext.sortSummary,
          message: 'LLM may have ignored sort verification hint or verified sort is correct',
        });

        // v392: Send buffered data_table now that sort verification is complete
        if (context.queryContext.bufferedDataTable && context.ws) {
          context.ws.send(JSON.stringify(context.queryContext.bufferedDataTable));
          logger.info('[v392 REASONING-HANDLER] Sent buffered data_table after verification complete', {
            sortSummary: context.queryContext.sortSummary,
          });
          // Clear buffered table
          context.queryContext.bufferedDataTable = undefined;
        }

        // Clear the flag to prevent issues in future iterations
        context.queryContext.sortVerificationPending = false;
      }

      return {
        nextState: 'FINALIZE',
        metadata: {
          reason: 'LLM provided final answer',
          hasFinalAnswer: true,
        },
      };
    }

    // Unexpected state: no tool calls and no final answer
    logger.warn('[v318 REASONING-HANDLER] Unexpected LLM response - no tool calls and no final answer', {
      lastMessageRole: lastMessage.role,
      hasContent: !!lastMessage.content,
      hasToolCalls: !!lastMessage.tool_calls,
    });

    // Default to FINALIZE to avoid infinite loop
    return {
      nextState: 'FINALIZE',
      metadata: {
        reason: 'Unexpected LLM response format - defaulting to FINALIZE',
        warning: 'NO_TOOL_CALLS_OR_FINAL_ANSWER',
      },
    };
  }

  /**
   * Called when entering REASONING state
   */
  async onEnter(context: StateContext): Promise<void> {
    logger.info('[v318 REASONING-HANDLER] Entering REASONING state', {
      iteration: context.iterationCount,
    });
  }

  /**
   * Called when exiting REASONING state
   */
  async onExit(context: StateContext): Promise<void> {
    logger.info('[v318 REASONING-HANDLER] Exiting REASONING state', {
      iteration: context.iterationCount,
    });
  }
}
