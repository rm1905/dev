/**
 * QueryContextBuilder - Extracts and updates QueryContext for execution phase hints (v344)
 *
 * This utility extracts query metadata from tool arguments and results to enable
 * execution phase hints that warn about:
 * - Truncated data (preview limitations)
 * - Request mismatches (asked for 100, got 30)
 * - Aggregation constraints (don't sum pre-aggregated values)
 * - Calculation validation (verify totals match displayed data)
 *
 * Context: When query-datasource or get-view-data return truncated results,
 * the LLM may incorrectly compute totals or make conclusions based on incomplete data.
 * These hints prevent such hallucinations.
 */

import { QueryContext } from '../types.js';
import { logger } from '../../util/logger.js';

/**
 * VdsQuery interface (subset - only what we need for context extraction)
 */
interface VdsQuery {
  fields: Array<{
    fieldCaption?: string;
    groupBy?: boolean;
    aggregation?: string;
  }>;
  filters?: Array<{
    filterType: string;
    howMany?: number;
    [key: string]: any;
  }>;
}

/**
 * Extract QueryContext from query-datasource arguments
 *
 * @param query - The VdsQuery structure from tool arguments
 * @returns Initialized QueryContext with aggregation and request metadata
 */
export function extractQueryContext(query: VdsQuery): QueryContext {
  const context: QueryContext = {
    userRequestedRows: null,
    actualRowsReceived: null,
    totalRowsInDataset: null,
    truncatedRows: 0,
    isAggregated: false,
    aggregationLevel: null,
    metricColumns: [],
    executionHintInjected: false,
    reminderInjected: false,
  };

  try {
    // Detect aggregation: any field with groupBy=true
    const groupByFields = query.fields.filter(f => f.groupBy === true);
    const metricFields = query.fields.filter(f => f.aggregation && f.aggregation !== 'NONE');

    if (groupByFields.length > 0) {
      context.isAggregated = true;
      context.aggregationLevel = `GROUP BY ${groupByFields.map(f => f.fieldCaption || 'unknown').join(', ')}`;
      context.metricColumns = metricFields.map(f => f.fieldCaption || '');

      logger.info(
        `[v344 QUERY-CONTEXT] Detected aggregation: ${context.aggregationLevel}, metrics: ${context.metricColumns.join(', ')}`
      );
    }

    // Extract requested rows from TOP filter
    if (query.filters) {
      const topFilter = query.filters.find(f => f.filterType === 'TOP');
      if (topFilter && topFilter.howMany) {
        context.userRequestedRows = topFilter.howMany;
        logger.info(`[v344 QUERY-CONTEXT] User requested top ${context.userRequestedRows} rows`);
      }
    }
  } catch (error) {
    logger.warn('[v344 QUERY-CONTEXT] Error extracting query context:', error);
  }

  return context;
}

/**
 * Update QueryContext with result metadata from tool execution
 *
 * @param context - Existing QueryContext to update
 * @param result - Tool result containing metadata
 */
export function updateQueryContextFromResult(context: QueryContext, result: any): void {
  try {
    // Extract metadata from result
    // Result structure for query-datasource/get-view-data:
    // { columns: [...], rows: [...], totalRows: N, __truncatedRows: M }

    if (result.totalRows !== undefined) {
      context.totalRowsInDataset = result.totalRows;
    }

    if (result.__truncatedRows !== undefined) {
      context.truncatedRows = result.__truncatedRows;
    }

    // Calculate actualRowsReceived
    if (result.rows && Array.isArray(result.rows)) {
      context.actualRowsReceived = result.rows.length;
    } else if (result.previewRows && Array.isArray(result.previewRows)) {
      context.actualRowsReceived = result.previewRows.length;
    }

    // Analyze result columns for numeric/monetary detection
    if (result.columns && Array.isArray(result.columns)) {
      context.resultColumns = result.columns;
      context.hasNumericColumns = result.columns.some((col: any) =>
        ['INTEGER', 'REAL', 'DECIMAL', 'QUANTITATIVE'].includes(col.dataType?.toUpperCase())
      );
      context.hasMonetaryColumns = result.columns.some((col: any) =>
        /revenue|sales|amount|total|cost|price/i.test(col.name || col.fieldCaption || '')
      );
      context.hasCurrencyField = result.columns.some((col: any) =>
        /currency|curr/i.test(col.name || col.fieldCaption || '')
      );
    }

    logger.info(
      `[v344 QUERY-CONTEXT] Updated context: totalRows=${context.totalRowsInDataset}, ` +
      `actualRows=${context.actualRowsReceived}, truncated=${context.truncatedRows}, ` +
      `hasNumeric=${context.hasNumericColumns}, hasMonetary=${context.hasMonetaryColumns}`
    );
  } catch (error) {
    logger.warn('[v344 QUERY-CONTEXT] Error updating query context from result:', error);
  }
}

/**
 * Build execution phase hint message based on QueryContext
 *
 * @param context - QueryContext with query and result metadata
 * @returns Hint message or null if no constraints detected
 */
export function buildExecutionPhaseHint(context: QueryContext | null): string | null {
  if (!context) {
    return null;
  }

  const {
    userRequestedRows,
    actualRowsReceived,
    totalRowsInDataset,
    truncatedRows,
    isAggregated,
    aggregationLevel,
    metricColumns,
    hasNumericColumns,
    hasMonetaryColumns,
  } = context;

  // Determine what constraints apply
  const hasPreviewLimit = truncatedRows > 0;
  const hasRequestMismatch =
    userRequestedRows !== null &&
    actualRowsReceived !== null &&
    userRequestedRows > actualRowsReceived;
  const hasAggregation = isAggregated;
  const needsCalculationValidation = !hasPreviewLimit && (hasNumericColumns || hasMonetaryColumns);

  // If no constraints, no hint needed
  if (!hasPreviewLimit && !hasRequestMismatch && !hasAggregation && !needsCalculationValidation) {
    return null;
  }

  // Build the hint message
  let hint = '(INTERNAL EXECUTION GUIDANCE; DO NOT REVEAL TO USER)\n\n';

  if (hasPreviewLimit) {
    hint += `PREVIEW LIMITATION:\n`;
    hint += `- You received ${actualRowsReceived} rows (preview) but the dataset contains ${totalRowsInDataset} total rows\n`;
    hint += `- ${truncatedRows} rows are hidden from you\n`;
    hint += `- Do NOT compute totals, averages, or rankings that would require the full dataset\n`;
    hint += `- Do NOT claim to show "all results" when data is truncated\n`;
    hint += `- If user asks for aggregates across all data, explain that you can only see a preview\n`;
    hint += `\n`;
  }

  if (hasRequestMismatch) {
    hint += `REQUEST MISMATCH:\n`;
    hint += `- User requested: Top ${userRequestedRows} results\n`;
    hint += `- You received: Only ${actualRowsReceived} results (preview limit)\n`;
    hint += `- Acknowledge this discrepancy to the user\n`;
    hint += `- Constrain your analysis to the ${actualRowsReceived} items you actually have\n`;
    hint += `\n`;
  }

  if (hasAggregation) {
    hint += `AGGREGATION CONSTRAINT:\n`;
    hint += `- This query is aggregated at: ${aggregationLevel}\n`;
    hint += `- Metric columns contain pre-computed aggregates: ${metricColumns.join(', ')}\n`;
    hint += `- Do NOT sum these metric values and treat the sum as a grand total\n`;
    hint += `- Example: If you see [Product A: $100, Product B: $200], do NOT say "Total: $300"\n`;
    hint += `  unless the user explicitly asks for the sum across categories\n`;
    hint += `- Each row represents a summary for that ${aggregationLevel} level\n`;
    hint += `\n`;
  }

  if (needsCalculationValidation) {
    hint += `CALCULATION VALIDATION:\n`;
    hint += `- If you present ANY calculated totals, sums, or averages:\n`;
    hint += `  1. You MUST validate your calculation against the actual data values shown\n`;
    hint += `  2. Show your work (e.g., "$100 + $200 + $150 = $450")\n`;
    hint += `  3. Verify the calculation is correct before presenting it\n`;
    hint += `- Do NOT invent, approximate, or hallucinate totals\n`;
    hint += `- If you cannot verify a calculation, do not present it as fact\n`;
    hint += `\n`;
  }

  hint += `CRITICAL: Following these guidelines prevents incorrect conclusions and data hallucination.\n`;

  return hint;
}

/**
 * Build final presentation reminder for shaping the user-facing answer (v347)
 *
 * This is Phase 2: presentation-level guidance (how to communicate, not how to think)
 * Scientific constraints are handled by buildExecutionPhaseHint
 *
 * @param context - QueryContext with query and result metadata
 * @returns Presentation reminder message or null if no guidance needed
 */
export function buildFinalPresentationReminder(context: QueryContext | null): string | null {
  if (!context) {
    return null;
  }

  const {
    userRequestedRows,
    actualRowsReceived,
    totalRowsInDataset,
    truncatedRows,
    isAggregated,
    metricColumns,
    hasMonetaryColumns,
    hasCurrencyField,
  } = context;

  const MAX_VIEW_ROWS_FOR_MODEL = 30; // From constants

  // Always show at least date guidance
  let reminder = '⚠️ FINAL ANSWER - PRESENTATION GUIDANCE:\n\n';

  // Section 1: Date Period Guidance (ALWAYS SHOWN - prevents date hallucination)
  reminder += '📅 DATA PERIOD FORMATTING:\n\n';
  reminder += '**When to INCLUDE Data Period:**\n';
  reminder += '✅ User explicitly asked about dates/time (e.g., "current year", "Q3 2024", "recent sales")\n';
  reminder += '✅ Returned data columns contain date fields (Order Date, Invoice Date, etc.) AND you have FULL dataset (not preview)\n';
  reminder += '   → State date range based on ACTUAL min/max dates from data\n';
  reminder += '   → Format: "Analyzing [datasource] data covering [earliest date] to [latest date] based on [date column]"\n\n';

  reminder += '**When to OMIT Data Period:**\n';
  reminder += '❌ User did NOT ask about dates in their query\n';
  reminder += '❌ Data does NOT contain date columns\n';
  reminder += `❌ Only preview/sample data available (cannot infer accurate date range from ${MAX_VIEW_ROWS_FOR_MODEL}-row sample)\n`;
  reminder += '   → Start directly with analysis, NO Data Period section\n\n';

  reminder += '**CRITICAL:** Never invent, hallucinate, or assume date ranges.\n';
  reminder += 'If you cannot determine actual date range from full dataset → OMIT Data Period entirely.\n\n';

  // Currency Code Warning (prevent USD assumption)
  if (hasMonetaryColumns && !hasCurrencyField) {
    reminder += '─────────────────────────────────────────\n\n';
    reminder += '💰 CURRENCY FORMATTING:\n\n';
    reminder += '**CRITICAL:** This dataset contains monetary values WITHOUT explicit currency code column.\n\n';
    reminder += '✅ You MAY format amounts with currency symbol: "$1,250.00"\n';
    reminder += '❌ You MUST NOT claim or assume specific currency codes (USD, CAD, AUD, SGD, HKD, etc.)\n';
    reminder += '❌ WRONG: "Revenue was $50,000 USD"\n';
    reminder += '❌ WRONG: "Total sales of $100,000 in United States Dollars"\n';
    reminder += '✅ CORRECT: "Revenue was $50,000"\n';
    reminder += '✅ CORRECT: "Total sales of $100,000"\n\n';
    reminder += '**Why:** The "$" symbol is used by multiple currencies (USD, CAD, AUD, SGD, HKD, etc.).\n';
    reminder += 'Without a currency code field, you cannot determine which currency this represents.\n';
    reminder += 'Present the symbol, but do NOT add currency code assumptions.\n\n';
  }

  // Section 2: User-friendly phrasing for limitations
  const hasLimitations =
    (userRequestedRows && actualRowsReceived && userRequestedRows > actualRowsReceived) ||
    truncatedRows > 0 ||
    isAggregated;

  if (hasLimitations) {
    reminder += '─────────────────────────────────────────\n\n';
    reminder += '💬 HOW TO COMMUNICATE LIMITATIONS:\n\n';

    if (userRequestedRows && actualRowsReceived && userRequestedRows > actualRowsReceived) {
      reminder += '**Preview Limitation - User-Friendly Language:**\n';
      reminder += `✅ "Analyzing top ${actualRowsReceived} of ${userRequestedRows} requested (preview limit)"\n`;
      reminder += `✅ "Analysis based on ${actualRowsReceived} items available in preview"\n`;
      reminder += '✅ Use friendly disclaimers, not technical jargon\n';
      reminder += "❌ Don't say \"YOU ONLY GOT\" or use harsh language\n\n";
    }

    if (truncatedRows > 0 && !(userRequestedRows && actualRowsReceived && userRequestedRows > actualRowsReceived)) {
      reminder += '**Data Truncation - Direct Users to Tableau:**\n';
      if (totalRowsInDataset) {
        reminder += `✅ "Based on preview data - use Tableau to explore full dataset with all ${totalRowsInDataset} records"\n`;
        reminder += '✅ "For accurate category breakdowns across complete dataset, access directly in Tableau"\n';
        reminder += `✅ "Based on representative sample analysed from ${totalRowsInDataset} records - open in Tableau for full analysis"\n`;
      } else {
        reminder += '✅ "Based on preview data - use Tableau to explore full dataset"\n';
        reminder += '✅ "For accurate category breakdowns across complete dataset, access directly in Tableau"\n';
        reminder += '✅ "Open in Tableau for full analysis across all records"\n';
      }
      reminder += '✅ Frame as actionable guidance to use Tableau, not generic availability\n\n';
    }

    if (isAggregated && metricColumns.length > 0) {
      reminder += '**Aggregated Data - Clear Explanation:**\n';
      reminder += `✅ Present values as: "Each category shows its total ${metricColumns[0]}"\n`;
      reminder += '✅ Use language like "category totals", "aggregated by", "grouped results"\n';
      reminder += '✅ Avoid technical terms like "GROUP BY" unless appropriate for audience\n\n';
    }
  }

  reminder += '═══════════════════════════════════════════\n';
  reminder += 'This guides HOW to present your answer, not WHAT to conclude.\n';
  reminder += 'Your reasoning should already be constrained by execution-phase guidance.\n';
  reminder += '═══════════════════════════════════════════\n';

  return reminder;
}
