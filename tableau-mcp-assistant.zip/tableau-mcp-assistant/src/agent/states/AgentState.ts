/**
 * AgentState class - Manages state machine transitions for agent execution
 *
 * This class is responsible for:
 * - Tracking current execution state
 * - Managing state transitions with validation
 * - Maintaining execution context
 * - Providing history management
 */

import { AgentStateType, StateContext, Message, SystemHint } from '../types.js';
import { logger } from '../../util/logger.js';

export class AgentState {
  private _current: AgentStateType;
  private _context: StateContext;
  private _history: Message[];
  private _startTime: number;

  constructor(initialContext: Partial<StateContext> = {}) {
    this._current = 'INIT';
    this._startTime = Date.now();
    this._history = [];

    // Initialize context with defaults
    this._context = {
      systemHints: [],
      iterationCount: 0,
      maxIterations: initialContext.maxIterations || 10, // v353: Changed default from 30 to 10 to match old broker.ts
      recoveryAttempts: 0,
      tokenUsage: {
        system: 0,
        user: 0,
        assistant: 0,
        tools: 0,
        total: 0,
      },
      ...initialContext,
    };
  }

  /**
   * Get current state
   */
  get current(): AgentStateType {
    return this._current;
  }

  /**
   * Get mutable context (for interceptors to modify)
   */
  get context(): StateContext {
    return this._context;
  }

  /**
   * Get message history
   */
  get history(): Message[] {
    return this._history;
  }

  /**
   * Get execution time in milliseconds
   */
  get executionTime(): number {
    return Date.now() - this._startTime;
  }

  /**
   * Check if current state is terminal
   */
  isTerminal(): boolean {
    return this._current === 'COMPLETED' || this._current === 'ABORTED';
  }

  /**
   * Check if max iterations reached
   */
  hasReachedMaxIterations(): boolean {
    return this._context.iterationCount >= this._context.maxIterations;
  }

  /**
   * Transition to a new state with validation
   */
  transition(to: AgentStateType, reason?: string): void {
    const from = this._current;

    // Validate transition
    if (!this.isValidTransition(from, to)) {
      logger.warn(
        `[AGENT-STATE] Invalid transition from ${from} to ${to}`,
        { reason }
      );
      // For now, allow the transition but log warning
      // In stricter mode, we could throw an error
    }

    logger.info(
      `[AGENT-STATE] ${from} → ${to}${reason ? `: ${reason}` : ''}`,
      {
        iteration: this._context.iterationCount,
        executionTime: this.executionTime,
      }
    );

    this._current = to;
  }

  /**
   * Validate if a state transition is allowed
   */
  private isValidTransition(from: AgentStateType, to: AgentStateType): boolean {
    // Define valid transitions
    const validTransitions: Record<AgentStateType, AgentStateType[]> = {
      INIT: ['REASONING', 'ABORTED'],
      REASONING: ['ACTION', 'FINALIZE', 'RECOVERY', 'ABORTED'],
      ACTION: ['REASONING', 'RECOVERY', 'ABORTED'],
      RECOVERY: ['REASONING', 'FINALIZE', 'ABORTED'],
      FINALIZE: ['COMPLETED'],
      COMPLETED: [], // Terminal state
      ABORTED: [],   // Terminal state
    };

    return validTransitions[from]?.includes(to) ?? false;
  }

  /**
   * Add a message to history
   */
  addMessage(message: Message): void {
    this._history.push(message);
  }

  /**
   * Add a system hint to context
   */
  addSystemHint(hint: SystemHint): void {
    this._context.systemHints.push(hint);
    logger.info(`[AGENT-STATE] Added system hint: ${hint.type} (${hint.priority})`, {
      message: hint.message.substring(0, 100),
    });
  }

  /**
   * Increment iteration count
   */
  incrementIteration(): void {
    this._context.iterationCount++;
    logger.info(`[AGENT-STATE] Iteration ${this._context.iterationCount}/${this._context.maxIterations}`);
  }

  /**
   * Update token usage
   */
  updateTokenUsage(phase: 'system' | 'user' | 'assistant' | 'tools', tokens: number): void {
    this._context.tokenUsage[phase] += tokens;
    this._context.tokenUsage.total += tokens;
  }

  /**
   * Get state summary for debugging
   */
  getSummary(): Record<string, any> {
    return {
      currentState: this._current,
      iteration: `${this._context.iterationCount}/${this._context.maxIterations}`,
      executionTime: `${this.executionTime}ms`,
      tokenUsage: this._context.tokenUsage.total,
      historyLength: this._history.length,
      systemHints: this._context.systemHints.length,
      isTerminal: this.isTerminal(),
    };
  }
}
