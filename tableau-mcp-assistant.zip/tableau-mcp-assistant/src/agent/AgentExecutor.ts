/**
 * AgentExecutor - Core orchestrator for agent execution
 *
 * Phase 1 (v313): Established state machine foundation
 * Phase 2A (v315): Proved interceptor pattern with tool execution
 * Phase 3 (v316+): Full replacement using StateHandler pattern
 *
 * This class implements the state machine pattern for agent execution,
 * replacing the monolithic handleUserPrompt function with a composable,
 * testable architecture.
 *
 * Key features:
 * - State machine loop: INIT → REASONING → ACTION → FINALIZE → COMPLETED
 * - StateHandler pattern for extensibility
 * - Interceptor support for cross-cutting concerns
 * - Abort signal handling
 * - Token usage tracking
 * - Comprehensive logging
 */

import { AgentConfig, AgentResult, AgentStateType } from './types.js';
import { AgentState } from './states/AgentState.js';
import { InterceptorManager } from './InterceptorManager.js';
import { StateHandler } from './StateHandler.js';
import { logger } from '../util/logger.js';

export class AgentExecutor {
  private state: AgentState;
  private interceptorManager: InterceptorManager;
  private config: AgentConfig;

  // Phase 3: State handlers (will be registered in Phase 3B-3F)
  private stateHandlers: Map<AgentStateType, StateHandler> = new Map();

  constructor(config: AgentConfig) {
    this.config = config;

    // Initialize state
    this.state = new AgentState({
      profileId: config.profileId,
      maxIterations: config.maxIterations || 10, // v353: Changed default from 30 to 10 to match old broker.ts
    });

    // Initialize interceptor manager
    this.interceptorManager = new InterceptorManager(config.interceptors || []);

    logger.info('[v316 AGENT-EXECUTOR] Initialized', {
      profileId: config.profileId,
      maxIterations: this.state.context.maxIterations,
      interceptorCount: config.interceptors?.length || 0,
    });
  }

  /**
   * Register a state handler for a specific state type
   * (Phase 3B-3F will register handlers for each state)
   */
  registerStateHandler(stateType: AgentStateType, handler: StateHandler): void {
    this.stateHandlers.set(stateType, handler);
    logger.debug(`[v316 AGENT-EXECUTOR] Registered handler for state: ${stateType}`);
  }

  /**
   * Execute the agent for a user prompt
   * Returns the final result after completing the state machine
   */
  async execute(userPrompt: string): Promise<AgentResult> {
    const startTime = Date.now();

    logger.info('[v316 AGENT-EXECUTOR] Starting execution', {
      userPrompt: userPrompt.substring(0, 100),
    });

    try {
      // Add initial user message to history
      this.state.addMessage({
        role: 'user',
        content: userPrompt,
      });

      // Main state machine loop
      while (!this.state.isTerminal()) {
        // Check abort signal
        if (this.config.abortSignal?.aborted) {
          logger.warn('[v316 AGENT-EXECUTOR] Abort signal detected');
          await this.transitionTo('ABORTED', 'User aborted');
          break;
        }

        // Check max iterations
        if (this.state.hasReachedMaxIterations()) {
          logger.warn('[v316 AGENT-EXECUTOR] Max iterations reached', {
            iterations: this.state.context.iterationCount,
            max: this.state.context.maxIterations,
          });
          await this.transitionTo('FINALIZE', 'Max iterations reached');
          continue;
        }

        // Execute current state
        await this.executeCurrentState();
      }

      // Build and return result
      const result = this.buildResult(startTime);

      logger.info('[v316 AGENT-EXECUTOR] Execution completed', {
        finalState: this.state.current,
        iterations: this.state.context.iterationCount,
        executionTime: result.metadata.executionTime,
        tokensUsed: result.metadata.tokensUsed,
      });

      return result;
    } catch (error) {
      logger.error('[v316 AGENT-EXECUTOR] Execution failed', { error });

      // Notify interceptors of error
      await this.interceptorManager.onError(error as Error, this.state.context);

      // Transition to aborted state
      await this.transitionTo('ABORTED', `Error: ${(error as Error).message}`);

      // Return error result
      return this.buildResult(startTime);
    }
  }

  /**
   * Execute the current state and transition to next state
   *
   * Phase 3: Uses StateHandler pattern if handler is registered,
   * otherwise falls back to placeholder methods (for gradual migration)
   */
  private async executeCurrentState(): Promise<void> {
    const currentState = this.state.current;
    const handler = this.stateHandlers.get(currentState);

    if (handler) {
      // Phase 3: Use registered StateHandler
      logger.info(`[v316 AGENT-EXECUTOR] Using StateHandler for: ${currentState}`);

      try {
        // Call onEnter hook
        if (handler.onEnter) {
          await handler.onEnter(this.state.context);
        }

        // Handle the state
        const result = await handler.handle(this.state.context, this.state.history);

        // Update messages if handler returned any
        if (result.messages) {
          for (const message of result.messages) {
            this.state.addMessage(message);
          }
        }

        // Store final answer if provided
        if (result.finalAnswer) {
          this.state.context.finalAnswer = result.finalAnswer;
        }

        // Call onExit hook
        if (handler.onExit) {
          await handler.onExit(this.state.context);
        }

        // Transition to next state
        await this.transitionTo(result.nextState, result.metadata?.reason as string);
      } catch (error) {
        logger.error(`[v316 AGENT-EXECUTOR] StateHandler error in ${currentState}`, error);
        throw error;
      }
    } else {
      // Fall back to Phase 1 placeholder methods
      logger.debug(`[v316 AGENT-EXECUTOR] Using placeholder for: ${currentState}`);

      switch (currentState) {
        case 'INIT':
          await this.handleInit();
          break;

        case 'REASONING':
          await this.handleReasoning();
          break;

        case 'ACTION':
          await this.handleAction();
          break;

        case 'RECOVERY':
          await this.handleRecovery();
          break;

        case 'FINALIZE':
          await this.handleFinalize();
          break;

        default:
          logger.error('[v316 AGENT-EXECUTOR] Unknown state', { state: currentState });
          await this.transitionTo('ABORTED', 'Unknown state');
      }
    }
  }

  /**
   * INIT state: Initialize context, detect intent, build system prompt
   */
  private async handleInit(): Promise<void> {
    logger.info('[AGENT-EXECUTOR-INIT] Initializing context');

    // TODO Phase 2: Extract intent detection into IntentDetector
    // TODO Phase 2: Extract prompt building into PromptBuilder
    // For now, just transition to REASONING
    // The actual prompt building will happen in handleUserPromptV2 adapter

    await this.transitionTo('REASONING', 'Initialization complete');
  }

  /**
   * REASONING state: Call LLM, parse response
   */
  private async handleReasoning(): Promise<void> {
    logger.info('[AGENT-EXECUTOR-REASONING] Calling LLM');

    this.state.incrementIteration();

    // TODO Phase 2: Extract LLM calling logic here
    // For now, this is a placeholder - actual LLM call happens in adapter

    // TEMPORARY: Just transition to demonstrate the loop
    // In real implementation, this would:
    // 1. Call LLM with system prompt + history
    // 2. Parse response for tool calls or final answer
    // 3. Transition to ACTION if tool calls, FINALIZE if final answer

    await this.transitionTo('ACTION', 'LLM returned tool calls (placeholder)');
  }

  /**
   * ACTION state: Execute MCP tools
   */
  private async handleAction(): Promise<void> {
    logger.info('[AGENT-EXECUTOR-ACTION] Executing tools');

    // TODO Phase 2: Extract tool execution logic here
    // For now, this is a placeholder

    // TEMPORARY: Just transition back to demonstrate interceptor hook
    await this.transitionTo('REASONING', 'Tools executed (placeholder)');
  }

  /**
   * RECOVERY state: Handle errors, inject recovery context
   */
  private async handleRecovery(): Promise<void> {
    logger.info('[AGENT-EXECUTOR-RECOVERY] Recovering from error');

    this.state.context.recoveryAttempts++;

    // TODO Phase 2: Extract error recovery logic here
    // For now, just transition back to reasoning

    await this.transitionTo('REASONING', 'Recovery complete');
  }

  /**
   * FINALIZE state: Ground answer, format response
   */
  private async handleFinalize(): Promise<void> {
    logger.info('[AGENT-EXECUTOR-FINALIZE] Finalizing result');

    // TODO Phase 2: Extract result formatting logic here
    // For now, just transition to completed

    await this.transitionTo('COMPLETED', 'Finalization complete');
  }

  /**
   * Transition to a new state with interceptor hooks
   */
  private async transitionTo(to: AgentStateType, reason?: string): Promise<void> {
    const from = this.state.current;

    // Call beforeStateTransition interceptors
    await this.interceptorManager.beforeStateTransition(from, to, this.state.context);

    // Perform transition
    this.state.transition(to, reason);

    // Call afterStateTransition interceptors
    await this.interceptorManager.afterStateTransition(from, to, this.state.context);
  }

  /**
   * Build final result object
   */
  private buildResult(startTime: number): AgentResult {
    const executionTime = Date.now() - startTime;

    return {
      finalAnswer: this.state.context.finalAnswer || this.extractFinalAnswerFromHistory(),
      metadata: {
        iterations: this.state.context.iterationCount,
        toolCalls: this.countToolCalls(),
        tokensUsed: this.state.context.tokenUsage.total,
        executionTime,
        finalState: this.state.current,
      },
      tokenUsage: this.state.context.tokenUsage,
      history: this.state.history,
    };
  }

  /**
   * Extract final answer from message history
   * (Fallback if FINALIZE state didn't set context.finalAnswer)
   */
  private extractFinalAnswerFromHistory(): string {
    // Find the last assistant message that's not a tool call
    for (let i = this.state.history.length - 1; i >= 0; i--) {
      const message = this.state.history[i];
      if (message.role === 'assistant' && message.content && !message.tool_calls) {
        return typeof message.content === 'string' ? message.content : 'No answer provided';
      }
    }
    return 'No answer provided';
  }

  /**
   * Count total tool calls in conversation history
   */
  private countToolCalls(): number {
    let count = 0;
    for (const message of this.state.history) {
      if (message.role === 'assistant' && message.tool_calls) {
        count += message.tool_calls.length;
      }
    }
    return count;
  }

  /**
   * Get current state summary (for debugging)
   */
  getStateSummary(): Record<string, any> {
    return this.state.getSummary();
  }
}
