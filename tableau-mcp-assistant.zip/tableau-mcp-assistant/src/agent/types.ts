/**
 * Core type definitions for the AgentExecutor refactor (Phase 1)
 *
 * This file defines the fundamental interfaces and types used throughout
 * the agent execution system.
 */

import { Message as ILlmMessage } from '../llm/ILlm.js';

/**
 * Agent state types representing the state machine transitions
 */
export type AgentStateType =
  | 'INIT'           // Initialize: Assemble system prompt, detect intent
  | 'REASONING'      // Call LLM, parse response for tool calls or final answer
  | 'ACTION'         // Execute MCP tools
  | 'RECOVERY'       // Handle errors, inject recovery context
  | 'FINALIZE'       // Ground answer, format response
  | 'COMPLETED'      // Terminal state
  | 'ABORTED';       // Aborted by user or timeout

/**
 * Context data carried through state transitions
 */
export interface StateContext {
  // Prompt components
  coreSystemPrompt?: string;
  scopeSystemPrompt?: string;

  // Intent and profile
  intent?: string;
  profileId?: string;

  // LLM Provider (for debugging/tracing)
  llmProvider?: 'openai' | 'local' | 'bedrock';

  // v350: Tool access control (for runtime enforcement)
  toolProfile?: 'dashboard_qna' | 'global_qna';
  allowedScope?: any; // AllowedScope from broker.ts (avoid circular import)

  // Configuration from profile settings
  maxViewRowsForModel?: number; // Maximum rows to send to LLM (from profile settings)

  // v392: WebSocket for UI updates (passed through context)
  ws?: any; // WebSocket type (avoiding import)

  // Hints and context injections
  systemHints: SystemHint[];
  dateContext?: string;
  sortPreferences?: string;

  // Iteration tracking
  iterationCount: number;
  maxIterations: number;

  // v359: Execution timing for quality metrics
  executionStartTime?: number; // Date.now() when execution begins

  // Error recovery
  lastQueryError?: string;
  recoveryAttempts: number;

  // Session-level hint tracking (v343)
  firstQueryDatasourceHintInjected?: boolean;

  // Query context tracking (v344)
  queryContext?: QueryContext | null;

  // Token tracking
  tokenUsage: {
    system: number;
    user: number;
    assistant: number;
    tools: number;
    total: number;
  };

  // Final answer (set by FINALIZE state handler)
  finalAnswer?: string;
}

/**
 * System hint that can be injected at various stages
 */
export interface SystemHint {
  type: 'PULSE_WORKFLOW' | 'LUID_EXTRACTION' | 'ERROR_RECOVERY' | 'DATASOURCE_SCHEMA' | 'EXECUTION_PHASE' | 'GENERAL';
  message: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  metadata?: Record<string, any>;
}

/**
 * Query context tracking for execution phase hints (v344)
 * Tracks query metadata to warn about truncation and aggregation constraints
 */
export interface QueryContext {
  // Row count tracking
  userRequestedRows: number | null;        // From query: "top 25 products"
  actualRowsReceived: number | null;       // From metadata.displayedRows
  totalRowsInDataset: number | null;       // From metadata.totalRows
  truncatedRows: number;                   // From metadata.__truncatedRows

  // Aggregation tracking
  isAggregated: boolean;                   // Detected from query structure (GROUP BY)
  aggregationLevel: string | null;         // e.g., "GROUP BY Product"
  metricColumns: string[];                 // e.g., ["Total Revenue", "Sum(Sales)"]

  // Control flags
  executionHintInjected: boolean;          // Flag to prevent duplicate execution-phase hints
  reminderInjected: boolean;               // Flag to prevent duplicate presentation reminders

  // v389: Sort verification tracking
  sortSummary?: string | null;             // Human-readable sort description (e.g., "Sorted by: Sales DESC")
  sortVerificationPending?: boolean;       // True when sort verification hint was injected and needs LLM response

  // v391: Duplicate query detection
  lastQueryDatasourceLuid?: string;        // The datasourceLuid of the last executed query-datasource
  lastQuerySortSummary?: string;           // The sort summary of the last executed query-datasource

  // v392: Buffered data table during sort verification
  bufferedDataTable?: any;                 // Data table message buffered during sort verification (sent only on finalize)

  // Result metadata for anti-hallucination guidance
  resultColumns?: any[];
  hasNumericColumns?: boolean;
  hasMonetaryColumns?: boolean;
  hasCurrencyField?: boolean;
}

/**
 * Tool execution result
 */
export interface ToolResult {
  toolName: string;
  arguments: Record<string, any>;
  result: any;
  isError: boolean;
  error?: string;
  executionTime: number;
  tokenCount?: number;
}

/**
 * Interceptor interface - allows hooking into agent lifecycle
 */
export interface Interceptor {
  /**
   * Called before transitioning to a new state
   */
  beforeStateTransition?(
    from: AgentStateType,
    to: AgentStateType,
    context: StateContext
  ): Promise<void>;

  /**
   * Called after transitioning to a new state
   */
  afterStateTransition?(
    from: AgentStateType,
    to: AgentStateType,
    context: StateContext
  ): Promise<void>;

  /**
   * Called before executing a tool
   */
  beforeAction?(
    toolName: string,
    args: Record<string, any>,
    context: StateContext
  ): Promise<void>;

  /**
   * Called after executing a tool
   */
  afterAction?(
    result: ToolResult,
    context: StateContext
  ): Promise<void>;

  /**
   * Called when an error occurs
   */
  onError?(
    error: Error,
    context: StateContext
  ): Promise<void>;
}

/**
 * Message in the conversation history
 * Re-export from ILlm for compatibility
 */
export type Message = ILlmMessage;

/**
 * Final result from agent execution
 */
export interface AgentResult {
  finalAnswer: string;
  metadata: {
    iterations: number;
    toolCalls: number;
    tokensUsed: number;
    executionTime: number;
    finalState: AgentStateType;
  };
  tokenUsage: StateContext['tokenUsage'];
  history: Message[];
}

/**
 * Configuration for AgentExecutor
 */
export interface AgentConfig {
  profileId: string;
  maxIterations?: number;
  interceptors?: Interceptor[];
  abortSignal?: AbortSignal;
}
