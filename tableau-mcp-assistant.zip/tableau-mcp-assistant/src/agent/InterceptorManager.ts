/**
 * InterceptorManager - Manages lifecycle hooks for agent execution
 *
 * This class coordinates calling all registered interceptors at the
 * appropriate points in the agent execution lifecycle.
 */

import { Interceptor, AgentStateType, StateContext, ToolResult } from './types.js';
import { logger } from '../util/logger.js';

export class InterceptorManager {
  private interceptors: Interceptor[];

  constructor(interceptors: Interceptor[] = []) {
    this.interceptors = interceptors;
    logger.info(`[INTERCEPTOR-MGR] Initialized with ${interceptors.length} interceptors`);
  }

  /**
   * Add an interceptor
   */
  addInterceptor(interceptor: Interceptor): void {
    this.interceptors.push(interceptor);
    logger.info(`[INTERCEPTOR-MGR] Added interceptor`);
  }

  /**
   * Call beforeStateTransition on all interceptors
   */
  async beforeStateTransition(
    from: AgentStateType,
    to: AgentStateType,
    context: StateContext
  ): Promise<void> {
    for (const interceptor of this.interceptors) {
      if (interceptor.beforeStateTransition) {
        try {
          await interceptor.beforeStateTransition(from, to, context);
        } catch (error) {
          logger.error('[INTERCEPTOR-MGR] Error in beforeStateTransition', {
            error,
            from,
            to,
          });
          // Continue with other interceptors even if one fails
        }
      }
    }
  }

  /**
   * Call afterStateTransition on all interceptors
   */
  async afterStateTransition(
    from: AgentStateType,
    to: AgentStateType,
    context: StateContext
  ): Promise<void> {
    for (const interceptor of this.interceptors) {
      if (interceptor.afterStateTransition) {
        try {
          await interceptor.afterStateTransition(from, to, context);
        } catch (error) {
          logger.error('[INTERCEPTOR-MGR] Error in afterStateTransition', {
            error,
            from,
            to,
          });
        }
      }
    }
  }

  /**
   * Call beforeAction on all interceptors
   */
  async beforeAction(
    toolName: string,
    args: Record<string, any>,
    context: StateContext
  ): Promise<void> {
    for (const interceptor of this.interceptors) {
      if (interceptor.beforeAction) {
        try {
          await interceptor.beforeAction(toolName, args, context);
        } catch (error) {
          logger.error('[INTERCEPTOR-MGR] Error in beforeAction', {
            error,
            toolName,
          });
        }
      }
    }
  }

  /**
   * Call afterAction on all interceptors
   */
  async afterAction(
    result: ToolResult,
    context: StateContext
  ): Promise<void> {
    for (const interceptor of this.interceptors) {
      if (interceptor.afterAction) {
        try {
          await interceptor.afterAction(result, context);
        } catch (error) {
          logger.error('[INTERCEPTOR-MGR] Error in afterAction', {
            error,
            toolName: result.toolName,
          });
        }
      }
    }
  }

  /**
   * Call onError on all interceptors
   */
  async onError(error: Error, context: StateContext): Promise<void> {
    for (const interceptor of this.interceptors) {
      if (interceptor.onError) {
        try {
          await interceptor.onError(error, context);
        } catch (interceptorError) {
          logger.error('[INTERCEPTOR-MGR] Error in onError handler', {
            originalError: error,
            interceptorError,
          });
        }
      }
    }
  }
}
