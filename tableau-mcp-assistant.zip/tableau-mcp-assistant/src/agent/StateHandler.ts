/**
 * StateHandler - Base interface for handling state transitions
 *
 * Each state in the agent lifecycle has a corresponding handler that:
 * 1. Performs state-specific logic
 * 2. Updates the StateContext
 * 3. Returns the next state to transition to
 */

import { AgentStateType, StateContext, Message } from './types.js';

/**
 * Result of handling a state transition
 */
export interface StateHandlerResult {
  /**
   * The next state to transition to
   */
  nextState: AgentStateType;

  /**
   * Optional messages to add to the conversation history
   */
  messages?: Message[];

  /**
   * Optional final answer (only set by FINALIZE state)
   */
  finalAnswer?: string;

  /**
   * Optional metadata about the state execution
   */
  metadata?: Record<string, any>;
}

/**
 * Base interface for state handlers
 */
export interface StateHandler {
  /**
   * Handle the current state and return the next state to transition to
   *
   * @param context - The current state context
   * @param messages - The conversation history so far
   * @returns StateHandlerResult indicating next state and any updates
   */
  handle(
    context: StateContext,
    messages: Message[]
  ): Promise<StateHandlerResult>;

  /**
   * Optional: Called when entering this state (before handle)
   */
  onEnter?(context: StateContext): Promise<void>;

  /**
   * Optional: Called when exiting this state (after handle)
   */
  onExit?(context: StateContext): Promise<void>;
}
