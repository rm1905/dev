/**
 * WorkbookIdHintInterceptor - Injects hints for workbook workflow
 *
 * This interceptor fires after list-workbooks and injects system hints
 * to guide the LLM through the correct workflow.
 *
 * Context: Workbook workflow requires multiple steps:
 * 1. list-workbooks (with filter) → Returns workbook with ID
 * 2. get-workbook (with ID) → Returns workbook details
 * 3. list-views (with ID) → Returns views in workbook
 *
 * Without this hint, LLMs often:
 * - Reuse old workbook IDs from previous queries
 * - Hallucinate or invent workbook IDs
 * - Skip the list-workbooks lookup step
 *
 * This interceptor addresses these issues by:
 * - Extracting workbook ID from list-workbooks result
 * - Explicitly showing the ID to use for subsequent calls
 * - Warning against reusing IDs from earlier in conversation
 */

import { Interceptor, ToolResult, StateContext, SystemHint } from '../types.js';
import { logger } from '../../util/logger.js';

export class WorkbookIdHintInterceptor implements Interceptor {
  /**
   * Called after a tool execution completes
   */
  async afterAction(result: ToolResult, context: StateContext): Promise<void> {
    // Only intercept list-workbooks with filter (lookup by name)
    if (result.toolName !== 'list-workbooks') {
      return;
    }

    const args = result.arguments as any;
    if (!args || typeof args !== 'object' || !args.filter) {
      return;
    }

    const filter = args.filter;
    if (typeof filter !== 'string' || !filter.startsWith('name:eq:')) {
      return;
    }

    const workbookName = filter.replace('name:eq:', '');
    logger.info(`[v343 WORKBOOK-ID-HINT] Detected list-workbooks lookup for "${workbookName}"`);

    try {
      const workbookId = this.extractIdFromListResult(result);

      if (!workbookId) {
        logger.warn('[v343 WORKBOOK-ID-HINT] No workbook ID extracted from result');
        return;
      }

      logger.info(`[v343 WORKBOOK-ID-HINT] Extracted ID for "${workbookName}": ${workbookId}`);

      // Build and inject the hint
      const hint: SystemHint = {
        type: 'LUID_EXTRACTION',
        priority: 'CRITICAL',
        message: this.buildWorkbookIdHint(workbookName, workbookId),
        metadata: {
          workbookName,
          workbookId,
          extractedAt: new Date().toISOString(),
        },
      };

      context.systemHints.push(hint);
      logger.info(`[v343 WORKBOOK-ID-HINT] Injected workbook ID hint for "${workbookName}" → ${workbookId}`);
    } catch (error) {
      logger.warn('[v343 WORKBOOK-ID-HINT] Failed to extract workbook ID from result:', error);
    }
  }

  /**
   * Extract workbook ID from list-workbooks result
   */
  private extractIdFromListResult(result: ToolResult): string | null {
    try {
      // Result structure: { result: { content: [{ text: "..." }] } }
      const content = (result.result as any)?.content;

      if (!content || !Array.isArray(content) || !content[0]?.text) {
        return null;
      }

      const workbooks = JSON.parse(content[0].text);

      // Data is an array of workbook objects: [{ id: "...", name: "...", ... }]
      if (!Array.isArray(workbooks) || workbooks.length === 0) {
        return null;
      }

      // Extract ID from first workbook
      return workbooks[0].id || null;
    } catch (error) {
      logger.error('[v343 WORKBOOK-ID-HINT] Error parsing result:', error);
      return null;
    }
  }

  /**
   * Build the workbook ID hint message (after list-workbooks)
   */
  private buildWorkbookIdHint(workbookName: string, workbookId: string): string {
    return [
      '',
      `⚠️  CRITICAL: You just looked up "${workbookName}"`,
      `✅ The correct workbook ID for "${workbookName}" is: ${workbookId}`,
      '',
      `**🔒 MANDATORY - Use THIS workbook ID for all subsequent calls:**`,
      ``,
      `Tool: get-workbook`,
      `Arguments:`,
      `{`,
      `  "workbookId": "${workbookId}"`,
      `}`,
      '',
      `Tool: list-views`,
      `Arguments:`,
      `{`,
      `  "workbookId": "${workbookId}"`,
      `}`,
      '',
      `**❌ WRONG - DO NOT DO THIS:**`,
      `• DO NOT use any other workbook ID from earlier in the conversation`,
      `• DO NOT reuse workbook IDs from previous queries`,
      `• DO NOT make up or hallucinate workbook IDs`,
      `• DO NOT assume you know the ID without calling list-workbooks`,
      '',
      `**✅ CORRECT - DO THIS:**`,
      `• Use THIS workbook ID for all calls: ${workbookId}`,
      `• This is the ONLY valid ID for "${workbookName}"`,
      `• If you need a different workbook, call list-workbooks again to get its ID`,
      '',
    ].join('\n');
  }
}
