/**
 * PulseHintInterceptor - Extracts v308 Pulse workflow hint logic
 *
 * This interceptor fires after list-pulse-metrics-from-metric-ids is called
 * and injects a system hint reminding the LLM to use definition IDs (not metric IDs)
 * for the next step: list-pulse-metric-definitions-from-definition-ids
 *
 * Context: Pulse metrics workflow requires two API calls:
 * 1. list-pulse-metrics-from-metric-ids → Returns metric objects with definition_id field
 * 2. list-pulse-metric-definitions-from-definition-ids → Returns human-readable metric names
 *
 * Without this hint, LLMs often:
 * - Use metric IDs instead of definition IDs (wrong parameter)
 * - Forget to include view: "DEFINITION_VIEW_FULL" (returns UUIDs instead of names)
 * - Skip step 2 entirely (returns UUIDs to user, unacceptable UX)
 */

import { Interceptor, ToolResult, StateContext, SystemHint } from '../types.js';
import { logger } from '../../util/logger.js';

export class PulseHintInterceptor implements Interceptor {
  /**
   * Called after a tool execution completes
   */
  async afterAction(result: ToolResult, context: StateContext): Promise<void> {
    // Only intercept list-pulse-metrics-from-metric-ids
    if (result.toolName !== 'list-pulse-metrics-from-metric-ids') {
      return;
    }

    logger.info('[v308 PULSE-HINT] Detected list-pulse-metrics-from-metric-ids call');

    try {
      const definitionIds = this.extractDefinitionIds(result);

      if (definitionIds.length === 0) {
        logger.warn('[v308 PULSE-HINT] No definition IDs extracted from result');
        return;
      }

      logger.info(`[v308 PULSE-HINT] Extracted ${definitionIds.length} definition IDs`);

      // Build and inject the hint
      const hint: SystemHint = {
        type: 'PULSE_WORKFLOW',
        priority: 'CRITICAL',
        message: this.buildPulseHint(definitionIds),
        metadata: {
          definitionIds,
          extractedAt: new Date().toISOString(),
        },
      };

      context.systemHints.push(hint);
      logger.info(`[v308 PULSE-HINT] Injected Pulse workflow guidance: ${JSON.stringify(definitionIds)}`);
    } catch (error) {
      logger.warn('[v308 PULSE-HINT] Failed to extract definition IDs from result:', error);
    }
  }

  /**
   * Extract definition IDs from the tool result
   */
  private extractDefinitionIds(result: ToolResult): string[] {
    try {
      // Result structure: { result: { content: [{ text: "..." }] } }
      const content = (result.result as any)?.content;

      logger.info(
        `[v308 PULSE-HINT] Content check: exists=${!!content}, isArray=${Array.isArray(content)}, length=${
          Array.isArray(content) ? content.length : 'N/A'
        }`
      );

      if (!content || !Array.isArray(content) || !content[0]?.text) {
        return [];
      }

      const data = JSON.parse(content[0].text);

      // Data is an array of metric objects: [{ id: "...", definition_id: "...", ... }]
      if (!Array.isArray(data) || data.length === 0) {
        logger.warn(
          `[v308 PULSE-HINT] Data is not an array or is empty: ${typeof data}, length=${
            Array.isArray(data) ? data.length : 'N/A'
          }`
        );
        return [];
      }

      // Extract definition_id from each metric object
      const definitionIds = data
        .map((metric: any) => metric.definition_id)
        .filter((id: any) => typeof id === 'string');

      logger.info(`[v308 PULSE-HINT] Extracted ${definitionIds.length} definition IDs from ${data.length} metrics`);

      return definitionIds;
    } catch (error) {
      logger.error('[v308 PULSE-HINT] Error parsing result:', error);
      return [];
    }
  }

  /**
   * Build the Pulse workflow hint message
   */
  private buildPulseHint(definitionIds: string[]): string {
    return [
      '',
      `🚨 CRITICAL SYSTEM INSTRUCTION - PULSE METRICS WORKFLOW`,
      ``,
      `You just called list-pulse-metrics-from-metric-ids and received ${definitionIds.length} metric(s).`,
      `Each metric object contains BOTH a "id" field (metric ID) and a "definition_id" field (definition ID).`,
      ``,
      `**🔒 MANDATORY NEXT STEP - COPY THIS EXACT CALL:**`,
      ``,
      `Tool: list-pulse-metric-definitions-from-definition-ids`,
      `Arguments:`,
      `{`,
      `  "metricDefinitionIds": ${JSON.stringify(definitionIds)},`,
      `  "view": "DEFINITION_VIEW_FULL"`,
      `}`,
      ``,
      `**⚠️  CRITICAL - DO NOT MODIFY THE IDs ABOVE:**`,
      `The IDs shown above are the correct DEFINITION IDs extracted from the "definition_id" field.`,
      ``,
      `**❌ WRONG - DO NOT DO THIS:**`,
      `• DO NOT use metric IDs from the first tool call (list-pulse-metric-subscriptions)`,
      `• DO NOT use the "id" field from list-pulse-metrics-from-metric-ids result`,
      `• DO NOT extract IDs yourself - use the exact IDs provided above`,
      `• DO NOT forget "view": "DEFINITION_VIEW_FULL"`,
      ``,
      `**✅ CORRECT - DO THIS:**`,
      `• Copy the exact metricDefinitionIds array shown above: ${JSON.stringify(definitionIds)}`,
      `• Include "view": "DEFINITION_VIEW_FULL" exactly as shown`,
      `• Call the tool immediately - this is mandatory to get human-readable metric names`,
      ``,
      `Without this next step, you cannot provide metric names (only UUIDs, which is unacceptable UX).`,
      '',
    ].join('\n');
  }
}
