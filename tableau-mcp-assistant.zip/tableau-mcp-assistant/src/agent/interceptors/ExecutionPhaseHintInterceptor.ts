/**
 * ExecutionPhaseHintInterceptor - Injects execution phase hints for data queries (v344)
 *
 * This interceptor fires after query-datasource and get-view-data tools and injects
 * system hints to warn about:
 * - Truncated data (preview limitations)
 * - Request mismatches (user asked for 100, got 30)
 * - Aggregation constraints (don't sum pre-aggregated values)
 * - Calculation validation (verify totals match displayed data)
 *
 * Context: When query results are truncated or aggregated, the LLM may incorrectly:
 * - Compute grand totals from truncated data
 * - Sum pre-aggregated values (e.g., treating category totals as additive)
 * - Make conclusions about "all data" when only seeing a preview
 *
 * This interceptor prevents such hallucinations by injecting constraints based on
 * the QueryContext metadata.
 */

import { Interceptor, ToolResult, StateContext, SystemHint } from '../types.js';
import { updateQueryContextFromResult, buildExecutionPhaseHint } from '../utils/QueryContextBuilder.js';
import { logger } from '../../util/logger.js';

export class ExecutionPhaseHintInterceptor implements Interceptor {
  /**
   * Called after a tool execution completes
   */
  async afterAction(result: ToolResult, context: StateContext): Promise<void> {
    // Only intercept query-datasource and get-view-data
    if (result.toolName !== 'query-datasource' && result.toolName !== 'get-view-data') {
      return;
    }

    // Only inject hint if query was successful
    if (result.isError) {
      logger.info(`[v344 EXECUTION-HINT] Skipping hint for failed ${result.toolName}`);
      return;
    }

    // Check if QueryContext exists (set by ActionStateHandler before tool execution)
    if (!context.queryContext) {
      logger.warn(`[v344 EXECUTION-HINT] No QueryContext found for ${result.toolName}`);
      return;
    }

    // Skip if hint already injected for this query
    if (context.queryContext.executionHintInjected) {
      logger.info(`[v344 EXECUTION-HINT] Hint already injected for this query context`);
      return;
    }

    logger.info(`[v344 EXECUTION-HINT] Processing ${result.toolName} result for execution phase hint`);

    try {
      // v349: Call summariseToolResult to get safeForModel with metadata
      // This extracts totalRows, __truncatedRows, rows[] in the correct format
      const { summariseToolResult } = await import('../../ws/broker.js');
      const { safeForModel } = summariseToolResult(result.toolName, result.result, null, context.maxViewRowsForModel ?? 30);

      logger.info('[v349 EXECUTION-HINT] Got safeForModel from summariseToolResult', {
        hasTotalRows: !!(safeForModel as any)?.totalRows,
        hasTruncatedRows: !!(safeForModel as any)?.__truncatedRows,
        rowCount: (safeForModel as any)?.rows?.length || (safeForModel as any)?.previewRows?.length,
      });

      // Update QueryContext with result metadata from safeForModel
      updateQueryContextFromResult(context.queryContext, safeForModel);

      // Build execution phase hint
      const hintMessage = buildExecutionPhaseHint(context.queryContext);

      if (!hintMessage) {
        logger.info('[v344 EXECUTION-HINT] No constraints detected, skipping hint');
        return;
      }

      // Inject the hint
      const hint: SystemHint = {
        type: 'EXECUTION_PHASE',
        priority: 'CRITICAL',
        message: hintMessage,
        metadata: {
          toolName: result.toolName,
          totalRows: context.queryContext.totalRowsInDataset,
          truncatedRows: context.queryContext.truncatedRows,
          isAggregated: context.queryContext.isAggregated,
          injectedAt: new Date().toISOString(),
        },
      };

      context.systemHints.push(hint);
      context.queryContext.executionHintInjected = true;

      logger.info(
        `[v344 EXECUTION-HINT] Injected execution phase hint: ` +
        `truncated=${context.queryContext.truncatedRows}, ` +
        `aggregated=${context.queryContext.isAggregated}`
      );
    } catch (error) {
      logger.warn('[v344 EXECUTION-HINT] Failed to process execution phase hint:', error);
    }
  }
}
