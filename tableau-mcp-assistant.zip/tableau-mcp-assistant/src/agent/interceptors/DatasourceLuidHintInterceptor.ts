/**
 * DatasourceLuidHintInterceptor - Injects hints for datasource workflow
 *
 * This interceptor fires after datasource tools and injects system hints
 * to guide the LLM through the correct workflow.
 *
 * Context: Datasource query workflow requires multiple steps:
 * 1. list-datasources (with filter) → Returns datasource with LUID
 * 2. get-datasource-metadata (with LUID) → Returns schema (fields, types)
 * 3. query-datasource (with LUID and fields) → Returns data
 *
 * Without these hints, LLMs often:
 * - Skip get-datasource-metadata and guess field names
 * - Reuse old LUIDs from previous queries
 * - Invent field names that don't exist
 *
 * This interceptor addresses these issues by:
 * - Extracting LUID from list-datasources result and suggesting get-datasource-metadata
 * - Extracting field list from get-datasource-metadata result and warning against hallucination
 */

import { Interceptor, ToolResult, StateContext, SystemHint } from '../types.js';
import { logger } from '../../util/logger.js';

export class DatasourceLuidHintInterceptor implements Interceptor {
  /**
   * Called after a tool execution completes
   */
  async afterAction(result: ToolResult, context: StateContext): Promise<void> {
    // Handle list-datasources
    if (result.toolName === 'list-datasources') {
      await this.handleListDatasources(result, context);
      return;
    }

    // Handle get-datasource-metadata
    if (result.toolName === 'get-datasource-metadata') {
      await this.handleGetDatasourceMetadata(result, context);
      return;
    }
  }

  /**
   * Handle list-datasources result - inject LUID and suggest get-datasource-metadata
   */
  private async handleListDatasources(result: ToolResult, context: StateContext): Promise<void> {
    // Only inject hint if this was a filter query (lookup by name)
    const args = result.arguments as any;
    if (!args || typeof args !== 'object' || !args.filter) {
      return;
    }

    const filter = args.filter;
    if (typeof filter !== 'string' || !filter.startsWith('name:eq:')) {
      return;
    }

    const datasourceName = filter.replace('name:eq:', '');
    logger.info(`[v342 DATASOURCE-LUID-HINT] Detected list-datasources lookup for "${datasourceName}"`);

    try {
      const datasourceLuid = this.extractLuidFromListResult(result);

      if (!datasourceLuid) {
        logger.warn('[v342 DATASOURCE-LUID-HINT] No LUID extracted from result');
        return;
      }

      logger.info(`[v342 DATASOURCE-LUID-HINT] Extracted LUID for "${datasourceName}": ${datasourceLuid}`);

      // Build and inject the hint
      const hint: SystemHint = {
        type: 'LUID_EXTRACTION',
        priority: 'CRITICAL',
        message: this.buildLuidHint(datasourceName, datasourceLuid),
        metadata: {
          datasourceName,
          datasourceLuid,
          extractedAt: new Date().toISOString(),
        },
      };

      context.systemHints.push(hint);
      logger.info(`[v342 DATASOURCE-LUID-HINT] Injected LUID hint for "${datasourceName}" → ${datasourceLuid}`);
    } catch (error) {
      logger.warn('[v342 DATASOURCE-LUID-HINT] Failed to extract LUID from result:', error);
    }
  }

  /**
   * Handle get-datasource-metadata result - inject field list reminder
   */
  private async handleGetDatasourceMetadata(result: ToolResult, context: StateContext): Promise<void> {
    const args = result.arguments as any;
    if (!args || !args.datasourceLuid) {
      return;
    }

    const datasourceLuid = args.datasourceLuid;
    logger.info(`[v342 DATASOURCE-FIELDS-HINT] Detected get-datasource-metadata for ${datasourceLuid}`);

    try {
      const fields = this.extractFieldsFromMetadataResult(result);

      if (fields.length === 0) {
        logger.warn('[v342 DATASOURCE-FIELDS-HINT] No fields extracted from result');
        return;
      }

      logger.info(`[v342 DATASOURCE-FIELDS-HINT] Extracted ${fields.length} fields`);

      // Build and inject the hint
      const hint: SystemHint = {
        type: 'DATASOURCE_SCHEMA',
        priority: 'CRITICAL',
        message: this.buildFieldsHint(datasourceLuid, fields),
        metadata: {
          datasourceLuid,
          fieldCount: fields.length,
          fields: fields.slice(0, 20), // Store first 20 for debugging
          extractedAt: new Date().toISOString(),
        },
      };

      context.systemHints.push(hint);
      logger.info(`[v342 DATASOURCE-FIELDS-HINT] Injected fields hint for ${datasourceLuid} (${fields.length} fields)`);
    } catch (error) {
      logger.warn('[v342 DATASOURCE-FIELDS-HINT] Failed to extract fields from result:', error);
    }
  }

  /**
   * Extract LUID from list-datasources result
   */
  private extractLuidFromListResult(result: ToolResult): string | null {
    try {
      // Result structure: { result: { content: [{ text: "..." }] } }
      const content = (result.result as any)?.content;

      if (!content || !Array.isArray(content) || !content[0]?.text) {
        return null;
      }

      const datasources = JSON.parse(content[0].text);

      // Data is an array of datasource objects: [{ id: "...", name: "...", ... }]
      if (!Array.isArray(datasources) || datasources.length === 0) {
        return null;
      }

      // Extract LUID (id field) from first datasource
      return datasources[0].id || null;
    } catch (error) {
      logger.error('[v342 DATASOURCE-LUID-HINT] Error parsing result:', error);
      return null;
    }
  }

  /**
   * Extract field names from get-datasource-metadata result
   */
  private extractFieldsFromMetadataResult(result: ToolResult): string[] {
    try {
      // Result structure: { result: { content: [{ text: "..." }] } }
      const content = (result.result as any)?.content;

      if (!content || !Array.isArray(content) || !content[0]?.text) {
        return [];
      }

      const metadata = JSON.parse(content[0].text);

      // Metadata structure: { id: "...", name: "...", fields: [{ name: "...", dataType: "..." }] }
      if (!metadata.fields || !Array.isArray(metadata.fields)) {
        return [];
      }

      // Extract field names
      return metadata.fields
        .map((field: any) => field.name)
        .filter((name: any) => typeof name === 'string');
    } catch (error) {
      logger.error('[v342 DATASOURCE-FIELDS-HINT] Error parsing result:', error);
      return [];
    }
  }

  /**
   * Build the LUID hint message (after list-datasources)
   */
  private buildLuidHint(datasourceName: string, datasourceLuid: string): string {
    return [
      '',
      `⚠️  CRITICAL: You just looked up "${datasourceName}"`,
      `✅ The correct LUID for "${datasourceName}" is: ${datasourceLuid}`,
      '',
      `**🔒 MANDATORY - Use THIS LUID for all subsequent calls:**`,
      `- get-datasource-metadata: { "datasourceLuid": "${datasourceLuid}" }`,
      `- query-datasource: { "datasourceLuid": "${datasourceLuid}", "query": {...} }`,
      '',
      `❌ DO NOT use any other LUID from earlier in the conversation`,
      `❌ DO NOT reuse LUIDs from previous datasource queries`,
      `✅ ONLY use the LUID you just received: ${datasourceLuid}`,
      '',
    ].join('\n');
  }

  /**
   * Build the fields hint message (after get-datasource-metadata)
   */
  private buildFieldsHint(datasourceLuid: string, fields: string[]): string {
    // Show first 50 fields in the hint (to avoid extremely long messages)
    const displayFields = fields.slice(0, 50);
    const hasMore = fields.length > 50;

    return [
      '',
      `🚨 CRITICAL SYSTEM INSTRUCTION - DATASOURCE SCHEMA LOCK`,
      '',
      `You just called get-datasource-metadata for datasourceId: ${datasourceLuid}`,
      `This datasource has ${fields.length} available field(s).`,
      '',
      `**🔒 MANDATORY - USE ONLY THESE FIELDS when querying this datasource:**`,
      '',
      displayFields.map(f => `  • ${f}`).join('\n'),
      hasMore ? `  ... and ${fields.length - 50} more fields (see full result above)` : '',
      '',
      `**❌ FORBIDDEN - NEVER DO THIS:**`,
      `• DO NOT invent field names that are not in the list above`,
      `• DO NOT assume fields exist without checking this schema`,
      `• DO NOT use field names from previous queries to other datasources`,
      `• DO NOT guess or hallucinate field names`,
      '',
      `**✅ CORRECT - DO THIS:**`,
      `• Use ONLY field names from the list above (case-sensitive)`,
      `• If user asks for a field that doesn't exist, explain which fields ARE available`,
      `• If a query fails with "unknown field", verify against this list and retry`,
      '',
    ].join('\n');
  }
}
