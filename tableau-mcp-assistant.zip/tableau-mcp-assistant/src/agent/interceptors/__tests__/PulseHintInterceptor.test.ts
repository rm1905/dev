/**
 * Unit tests for PulseHintInterceptor
 *
 * These tests demonstrate the testability of the refactored architecture.
 * The interceptor can be tested in isolation without needing a full
 * WebSocket connection, LLM, or database.
 *
 * To run these tests:
 * 1. Install a test framework: npm install --save-dev vitest
 * 2. Add to package.json: "test": "vitest"
 * 3. Run: npm test
 *
 * For now, this file serves as documentation of test cases.
 */

import { PulseHintInterceptor } from '../PulseHintInterceptor.js';
import { ToolResult, StateContext } from '../../types.js';

/**
 * Helper to create a mock ToolResult
 */
function createMockToolResult(
  toolName: string,
  resultData: any
): ToolResult {
  return {
    toolName,
    arguments: {},
    result: {
      content: [{ text: JSON.stringify(resultData) }],
    },
    isError: false,
    executionTime: 100,
  };
}

/**
 * Helper to create a mock StateContext
 */
function createMockContext(): StateContext {
  return {
    systemHints: [],
    iterationCount: 1,
    maxIterations: 10, // v353: Changed from 30 to 10 to match old broker.ts
    recoveryAttempts: 0,
    tokenUsage: {
      system: 0,
      user: 0,
      assistant: 0,
      tools: 0,
      total: 0,
    },
  };
}

// ========================================
// Test Case 1: Should extract definition IDs from valid result
// ========================================

async function testExtractDefinitionIds() {
  const interceptor = new PulseHintInterceptor();
  const context = createMockContext();

  const mockData = [
    {
      id: 'metric-id-1',
      definition_id: 'def-id-1',
      specification: {},
      is_default: false,
    },
    {
      id: 'metric-id-2',
      definition_id: 'def-id-2',
      specification: {},
      is_default: false,
    },
  ];

  const result = createMockToolResult('list-pulse-metrics-from-metric-ids', mockData);

  await interceptor.afterAction!(result, context);

  // Assertions (with a real test framework):
  // expect(context.systemHints).toHaveLength(1);
  // expect(context.systemHints[0].type).toBe('PULSE_WORKFLOW');
  // expect(context.systemHints[0].priority).toBe('CRITICAL');
  // expect(context.systemHints[0].metadata?.definitionIds).toEqual(['def-id-1', 'def-id-2']);

  console.log('✓ Test 1: Should extract definition IDs from valid result');
  console.log('  Hints injected:', context.systemHints.length);
  console.log('  Definition IDs:', context.systemHints[0]?.metadata?.definitionIds);
}

// ========================================
// Test Case 2: Should not inject hint for other tools
// ========================================

async function testIgnoreOtherTools() {
  const interceptor = new PulseHintInterceptor();
  const context = createMockContext();

  const result = createMockToolResult('get-view-data', { data: 'some data' });

  await interceptor.afterAction!(result, context);

  // Assertions:
  // expect(context.systemHints).toHaveLength(0);

  console.log('✓ Test 2: Should not inject hint for other tools');
  console.log('  Hints injected:', context.systemHints.length);
}

// ========================================
// Test Case 3: Should handle empty results gracefully
// ========================================

async function testHandleEmptyResults() {
  const interceptor = new PulseHintInterceptor();
  const context = createMockContext();

  const result = createMockToolResult('list-pulse-metrics-from-metric-ids', []);

  await interceptor.afterAction!(result, context);

  // Assertions:
  // expect(context.systemHints).toHaveLength(0);

  console.log('✓ Test 3: Should handle empty results gracefully');
  console.log('  Hints injected:', context.systemHints.length);
}

// ========================================
// Test Case 4: Should handle malformed data without crashing
// ========================================

async function testHandleMalformedData() {
  const interceptor = new PulseHintInterceptor();
  const context = createMockContext();

  // Missing definition_id field
  const mockData = [
    {
      id: 'metric-id-1',
      specification: {},
    },
  ];

  const result = createMockToolResult('list-pulse-metrics-from-metric-ids', mockData);

  await interceptor.afterAction!(result, context);

  // Assertions:
  // expect(context.systemHints).toHaveLength(0);
  // Should not throw an error

  console.log('✓ Test 4: Should handle malformed data without crashing');
  console.log('  Hints injected:', context.systemHints.length);
}

// ========================================
// Test Case 5: Should include correct hint message format
// ========================================

async function testHintMessageFormat() {
  const interceptor = new PulseHintInterceptor();
  const context = createMockContext();

  const mockData = [
    {
      id: 'metric-id-1',
      definition_id: 'test-def-id',
      specification: {},
    },
  ];

  const result = createMockToolResult('list-pulse-metrics-from-metric-ids', mockData);

  await interceptor.afterAction!(result, context);

  const hint = context.systemHints[0];

  // Assertions:
  // expect(hint.message).toContain('list-pulse-metric-definitions-from-definition-ids');
  // expect(hint.message).toContain('DEFINITION_VIEW_FULL');
  // expect(hint.message).toContain('test-def-id');

  console.log('✓ Test 5: Should include correct hint message format');
  console.log('  Hint contains required keywords:', {
    hasToolName: hint.message.includes('list-pulse-metric-definitions-from-definition-ids'),
    hasView: hint.message.includes('DEFINITION_VIEW_FULL'),
    hasDefId: hint.message.includes('test-def-id'),
  });
}

// ========================================
// Test Case 6: Should filter out non-string definition IDs
// ========================================

async function testFilterNonStringIds() {
  const interceptor = new PulseHintInterceptor();
  const context = createMockContext();

  const mockData = [
    { id: 'metric-1', definition_id: 'valid-id' },
    { id: 'metric-2', definition_id: null },
    { id: 'metric-3', definition_id: undefined },
    { id: 'metric-4', definition_id: 123 }, // number
    { id: 'metric-5', definition_id: 'another-valid-id' },
  ];

  const result = createMockToolResult('list-pulse-metrics-from-metric-ids', mockData);

  await interceptor.afterAction!(result, context);

  // Assertions:
  // expect(context.systemHints[0].metadata?.definitionIds).toEqual(['valid-id', 'another-valid-id']);

  console.log('✓ Test 6: Should filter out non-string definition IDs');
  console.log('  Valid IDs extracted:', context.systemHints[0]?.metadata?.definitionIds);
}

// ========================================
// Run all tests
// ========================================

async function runAllTests() {
  console.log('\n========================================');
  console.log('PulseHintInterceptor Test Suite');
  console.log('========================================\n');

  try {
    await testExtractDefinitionIds();
    await testIgnoreOtherTools();
    await testHandleEmptyResults();
    await testHandleMalformedData();
    await testHintMessageFormat();
    await testFilterNonStringIds();

    console.log('\n========================================');
    console.log('✓ All tests passed!');
    console.log('========================================\n');
  } catch (error) {
    console.error('\n✗ Test failed:', error);
    process.exit(1);
  }
}

// Export for test framework integration
export {
  testExtractDefinitionIds,
  testIgnoreOtherTools,
  testHandleEmptyResults,
  testHandleMalformedData,
  testHintMessageFormat,
  testFilterNonStringIds,
  runAllTests,
};

// Run tests if executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runAllTests();
}
