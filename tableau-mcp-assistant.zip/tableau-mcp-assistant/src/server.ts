/**
 * Main Express server with WebSocket support
 */

import express from 'express';
import { WebSocketServer } from 'ws';
import { createServer } from 'http';
import { config } from './util/env.js';
import { logger } from './util/logger.js';
import { sessionRouter } from './routes/session.js';
import { settingsRouter } from './routes/settings.js';
import { downloadRouter } from './routes/download.js';
import { promptsRouter } from './routes/prompts.js';
import { promptManager } from './util/PromptManager.js';
import { createMcpServer } from './ws/mcpServerProxy.js';
import { createBrokerServer } from './ws/broker.js';

// Initialize Express app
const app = express();
const httpServer = createServer(app);

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS middleware
app.use((_req, res, next) => {
  const settings = config.getSettingsSync();
  const allowedOrigins = settings.ALLOWED_ORIGINS
    .split(',')
    .map((o: string) => o.trim())
    .filter((o: string) => o.length > 0);

  const origin = _req.get('origin');

  if (allowedOrigins.length === 0 || (origin && allowedOrigins.includes(origin))) {
    res.setHeader('Access-Control-Allow-Origin', origin || '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
  }

  if (_req.method === 'OPTIONS') {
    res.sendStatus(200);
    return;
  }

  next();
});

// Health check
app.get('/healthz', (_req, res) => {
  res.json({ ok: true });
});

// Admin endpoint to run Phase 2 migration (v434)
app.post('/admin/migrate-phase2-hints', async (_req, res): Promise<void> => {
  try {
    const { Pool } = await import('pg');
    const pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: process.env.NODE_ENV === 'production' ? {
        rejectUnauthorized: false
      } : false,
    });

    const client = await pool.connect();

    try {
      await client.query('BEGIN');

      // Extract datasourceLookupHint content
      const datasourceLookupHint = [
        '',
        '🚨 CRITICAL: User mentioned a datasource in their query',
        '',
        '⚠️  MANDATORY WORKFLOW - You MUST follow these steps in order:',
        '',
        '**STEP 1: Look up the datasource LUID**',
        '  - Extract the datasource name from the user\'s question',
        '  - Call: list-datasources({ filter: "name:eq:<datasource name>" })',
        '  - Wait for the result and extract the LUID from it',
        '',
        '**STEP 2: Use the LUID you just received**',
        '  - get-datasource-metadata({ datasourceLuid: "<LUID from step 1>" })',
        '  - query-datasource({ datasourceLuid: "<LUID from step 1>", query: {...} })',
        '',
        '🔒 CRITICAL RULES:',
        '  ❌ NEVER skip the list-datasources lookup step',
        '  ❌ NEVER reuse a datasourceLuid from earlier in the conversation',
        '  ❌ NEVER use a datasourceLuid without first calling list-datasources',
        '  ✅ ALWAYS perform a fresh list-datasources lookup for EVERY datasource query',
        '  ✅ Each new datasource query MUST start with list-datasources',
        '',
        '⚠️  Even if you queried this datasource before, you MUST call list-datasources again',
        '',
      ].join('\n');

      // Extract workbookLookupHint content
      const workbookLookupHint = [
        '',
        '🚨 CRITICAL: User mentioned a workbook in their query',
        '',
        '⚠️  MANDATORY WORKFLOW - You MUST follow these steps in order:',
        '',
        '**STEP 1: Look up the workbook ID**',
        '  - Extract the workbook name from the user\'s question',
        '  - Call: list-workbooks({ filter: "name:eq:<workbook name>" })',
        '  - Wait for the result and extract the workbook ID from it',
        '',
        '**STEP 2: Use the workbook ID you just received**',
        '  - get-workbook({ workbookId: "<ID from step 1>" })',
        '  - list-views({ workbookId: "<ID from step 1>" })',
        '',
        '🔒 CRITICAL RULES:',
        '  ❌ NEVER skip the list-workbooks lookup step',
        '  ❌ NEVER reuse a workbookId from earlier in the conversation',
        '  ❌ NEVER use a workbookId without first calling list-workbooks',
        '  ❌ NEVER make up or hallucinate workbook IDs',
        '  ✅ ALWAYS perform a fresh list-workbooks lookup for EVERY workbook query',
        '  ✅ Each new workbook query MUST start with list-workbooks',
        '',
        '⚠️  Even if you queried this workbook before, you MUST call list-workbooks again',
        '',
      ].join('\n');

      // Create datasource_lookup_upfront_hint section
      await client.query(`
        INSERT INTO prompt_sections (section_name, content, description, created_at, updated_at)
        VALUES ($1, $2, $3, NOW(), NOW())
        ON CONFLICT (section_name) DO UPDATE SET
          content = EXCLUDED.content,
          description = EXCLUDED.description,
          updated_at = NOW()
      `, [
        'datasource_lookup_upfront_hint',
        datasourceLookupHint,
        'Keyword-based upfront hint injected when user mentions "datasource" in their query. Enforces mandatory LUID lookup workflow via list-datasources before any datasource operations. Stacks BEFORE datasource_query_upfront_hint when both conditions are met (keyword + intent). Update this to modify datasource LUID lookup enforcement rules.'
      ]);

      // Create workbook_lookup_upfront_hint section
      await client.query(`
        INSERT INTO prompt_sections (section_name, content, description, created_at, updated_at)
        VALUES ($1, $2, $3, NOW(), NOW())
        ON CONFLICT (section_name) DO UPDATE SET
          content = EXCLUDED.content,
          description = EXCLUDED.description,
          updated_at = NOW()
      `, [
        'workbook_lookup_upfront_hint',
        workbookLookupHint,
        'Keyword-based upfront hint injected when user mentions "workbook" in their query. Enforces mandatory workbook ID lookup workflow via list-workbooks before any workbook operations. Update this to modify workbook ID lookup enforcement rules.'
      ]);

      await client.query('COMMIT');

      res.json({
        success: true,
        message: 'Phase 2 migration complete',
        sections: [
          { name: 'datasource_lookup_upfront_hint', size: datasourceLookupHint.length },
          { name: 'workbook_lookup_upfront_hint', size: workbookLookupHint.length }
        ]
      });

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
      await pool.end();
    }

  } catch (error: any) {
    logger.error('Failed to run Phase 2 migration', error);
    res.status(500).json({ error: error.message });
  }
});

// Admin endpoint to sync MAX_VIEW_ROWS_FOR_MODEL (v276)
app.post('/admin/sync-max-view-rows', async (_req, res): Promise<void> => {
  try {
    const { Pool } = await import('pg');
    const pool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: process.env.NODE_ENV === 'production' ? {
        rejectUnauthorized: false
      } : false,
    });

    const result = await pool.query(
      `UPDATE prompt_variables
       SET value = $1, updated_at = CURRENT_TIMESTAMP
       WHERE variable_name = $2`,
      ['30', 'MAX_VIEW_ROWS_FOR_MODEL']
    );

    if (result.rowCount === 0) {
      await pool.end();
      res.status(404).json({ error: 'MAX_VIEW_ROWS_FOR_MODEL variable not found' });
      return;
    }

    const verify = await pool.query(
      'SELECT variable_name, value, data_type, description FROM prompt_variables WHERE variable_name = $1',
      ['MAX_VIEW_ROWS_FOR_MODEL']
    );

    await pool.end();

    res.json({
      success: true,
      message: 'Successfully updated MAX_VIEW_ROWS_FOR_MODEL from 20 to 30',
      variable: verify.rows[0]
    });
  } catch (error: any) {
    logger.error('Failed to sync MAX_VIEW_ROWS_FOR_MODEL', error);
    res.status(500).json({ error: error.message });
  }
});

// Mount routes
app.use('/', sessionRouter);
app.use('/', settingsRouter);
app.use('/', downloadRouter);
app.use('/', promptsRouter);

// Serve static files
app.use('/ui', express.static('src/public/ui'));

// Serve prompts UI
app.get('/prompts', (_req, res) => {
  res.sendFile('src/public/prompts.html', { root: process.cwd() });
});

// Serve debug console UI
app.get('/debug', (_req, res) => {
  res.sendFile('src/public/debug.html', { root: process.cwd() });
});

// Serve .trex file
app.get('/tableau-mcp-extension.trex', (_req, res) => {
  res.setHeader('Content-Type', 'application/xml');
  res.sendFile('src/public/tableau-mcp-extension.trex', { root: process.cwd() });
});

// Global error handler - must be LAST, after all routes and middleware
// This catches any unhandled errors and returns JSON instead of HTML
app.use((err: Error, _req: express.Request, res: express.Response, next: express.NextFunction) => {
  logger.error('Unhandled error in request', err);

  // If headers already sent, delegate to default Express error handler
  if (res.headersSent) {
    return next(err);
  }

  // Return JSON error response
  res.status(500).json({
    error: err.message || 'Internal server error',
    details: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });
});

// Create WebSocket servers
const mcpWss = new WebSocketServer({ noServer: true });
const brokerWss = new WebSocketServer({ noServer: true });

// Initialize MCP and Broker servers
createMcpServer(mcpWss);
createBrokerServer(brokerWss);

// WebSocket upgrade handler
httpServer.on('upgrade', (request, socket, head) => {
  const url = new URL(request.url || '', `http://localhost`);

  if (url.pathname === '/mcp/ws') {
    mcpWss.handleUpgrade(request, socket, head, (ws) => {
      mcpWss.emit('connection', ws, request);
    });
  } else if (url.pathname === '/broker/ws') {
    brokerWss.handleUpgrade(request, socket, head, (ws) => {
      brokerWss.emit('connection', ws, request);
    });
  } else {
    socket.destroy();
  }
});

// Initialize PromptManager and auto-seed if needed
(async () => {
  try {
    await promptManager.initialize();
    logger.info('[Startup] PromptManager initialized successfully');

    // Auto-seed prompts from MD files if database is empty
    if (process.env.DATABASE_URL) {
      const { Pool } = await import('pg');
      const { autoSeedPromptsIfEmpty } = await import('./util/seedPrompts.js');

      const pool = new Pool({
        connectionString: process.env.DATABASE_URL,
        ssl: process.env.NODE_ENV === 'production' ? {
          rejectUnauthorized: false
        } : false,
      });

      await autoSeedPromptsIfEmpty(pool);
      await pool.end();
    }
  } catch (error) {
    logger.warn('[Startup] PromptManager initialization failed (prompts will use fallback)', error);
  }
})();

// Start server
const port = parseInt(config.getEnv().PORT);
httpServer.listen(port, '0.0.0.0', () => {
  logger.info(`Server listening on port ${port}`);
  logger.info(`Environment: ${config.getEnv().NODE_ENV}`);
  logger.info(`MCP Server: ws://localhost:${port}/mcp/ws`);
  logger.info(`Broker Server: ws://localhost:${port}/broker/ws`);
  logger.info(`Settings UI: http://localhost:${port}/settings`);
  logger.info(`Extension UI: http://localhost:${port}/ui/`);
  logger.info(`Prompts UI: http://localhost:${port}/prompts`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down gracefully');
  httpServer.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});
