/**
 * Database connection and operations for profile storage
 */

import { Pool } from 'pg';
import { Settings, SettingsSchemaBase, Profile } from './schema.js';
import { logger } from './logger.js';

class DatabaseManager {
  private pool: Pool | null = null;
  private initialized: boolean = false;

  constructor() {
    // Initialize connection pool if DATABASE_URL is available
    if (process.env.DATABASE_URL) {
      this.pool = new Pool({
        connectionString: process.env.DATABASE_URL,
        ssl: process.env.NODE_ENV === 'production' ? {
          rejectUnauthorized: false
        } : false,
      });
      logger.info('Database connection pool initialized');
    } else {
      logger.warn('DATABASE_URL not set. Profile persistence to database disabled.');
    }
  }

  /**
   * Initialize database schema
   */
  async initialize(): Promise<void> {
    if (this.initialized || !this.pool) {
      return;
    }

    try {
      // Create profiles table if it doesn't exist
      await this.pool.query(`
        CREATE TABLE IF NOT EXISTS profiles (
          name VARCHAR(255) PRIMARY KEY,
          settings JSONB NOT NULL,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        );

        -- Create index on name for faster lookups
        CREATE INDEX IF NOT EXISTS idx_profiles_name ON profiles(name);

        -- Create trigger to update updated_at timestamp
        CREATE OR REPLACE FUNCTION update_updated_at_column()
        RETURNS TRIGGER AS $$
        BEGIN
          NEW.updated_at = CURRENT_TIMESTAMP;
          RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;

        DROP TRIGGER IF EXISTS update_profiles_updated_at ON profiles;
        CREATE TRIGGER update_profiles_updated_at
        BEFORE UPDATE ON profiles
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
      `);

      this.initialized = true;
      logger.info('Database schema initialized successfully');
    } catch (error) {
      logger.error('Failed to initialize database schema', error);
      throw error;
    }
  }

  /**
   * Get all profiles from database (excluding "default")
   */
  async getProfiles(): Promise<Profile[]> {
    if (!this.pool) {
      return [];
    }

    await this.initialize();

    try {
      const result = await this.pool.query(
        'SELECT name, settings FROM profiles WHERE name != $1 ORDER BY name',
        ['default']
      );

      return result.rows.map((row: any) => ({
        name: row.name,
        settings: SettingsSchemaBase.parse(row.settings),
      }));
    } catch (error) {
      logger.error('Failed to fetch profiles from database', error);
      return [];
    }
  }

  /**
   * Get a specific profile by name
   */
  async getProfile(name: string): Promise<Profile | null> {
    if (!this.pool || name === 'default') {
      return null;
    }

    await this.initialize();

    try {
      const result = await this.pool.query(
        'SELECT name, settings FROM profiles WHERE name = $1',
        [name]
      );

      if (result.rows.length === 0) {
        return null;
      }

      const row = result.rows[0];
      return {
        name: row.name,
        settings: SettingsSchemaBase.parse(row.settings),
      };
    } catch (error) {
      logger.error(`Failed to fetch profile "${name}" from database`, error);
      return null;
    }
  }

  /**
   * Save or update a profile (excluding "default")
   */
  async saveProfile(name: string, settings: Settings): Promise<void> {
    if (!this.pool) {
      throw new Error('Database not available. Cannot save profile.');
    }

    if (name === 'default') {
      throw new Error('Cannot save "default" profile to database. Use config.json instead.');
    }

    await this.initialize();

    try {
      // Upsert profile
      await this.pool.query(
        `INSERT INTO profiles (name, settings)
         VALUES ($1, $2)
         ON CONFLICT (name)
         DO UPDATE SET settings = $2, updated_at = CURRENT_TIMESTAMP`,
        [name, JSON.stringify(settings)]
      );

      logger.info(`Profile "${name}" saved to database`);
    } catch (error) {
      logger.error(`Failed to save profile "${name}" to database`, error);
      throw error;
    }
  }

  /**
   * Delete a profile (excluding "default")
   */
  async deleteProfile(name: string): Promise<void> {
    if (!this.pool) {
      throw new Error('Database not available. Cannot delete profile.');
    }

    if (name === 'default') {
      throw new Error('Cannot delete "default" profile from database.');
    }

    await this.initialize();

    try {
      const result = await this.pool.query(
        'DELETE FROM profiles WHERE name = $1',
        [name]
      );

      if (result.rowCount === 0) {
        throw new Error(`Profile "${name}" not found in database`);
      }

      logger.info(`Profile "${name}" deleted from database`);
    } catch (error) {
      logger.error(`Failed to delete profile "${name}" from database`, error);
      throw error;
    }
  }

  /**
   * Check if database is available
   */
  isAvailable(): boolean {
    return this.pool !== null;
  }

  /**
   * Close database connection
   */
  async close(): Promise<void> {
    if (this.pool) {
      await this.pool.end();
      logger.info('Database connection closed');
    }
  }
}

export const db = new DatabaseManager();
