/**
 * Environment and configuration management
 */

import 'dotenv/config';
import { z } from 'zod';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { dirname } from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';
import { Settings, SettingsSchema, SettingsSchemaBase, Profile, ProfilesConfig, ProfilesConfigSchema } from './schema.js';
import { logger } from './logger.js';
import { db } from './db.js';

const execAsync = promisify(exec);

const CONFIG_PATH = './config/config.json';
const LEGACY_CONFIG_PATH = './config/config.json.bak';

// Environment variables schema
const EnvSchema = z.object({
  PORT: z.string().default('3000'),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('production'),
  CONFIG_PASSWORD: z.string().min(1),
  LOG_LEVEL: z.enum(['debug', 'info', 'warn', 'error']).default('info'),
});

export type Env = z.infer<typeof EnvSchema>;

class ConfigManager {
  private env: Env;
  private profilesConfig: ProfilesConfig;

  constructor() {
    // Parse environment variables
    this.env = EnvSchema.parse({
      PORT: process.env.PORT || '3000',
      NODE_ENV: process.env.NODE_ENV || 'production',
      CONFIG_PASSWORD: process.env.CONFIG_PASSWORD,
      LOG_LEVEL: process.env.LOG_LEVEL || 'info',
    });

    // Load profiles config from file
    this.profilesConfig = this.loadProfiles();

    // Set log level
    logger.setLevel(this.env.LOG_LEVEL as 'debug' | 'info' | 'warn' | 'error');
  }

  private loadProfiles(): ProfilesConfig {
    try {
      if (existsSync(CONFIG_PATH)) {
        const raw = readFileSync(CONFIG_PATH, 'utf-8');
        const json = JSON.parse(raw);

        // Try to parse as profiles config
        try {
          const parsed = ProfilesConfigSchema.parse(json);

          // Filter out non-default profiles from config.json
          // Non-default profiles should only be in the database
          const defaultOnly: ProfilesConfig = {
            defaultProfile: parsed.defaultProfile,
            profiles: parsed.profiles.filter(p => p.name === 'default'),
          };

          // If we found non-default profiles in config.json, save cleaned version
          if (parsed.profiles.length !== defaultOnly.profiles.length) {
            logger.info('Found non-default profiles in config.json. These will be moved to database on next save.');
            this.saveProfilesConfig(defaultOnly);
          }

          // Apply environment variable overrides to "default" profile and persist to file
          // This ensures config.json always reflects the latest settings from Heroku config vars
          const defaultProfile = defaultOnly.profiles.find(p => p.name === 'default');
          if (defaultProfile) {
            let hasEnvOverrides = false;
            const envOverrides: Partial<Settings> = {};

            // Check for env var overrides (prefixed with DEFAULT_PROFILE_)
            if (process.env.DEFAULT_PROFILE_OPENAI_API_KEY) {
              envOverrides.OPENAI_API_KEY = process.env.DEFAULT_PROFILE_OPENAI_API_KEY;
              hasEnvOverrides = true;
            }
            if (process.env.DEFAULT_PROFILE_DEFAULT_MODEL) {
              envOverrides.DEFAULT_MODEL = process.env.DEFAULT_PROFILE_DEFAULT_MODEL;
              hasEnvOverrides = true;
            }
            if (process.env.DEFAULT_PROFILE_TABLEAU_BASE_URL) {
              envOverrides.TABLEAU_BASE_URL = process.env.DEFAULT_PROFILE_TABLEAU_BASE_URL;
              hasEnvOverrides = true;
            }
            if (process.env.DEFAULT_PROFILE_TABLEAU_SITE_CONTENT_URL) {
              envOverrides.TABLEAU_SITE_CONTENT_URL = process.env.DEFAULT_PROFILE_TABLEAU_SITE_CONTENT_URL;
              hasEnvOverrides = true;
            }
            if (process.env.DEFAULT_PROFILE_AUTHENTICATION_TYPE) {
              envOverrides.AUTHENTICATION_TYPE = process.env.DEFAULT_PROFILE_AUTHENTICATION_TYPE as 'pat' | 'direct-trust';
              hasEnvOverrides = true;
            }
            if (process.env.DEFAULT_PROFILE_TABLEAU_PAT_NAME) {
              envOverrides.TABLEAU_PAT_NAME = process.env.DEFAULT_PROFILE_TABLEAU_PAT_NAME;
              hasEnvOverrides = true;
            }
            if (process.env.DEFAULT_PROFILE_TABLEAU_PAT_SECRET) {
              envOverrides.TABLEAU_PAT_SECRET = process.env.DEFAULT_PROFILE_TABLEAU_PAT_SECRET;
              hasEnvOverrides = true;
            }
            if (process.env.DEFAULT_PROFILE_JWT_SUB_CLAIM) {
              envOverrides.JWT_SUB_CLAIM = process.env.DEFAULT_PROFILE_JWT_SUB_CLAIM;
              hasEnvOverrides = true;
            }
            if (process.env.DEFAULT_PROFILE_CONNECTED_APP_CLIENT_ID) {
              envOverrides.CONNECTED_APP_CLIENT_ID = process.env.DEFAULT_PROFILE_CONNECTED_APP_CLIENT_ID;
              hasEnvOverrides = true;
            }
            if (process.env.DEFAULT_PROFILE_CONNECTED_APP_SECRET_ID) {
              envOverrides.CONNECTED_APP_SECRET_ID = process.env.DEFAULT_PROFILE_CONNECTED_APP_SECRET_ID;
              hasEnvOverrides = true;
            }
            if (process.env.DEFAULT_PROFILE_CONNECTED_APP_SECRET_VALUE) {
              envOverrides.CONNECTED_APP_SECRET_VALUE = process.env.DEFAULT_PROFILE_CONNECTED_APP_SECRET_VALUE;
              hasEnvOverrides = true;
            }
            if (process.env.DEFAULT_PROFILE_JWT_ADDITIONAL_PAYLOAD) {
              envOverrides.JWT_ADDITIONAL_PAYLOAD = process.env.DEFAULT_PROFILE_JWT_ADDITIONAL_PAYLOAD;
              hasEnvOverrides = true;
            }
            if (process.env.DEFAULT_PROFILE_ALLOWED_ORIGINS) {
              envOverrides.ALLOWED_ORIGINS = process.env.DEFAULT_PROFILE_ALLOWED_ORIGINS;
              hasEnvOverrides = true;
            }
            if (process.env.DEFAULT_PROFILE_REQUEST_TIMEOUT_MS) {
              envOverrides.REQUEST_TIMEOUT_MS = parseInt(process.env.DEFAULT_PROFILE_REQUEST_TIMEOUT_MS, 10);
              hasEnvOverrides = true;
            }
            if (process.env.DEFAULT_PROFILE_MAX_ROWS) {
              envOverrides.MAX_ROWS = parseInt(process.env.DEFAULT_PROFILE_MAX_ROWS, 10);
              hasEnvOverrides = true;
            }
            if (process.env.DEFAULT_PROFILE_MAX_VIEW_ROWS_FOR_MODEL) {
              envOverrides.MAX_VIEW_ROWS_FOR_MODEL = parseInt(process.env.DEFAULT_PROFILE_MAX_VIEW_ROWS_FOR_MODEL, 10);
              hasEnvOverrides = true;
            }

            // If we have env overrides, merge them and persist to config.json
            if (hasEnvOverrides) {
              defaultProfile.settings = { ...defaultProfile.settings, ...envOverrides };
              logger.info('Applied environment variable overrides to "default" profile');
              logger.info('Writing updated settings to config.json to ensure persistence...');
              this.saveProfilesConfig(defaultOnly);
            }
          }

          logger.info('Loaded profiles configuration from config file');
          return defaultOnly;
        } catch {
          // Legacy format: migrate single settings object to profile
          logger.info('Migrating legacy settings to profiles format');
          const legacySettings = SettingsSchema.parse(json);

          // Backup legacy config
          writeFileSync(LEGACY_CONFIG_PATH, JSON.stringify(legacySettings, null, 2), 'utf-8');
          logger.info('Backed up legacy config to config.json.bak');

          const migratedConfig: ProfilesConfig = {
            defaultProfile: 'default',
            profiles: [{
              name: 'default',
              settings: legacySettings,
            }],
          };

          // Save migrated config
          this.saveProfilesConfig(migratedConfig);
          return migratedConfig;
        }
      }
    } catch (error) {
      logger.warn(`Failed to load profiles from file, using defaults: ${error instanceof Error ? error.message : String(error)}`);
    }

    // Return defaults with env overrides
    // Use SettingsSchemaBase (without strict validation) for backward compatibility
    // This allows partial configuration when loading from environment variables
    const defaultSettings = SettingsSchemaBase.parse({
      // LLM Provider fields
      LLM_PROVIDER: (process.env.LLM_PROVIDER as 'openai' | 'local') || 'openai',
      OPENAI_API_KEY: process.env.OPENAI_API_KEY,
      OPENAI_DEFAULT_MODEL: process.env.OPENAI_DEFAULT_MODEL || process.env.DEFAULT_MODEL || 'gpt-4o-mini',
      LOCAL_BASE_URL: process.env.LOCAL_BASE_URL,
      LOCAL_API_KEY: process.env.LOCAL_API_KEY,
      LOCAL_MODEL: process.env.LOCAL_MODEL,
      DEFAULT_MODEL: process.env.DEFAULT_MODEL || 'gpt-4o-mini',

      // Tableau configuration
      TABLEAU_BASE_URL: process.env.TABLEAU_BASE_URL,
      TABLEAU_SITE_CONTENT_URL: process.env.TABLEAU_SITE_CONTENT_URL || '',

      // Authentication fields
      AUTHENTICATION_TYPE: (process.env.AUTHENTICATION_TYPE as 'pat' | 'direct-trust') || 'pat',
      TABLEAU_PAT_NAME: process.env.TABLEAU_PAT_NAME,
      TABLEAU_PAT_SECRET: process.env.TABLEAU_PAT_SECRET,
      JWT_SUB_CLAIM: process.env.JWT_SUB_CLAIM,
      CONNECTED_APP_CLIENT_ID: process.env.CONNECTED_APP_CLIENT_ID,
      CONNECTED_APP_SECRET_ID: process.env.CONNECTED_APP_SECRET_ID,
      CONNECTED_APP_SECRET_VALUE: process.env.CONNECTED_APP_SECRET_VALUE,
      JWT_ADDITIONAL_PAYLOAD: process.env.JWT_ADDITIONAL_PAYLOAD,

      // Application settings
      ALLOWED_ORIGINS: process.env.ALLOWED_ORIGINS || '',
      REQUEST_TIMEOUT_MS: parseInt(process.env.REQUEST_TIMEOUT_MS || '60000'),
      MAX_ROWS: parseInt(process.env.MAX_ROWS || '500'),
      MAX_VIEW_ROWS_FOR_MODEL: parseInt(process.env.MAX_VIEW_ROWS_FOR_MODEL || '30'),
    });

    return {
      defaultProfile: 'default',
      profiles: [{
        name: 'default',
        settings: defaultSettings,
      }],
    };
  }

  private saveProfilesConfig(config: ProfilesConfig): void {
    // Ensure directory exists
    const dir = dirname(CONFIG_PATH);
    if (!existsSync(dir)) {
      mkdirSync(dir, { recursive: true });
    }

    writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf-8');
  }

  getEnv(): Env {
    return this.env;
  }

  // Get settings for a specific profile (or default)
  async getSettings(profileName?: string): Promise<Settings> {
    const name = profileName || this.profilesConfig.defaultProfile || 'default';

    // Check config.json first (for "default" profile)
    const profile = this.profilesConfig.profiles.find(p => p.name === name);

    if (profile) {
      // For "default" profile, apply environment variable overrides
      // This allows persistent changes on Heroku where filesystem is ephemeral
      if (name === 'default') {
        const envOverrides: Partial<Settings> = {};

        // Check for env var overrides (prefixed with DEFAULT_PROFILE_)
        if (process.env.DEFAULT_PROFILE_OPENAI_API_KEY) {
          envOverrides.OPENAI_API_KEY = process.env.DEFAULT_PROFILE_OPENAI_API_KEY;
        }
        if (process.env.DEFAULT_PROFILE_DEFAULT_MODEL) {
          envOverrides.DEFAULT_MODEL = process.env.DEFAULT_PROFILE_DEFAULT_MODEL;
        }
        if (process.env.DEFAULT_PROFILE_TABLEAU_BASE_URL) {
          envOverrides.TABLEAU_BASE_URL = process.env.DEFAULT_PROFILE_TABLEAU_BASE_URL;
        }
        if (process.env.DEFAULT_PROFILE_TABLEAU_SITE_CONTENT_URL) {
          envOverrides.TABLEAU_SITE_CONTENT_URL = process.env.DEFAULT_PROFILE_TABLEAU_SITE_CONTENT_URL;
        }
        if (process.env.DEFAULT_PROFILE_AUTHENTICATION_TYPE) {
          envOverrides.AUTHENTICATION_TYPE = process.env.DEFAULT_PROFILE_AUTHENTICATION_TYPE as 'pat' | 'direct-trust';
        }
        if (process.env.DEFAULT_PROFILE_TABLEAU_PAT_NAME) {
          envOverrides.TABLEAU_PAT_NAME = process.env.DEFAULT_PROFILE_TABLEAU_PAT_NAME;
        }
        if (process.env.DEFAULT_PROFILE_TABLEAU_PAT_SECRET) {
          envOverrides.TABLEAU_PAT_SECRET = process.env.DEFAULT_PROFILE_TABLEAU_PAT_SECRET;
        }
        if (process.env.DEFAULT_PROFILE_JWT_SUB_CLAIM) {
          envOverrides.JWT_SUB_CLAIM = process.env.DEFAULT_PROFILE_JWT_SUB_CLAIM;
        }
        if (process.env.DEFAULT_PROFILE_CONNECTED_APP_CLIENT_ID) {
          envOverrides.CONNECTED_APP_CLIENT_ID = process.env.DEFAULT_PROFILE_CONNECTED_APP_CLIENT_ID;
        }
        if (process.env.DEFAULT_PROFILE_CONNECTED_APP_SECRET_ID) {
          envOverrides.CONNECTED_APP_SECRET_ID = process.env.DEFAULT_PROFILE_CONNECTED_APP_SECRET_ID;
        }
        if (process.env.DEFAULT_PROFILE_CONNECTED_APP_SECRET_VALUE) {
          envOverrides.CONNECTED_APP_SECRET_VALUE = process.env.DEFAULT_PROFILE_CONNECTED_APP_SECRET_VALUE;
        }
        if (process.env.DEFAULT_PROFILE_JWT_ADDITIONAL_PAYLOAD) {
          envOverrides.JWT_ADDITIONAL_PAYLOAD = process.env.DEFAULT_PROFILE_JWT_ADDITIONAL_PAYLOAD;
        }
        // LLM Provider fields
        if (process.env.DEFAULT_PROFILE_LLM_PROVIDER) {
          envOverrides.LLM_PROVIDER = process.env.DEFAULT_PROFILE_LLM_PROVIDER as 'openai';
        }
        if (process.env.DEFAULT_PROFILE_OPENAI_DEFAULT_MODEL) {
          envOverrides.OPENAI_DEFAULT_MODEL = process.env.DEFAULT_PROFILE_OPENAI_DEFAULT_MODEL as any;
        }
        // Local LLM fields
        if (process.env.DEFAULT_PROFILE_LOCAL_BASE_URL) {
          envOverrides.LOCAL_BASE_URL = process.env.DEFAULT_PROFILE_LOCAL_BASE_URL;
        }
        if (process.env.DEFAULT_PROFILE_LOCAL_API_KEY) {
          envOverrides.LOCAL_API_KEY = process.env.DEFAULT_PROFILE_LOCAL_API_KEY;
        }
        if (process.env.DEFAULT_PROFILE_LOCAL_MODEL) {
          envOverrides.LOCAL_MODEL = process.env.DEFAULT_PROFILE_LOCAL_MODEL;
        }
        // Future: Add support for other providers' environment variables here
        // Application settings
        if (process.env.DEFAULT_PROFILE_ALLOWED_ORIGINS) {
          envOverrides.ALLOWED_ORIGINS = process.env.DEFAULT_PROFILE_ALLOWED_ORIGINS;
        }
        if (process.env.DEFAULT_PROFILE_REQUEST_TIMEOUT_MS) {
          envOverrides.REQUEST_TIMEOUT_MS = parseInt(process.env.DEFAULT_PROFILE_REQUEST_TIMEOUT_MS, 10);
        }
        if (process.env.DEFAULT_PROFILE_MAX_ROWS) {
          envOverrides.MAX_ROWS = parseInt(process.env.DEFAULT_PROFILE_MAX_ROWS, 10);
        }
        if (process.env.DEFAULT_PROFILE_MAX_VIEW_ROWS_FOR_MODEL) {
          envOverrides.MAX_VIEW_ROWS_FOR_MODEL = parseInt(process.env.DEFAULT_PROFILE_MAX_VIEW_ROWS_FOR_MODEL, 10);
        }

        return { ...profile.settings, ...envOverrides };
      }

      return { ...profile.settings };
    }

    // Not in config.json, check database
    const dbProfile = await db.getProfile(name);
    if (dbProfile) {
      return { ...dbProfile.settings };
    }

    throw new Error(`Profile "${name}" not found`);
  }

  // Synchronous version for backward compatibility (only checks config.json)
  // IMPORTANT: This method only supports the "default" profile from config.json
  // For non-default profiles (which are stored in the database), use async getSettings()
  getSettingsSync(profileName?: string): Settings {
    // If a specific profile is requested and it's not "default", throw an error
    if (profileName && profileName !== 'default') {
      throw new Error(`Profile "${profileName}" cannot be loaded synchronously. Non-default profiles are stored in the database. Use async getSettings() instead.`);
    }

    // Always use "default" profile for sync access
    const name = 'default';
    const profile = this.profilesConfig.profiles.find(p => p.name === name);

    if (!profile) {
      throw new Error(`Default profile not found in config.json. This should not happen.`);
    }

    // For "default" profile, apply environment variable overrides
    if (name === 'default') {
      const envOverrides: Partial<Settings> = {};

      // Check for env var overrides (prefixed with DEFAULT_PROFILE_)
      if (process.env.DEFAULT_PROFILE_OPENAI_API_KEY) {
        envOverrides.OPENAI_API_KEY = process.env.DEFAULT_PROFILE_OPENAI_API_KEY;
      }
      if (process.env.DEFAULT_PROFILE_DEFAULT_MODEL) {
        envOverrides.DEFAULT_MODEL = process.env.DEFAULT_PROFILE_DEFAULT_MODEL;
      }
      if (process.env.DEFAULT_PROFILE_TABLEAU_BASE_URL) {
        envOverrides.TABLEAU_BASE_URL = process.env.DEFAULT_PROFILE_TABLEAU_BASE_URL;
      }
      if (process.env.DEFAULT_PROFILE_TABLEAU_SITE_CONTENT_URL) {
        envOverrides.TABLEAU_SITE_CONTENT_URL = process.env.DEFAULT_PROFILE_TABLEAU_SITE_CONTENT_URL;
      }
      if (process.env.DEFAULT_PROFILE_AUTHENTICATION_TYPE) {
        envOverrides.AUTHENTICATION_TYPE = process.env.DEFAULT_PROFILE_AUTHENTICATION_TYPE as 'pat' | 'direct-trust';
      }
      if (process.env.DEFAULT_PROFILE_TABLEAU_PAT_NAME) {
        envOverrides.TABLEAU_PAT_NAME = process.env.DEFAULT_PROFILE_TABLEAU_PAT_NAME;
      }
      if (process.env.DEFAULT_PROFILE_TABLEAU_PAT_SECRET) {
        envOverrides.TABLEAU_PAT_SECRET = process.env.DEFAULT_PROFILE_TABLEAU_PAT_SECRET;
      }
      if (process.env.DEFAULT_PROFILE_JWT_SUB_CLAIM) {
        envOverrides.JWT_SUB_CLAIM = process.env.DEFAULT_PROFILE_JWT_SUB_CLAIM;
      }
      if (process.env.DEFAULT_PROFILE_CONNECTED_APP_CLIENT_ID) {
        envOverrides.CONNECTED_APP_CLIENT_ID = process.env.DEFAULT_PROFILE_CONNECTED_APP_CLIENT_ID;
      }
      if (process.env.DEFAULT_PROFILE_CONNECTED_APP_SECRET_ID) {
        envOverrides.CONNECTED_APP_SECRET_ID = process.env.DEFAULT_PROFILE_CONNECTED_APP_SECRET_ID;
      }
      if (process.env.DEFAULT_PROFILE_CONNECTED_APP_SECRET_VALUE) {
        envOverrides.CONNECTED_APP_SECRET_VALUE = process.env.DEFAULT_PROFILE_CONNECTED_APP_SECRET_VALUE;
      }
      if (process.env.DEFAULT_PROFILE_JWT_ADDITIONAL_PAYLOAD) {
        envOverrides.JWT_ADDITIONAL_PAYLOAD = process.env.DEFAULT_PROFILE_JWT_ADDITIONAL_PAYLOAD;
      }
      if (process.env.DEFAULT_PROFILE_ALLOWED_ORIGINS) {
        envOverrides.ALLOWED_ORIGINS = process.env.DEFAULT_PROFILE_ALLOWED_ORIGINS;
      }
      if (process.env.DEFAULT_PROFILE_REQUEST_TIMEOUT_MS) {
        envOverrides.REQUEST_TIMEOUT_MS = parseInt(process.env.DEFAULT_PROFILE_REQUEST_TIMEOUT_MS, 10);
      }
      if (process.env.DEFAULT_PROFILE_MAX_ROWS) {
        envOverrides.MAX_ROWS = parseInt(process.env.DEFAULT_PROFILE_MAX_ROWS, 10);
      }
      if (process.env.DEFAULT_PROFILE_MAX_VIEW_ROWS_FOR_MODEL) {
        envOverrides.MAX_VIEW_ROWS_FOR_MODEL = parseInt(process.env.DEFAULT_PROFILE_MAX_VIEW_ROWS_FOR_MODEL, 10);
      }

      return { ...profile.settings, ...envOverrides };
    }

    return { ...profile.settings };
  }

  // Get all profiles (from both config.json and database)
  async getProfiles(): Promise<Profile[]> {
    const configProfiles = this.profilesConfig.profiles.map(p => ({
      name: p.name,
      settings: { ...p.settings },
    }));

    // Get profiles from database
    const dbProfiles = await db.getProfiles();

    // Combine profiles (config.json first, then database)
    return [...configProfiles, ...dbProfiles];
  }

  // Synchronous version for backward compatibility (only returns config.json profiles)
  getProfilesSync(): Profile[] {
    return this.profilesConfig.profiles.map(p => ({
      name: p.name,
      settings: { ...p.settings },
    }));
  }

  // Get default profile name
  getDefaultProfile(): string | undefined {
    return this.profilesConfig.defaultProfile;
  }

  // Set default profile
  async setDefaultProfile(profileName: string): Promise<void> {
    // Check config.json first
    const profile = this.profilesConfig.profiles.find(p => p.name === profileName);

    // If not in config.json, check database
    if (!profile) {
      const dbProfile = await db.getProfile(profileName);
      if (!dbProfile) {
        throw new Error(`Profile "${profileName}" not found`);
      }
    }

    this.profilesConfig.defaultProfile = profileName;
    this.saveProfilesConfig(this.profilesConfig);
    logger.info(`Set default profile to: ${profileName}`);
  }

  // Synchronous version for backward compatibility
  setDefaultProfileSync(profileName: string): void {
    const profile = this.profilesConfig.profiles.find(p => p.name === profileName);
    if (!profile) {
      throw new Error(`Profile "${profileName}" not found in config.json. Use async setDefaultProfile() to check database.`);
    }

    this.profilesConfig.defaultProfile = profileName;
    this.saveProfilesConfig(this.profilesConfig);
    logger.info(`Set default profile to: ${profileName}`);
  }

  // Helper function to automatically set Heroku config vars using Platform API
  private async setHerokuConfigVars(settings: Partial<Settings>): Promise<void> {
    try {
      // Check if HEROKU_API_KEY is set
      const apiKey = process.env.HEROKU_API_KEY;
      if (!apiKey) {
        logger.warn('HEROKU_API_KEY not set. Cannot automatically persist settings to Heroku config vars.');
        logger.warn('To enable automatic persistence, set HEROKU_API_KEY environment variable.');
        logger.info('Alternatively, manually set config vars using: heroku config:set DEFAULT_PROFILE_<KEY>=<VALUE>');
        return;
      }

      // Detect Heroku app name from environment or git remote
      let appName: string | undefined = process.env.HEROKU_APP_NAME;

      if (!appName) {
        // Try to get app name from git remote
        try {
          const { stdout } = await execAsync('git remote get-url heroku 2>/dev/null');
          const match = stdout.match(/\/([^/]+)\.git/);
          if (match) {
            appName = match[1];
          }
        } catch {
          // Git remote not found, continue
        }
      }

      if (!appName) {
        logger.warn('Could not detect Heroku app name. Skipping automatic config var updates.');
        logger.warn('Set HEROKU_APP_NAME environment variable or ensure git remote "heroku" is configured.');
        return;
      }

      logger.info(`Detected Heroku app: ${appName}`);
      logger.info('Automatically persisting settings to Heroku config vars via Platform API...');

      // Build config vars object
      const configVars: Record<string, string> = {};
      Object.entries(settings).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== '') {
          const envVarName = `DEFAULT_PROFILE_${key}`;
          configVars[envVarName] = String(value);
        }
      });

      if (Object.keys(configVars).length === 0) {
        logger.info('No settings to persist.');
        return;
      }

      // Use Heroku Platform API to set config vars
      // https://devcenter.heroku.com/articles/platform-api-reference#config-vars-update
      const response = await fetch(`https://api.heroku.com/apps/${appName}/config-vars`, {
        method: 'PATCH',
        headers: {
          'Accept': 'application/vnd.heroku+json; version=3',
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(configVars),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Heroku API error: ${response.status} ${response.statusText} - ${errorText}`);
      }

      logger.info('✅ Successfully persisted settings to Heroku config vars');
      logger.info(`Updated ${Object.keys(configVars).length} environment variables`);
      logger.info('Note: Config var changes will take effect on next dyno restart.');
    } catch (error) {
      logger.error('Failed to automatically set Heroku config vars:', error);
      logger.warn('Settings saved to local file but may not persist across deployments.');
      logger.warn('To enable automatic persistence, ensure HEROKU_API_KEY is set.');
      logger.warn('Or manually run: heroku config:set DEFAULT_PROFILE_<KEY>=<VALUE>');
    }
  }

  // Create or update a profile
  async saveProfile(profileName: string, settings: Partial<Settings>): Promise<void> {
    // "default" profile is saved to config.json
    if (profileName === 'default') {
      const existingIndex = this.profilesConfig.profiles.findIndex(p => p.name === profileName);

      if (existingIndex >= 0) {
        // Update existing profile
        const existingSettings = this.profilesConfig.profiles[existingIndex].settings;
        this.profilesConfig.profiles[existingIndex].settings = SettingsSchema.parse({
          ...existingSettings,
          ...settings,
        });
        logger.info(`Updated profile: ${profileName}`);
      } else {
        // Create new profile
        const newSettings = SettingsSchema.parse(settings);
        this.profilesConfig.profiles.push({
          name: profileName,
          settings: newSettings,
        });
        logger.info(`Created profile: ${profileName}`);

        // Set as default if it's the first profile
        if (this.profilesConfig.profiles.length === 1) {
          this.profilesConfig.defaultProfile = profileName;
        }
      }

      this.saveProfilesConfig(this.profilesConfig);
      logger.info(`Successfully saved "default" profile to config.json`);

      // Automatically persist to Heroku config vars
      // This ensures settings survive app restarts and redeployments
      try {
        await this.setHerokuConfigVars(settings);
        logger.info('Settings will persist across deployments via Heroku config vars');
      } catch (err) {
        logger.error('Failed to persist settings to Heroku config vars:', err);
        logger.warn('⚠️  Settings saved locally but may not survive deployment');
        logger.warn('To manually persist, run: heroku config:set DEFAULT_PROFILE_<KEY>=<VALUE>');
      }
    } else {
      // Non-default profiles are saved to database
      if (!db.isAvailable()) {
        throw new Error('Database not available. Cannot save non-default profile.');
      }

      // Get existing settings from database if available
      const existingProfile = await db.getProfile(profileName);
      const mergedSettings = existingProfile
        ? SettingsSchema.parse({ ...existingProfile.settings, ...settings })
        : SettingsSchema.parse(settings);

      await db.saveProfile(profileName, mergedSettings);
      logger.info(`Saved profile "${profileName}" to database`);
    }
  }

  // Synchronous version for backward compatibility (only works for "default" profile)
  saveProfileSync(profileName: string, settings: Partial<Settings>): void {
    if (profileName !== 'default') {
      throw new Error('saveProfileSync only works for "default" profile. Use async saveProfile() for other profiles.');
    }

    const existingIndex = this.profilesConfig.profiles.findIndex(p => p.name === profileName);

    if (existingIndex >= 0) {
      // Update existing profile
      const existingSettings = this.profilesConfig.profiles[existingIndex].settings;
      this.profilesConfig.profiles[existingIndex].settings = SettingsSchema.parse({
        ...existingSettings,
        ...settings,
      });
      logger.info(`Updated profile: ${profileName}`);
    } else {
      // Create new profile
      const newSettings = SettingsSchema.parse(settings);
      this.profilesConfig.profiles.push({
        name: profileName,
        settings: newSettings,
      });
      logger.info(`Created profile: ${profileName}`);

      // Set as default if it's the first profile
      if (this.profilesConfig.profiles.length === 1) {
        this.profilesConfig.defaultProfile = profileName;
      }
    }

    this.saveProfilesConfig(this.profilesConfig);
    logger.info(`Successfully saved "default" profile to config.json`);

    // Automatically persist to Heroku config vars
    // Run async without awaiting to avoid blocking the save operation
    this.setHerokuConfigVars(settings)
      .then(() => {
        logger.info('Settings will persist across deployments via Heroku config vars');
      })
      .catch(err => {
        logger.error('Failed to persist settings to Heroku config vars:', err);
        logger.warn('⚠️  Settings saved locally but may not survive deployment');
        logger.warn('To manually persist, run: heroku config:set DEFAULT_PROFILE_<KEY>=<VALUE>');
      });
  }

  // Delete a profile
  async deleteProfile(profileName: string): Promise<void> {
    // Check if profile exists in config.json
    const index = this.profilesConfig.profiles.findIndex(p => p.name === profileName);

    if (index >= 0) {
      // Profile is in config.json ("default" profile)
      // Can't delete if it's the only profile in config.json
      const totalProfiles = this.profilesConfig.profiles.length + (await db.getProfiles()).length;
      if (totalProfiles === 1) {
        throw new Error('Cannot delete the last profile');
      }

      this.profilesConfig.profiles.splice(index, 1);

      // Update default if we deleted it
      if (this.profilesConfig.defaultProfile === profileName) {
        // Set default to first available profile (from config.json or database)
        if (this.profilesConfig.profiles.length > 0) {
          this.profilesConfig.defaultProfile = this.profilesConfig.profiles[0].name;
        } else {
          const dbProfiles = await db.getProfiles();
          if (dbProfiles.length > 0) {
            this.profilesConfig.defaultProfile = dbProfiles[0].name;
          }
        }
        logger.info(`Updated default profile to: ${this.profilesConfig.defaultProfile}`);
      }

      this.saveProfilesConfig(this.profilesConfig);
      logger.info(`Deleted profile: ${profileName}`);
    } else {
      // Profile is not in config.json, check database
      if (!db.isAvailable()) {
        throw new Error('Database not available and profile not found in config.json');
      }

      const dbProfile = await db.getProfile(profileName);
      if (!dbProfile) {
        throw new Error(`Profile "${profileName}" not found`);
      }

      // Can't delete if it's the only profile
      const totalProfiles = this.profilesConfig.profiles.length + (await db.getProfiles()).length;
      if (totalProfiles === 1) {
        throw new Error('Cannot delete the last profile');
      }

      await db.deleteProfile(profileName);

      // Update default if we deleted it
      if (this.profilesConfig.defaultProfile === profileName) {
        // Set default to first available profile (from config.json or database)
        if (this.profilesConfig.profiles.length > 0) {
          this.profilesConfig.defaultProfile = this.profilesConfig.profiles[0].name;
        } else {
          const dbProfiles = await db.getProfiles();
          if (dbProfiles.length > 0) {
            this.profilesConfig.defaultProfile = dbProfiles[0].name;
          }
        }
        this.saveProfilesConfig(this.profilesConfig);
        logger.info(`Updated default profile to: ${this.profilesConfig.defaultProfile}`);
      }

      logger.info(`Deleted profile "${profileName}" from database`);
    }
  }

  // Synchronous version for backward compatibility (only works for config.json profiles)
  deleteProfileSync(profileName: string): void {
    const index = this.profilesConfig.profiles.findIndex(p => p.name === profileName);

    if (index < 0) {
      throw new Error(`Profile "${profileName}" not found in config.json. Use async deleteProfile() to check database.`);
    }

    // Can't delete if it's the only profile
    if (this.profilesConfig.profiles.length === 1) {
      throw new Error('Cannot delete the last profile');
    }

    this.profilesConfig.profiles.splice(index, 1);

    // Update default if we deleted it
    if (this.profilesConfig.defaultProfile === profileName) {
      this.profilesConfig.defaultProfile = this.profilesConfig.profiles[0].name;
      logger.info(`Updated default profile to: ${this.profilesConfig.defaultProfile}`);
    }

    this.saveProfilesConfig(this.profilesConfig);
    logger.info(`Deleted profile: ${profileName}`);
  }

  // Backward compatibility: save to default profile
  async saveSettings(newSettings: Partial<Settings>): Promise<void> {
    const defaultProfile = this.profilesConfig.defaultProfile || 'default';
    await this.saveProfile(defaultProfile, newSettings);
  }

  // Synchronous version for backward compatibility
  saveSettingsSync(newSettings: Partial<Settings>): void {
    const defaultProfile = this.profilesConfig.defaultProfile || 'default';
    this.saveProfileSync(defaultProfile, newSettings);
  }

  reloadProfiles(): void {
    this.profilesConfig = this.loadProfiles();
  }
}

export const config = new ConfigManager();
