/**
 * Auto-seed prompt_sections from MD files on first startup
 */

import { Pool } from 'pg';
import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { logger } from './logger.js';

interface PromptFile {
  filename: string;
  sectionName: string;
  description: string;
}

// Map filenames to section names and descriptions
const PROMPT_FILES: PromptFile[] = [
  {
    filename: 'core_prompt.md',
    sectionName: 'core_prompt',
    description: 'Core system prompt - base instructions for all profiles'
  },
  {
    filename: 'scope_section_global.md',
    sectionName: 'scope_section_global',
    description: 'MODE 2: Global Access - for global_qna profile'
  },
  {
    filename: 'scope_section_dashboard.md',
    sectionName: 'scope_section_dashboard',
    description: 'MODE 1: Dashboard-Scoped Access - for dashboard_qna profile'
  },
  {
    filename: 'scope_rules_both_modes.md',
    sectionName: 'scope_rules_both_modes',
    description: 'Common scope rules for both modes'
  },
  {
    filename: 'content_discovery_guidance.md',
    sectionName: 'content_discovery_guidance',
    description: 'Guidance for content discovery intents (listing/browsing)'
  },
  {
    filename: 'search_content_guidance.md',
    sectionName: 'search_content_guidance',
    description: 'Guidance for search-content tool usage'
  },
  {
    filename: 'pulse_planner_guidance.md',
    sectionName: 'pulse_planner_guidance',
    description: 'Guidance for Pulse metric planning (global_qna only)'
  },
  {
    filename: 'pulse_presentation_guidance.md',
    sectionName: 'pulse_presentation_guidance',
    description: 'Guidance for Pulse metric presentation (global_qna only)'
  },
  {
    filename: 'datasource_lookup_upfront_hint.md',
    sectionName: 'datasource_lookup_upfront_hint',
    description: 'Upfront hint for datasource lookup validation'
  },
  {
    filename: 'datasource_query_upfront_hint.md',
    sectionName: 'datasource_query_upfront_hint',
    description: 'Upfront hint for query validation'
  },
  {
    filename: 'workbook_lookup_upfront_hint.md',
    sectionName: 'workbook_lookup_upfront_hint',
    description: 'Upfront hint for workbook lookup validation'
  }
];

/**
 * Auto-seed prompts from MD files if database is empty
 * Safe to call on every startup - only seeds if needed
 */
export async function autoSeedPromptsIfEmpty(pool: Pool): Promise<void> {
  try {
    // Check if prompt_sections table has any data
    const countResult = await pool.query('SELECT COUNT(*) FROM prompt_sections');
    const currentCount = parseInt(countResult.rows[0].count);

    if (currentCount > 0) {
      logger.info(`[AutoSeed] Database already has ${currentCount} prompt sections, skipping seed`);
      return;
    }

    logger.info('[AutoSeed] Database is empty, seeding prompts from MD files...');

    const __filename = fileURLToPath(import.meta.url);
    const __dirname = dirname(__filename);
    const promptsDir = join(__dirname, '../prompts');

    let inserted = 0;

    for (const { filename, sectionName, description } of PROMPT_FILES) {
      const filePath = join(promptsDir, filename);

      try {
        const content = readFileSync(filePath, 'utf-8');

        // Insert section
        const result = await pool.query(`
          INSERT INTO prompt_sections (section_name, description, content, active_version)
          VALUES ($1, $2, $3, 1)
          RETURNING id
        `, [sectionName, description, content]);

        const sectionId = result.rows[0].id;

        // Insert initial version
        await pool.query(`
          INSERT INTO prompt_versions (section_id, version, content, created_by, change_summary)
          VALUES ($1, 1, $2, 'auto-seed', 'Initial seed from MD file on first startup')
        `, [sectionId, content]);

        logger.info(`[AutoSeed] ✓ ${sectionName} (${Math.round(content.length / 1024)}KB)`);
        inserted++;

      } catch (error: any) {
        logger.error(`[AutoSeed] Failed to seed ${filename}:`, error.message);
      }
    }

    logger.info(`[AutoSeed] Successfully seeded ${inserted}/${PROMPT_FILES.length} prompt sections`);

    // Seed prompt variables (documentation for placeholders)
    await seedPromptVariables(pool);

  } catch (error) {
    logger.error('[AutoSeed] Auto-seed failed:', error);
    // Don't throw - allow app to continue with file fallbacks
  }
}

/**
 * Seed prompt variables (placeholders used in prompts)
 */
async function seedPromptVariables(pool: Pool): Promise<void> {
  try {
    const variables = [
      {
        name: 'MAX_VIEW_ROWS_FOR_MODEL',
        value: '[Runtime-replaced from profile settings: default 30]',
        dataType: 'runtime',
        description: 'Maximum number of preview rows sent to LLM for analysis. Value comes from per-profile settings (default: 30). Configure via /settings UI or MAX_VIEW_ROWS_FOR_MODEL env var.'
      },
      {
        name: 'SCOPE_SECTION',
        value: '[Runtime-replaced based on toolProfile: dashboard_qna or global_qna]',
        dataType: 'runtime',
        description: 'Conditional section: Replaced at runtime with scope_section_dashboard or scope_section_global based on toolProfile.'
      },
      {
        name: 'CONTENT_DISCOVERY_GUIDANCE',
        value: '[Runtime-replaced based on intent: content_discovery or unknown]',
        dataType: 'runtime',
        description: 'Conditional section: Replaced at runtime with content_discovery_guidance section when intent is content_discovery or unknown.'
      },
      {
        name: 'SEARCH_CONTENT_GUIDANCE',
        value: '[Runtime-replaced for global_qna profile only]',
        dataType: 'runtime',
        description: 'Conditional section: Replaced at runtime with search_content_guidance section when toolProfile is global_qna.'
      },
      {
        name: 'PULSE_PLANNER_GUIDANCE',
        value: '[Runtime-replaced for pulse_query intent in global_qna]',
        dataType: 'runtime',
        description: 'Conditional section: Replaced at runtime with pulse_planner_guidance section when intent is pulse_query or unknown in global_qna profile.'
      },
      {
        name: 'PULSE_PRESENTATION_GUIDANCE',
        value: '[Runtime-replaced for pulse_query intent in global_qna]',
        dataType: 'runtime',
        description: 'Conditional section: Replaced at runtime with pulse_presentation_guidance section when intent is pulse_query or unknown in global_qna profile.'
      }
    ];

    let inserted = 0;
    let skipped = 0;

    for (const { name, value, dataType, description } of variables) {
      // Check if variable already exists
      const existsResult = await pool.query(
        'SELECT variable_name FROM prompt_variables WHERE variable_name = $1',
        [name]
      );

      if (existsResult.rows.length > 0) {
        skipped++;
        continue;
      }

      await pool.query(
        'INSERT INTO prompt_variables (variable_name, value, data_type, description) VALUES ($1, $2, $3, $4)',
        [name, value, dataType, description]
      );

      inserted++;
    }

    if (inserted > 0) {
      logger.info(`[AutoSeed] ✓ Seeded ${inserted} prompt variables`);
    } else {
      logger.info(`[AutoSeed] Prompt variables already exist (${skipped} skipped)`);
    }

  } catch (error) {
    logger.error('[AutoSeed] Failed to seed prompt variables:', error);
    // Don't throw - this is not critical
  }
}
