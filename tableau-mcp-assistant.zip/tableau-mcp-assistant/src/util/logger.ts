/**
 * Simple logger utility
 */

type LogLevel = 'debug' | 'info' | 'warn' | 'error';

class Logger {
  private logLevel: LogLevel = 'info';

  setLevel(level: LogLevel): void {
    this.logLevel = level;
  }

  private shouldLog(level: LogLevel): boolean {
    const levels: LogLevel[] = ['debug', 'info', 'warn', 'error'];
    return levels.indexOf(level) >= levels.indexOf(this.logLevel);
  }

  debug(message: string, ...args: unknown[]): void {
    if (this.shouldLog('debug')) {
      console.log(`[DEBUG] ${new Date().toISOString()} - ${message}`, ...args);
    }
  }

  info(message: string, ...args: unknown[]): void {
    if (this.shouldLog('info')) {
      console.log(`[INFO] ${new Date().toISOString()} - ${message}`, ...args);
    }
  }

  warn(message: string, ...args: unknown[]): void {
    if (this.shouldLog('warn')) {
      console.warn(`[WARN] ${new Date().toISOString()} - ${message}`, ...args);
    }
  }

  error(message: string, error?: unknown): void {
    if (this.shouldLog('error')) {
      // Safely serialize error to avoid crashes with complex objects
      let errorDetails: string | undefined;
      if (error !== undefined) {
        if (error instanceof Error) {
          errorDetails = `${error.message}\n${error.stack}`;
        } else {
          try {
            errorDetails = JSON.stringify(error, null, 2);
          } catch {
            errorDetails = String(error);
          }
        }
      }
      if (errorDetails) {
        console.error(`[ERROR] ${new Date().toISOString()} - ${message}\n${errorDetails}`);
      } else {
        console.error(`[ERROR] ${new Date().toISOString()} - ${message}`);
      }
    }
  }
}

export const logger = new Logger();
