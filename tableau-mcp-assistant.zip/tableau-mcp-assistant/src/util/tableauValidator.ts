/**
 * Tableau Server Connection Validator
 * Validates PAT credentials, server URL, and connectivity before attempting MCP connections
 */

import { logger } from './logger.js';
import { Settings } from './schema.js';
import jwt from 'jsonwebtoken';
import { v4 as uuidv4 } from 'uuid';

export interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

export class TableauValidator {
  /**
   * Validate all Tableau configuration settings
   */
  static async validateConfiguration(settings: Settings, profileName?: string): Promise<ValidationResult> {
    const errors: string[] = [];
    const warnings: string[] = [];
    const profile = profileName || 'default';

    logger.info(`🔍 Validating Tableau configuration for profile: ${profile}`);

    // 1. Check required fields
    if (!settings.TABLEAU_BASE_URL) {
      errors.push('TABLEAU_BASE_URL is required but not set');
    }

    // Check authentication type (defaults to 'pat' for backward compatibility)
    const authType = settings.AUTHENTICATION_TYPE || 'pat';
    logger.info(`Authentication type: ${authType}`);

    // Validate authentication-specific fields
    if (authType === 'pat') {
      if (!settings.TABLEAU_PAT_NAME) {
        errors.push('TABLEAU_PAT_NAME is required for PAT authentication but not set');
      }

      if (!settings.TABLEAU_PAT_SECRET) {
        errors.push('TABLEAU_PAT_SECRET is required for PAT authentication but not set');
      }
    } else if (authType === 'direct-trust') {
      if (!settings.JWT_SUB_CLAIM) {
        errors.push('JWT_SUB_CLAIM is required for Direct Trust authentication but not set');
      }

      if (!settings.CONNECTED_APP_CLIENT_ID) {
        errors.push('CONNECTED_APP_CLIENT_ID is required for Direct Trust authentication but not set');
      }

      if (!settings.CONNECTED_APP_SECRET_ID) {
        errors.push('CONNECTED_APP_SECRET_ID is required for Direct Trust authentication but not set');
      }

      if (!settings.CONNECTED_APP_SECRET_VALUE) {
        errors.push('CONNECTED_APP_SECRET_VALUE is required for Direct Trust authentication but not set');
      }
    }

    // If basic validation failed, return early
    if (errors.length > 0) {
      logger.error(`❌ Configuration validation failed for profile ${profile}:`, errors);
      return { valid: false, errors, warnings };
    }

    // 2. Validate URL format
    const urlValidation = this.validateServerUrl(settings.TABLEAU_BASE_URL!);
    if (!urlValidation.valid) {
      errors.push(...urlValidation.errors);
    }
    warnings.push(...urlValidation.warnings);

    // 3. Validate site content URL format (if provided)
    if (settings.TABLEAU_SITE_CONTENT_URL) {
      const siteValidation = this.validateSiteContentUrl(settings.TABLEAU_SITE_CONTENT_URL);
      if (!siteValidation.valid) {
        errors.push(...siteValidation.errors);
      }
      warnings.push(...siteValidation.warnings);
    }

    // If URL format validation failed, return early (no point testing connectivity)
    if (errors.length > 0) {
      logger.error(`❌ URL validation failed for profile ${profile}:`, errors);
      return { valid: false, errors, warnings };
    }

    // 4. Test server connectivity
    const connectivityResult = await this.testServerConnectivity(settings.TABLEAU_BASE_URL!);
    if (!connectivityResult.valid) {
      errors.push(...connectivityResult.errors);
    }
    warnings.push(...connectivityResult.warnings);

    // If connectivity test failed, return early (no point testing auth)
    if (errors.length > 0) {
      logger.error(`❌ Server connectivity test failed for profile ${profile}:`, errors);
      return { valid: false, errors, warnings };
    }

    // 5. Test authentication (PAT or Direct Trust)
    if (authType === 'pat') {
      const authResult = await this.testPatAuthentication(
        settings.TABLEAU_BASE_URL!,
        settings.TABLEAU_PAT_NAME!,
        settings.TABLEAU_PAT_SECRET!,
        settings.TABLEAU_SITE_CONTENT_URL || ''
      );

      errors.push(...authResult.errors);
      warnings.push(...authResult.warnings);
    } else if (authType === 'direct-trust') {
      // Test Direct Trust JWT authentication
      const authResult = await this.testDirectTrustAuthentication(
        settings.TABLEAU_BASE_URL!,
        settings.JWT_SUB_CLAIM!,
        settings.CONNECTED_APP_CLIENT_ID!,
        settings.CONNECTED_APP_SECRET_ID!,
        settings.CONNECTED_APP_SECRET_VALUE!,
        settings.TABLEAU_SITE_CONTENT_URL || ''
      );

      errors.push(...authResult.errors);
      warnings.push(...authResult.warnings);
    }

    const valid = errors.length === 0;

    if (valid) {
      logger.info(`✅ Tableau configuration validated successfully for profile: ${profile}`);
      if (warnings.length > 0) {
        logger.warn(`⚠️  ${warnings.length} warning(s) for profile ${profile}:`, warnings);
      }
    } else {
      logger.error(`❌ Tableau configuration validation failed for profile ${profile}:`, errors);
    }

    return { valid, errors, warnings };
  }

  /**
   * Validate Tableau Server URL format
   */
  private static validateServerUrl(serverUrl: string): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    try {
      const url = new URL(serverUrl);

      // Check protocol
      if (!['http:', 'https:'].includes(url.protocol)) {
        errors.push(`Invalid protocol "${url.protocol}". Server URL must use http:// or https://`);
      }

      // Warn if using http instead of https
      if (url.protocol === 'http:') {
        warnings.push('Using http:// instead of https:// is not recommended for production');
      }

      // Check if hostname is present
      if (!url.hostname || url.hostname === 'localhost' || url.hostname === '127.0.0.1') {
        warnings.push('Server URL points to localhost. Ensure this is correct.');
      }

      // Warn if URL contains path
      if (url.pathname !== '/') {
        warnings.push(`Server URL contains path "${url.pathname}". Base URL should typically not include a path.`);
      }

    } catch (error) {
      errors.push(`Invalid Server URL format: ${serverUrl}. Must be a valid URL (e.g., https://tableau.example.com)`);
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
    };
  }

  /**
   * Validate Tableau Site Content URL format
   */
  private static validateSiteContentUrl(siteUrl: string): ValidationResult {
    const errors: string[] = [];
    const warnings: string[] = [];

    // Site content URL should be a simple string without special characters
    if (siteUrl.includes('/') || siteUrl.includes('\\')) {
      errors.push('Site Content URL should not contain slashes. Use only the site name (e.g., "mysite")');
    }

    if (siteUrl.includes('http://') || siteUrl.includes('https://')) {
      errors.push('Site Content URL should not be a full URL. Use only the site name (e.g., "mysite")');
    }

    if (siteUrl.length > 0 && siteUrl.length < 2) {
      warnings.push('Site Content URL is very short. Verify this is correct.');
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
    };
  }

  /**
   * Test connectivity to Tableau Server
   */
  private static async testServerConnectivity(serverUrl: string, timeoutMs: number = 10000): Promise<ValidationResult> {
    const errors: string[] = [];
    const warnings: string[] = [];

    logger.info(`🔌 Testing connectivity to Tableau Server: ${serverUrl}`);

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMs);

      try {
        // Try to fetch the server root or a known endpoint
        const response = await fetch(serverUrl, {
          method: 'HEAD',
          signal: controller.signal,
          redirect: 'manual', // Don't follow redirects
        });

        clearTimeout(timeout);

        // Any response (even 404) means the server is reachable
        logger.info(`✅ Server is reachable. HTTP status: ${response.status}`);

        // Check for common misconfigurations
        if (response.status === 404) {
          warnings.push('Server responded with 404. This may be normal, but verify the URL is correct.');
        }

      } catch (fetchError: any) {
        clearTimeout(timeout);

        if (fetchError.name === 'AbortError') {
          errors.push(`Connection timeout after ${timeoutMs}ms. Server may be down or unreachable.`);
        } else if (fetchError.code === 'ENOTFOUND' || fetchError.cause?.code === 'ENOTFOUND') {
          errors.push(`Server not found. DNS lookup failed for ${serverUrl}. Check the server URL.`);
        } else if (fetchError.code === 'ECONNREFUSED' || fetchError.cause?.code === 'ECONNREFUSED') {
          errors.push(`Connection refused. Server is not accepting connections at ${serverUrl}.`);
        } else if (fetchError.code === 'ECONNRESET' || fetchError.cause?.code === 'ECONNRESET') {
          errors.push(`Connection reset by server. Server may be experiencing issues.`);
        } else if (fetchError.cause?.code === 'UNABLE_TO_VERIFY_LEAF_SIGNATURE') {
          warnings.push('SSL certificate verification failed. This may be a self-signed certificate.');
        } else {
          errors.push(`Network error: ${fetchError.message}`);
        }
      }

    } catch (error: any) {
      errors.push(`Unexpected error testing connectivity: ${error.message}`);
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
    };
  }

  /**
   * Get the REST API version from Tableau Server
   */
  private static async getApiVersion(
    serverUrl: string,
    timeoutMs: number = 10000
  ): Promise<{ version: string | null; error: string | null }> {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMs);

      try {
        const serverInfoUrl = `${serverUrl}/api/serverinfo`;
        logger.debug(`Fetching API version from: ${serverInfoUrl}`);

        const response = await fetch(serverInfoUrl, {
          method: 'GET',
          signal: controller.signal,
        });

        clearTimeout(timeout);

        if (response.ok) {
          const text = await response.text();
          // Parse XML to get the REST API version
          // Example: <serverInfo><restApiVersion>3.21</restApiVersion>...</serverInfo>
          const versionMatch = text.match(/<restApiVersion>([^<]+)<\/restApiVersion>/);
          if (versionMatch && versionMatch[1]) {
            logger.info(`✅ Detected REST API version: ${versionMatch[1]}`);
            return { version: versionMatch[1], error: null };
          } else {
            logger.warn(`⚠️  Could not parse API version from serverinfo, using default 3.21`);
            return { version: '3.21', error: null }; // Fallback to 3.21
          }
        } else {
          const errorMsg = `Failed to fetch serverinfo (${response.status})`;
          logger.warn(`⚠️  ${errorMsg}, using default API version 3.21`);
          return { version: '3.21', error: null }; // Fallback to 3.21
        }
      } catch (fetchError: any) {
        clearTimeout(timeout);
        logger.warn(`⚠️  Error fetching serverinfo: ${fetchError.message}, using default API version 3.21`);
        return { version: '3.21', error: null }; // Fallback to 3.21
      }
    } catch (error: any) {
      logger.warn(`⚠️  Unexpected error getting API version: ${error.message}, using default API version 3.21`);
      return { version: '3.21', error: null }; // Fallback to 3.21
    }
  }

  /**
   * Test PAT authentication with Tableau Server
   * Makes an actual REST API call to verify credentials
   */
  private static async testPatAuthentication(
    serverUrl: string,
    patName: string,
    patSecret: string,
    siteContentUrl: string,
    timeoutMs: number = 10000
  ): Promise<ValidationResult> {
    const errors: string[] = [];
    const warnings: string[] = [];

    logger.info(`🔐 Testing PAT authentication with Tableau Server...`);

    try {
      // First, get the API version from serverinfo
      const { version: apiVersion } = await this.getApiVersion(serverUrl, timeoutMs);

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMs);

      try {
        // Construct the Tableau REST API sign-in endpoint
        // https://help.tableau.com/current/api/rest_api/en-us/REST/rest_api_concepts_auth.htm#signin-pat
        // The site is specified in the request body, NOT in the URL path
        const signInUrl = `${serverUrl}/api/${apiVersion}/auth/signin`;

        logger.debug(`Attempting authentication at: ${signInUrl}`);

        // Use XML format for authentication request (Tableau Cloud requires XML)
        const requestBody = `<tsRequest>
  <credentials personalAccessTokenName="${patName}"
               personalAccessTokenSecret="${patSecret}">
    <site contentUrl="${siteContentUrl || ''}" />
  </credentials>
</tsRequest>`;

        const response = await fetch(signInUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/xml',
            'Accept': 'application/json',
          },
          body: requestBody,
          signal: controller.signal,
        });

        clearTimeout(timeout);

        if (response.ok) {
          const data: any = await response.json();
          logger.info(`✅ PAT authentication successful!`);

          // Log useful information about the authenticated user
          if (data.credentials?.user?.name) {
            logger.info(`   Authenticated as: ${data.credentials.user.name}`);
          }
          if (data.credentials?.site?.contentUrl !== undefined) {
            logger.info(`   Site: ${data.credentials.site.contentUrl || '(default)'}`);
          }

        } else {
          const responseText = await response.text();
          let errorDetail = responseText;

          try {
            const errorData = JSON.parse(responseText);
            if (errorData.error?.summary) {
              errorDetail = errorData.error.summary;
            }
            // Log the full error response for debugging
            logger.debug(`Authentication error response (${response.status}): ${JSON.stringify(errorData, null, 2)}`);
          } catch {
            // Response wasn't JSON, use text as-is
            logger.debug(`Authentication error response (${response.status}) - Raw text: ${responseText.substring(0, 500)}`);
          }

          if (response.status === 401) {
            errors.push(`Authentication failed (401 Unauthorized): Invalid PAT name or PAT secret. Error: ${errorDetail}`);
          } else if (response.status === 404) {
            // Enhanced 404 error message with debugging info
            logger.error(`❌ 404 Authentication Endpoint Not Found - Debugging info:`);
            logger.error(`   URL attempted: ${signInUrl}`);
            logger.error(`   Server: ${serverUrl}`);
            logger.error(`   API Version: ${apiVersion}`);
            logger.error(`   Site: "${siteContentUrl || '(default site)'}"`);
            logger.error(`   PAT Name: ${patName}`);
            logger.error(`   Response: ${errorDetail}`);
            errors.push(`Authentication endpoint not found (404). The site "${siteContentUrl || 'default'}" may not exist, the Server URL may be incorrect, or the API version may be wrong. Check logs for details.`);
          } else if (response.status === 400) {
            errors.push(`Bad request (400): ${errorDetail}. Check PAT name, PAT secret, and site content URL.`);
          } else if (response.status === 403) {
            errors.push(`Forbidden (403): PAT may be expired or lack necessary permissions. Error: ${errorDetail}`);
          } else if (response.status === 503 || response.status === 502) {
            errors.push(`Server unavailable (${response.status}): Tableau Server may be down or restarting. Error: ${errorDetail}`);
          } else {
            errors.push(`Authentication failed with status ${response.status}: ${errorDetail}`);
          }
        }

      } catch (fetchError: any) {
        clearTimeout(timeout);

        if (fetchError.name === 'AbortError') {
          errors.push(`Authentication timeout after ${timeoutMs}ms. Server may be slow or unresponsive.`);
        } else {
          errors.push(`Network error during authentication: ${fetchError.message}`);
        }
      }

    } catch (error: any) {
      errors.push(`Unexpected error testing authentication: ${error.message}`);
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
    };
  }

  /**
   * Test Direct Trust (JWT) authentication with Tableau Server
   * Generates a JWT and tests it against the REST API
   */
  private static async testDirectTrustAuthentication(
    serverUrl: string,
    jwtSubClaim: string,
    connectedAppClientId: string,
    connectedAppSecretId: string,
    connectedAppSecretValue: string,
    siteContentUrl: string,
    timeoutMs: number = 10000
  ): Promise<ValidationResult> {
    const errors: string[] = [];
    const warnings: string[] = [];

    logger.info(`🔐 Testing Direct Trust (JWT) authentication with Tableau Server...`);

    try {
      // First, get the API version from serverinfo
      const { version: apiVersion } = await this.getApiVersion(serverUrl, timeoutMs);

      // Generate JWT token
      logger.debug('Generating JWT token for Direct Trust authentication...');

      const now = Math.floor(Date.now() / 1000);
      const jwtPayload = {
        iss: connectedAppClientId,
        sub: jwtSubClaim,
        aud: 'tableau',
        exp: now + 300, // Token expires in 5 minutes
        jti: uuidv4(),
        scp: ['tableau:content:read', 'tableau:workbooks:read', 'tableau:views:read', 'tableau:datasources:read']
      };

      let token: string;
      try {
        // Sign JWT with the Connected App secret
        token = jwt.sign(jwtPayload, connectedAppSecretValue, {
          algorithm: 'HS256',
          keyid: connectedAppSecretId
        });
        logger.debug('JWT token generated successfully');
      } catch (jwtError: any) {
        errors.push(`Failed to generate JWT token: ${jwtError.message}. Check that CONNECTED_APP_SECRET_VALUE is valid.`);
        return { valid: false, errors, warnings };
      }

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), timeoutMs);

      try {
        // Construct the Tableau REST API sign-in endpoint for JWT
        // https://help.tableau.com/current/api/rest_api/en-us/REST/rest_api_concepts_auth.htm#signin-jwt
        const signInUrl = `${serverUrl}/api/${apiVersion}/auth/signin`;

        logger.debug(`Attempting JWT authentication at: ${signInUrl}`);

        // Use JSON format for JWT authentication request
        const requestBody = JSON.stringify({
          credentials: {
            jwt: token,
            site: {
              contentUrl: siteContentUrl || ''
            }
          }
        });

        const response = await fetch(signInUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          },
          body: requestBody,
          signal: controller.signal,
        });

        clearTimeout(timeout);

        if (response.ok) {
          const data: any = await response.json();
          logger.info(`✅ Direct Trust (JWT) authentication successful!`);

          // Log useful information about the authenticated user
          if (data.credentials?.user?.name) {
            logger.info(`   Authenticated as: ${data.credentials.user.name}`);
          }
          if (data.credentials?.site?.contentUrl !== undefined) {
            logger.info(`   Site: ${data.credentials.site.contentUrl || '(default)'}`);
          }

        } else {
          const responseText = await response.text();
          let errorDetail = responseText;

          try {
            const errorData = JSON.parse(responseText);
            if (errorData.error?.summary) {
              errorDetail = errorData.error.summary;
            }
            if (errorData.error?.detail) {
              errorDetail += ` - ${errorData.error.detail}`;
            }
            // Log the full error response for debugging
            logger.debug(`JWT authentication error response (${response.status}): ${JSON.stringify(errorData, null, 2)}`);
          } catch {
            // Response wasn't JSON, use text as-is
            logger.debug(`JWT authentication error response (${response.status}) - Raw text: ${responseText.substring(0, 500)}`);
          }

          if (response.status === 401) {
            errors.push(`JWT authentication failed (401 Unauthorized): Invalid Connected App credentials or JWT claims. Error: ${errorDetail}`);
            errors.push(`Please verify: 1) CONNECTED_APP_CLIENT_ID matches your Connected App, 2) CONNECTED_APP_SECRET_ID and SECRET_VALUE are correct, 3) JWT_SUB_CLAIM matches a valid Tableau user`);
          } else if (response.status === 404) {
            logger.error(`❌ 404 JWT Authentication Endpoint Not Found - Debugging info:`);
            logger.error(`   URL attempted: ${signInUrl}`);
            logger.error(`   Server: ${serverUrl}`);
            logger.error(`   API Version: ${apiVersion}`);
            logger.error(`   Site: "${siteContentUrl || '(default site)'}"`);
            logger.error(`   JWT Subject: ${jwtSubClaim}`);
            logger.error(`   Client ID: ${connectedAppClientId}`);
            logger.error(`   Response: ${errorDetail}`);
            errors.push(`JWT authentication endpoint not found (404). The site "${siteContentUrl || 'default'}" may not exist, the Server URL may be incorrect, or the API version may be wrong. Check logs for details.`);
          } else if (response.status === 400) {
            errors.push(`Bad request (400): ${errorDetail}. Check JWT_SUB_CLAIM (must be a valid Tableau username), CONNECTED_APP_CLIENT_ID, and site content URL.`);
          } else if (response.status === 403) {
            errors.push(`Forbidden (403): Connected App may not have necessary permissions or is not enabled for Direct Trust. Error: ${errorDetail}`);
            errors.push(`Ensure your Connected App has "Direct Trust" enabled in Tableau Server settings.`);
          } else if (response.status === 503 || response.status === 502) {
            errors.push(`Server unavailable (${response.status}): Tableau Server may be down or restarting. Error: ${errorDetail}`);
          } else {
            errors.push(`JWT authentication failed with status ${response.status}: ${errorDetail}`);
          }
        }

      } catch (fetchError: any) {
        clearTimeout(timeout);

        if (fetchError.name === 'AbortError') {
          errors.push(`JWT authentication timeout after ${timeoutMs}ms. Server may be slow or unresponsive.`);
        } else {
          errors.push(`Network error during JWT authentication: ${fetchError.message}`);
        }
      }

    } catch (error: any) {
      errors.push(`Unexpected error testing JWT authentication: ${error.message}`);
    }

    return {
      valid: errors.length === 0,
      errors,
      warnings,
    };
  }

  /**
   * Format validation results as a user-friendly error message
   */
  static formatValidationErrors(result: ValidationResult, profileName?: string): string {
    const profile = profileName ? ` for profile "${profileName}"` : '';
    const lines: string[] = [`❌ Tableau configuration validation failed${profile}:\n`];

    if (result.errors.length > 0) {
      lines.push('Errors:');
      result.errors.forEach((error, i) => {
        lines.push(`  ${i + 1}. ${error}`);
      });
    }

    if (result.warnings.length > 0) {
      lines.push('\nWarnings:');
      result.warnings.forEach((warning, i) => {
        lines.push(`  ${i + 1}. ${warning}`);
      });
    }

    lines.push('\n💡 Tips:');
    lines.push('  • Verify your TABLEAU_BASE_URL (e.g., https://tableau.example.com)');
    lines.push('  • For PAT authentication: Check that TABLEAU_PAT_NAME and TABLEAU_PAT_SECRET are correct');
    lines.push('  • For Direct Trust: Verify JWT_SUB_CLAIM, CONNECTED_APP_CLIENT_ID, and Connected App secrets');
    lines.push('  • Ensure the Tableau Server is running and accessible');
    lines.push('  • Verify TABLEAU_SITE_CONTENT_URL if using a non-default site');

    return lines.join('\n');
  }
}
