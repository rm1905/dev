/**
 * PromptManager - Manages system prompts with caching and version control
 *
 * Features:
 * - Load prompts from PostgreSQL database
 * - Runtime variable interpolation ({{VAR_NAME}})
 * - 5-minute LRU cache for performance
 * - Version control and rollback support
 * - Format preservation (exact whitespace/newlines)
 */

import { Pool } from 'pg';
import { logger } from './logger.js';

interface CacheEntry {
  value: string;
  timestamp: number;
}

interface PromptSection {
  id: string;
  section_name: string;
  description?: string;
  content: string;
  active_version: number;
  conditional_rule?: any;
  created_at: Date;
  updated_at: Date;
}

interface PromptVersion {
  id: string;
  section_id: string;
  version: number;
  content: string;
  created_by?: string;
  change_summary?: string;
  created_at: Date;
}

interface PromptVariable {
  variable_name: string;
  value: string;
  data_type: string;
  description?: string;
}

export class PromptManager {
  private pool: Pool | null = null;
  private cache: Map<string, CacheEntry>;
  private cacheExpiry: number; // milliseconds
  private variables: Map<string, any>;
  private initialized: boolean = false;

  constructor() {
    // Initialize connection pool if DATABASE_URL is available
    if (process.env.DATABASE_URL) {
      this.pool = new Pool({
        connectionString: process.env.DATABASE_URL,
        ssl: process.env.NODE_ENV === 'production' ? {
          rejectUnauthorized: false
        } : false,
      });
      logger.info('[PromptManager] Database connection pool initialized');
    } else {
      logger.warn('[PromptManager] DATABASE_URL not set. Prompt management disabled.');
    }

    this.cache = new Map();
    this.cacheExpiry = 5 * 60 * 1000; // 5 minutes
    this.variables = new Map();
  }

  /**
   * Initialize PromptManager - must be called before use
   * This ensures database tables exist (safe to call multiple times)
   */
  async initialize(): Promise<void> {
    if (this.initialized || !this.pool) {
      return;
    }

    try {
      // Create prompt management tables if they don't exist
      await this.pool.query(`
        -- Create prompt_sections table to store active prompt content
        CREATE TABLE IF NOT EXISTS prompt_sections (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          section_name VARCHAR(100) UNIQUE NOT NULL,
          description TEXT,
          content TEXT NOT NULL,
          active_version INT NOT NULL DEFAULT 1,
          conditional_rule JSONB,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- Create prompt_versions table for version history and rollback
        CREATE TABLE IF NOT EXISTS prompt_versions (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          section_id UUID NOT NULL REFERENCES prompt_sections(id) ON DELETE CASCADE,
          version INT NOT NULL,
          content TEXT NOT NULL,
          created_by VARCHAR(100),
          change_summary TEXT,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          UNIQUE(section_id, version)
        );

        -- Create prompt_variables table for runtime variable interpolation
        CREATE TABLE IF NOT EXISTS prompt_variables (
          id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
          variable_name VARCHAR(100) UNIQUE NOT NULL,
          value TEXT NOT NULL,
          data_type VARCHAR(20) DEFAULT 'string',
          description TEXT,
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        );

        -- Create trigger to auto-increment version number when updating prompt_sections
        CREATE OR REPLACE FUNCTION increment_prompt_version()
        RETURNS TRIGGER AS $$
        BEGIN
          NEW.active_version := OLD.active_version + 1;
          NEW.updated_at := NOW();
          RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;

        DROP TRIGGER IF EXISTS prompt_version_increment ON prompt_sections;
        CREATE TRIGGER prompt_version_increment
          BEFORE UPDATE ON prompt_sections
          FOR EACH ROW
          WHEN (OLD.content IS DISTINCT FROM NEW.content)
          EXECUTE FUNCTION increment_prompt_version();

        -- Create indexes for performance
        CREATE INDEX IF NOT EXISTS idx_prompt_versions_section_id ON prompt_versions(section_id);
        CREATE INDEX IF NOT EXISTS idx_prompt_versions_created_at ON prompt_versions(created_at DESC);

        -- Note: Runtime variables (MAX_VIEW_ROWS_FOR_MODEL, SCOPE_SECTION, etc.)
        -- are NOT stored in this table. They are replaced at runtime by buildSystemPrompt()
        -- with values from config/profile settings.
        --
        -- This table is for variables that are managed via the Prompt Management UI
        -- and have static values that don't depend on session/profile configuration.
      `);

      logger.info('[PromptManager] Database schema initialized successfully');

      // Load variables into memory for fast interpolation
      await this.loadVariables();

      this.initialized = true;
      logger.info('[PromptManager] Initialized successfully');
    } catch (error) {
      logger.error('[PromptManager] Failed to initialize', error);
      throw error;
    }
  }

  /**
   * Load variables from database into memory
   */
  private async loadVariables(): Promise<void> {
    if (!this.pool) return;

    try {
      const result = await this.pool.query(
        'SELECT variable_name, value, data_type FROM prompt_variables'
      );

      this.variables.clear();
      for (const row of result.rows) {
        const { variable_name, value, data_type } = row;

        // Skip 'runtime' variables - they should be replaced by buildSystemPrompt() at runtime
        // with values from profile settings, not from database
        if (data_type === 'runtime') {
          logger.info(`[PromptManager] Skipping runtime variable: ${variable_name} (will be replaced at runtime)`);
          continue;
        }

        // Convert value to appropriate type
        let typedValue: any = value;
        if (data_type === 'number') {
          typedValue = parseFloat(value);
        } else if (data_type === 'boolean') {
          typedValue = value.toLowerCase() === 'true';
        } else if (data_type === 'json') {
          try {
            typedValue = JSON.parse(value);
          } catch (e) {
            logger.warn(`[PromptManager] Failed to parse JSON variable ${variable_name}`);
          }
        }

        this.variables.set(variable_name, typedValue);
      }

      logger.info(`[PromptManager] Loaded ${this.variables.size} variables`);
    } catch (error) {
      logger.error('[PromptManager] Failed to load variables', error);
      throw error;
    }
  }

  /**
   * Get a prompt section by name with caching
   * Returns interpolated prompt with variables replaced
   */
  async getSection(sectionName: string, skipCache: boolean = false): Promise<string> {
    if (!this.pool) {
      throw new Error('[PromptManager] Database not available');
    }

    await this.initialize();

    const cacheKey = `section:${sectionName}`;

    // Check cache first (unless skipCache is true)
    if (!skipCache) {
      const cached = this.getCached(cacheKey);
      if (cached) {
        return cached;
      }
    }

    try {
      // Load section from database
      const section = await this.loadSectionFromDb(sectionName);

      // Reload variables to get latest values
      await this.loadVariables();

      // Interpolate variables
      const interpolated = this.interpolate(section.content, sectionName);

      // Cache the interpolated result
      this.setCache(cacheKey, interpolated);

      return interpolated;
    } catch (error) {
      logger.error(`[PromptManager] Failed to get section "${sectionName}"`, error);
      throw error;
    }
  }

  /**
   * Load a section from database without interpolation
   */
  private async loadSectionFromDb(sectionName: string): Promise<PromptSection> {
    if (!this.pool) {
      throw new Error('[PromptManager] Database not available');
    }

    const result = await this.pool.query(
      'SELECT * FROM prompt_sections WHERE section_name = $1',
      [sectionName]
    );

    if (result.rows.length === 0) {
      throw new Error(`[PromptManager] Section "${sectionName}" not found`);
    }

    return result.rows[0];
  }

  /**
   * Get raw section content without variable interpolation
   * Useful for editing in UI
   */
  async getSectionRaw(sectionName: string): Promise<PromptSection> {
    if (!this.pool) {
      throw new Error('[PromptManager] Database not available');
    }

    await this.initialize();

    return await this.loadSectionFromDb(sectionName);
  }

  /**
   * Update a section's content
   * Creates a new version in prompt_versions table
   */
  async updateSection(
    sectionName: string,
    newContent: string,
    createdBy: string = 'system',
    changeSummary: string = ''
  ): Promise<number> {
    if (!this.pool) {
      throw new Error('[PromptManager] Database not available');
    }

    await this.initialize();

    // Reload variables to ensure validation uses latest values
    await this.loadVariables();

    // Validate variable references before saving
    await this.validateVariableReferences(newContent, sectionName);

    const client = await this.pool.connect();

    try {
      await client.query('BEGIN');

      // Get current section
      const sectionResult = await client.query(
        'SELECT id, active_version FROM prompt_sections WHERE section_name = $1',
        [sectionName]
      );

      if (sectionResult.rows.length === 0) {
        throw new Error(`Section "${sectionName}" not found`);
      }

      const { id: sectionId, active_version: currentVersion } = sectionResult.rows[0];
      const newVersion = currentVersion + 1;

      // Update section content and explicitly set new version
      // Note: We explicitly increment version here instead of relying on trigger
      await client.query(
        'UPDATE prompt_sections SET content = $1, active_version = $2, updated_at = NOW() WHERE section_name = $3',
        [newContent, newVersion, sectionName]
      );

      // Create version record
      await client.query(
        `INSERT INTO prompt_versions (section_id, version, content, created_by, change_summary)
         VALUES ($1, $2, $3, $4, $5)`,
        [sectionId, newVersion, newContent, createdBy, changeSummary]
      );

      await client.query('COMMIT');

      // Invalidate cache for this section
      this.invalidateCache(sectionName);

      logger.info(`[PromptManager] Updated section "${sectionName}" to version ${newVersion}`);

      return newVersion;
    } catch (error) {
      await client.query('ROLLBACK');
      logger.error(`[PromptManager] Failed to update section "${sectionName}"`, error);
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Get version history for a section
   */
  async getVersionHistory(sectionName: string, limit: number = 10): Promise<PromptVersion[]> {
    if (!this.pool) {
      throw new Error('[PromptManager] Database not available');
    }

    await this.initialize();

    try {
      const result = await this.pool.query(
        `SELECT pv.*
         FROM prompt_versions pv
         JOIN prompt_sections ps ON pv.section_id = ps.id
         WHERE ps.section_name = $1
         ORDER BY pv.version DESC
         LIMIT $2`,
        [sectionName, limit]
      );

      return result.rows;
    } catch (error) {
      logger.error(`[PromptManager] Failed to get version history for "${sectionName}"`, error);
      throw error;
    }
  }

  /**
   * Rollback a section to a previous version
   */
  async rollbackToVersion(
    sectionName: string,
    targetVersion: number,
    createdBy: string = 'system'
  ): Promise<void> {
    if (!this.pool) {
      throw new Error('[PromptManager] Database not available');
    }

    await this.initialize();

    const client = await this.pool.connect();

    try {
      await client.query('BEGIN');

      // Get the content from target version
      const versionResult = await client.query(
        `SELECT pv.content
         FROM prompt_versions pv
         JOIN prompt_sections ps ON pv.section_id = ps.id
         WHERE ps.section_name = $1 AND pv.version = $2`,
        [sectionName, targetVersion]
      );

      if (versionResult.rows.length === 0) {
        throw new Error(`Version ${targetVersion} not found for section "${sectionName}"`);
      }

      const targetContent = versionResult.rows[0].content;

      // Update section with content from target version
      await this.updateSection(
        sectionName,
        targetContent,
        createdBy,
        `Rolled back to version ${targetVersion}`
      );

      await client.query('COMMIT');

      logger.info(`[PromptManager] Rolled back "${sectionName}" to version ${targetVersion}`);
    } catch (error) {
      await client.query('ROLLBACK');
      logger.error(`[PromptManager] Failed to rollback "${sectionName}" to version ${targetVersion}`, error);
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Delete a specific version (v379)
   * Cannot delete the currently active version
   */
  async deleteVersion(
    sectionName: string,
    versionNumber: number
  ): Promise<void> {
    if (!this.pool) {
      throw new Error('[PromptManager] Database not available');
    }

    await this.initialize();

    const client = await this.pool.connect();

    try {
      await client.query('BEGIN');

      // Check if this version is the active version
      const sectionResult = await client.query(
        `SELECT id, active_version
         FROM prompt_sections
         WHERE section_name = $1`,
        [sectionName]
      );

      if (sectionResult.rows.length === 0) {
        throw new Error(`Section "${sectionName}" not found`);
      }

      const { id: sectionId, active_version } = sectionResult.rows[0];

      if (active_version === versionNumber) {
        throw new Error(`Cannot delete active version ${versionNumber}. Please activate a different version first.`);
      }

      // Check if version exists
      const versionResult = await client.query(
        `SELECT id FROM prompt_versions
         WHERE section_id = $1 AND version = $2`,
        [sectionId, versionNumber]
      );

      if (versionResult.rows.length === 0) {
        throw new Error(`Version ${versionNumber} not found for section "${sectionName}"`);
      }

      // Delete the version
      await client.query(
        `DELETE FROM prompt_versions
         WHERE section_id = $1 AND version = $2`,
        [sectionId, versionNumber]
      );

      await client.query('COMMIT');

      logger.info(`[PromptManager] Deleted version ${versionNumber} of "${sectionName}"`);
    } catch (error) {
      await client.query('ROLLBACK');
      logger.error(`[PromptManager] Failed to delete version ${versionNumber} of "${sectionName}"`, error);
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Get all available sections
   * Returns content_length instead of full content for performance
   */
  async listSections(): Promise<Array<Omit<PromptSection, 'content'> & { content_length: number }>> {
    if (!this.pool) {
      throw new Error('[PromptManager] Database not available');
    }

    await this.initialize();

    try {
      const result = await this.pool.query(
        'SELECT id, section_name, description, active_version, created_at, updated_at, LENGTH(content) as content_length FROM prompt_sections ORDER BY section_name'
      );

      return result.rows;
    } catch (error) {
      logger.error('[PromptManager] Failed to list sections', error);
      throw error;
    }
  }

  /**
   * Get all variables
   */
  async getVariables(): Promise<PromptVariable[]> {
    if (!this.pool) {
      throw new Error('[PromptManager] Database not available');
    }

    await this.initialize();

    try {
      const result = await this.pool.query(
        'SELECT variable_name, value, data_type, description FROM prompt_variables ORDER BY variable_name'
      );

      return result.rows;
    } catch (error) {
      logger.error('[PromptManager] Failed to get variables', error);
      throw error;
    }
  }

  /**
   * Interpolate variables in template
   * Supports both {{VAR}} and ${VAR} syntax
   */
  private interpolate(template: string, sectionName: string): string {
    // List of runtime variables that should be replaced by buildSystemPrompt() at runtime
    const runtimeVariables = new Set([
      'MAX_VIEW_ROWS_FOR_MODEL',
      'SCOPE_SECTION',
      'CONTENT_DISCOVERY_GUIDANCE',
      'SEARCH_CONTENT_GUIDANCE',
      'PULSE_PLANNER_GUIDANCE',
      'PULSE_PRESENTATION_GUIDANCE'
    ]);

    return template.replace(/\{\{(\w+)\}\}|\$\{(\w+)\}/g, (match, p1, p2) => {
      const varName = p1 || p2;

      // Skip runtime variables - they will be replaced by buildSystemPrompt()
      if (runtimeVariables.has(varName)) {
        return match; // Keep placeholder for runtime replacement
      }

      if (!this.variables.has(varName)) {
        logger.warn(`[PromptManager] Variable "${varName}" not defined in section "${sectionName}"`);
        return match; // Keep placeholder if variable not found
      }

      return String(this.variables.get(varName));
    });
  }

  /**
   * Validate that all variable references in content exist
   * Allows both simple variables (from prompt_variables) and section references (from prompt_sections)
   */
  private async validateVariableReferences(content: string, sectionName: string): Promise<void> {
    const variableRefs = content.match(/\{\{(\w+)\}\}|\$\{(\w+)\}/g) || [];
    const undefinedVars: string[] = [];

    // Runtime variables that are replaced by buildSystemPrompt() with values from config
    // These are NOT stored in prompt_variables table
    const runtimeVariables = new Set([
      'MAX_VIEW_ROWS_FOR_MODEL',
      'SCOPE_SECTION',
      'CONTENT_DISCOVERY_GUIDANCE',
      'SEARCH_CONTENT_GUIDANCE',
      'PULSE_PLANNER_GUIDANCE',
      'PULSE_PRESENTATION_GUIDANCE'
    ]);

    for (const ref of variableRefs) {
      const varName = ref.replace(/^\{\{|\}\}$|\$\{|\}$/g, '');

      // Check if it's a variable OR a runtime variable (replaced later by buildSystemPrompt)
      if (!this.variables.has(varName) && !runtimeVariables.has(varName)) {
        undefinedVars.push(varName);
      }
    }

    if (undefinedVars.length > 0) {
      throw new Error(
        `[PromptManager] Undefined variables in section "${sectionName}": ${undefinedVars.join(', ')}`
      );
    }
  }

  /**
   * Get value from cache if not expired
   */
  private getCached(key: string): string | null {
    const entry = this.cache.get(key);
    if (!entry) return null;

    const age = Date.now() - entry.timestamp;
    if (age > this.cacheExpiry) {
      this.cache.delete(key);
      return null;
    }

    return entry.value;
  }

  /**
   * Set value in cache
   */
  private setCache(key: string, value: string): void {
    this.cache.set(key, {
      value,
      timestamp: Date.now(),
    });
  }

  /**
   * Invalidate cache for a specific section or all cache
   */
  invalidateCache(sectionName?: string): void {
    if (sectionName) {
      const cacheKey = `section:${sectionName}`;
      this.cache.delete(cacheKey);
      logger.info(`[PromptManager] Cache invalidated for section "${sectionName}"`);
    } else {
      this.cache.clear();
      logger.info('[PromptManager] All cache invalidated');
    }
  }

  /**
   * Get cache statistics
   */
  getCacheStats(): { size: number; keys: string[] } {
    return {
      size: this.cache.size,
      keys: Array.from(this.cache.keys()),
    };
  }

  /**
   * Check if PromptManager is available
   */
  isAvailable(): boolean {
    return this.pool !== null && this.initialized;
  }

  /**
   * Close database connection
   */
  async close(): Promise<void> {
    if (this.pool) {
      await this.pool.end();
      logger.info('[PromptManager] Database connection closed');
    }
  }
}

// Export singleton instance
export const promptManager = new PromptManager();
