/**
 * Zod schemas for VDS (Viz Data Service) query validation
 * Provides runtime validation for query-datasource tool arguments
 * v197: Initial implementation for query-datasource only
 * v367: Added structured error metadata for UI display
 */

import { z } from 'zod';
import { addStructuredIssue } from './validation-errors.js';

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// VDS FIELD SCHEMA
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const VdsFieldSchema = z.object({
  fieldCaption: z.string().min(1, 'Field caption is required and cannot be empty'),

  // Aggregation function (optional)
  // v283: Expanded to include date functions and additional aggregations
  function: z.enum([
    // Aggregation functions
    'SUM', 'AVG', 'MEDIAN', 'COUNT', 'COUNTD', 'MIN', 'MAX', 'STDEV', 'VAR', 'COLLECT',
    // Date extraction functions
    'YEAR', 'QUARTER', 'MONTH', 'WEEK', 'DAY',
    // Date truncation functions
    'TRUNC_YEAR', 'TRUNC_QUARTER', 'TRUNC_MONTH', 'TRUNC_WEEK', 'TRUNC_DAY'
  ]).optional(),

  // Field alias (optional)
  fieldAlias: z.string().optional(),

  // Calculation expression (optional)
  calculation: z.string().optional(),

  // Decimal precision (optional)
  maxDecimalPlaces: z.number().int().nonnegative().optional(),

  // Sort configuration (optional)
  sortPriority: z.number().int().min(1).optional(),
  sortDirection: z.enum(['ASC', 'DESC']).optional(),

  // Indicates if this field is a dimension (true) vs a measure (false/undefined)
  groupBy: z.boolean().optional(),
});

export type VdsField = z.infer<typeof VdsFieldSchema>;

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// VDS FILTER SCHEMAS - Discriminated Union by filterType
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// Common field reference schema
// v403: Added calculation support for ad-hoc calculated fields in filters
const FieldReferenceSchema = z.object({
  fieldCaption: z.string().optional(), // Optional when using calculation
  function: z.string().optional(), // Optional aggregation function for measures
  calculation: z.string().optional(), // v403: Ad-hoc calculation expression (e.g., "[Field1] + [Field2]")
}).refine(
  (data) => data.fieldCaption !== undefined || data.calculation !== undefined,
  {
    message: 'Field reference must have either fieldCaption or calculation',
  }
);

// Helper function to detect if a field name indicates a date field
function isDateField(fieldCaption: string): boolean {
  const fieldName = fieldCaption.toLowerCase();
  return fieldName.includes('date') ||
         fieldName.includes('datetime') ||
         fieldName.includes('timestamp') ||
         fieldName.includes('time') ||
         fieldName === 'year' ||
         fieldName === 'month' ||
         fieldName === 'day';
}

// SET filter - for categorical/discrete values (e.g., "Region IN ['East', 'West']")
// NOTE: SET filters are NOT allowed on date fields - use DATE or QUANTITATIVE_DATE instead
const VdsSetFilterSchema = z.object({
  filterType: z.literal('SET'),
  field: FieldReferenceSchema.optional(),
  column: FieldReferenceSchema.optional(),
  values: z.array(
    z.union([z.string(), z.number(), z.boolean()])
  ).min(1, 'SET filter requires at least one value'),
  exclude: z.boolean().optional(),
}).superRefine((data, ctx) => {
  // v367: Use superRefine to collect ALL validation errors with structured metadata

  // Check 1: Must have field or column reference
  if (data.field === undefined && data.column === undefined) {
    addStructuredIssue(
      ctx,
      ['field'],
      {
        summary: "SET filter missing field reference",
        detail: "SET filter requires either 'field' or 'column' property to specify which field to filter",
        action: "Add field property: { field: { fieldCaption: 'FieldName' }, values: [...] }"
      }
    );
  }

  // Check 2: Cannot use on date fields
  const fieldCaption = data.field?.fieldCaption || data.column?.fieldCaption;
  if (fieldCaption && isDateField(fieldCaption)) {
    addStructuredIssue(
      ctx,
      ['filterType'],
      {
        summary: "Cannot use SET filter on date fields",
        detail: `SET filter cannot be used on date field '${fieldCaption}'. Date fields require DATE (relative periods) or QUANTITATIVE_DATE (absolute dates) filter types`,
        action: "Replace SET filter with QUANTITATIVE_DATE filter. Example: { filterType: 'QUANTITATIVE_DATE', field: { fieldCaption: '" + fieldCaption + "' }, quantitativeFilterType: 'RANGE', minDate: '2026-01-01', maxDate: '2026-12-31' }"
      }
    );
  }
});

// MATCH filter - for text pattern matching (e.g., "Product LIKE '%Phone%'")
// NOTE: MATCH filters are NOT allowed on date fields - use DATE or QUANTITATIVE_DATE instead
// You must have at least one of: startsWith, endsWith, or contains
const VdsMatchFilterSchema = z.object({
  filterType: z.literal('MATCH'),
  field: FieldReferenceSchema.optional(),
  column: FieldReferenceSchema.optional(),
  startsWith: z.string().optional(),
  endsWith: z.string().optional(),
  contains: z.string().optional(),
  exclude: z.boolean().optional(),
}).superRefine((data, ctx) => {
  // v367: Use superRefine to collect ALL validation errors with structured metadata

  // Check 1: Must have field or column reference
  if (data.field === undefined && data.column === undefined) {
    addStructuredIssue(
      ctx,
      ['field'],
      {
        summary: "MATCH filter missing field reference",
        detail: "MATCH filter requires either 'field' or 'column' property to specify which field to filter",
        action: "Add field property: { field: { fieldCaption: 'FieldName' }, contains: 'search text' }"
      }
    );
  }

  // Check 2: Cannot use on date fields
  const fieldCaption = data.field?.fieldCaption || data.column?.fieldCaption;
  if (fieldCaption && isDateField(fieldCaption)) {
    addStructuredIssue(
      ctx,
      ['filterType'],
      {
        summary: "Cannot use MATCH filter on date fields",
        detail: `MATCH filter cannot be used on date field '${fieldCaption}'. Date fields require DATE (relative periods) or QUANTITATIVE_DATE (absolute dates) filter types`,
        action: "Replace MATCH filter with QUANTITATIVE_DATE filter. Example: { filterType: 'QUANTITATIVE_DATE', field: { fieldCaption: '" + fieldCaption + "' }, quantitativeFilterType: 'RANGE', minDate: '2026-01-01', maxDate: '2026-12-31' }"
      }
    );
  }

  // Check 3: Must have at least one matching criterion
  if (!data.startsWith && !data.endsWith && !data.contains) {
    addStructuredIssue(
      ctx,
      ['contains'],
      {
        summary: "MATCH filter missing search criteria",
        detail: "MATCH filter requires at least one of: startsWith, endsWith, or contains",
        action: "Add at least one search criterion: { contains: 'search text' } or { startsWith: 'prefix' } or { endsWith: 'suffix' }"
      }
    );
  }
});

// QUANTITATIVE_NUMERICAL filter - for numeric range filtering (e.g., "Sales > 1000")
// v209: Reverted to use 'field' (not 'column') with optional function property
// v404: Added ONLY_NON_NULL to filter out null values
// v420: Added RANGE support for exact value matching (min=max)
const VdsQuantitativeNumericalFilterSchema = z.object({
  filterType: z.literal('QUANTITATIVE_NUMERICAL'),
  field: FieldReferenceSchema.optional(),
  column: FieldReferenceSchema.optional(),
  quantitativeFilterType: z.enum(['MIN', 'MAX', 'RANGE', 'ONLY_NON_NULL']),
  min: z.number().optional(),
  max: z.number().optional(),
  includeNulls: z.boolean().optional(),
}).superRefine((data, ctx) => {
  // v206: Use superRefine to collect ALL validation errors, not just first one

  // Check 1: Must have field or column reference
  if (data.field === undefined && data.column === undefined) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'QUANTITATIVE_NUMERICAL filter requires either field or column reference',
    });
  }

  // Check 2: Must have at least min or max (not required for ONLY_NON_NULL)
  if (data.quantitativeFilterType !== 'ONLY_NON_NULL' && data.min === undefined && data.max === undefined) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'QUANTITATIVE_NUMERICAL filter requires at least min or max',
    });
  }

  // Check 3: Validate quantitativeFilterType matches provided values
  if (data.quantitativeFilterType === 'MIN' && data.min === undefined) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'quantitativeFilterType "MIN" requires min value to be specified',
    });
  }
  if (data.quantitativeFilterType === 'MAX' && data.max === undefined) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'quantitativeFilterType "MAX" requires max value to be specified',
    });
  }

  // v420: Check for RANGE - requires both min and max
  if (data.quantitativeFilterType === 'RANGE') {
    if (data.min === undefined || data.max === undefined) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'quantitativeFilterType "RANGE" requires both min and max values to be specified',
      });
    }
  }

  // Check 4: ONLY_NON_NULL should not have min/max values
  if (data.quantitativeFilterType === 'ONLY_NON_NULL' && (data.min !== undefined || data.max !== undefined)) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'quantitativeFilterType "ONLY_NON_NULL" should not have min or max values',
    });
  }
});

// QUANTITATIVE_DATE filter - for absolute date boundary filtering (e.g., "Order Date < 2020-04-01" or "2025-01-01 to 2025-12-31")
// v208: Added RANGE support for date ranges (e.g., "year 2025")
const VdsQuantitativeDateFilterSchema = z.object({
  filterType: z.literal('QUANTITATIVE_DATE'),
  field: FieldReferenceSchema.optional(),
  column: FieldReferenceSchema.optional(),
  quantitativeFilterType: z.enum(['MIN', 'MAX', 'RANGE']), // v208: Added RANGE
  minDate: z.string().optional(), // ISO date string (YYYY-MM-DD)
  maxDate: z.string().optional(), // ISO date string (YYYY-MM-DD)
  includeNulls: z.boolean().optional(),
}).superRefine((data, ctx) => {
  // v206: Use superRefine to collect ALL validation errors, not just first one

  // Check 1: Must have field or column reference
  if (data.field === undefined && data.column === undefined) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'QUANTITATIVE_DATE filter requires either field or column reference',
    });
  }

  // Check 2: Must have at least minDate or maxDate
  if (data.minDate === undefined && data.maxDate === undefined) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'QUANTITATIVE_DATE filter requires at least minDate or maxDate',
    });
  }

  // v208: Check 3: RANGE requires both minDate and maxDate
  if (data.quantitativeFilterType === 'RANGE') {
    if (data.minDate === undefined || data.maxDate === undefined) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'quantitativeFilterType "RANGE" requires both minDate and maxDate to be specified',
      });
    }
  }

  // v208: Check 4: MIN requires minDate, MAX requires maxDate
  if (data.quantitativeFilterType === 'MIN' && data.minDate === undefined) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'quantitativeFilterType "MIN" requires minDate to be specified',
    });
  }
  if (data.quantitativeFilterType === 'MAX' && data.maxDate === undefined) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'quantitativeFilterType "MAX" requires maxDate to be specified',
    });
  }
});

// DATE filter - for relative/period-based date filtering (e.g., "Current Year", "Last 3 Months")
const VdsDateFilterSchema = z.object({
  filterType: z.literal('DATE'),
  field: FieldReferenceSchema.optional(),
  column: FieldReferenceSchema.optional(),

  // REQUIRED fields for DATE filter
  periodType: z.enum([
    'YEARS', 'QUARTERS', 'MONTHS', 'WEEKS', 'DAYS', 'HOURS', 'MINUTES', 'SECONDS'
  ], {
    errorMap: () => ({
      message: 'Invalid periodType. Must be one of: YEARS, QUARTERS, MONTHS, WEEKS, DAYS, HOURS, MINUTES, SECONDS'
    })
  }),
  dateRangeType: z.enum([
    'CURRENT', 'LASTN', 'NEXTN', 'TODATE', 'LASTWEEK', 'LASTMONTH',
    'LASTQUARTER', 'LASTYEAR', 'NEXTWEEK', 'NEXTMONTH', 'NEXTQUARTER', 'NEXTYEAR'
  ], {
    errorMap: () => ({
      message: 'Invalid dateRangeType. Common mistake: use "LASTN" (not "LAST") with rangeN field. Valid: CURRENT, LASTN, NEXTN, TODATE, LASTWEEK, LASTMONTH, LASTQUARTER, LASTYEAR, NEXTWEEK, NEXTMONTH, NEXTQUARTER, NEXTYEAR'
    })
  }),

  // Optional fields
  rangeN: z.number().int().positive().optional(),
  anchorDate: z.string().optional(), // ISO date string (YYYY-MM-DD), defaults to today if not specified
  includeNulls: z.boolean().optional(),
}).passthrough().superRefine((data: any, ctx) => {
  // v206/v368: Use superRefine to collect ALL validation errors, not just first one

  // v368: Check 0: Catch common "LAST" mistake (should be "LASTN")
  if (data.dateRangeType === 'LAST') {
    addStructuredIssue(
      ctx,
      ['dateRangeType'],
      {
        summary: 'Use "LASTN" instead of "LAST" for date ranges',
        detail: 'dateRangeType "LAST" is not valid. Use "LASTN" with rangeN field to specify "last N periods".',
        action: 'Change dateRangeType from "LAST" to "LASTN" and ensure rangeN field is set (e.g., rangeN: 90 for last 90 days).'
      },
      '🚨 Invalid dateRangeType: "LAST"\n\n' +
      '**The Problem:** You used dateRangeType: "LAST", but this is not a valid value.\n\n' +
      '**The Solution:** Use "LASTN" instead and specify rangeN.\n\n' +
      '❌ **WRONG**:\n' +
      '{\n' +
      '  "filterType": "DATE",\n' +
      '  "field": { "fieldCaption": "Order Date" },\n' +
      '  "periodType": "DAYS",\n' +
      '  "dateRangeType": "LAST",\n' +
      '  "rangeN": 90\n' +
      '}\n\n' +
      '✅ **CORRECT**:\n' +
      '{\n' +
      '  "filterType": "DATE",\n' +
      '  "field": { "fieldCaption": "Order Date" },\n' +
      '  "periodType": "DAYS",\n' +
      '  "dateRangeType": "LASTN",\n' +
      '  "rangeN": 90\n' +
      '}\n\n' +
      'Valid dateRangeType values: CURRENT, LASTN, NEXTN, TODATE, LASTWEEK, LASTMONTH, LASTQUARTER, LASTYEAR, NEXTWEEK, NEXTMONTH, NEXTQUARTER, NEXTYEAR'
    );
  }

  // Check 1: Must have field or column reference
  if (data.field === undefined && data.column === undefined) {
    addStructuredIssue(
      ctx,
      ['field'],
      {
        summary: 'DATE filter missing field reference',
        detail: 'DATE filter requires either "field" or "column" property to specify which date field to filter',
        action: 'Add field property: { field: { fieldCaption: "Order Date" } }'
      }
    );
  }

  // Check 2: LASTN/NEXTN requires rangeN field
  const needsRangeN = data.dateRangeType === 'LASTN' || data.dateRangeType === 'NEXTN';
  if (needsRangeN && data.rangeN === undefined) {
    addStructuredIssue(
      ctx,
      ['rangeN'],
      {
        summary: 'LASTN/NEXTN requires rangeN field',
        detail: 'When using dateRangeType "LASTN" or "NEXTN", you must specify rangeN to indicate how many periods',
        action: 'Add rangeN field with the number of periods (e.g., rangeN: 3 for last 3 months)'
      }
    );
  }
});

// TOP filter - for "Top N by Measure" queries (e.g., "Top 10 Products by Sales")
// v414: fieldToMeasure now uses FieldReferenceSchema to support LOD calculations
const VdsTopFilterSchema = z.object({
  filterType: z.literal('TOP'),
  field: FieldReferenceSchema.optional(),
  column: FieldReferenceSchema.optional(),
  howMany: z.number().int().positive('howMany must be a positive integer'),
  direction: z.enum(['TOP', 'BOTTOM']).optional(),
  fieldToMeasure: FieldReferenceSchema.optional(), // v414: Now supports calculation (LOD expressions)
}).superRefine((data, ctx) => {
  // v206: Use superRefine for consistency with other filter schemas

  // Check: Must have field or column reference
  if (data.field === undefined && data.column === undefined) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'TOP filter requires either field or column reference',
    });
  }
});

// Union of all filter types (uses z.union instead of discriminatedUnion to support .refine() validation)
export const VdsFilterSchema = z.union([
  VdsSetFilterSchema,
  VdsMatchFilterSchema,
  VdsQuantitativeNumericalFilterSchema,
  VdsQuantitativeDateFilterSchema,
  VdsDateFilterSchema,
  VdsTopFilterSchema,
]);

export type VdsFilter = z.infer<typeof VdsFilterSchema>;

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// VDS QUERY SCHEMA
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const VdsQuerySchema = z.object({
  fields: z.array(VdsFieldSchema).min(1, 'Query must include at least one field'),
  filters: z.array(VdsFilterSchema).optional(),
})
.passthrough()  // v204: Allow unknown keys to pass through so refinement can check them
.superRefine((data: any, ctx) => {
  // v206: Use superRefine instead of refine to allow collecting multiple errors
  // This ensures ALL validation errors are reported at once, not just the first one

  // v273/v367: Check for "limit" field (not supported - VDS API doesn't accept limit parameter)
  if (data.limit !== undefined) {
    addStructuredIssue(
      ctx,
      ['limit'],
      {
        summary: "Remove 'limit' parameter - not supported",
        detail: "The 'limit' parameter is not supported in query-datasource. The VDS API does not accept a limit parameter.",
        action: "Remove the 'limit' field from the query. The system automatically limits results to prevent context overflow."
      },
      'The "limit" parameter is not supported in query-datasource. The VDS API does not accept a limit parameter.\n\n' +
      '❌ **WRONG**: { query: { fields: [...], limit: 10 } }\n\n' +
      '✅ **CORRECT**: { query: { fields: [...] } }\n\n' +
      'The system automatically limits results to prevent context overflow. Do not include a "limit" field in your query.'
    );
  }

  // v278/v367: Check for "limits" field (plural variation - also not supported)
  if (data.limits !== undefined) {
    addStructuredIssue(
      ctx,
      ['limits'],
      {
        summary: "Remove 'limits' parameter - not supported",
        detail: "The 'limits' parameter is not supported in query-datasource. The VDS API does not accept a limits parameter.",
        action: "Remove the 'limits' field from the query. The system automatically limits results to prevent context overflow."
      },
      'The "limits" parameter is not supported in query-datasource. The VDS API does not accept a limits parameter.\n\n' +
      '❌ **WRONG**: { query: { fields: [...], limits: { count: 10 } } }\n\n' +
      '✅ **CORRECT**: { query: { fields: [...] } }\n\n' +
      'The system automatically limits results to prevent context overflow. Do not include "limit" or "limits" in your query.'
    );
  }

  // v283/v367: Check for "groupBy" array (common mistake - should use aggregation functions instead)
  if (data.groupBy !== undefined) {
    addStructuredIssue(
      ctx,
      ['groupBy'],
      {
        summary: "Remove 'groupBy' parameter - not supported",
        detail: "query-datasource does not support a 'groupBy' parameter. VDS automatically groups by dimension fields (fields without aggregation functions).",
        action: "Delete the 'groupBy' array entirely. Keep all existing field definitions unchanged with their functions (TRUNC_QUARTER, TRUNC_MONTH, SUM, etc.). VDS automatically groups by all dimension fields."
      },
      '🚨 CRITICAL ERROR: query-datasource does NOT support a "groupBy" parameter!\n\n' +
      '🎯 **CRITICAL: THIS IS A GROUPBY PARAMETER ERROR ONLY**\n\n' +
      '⚠️ **DO NOT CHANGE YOUR EXISTING FIELDS OR THEIR FUNCTIONS!**\n' +
      '⚠️ **Your field definitions are correct - you ONLY need to remove the groupBy parameter!**\n' +
      '⚠️ **Keep ALL existing functions on fields (TRUNC_QUARTER, TRUNC_MONTH, SUM, etc.)!**\n\n' +
      '**The Problem:**\n' +
      'You tried to use a "groupBy" array to group data, but this parameter does not exist in query-datasource.\n\n' +
      '**The Solution:**\n' +
      'DELETE the "groupBy" array and keep your fields exactly as they are. VDS automatically groups by dimension fields.\n\n' +
      '❌ **WRONG**: Separate groupBy array\n' +
      '{\n' +
      '  "fields": [\n' +
      '    { "fieldCaption": "Order Date", "function": "TRUNC_QUARTER" },\n' +
      '    { "fieldCaption": "Sales", "function": "SUM" }\n' +
      '  ],\n' +
      '  "groupBy": [{ "fieldCaption": "Order Date" }]  ❌ THIS DOES NOT EXIST!\n' +
      '}\n\n' +
      '✅ **CORRECT**: No groupBy array - just keep your fields\n' +
      '{\n' +
      '  "fields": [\n' +
      '    { "fieldCaption": "Order Date", "function": "TRUNC_QUARTER" },  ✅ KEEP the function!\n' +
      '    { "fieldCaption": "Sales", "function": "SUM" }\n' +
      '  ]\n' +
      '}\n\n' +
      '**IMPORTANT - Preserve Date Functions:**\n' +
      '- If a date field has TRUNC_QUARTER, TRUNC_MONTH, YEAR, etc. → KEEP IT!\n' +
      '- Date extraction/truncation functions are NOT aggregations - they transform the dimension\n' +
      '- Example: { "fieldCaption": "Order Date", "function": "TRUNC_QUARTER" } ✅ KEEP AS IS\n\n' +
      '**How Grouping Works in VDS:**\n' +
      '- Fields WITHOUT aggregation functions (or with date functions) are dimensions\n' +
      '- Fields WITH aggregation functions (SUM, AVG, COUNT, etc.) are measures\n' +
      '- VDS automatically groups by all dimension fields\n\n' +
      '**HOW TO FIX:**\n' +
      '1. DELETE the "groupBy" array entirely\n' +
      '2. KEEP ALL your existing field definitions unchanged\n' +
      '3. If a field had TRUNC_QUARTER, YEAR, or other date functions → PRESERVE THEM\n' +
      '4. If a field had SUM, AVG, or other aggregations → PRESERVE THEM\n' +
      '5. Do NOT remove or modify any existing functions on fields'
    );
  }

  // v367: Check for root-level sort fields (should be inside field objects)
  if (data.sortDirection !== undefined || data.sortPriority !== undefined) {
    addStructuredIssue(
      ctx,
      ['sortDirection'],
      {
        summary: "Sort properties must be inside field objects",
        detail: "sortDirection and sortPriority are at the query level instead of inside the field objects in the 'fields' array",
        action: "Move sortDirection and sortPriority properties into the specific field object that should be sorted. Keep all other field definitions unchanged."
      },
      // Full detailed message for LLM self-correction
      'sortDirection and sortPriority must be inside field objects, not at the query level.\n\n' +
      '🎯 **CRITICAL: THIS IS A SORT PLACEMENT ERROR ONLY**\n\n' +
      '⚠️ **DO NOT CHANGE YOUR FIELDS, FILTERS, OR AGGREGATION LOGIC!**\n' +
      '⚠️ **Your query structure is correct - you ONLY need to move the sort properties!**\n\n' +
      '**STEP 1: Identify which field to add sort to**\n' +
      'Based on the user\'s original question:\n' +
      '📊 TIME SERIES (trends, over time) → sort by DATE field (ASC)\n' +
      '🏆 RANKINGS (top/bottom) → sort by MEASURE field (DESC/ASC)\n' +
      '🔤 ALPHABETICAL → sort by TEXT/DIMENSION field (ASC)\n\n' +
      '**STEP 2: Fix the query**\n' +
      '1. Keep ALL existing field definitions\n' +
      '2. Add sortDirection and sortPriority to the identified field\n' +
      '3. Remove sortDirection/sortPriority from query level\n\n' +
      'Example: { fieldCaption: "Order Date", function: "TRUNC_QUARTER", sortDirection: "ASC", sortPriority: 1 }'
    );
  }

  // v367: Check for "sorts" array (common mistake - should use field objects instead)
  if (data.sorts !== undefined) {
    addStructuredIssue(
      ctx,
      ['sorts'],
      {
        summary: "Remove 'sorts' array - add sort to field objects",
        detail: "Do not create a 'sorts' array. Instead, add sortDirection and sortPriority properties directly to field objects in the 'fields' array.",
        action: "Delete the 'sorts' array. Keep all existing fields unchanged. Add sortDirection and sortPriority to the appropriate field: for time series queries, sort by the date field (ASC); for rankings, sort by the measure field (DESC for top, ASC for bottom); for alphabetical, sort by the text/dimension field (ASC)."
      },
      'DO NOT create a "sorts" array! Instead, add sortDirection and sortPriority properties directly to the field objects in the "fields" array.\n\n' +
      '🎯 **CRITICAL: THIS IS A SORT SYNTAX ERROR ONLY**\n\n' +
      '⚠️ **DO NOT CHANGE YOUR FIELDS, FILTERS, OR AGGREGATION LOGIC!**\n' +
      '⚠️ **Your query structure is correct - you ONLY need to fix the sort syntax!**\n' +
      '⚠️ **Keep ALL your existing fields (with their functions, aliases, etc.) exactly as they are!**\n\n' +
      '**STEP 1: Identify which field to add sort to**\n' +
      'Read the ORIGINAL user question and use this decision tree:\n\n' +
      '📊 **If user asks about TRENDS, TIME SERIES, or OVER TIME:**\n' +
      '   - Examples: "quarterly sales trends", "monthly revenue", "sales over time"\n' +
      '   → ADD sort to the DATE/TIME field (the one with TRUNC_QUARTER, TRUNC_MONTH, YEAR, etc.)\n' +
      '   → Direction: Usually ASC (chronological order)\n\n' +
      '🏆 **If user asks for RANKINGS or TOP/BOTTOM:**\n' +
      '   - Examples: "top 10 products by sales", "highest revenue customers", "lowest performing"\n' +
      '   → ADD sort to the MEASURE field (the one with SUM, AVG, COUNT, etc.)\n' +
      '   → Direction: DESC for "top/highest", ASC for "bottom/lowest"\n\n' +
      '🔤 **If user asks for ALPHABETICAL order:**\n' +
      '   - Examples: "products alphabetically", "customers sorted by name"\n' +
      '   → ADD sort to the TEXT/DIMENSION field (the one without aggregation function)\n' +
      '   → Direction: Usually ASC (A-Z)\n\n' +
      '📈 **Default (if unclear):**\n' +
      '   → ADD sort to the first DIMENSION field (field without aggregation function)\n\n' +
      '**STEP 2: Fix the query**\n' +
      '1. DELETE the "sorts" array entirely\n' +
      '2. Keep ALL the fields you already defined\n' +
      '3. Find the field identified in STEP 1\n' +
      '4. ADD sortDirection and sortPriority to THAT field only\n\n' +
      '**Example: User asks "show quarterly sales trends"**\n' +
      '- This is a TIME SERIES query → sort by the DATE field\n' +
      '✅ DELETE the "sorts" array\n' +
      '✅ KEEP Order Date field with TRUNC_QUARTER\n' +
      '✅ KEEP Sales field with SUM\n' +
      '✅ ADD sort to Order Date field: { fieldCaption: "Order Date", function: "TRUNC_QUARTER", sortDirection: "ASC", sortPriority: 1 }\n\n' +
      '**Example: User asks "top 10 products by sales"**\n' +
      '- This is a RANKING query → sort by the MEASURE field\n' +
      '✅ DELETE the "sorts" array\n' +
      '✅ KEEP Product Name field (dimension)\n' +
      '✅ KEEP Sales field with SUM\n' +
      '✅ ADD sort to Sales field: { fieldCaption: "Sales", function: "SUM", sortDirection: "DESC", sortPriority: 1 }\n\n' +
      '⚠️ **The examples above use generic field names as illustrations!**\n' +
      '⚠️ **Use the ACTUAL fields from YOUR query - don\'t copy "Order Date" or "Sales"!**'
    );
  }

  // v415: Check for "sort" array (singular - common mistake variation)
  if (data.sort !== undefined) {
    addStructuredIssue(
      ctx,
      ['sort'],
      {
        summary: "Remove 'sort' array - add sort to field objects",
        detail: "Do not create a 'sort' array. Instead, add sortDirection and sortPriority properties directly to field objects in the 'fields' array.",
        action: "Delete the 'sort' array. Keep all existing fields unchanged. Add sortDirection and sortPriority to the appropriate field: for time series queries, sort by the date field (ASC); for rankings, sort by the measure field (DESC for top, ASC for bottom); for superlatives (highest/lowest), sort by the measure field."
      },
      '🚨 DO NOT create a "sort" array! Instead, add sortDirection and sortPriority properties directly to the field objects in the "fields" array.\n\n' +
      '🎯 **CRITICAL: THIS IS A SORT SYNTAX ERROR ONLY**\n\n' +
      '⚠️ **DO NOT CHANGE YOUR FIELDS, FILTERS, OR AGGREGATION LOGIC!**\n' +
      '⚠️ **Your query structure is correct - you ONLY need to fix the sort syntax!**\n' +
      '⚠️ **Keep ALL your existing fields (with their functions, aliases, etc.) exactly as they are!**\n\n' +
      '**THE PROBLEM:**\n' +
      'You created a "sort" array at the query level:\n' +
      '❌ WRONG:\n' +
      '```json\n' +
      '{\n' +
      '  "fields": [\n' +
      '    { "fieldCaption": "School" },\n' +
      '    { "fieldCaption": "Total Enrollees" }\n' +
      '  ],\n' +
      '  "sort": [  ❌ THIS DOES NOT EXIST!\n' +
      '    {\n' +
      '      "field": { "fieldCaption": "Total Enrollees" },\n' +
      '      "sortDirection": "DESC"\n' +
      '    }\n' +
      '  ]\n' +
      '}\n' +
      '```\n\n' +
      '**THE SOLUTION:**\n' +
      'Add sortDirection and sortPriority directly to the field object:\n' +
      '✅ CORRECT:\n' +
      '```json\n' +
      '{\n' +
      '  "fields": [\n' +
      '    { "fieldCaption": "School" },\n' +
      '    {\n' +
      '      "fieldCaption": "Total Enrollees",\n' +
      '      "sortDirection": "DESC",\n' +
      '      "sortPriority": 1\n' +
      '    }\n' +
      '  ]\n' +
      '}\n' +
      '```\n\n' +
      '**STEP 1: Identify which field to add sort to**\n' +
      'Read the ORIGINAL user question and use this decision tree:\n\n' +
      '📊 **If user asks about TRENDS or TIME SERIES:**\n' +
      '   → ADD sort to the DATE/TIME field\n' +
      '   → Direction: ASC (chronological order)\n\n' +
      '🏆 **If user asks for RANKINGS (top N, bottom N):**\n' +
      '   → ADD sort to the MEASURE field\n' +
      '   → Direction: DESC for "top/highest", ASC for "bottom/lowest"\n\n' +
      '🎯 **If user asks for SUPERLATIVES (highest/lowest single item):**\n' +
      '   → ADD sort to the MEASURE field\n' +
      '   → Direction: DESC for "highest/maximum/best", ASC for "lowest/minimum/worst"\n\n' +
      '🔤 **If user asks for ALPHABETICAL order:**\n' +
      '   → ADD sort to the TEXT/DIMENSION field\n' +
      '   → Direction: ASC (A-Z)\n\n' +
      '**STEP 2: Fix the query**\n' +
      '1. DELETE the "sort" array entirely\n' +
      '2. Keep ALL the fields you already defined\n' +
      '3. Find the field identified in STEP 1 (look at its fieldCaption)\n' +
      '4. ADD sortDirection and sortPriority to THAT field object in the "fields" array\n\n' +
      '**HOW TO FIX:**\n' +
      '- Remove the entire "sort" array from the query\n' +
      '- Find the field object in "fields" array that matches the field you want to sort by\n' +
      '- Add sortDirection: "ASC" or "DESC" to that field object\n' +
      '- Add sortPriority: 1 to that field object\n' +
      '- Do NOT change any other properties of the field\n\n' +
      '⚠️ **The examples above use generic field names as illustrations!**\n' +
      '⚠️ **Use the ACTUAL fields from YOUR query - match the fieldCaption exactly!**'
    );
  }

  // v352/v367: Check for TOP filter properties at query level (should be inside filters array)
  if (data.filterType !== undefined || data.howMany !== undefined || data.fieldToMeasure !== undefined || data.direction !== undefined) {
    addStructuredIssue(
      ctx,
      ['filterType'],
      {
        summary: "TOP filter properties must be inside filters array",
        detail: "TOP filter properties (filterType, howMany, fieldToMeasure, direction) are at the query level instead of inside a filter object in the filters array",
        action: "Remove filterType, howMany, fieldToMeasure, direction from query level. Create a filter object inside filters array with: field (dimension to show), filterType: 'TOP', howMany (number of items), fieldToMeasure (measure to rank by), direction ('TOP' or 'BOTTOM'). Remove sortDirection/sortPriority from fields as TOP filter handles sorting."
      },
      '🚨 CRITICAL ERROR: TOP filter properties (filterType, howMany, fieldToMeasure, direction) must be inside a filter object in the filters array, NOT at the query level!\n\n' +
      '🎯 **CRITICAL: THIS IS A TOP FILTER PLACEMENT ERROR**\n\n' +
      '⚠️ **You placed TOP filter properties at the wrong level!**\n\n' +
      '❌ **WRONG** (TOP filter properties at query level):\n' +
      '```json\n' +
      '{\n' +
      '  "fields": [\n' +
      '    { "fieldCaption": "Product Name", "sortDirection": "DESC", "sortPriority": 1 },\n' +
      '    { "fieldCaption": "Sales", "function": "SUM", "fieldAlias": "Total Revenue" }\n' +
      '  ],\n' +
      '  "filters": [],\n' +
      '  "filterType": "TOP",  ❌ WRONG LEVEL!\n' +
      '  "howMany": 10,  ❌ WRONG LEVEL!\n' +
      '  "fieldToMeasure": {  ❌ WRONG LEVEL!\n' +
      '    "fieldCaption": "Sales",\n' +
      '    "function": "SUM"\n' +
      '  }\n' +
      '}\n' +
      '```\n\n' +
      '✅ **CORRECT** (TOP filter inside filters array):\n' +
      '```json\n' +
      '{\n' +
      '  "fields": [\n' +
      '    { "fieldCaption": "Product Name" },\n' +
      '    { "fieldCaption": "Sales", "function": "SUM", "fieldAlias": "Total Revenue" }\n' +
      '  ],\n' +
      '  "filters": [\n' +
      '    {\n' +
      '      "field": { "fieldCaption": "Product Name" },\n' +
      '      "filterType": "TOP",\n' +
      '      "howMany": 10,\n' +
      '      "fieldToMeasure": {\n' +
      '        "fieldCaption": "Sales",\n' +
      '        "function": "SUM"\n' +
      '      },\n' +
      '      "direction": "TOP"\n' +
      '    }\n' +
      '  ]\n' +
      '}\n' +
      '```\n\n' +
      '**HOW TO FIX:**\n' +
      '1. REMOVE filterType, howMany, fieldToMeasure, direction from the query level\n' +
      '2. CREATE a new filter object inside the "filters" array\n' +
      '3. ADD the "field" property specifying which dimension to filter (usually the first non-aggregated field)\n' +
      '4. MOVE filterType, howMany, fieldToMeasure, direction into this filter object\n' +
      '5. REMOVE sortDirection/sortPriority from fields (TOP filter handles sorting automatically)\n\n' +
      '**KEY POINTS:**\n' +
      '- TOP filter = "show me top N items by measure"\n' +
      '- field property = which dimension to show (e.g., Product Name)\n' +
      '- fieldToMeasure = what to rank by (e.g., SUM(Sales))\n' +
      '- howMany = how many items to return\n' +
      '- direction = "TOP" for highest values, "BOTTOM" for lowest values'
    );
  }

  // v367: Check for QUANTITATIVE_NUMERICAL + DATE filter pairing (should use QUANTITATIVE_DATE instead)
  if (data.filters && Array.isArray(data.filters)) {
    const hasQuantitativeNumerical = data.filters.some((f: any) => f.filterType === 'QUANTITATIVE_NUMERICAL');
    const dateFilterIndexes = data.filters
      .map((f: any, idx: number) => f.filterType === 'DATE' ? idx : -1)
      .filter((idx: number) => idx !== -1);

    if (hasQuantitativeNumerical && dateFilterIndexes.length > 0) {
      dateFilterIndexes.forEach((idx: number) => {
        addStructuredIssue(
          ctx,
          ['filters', idx, 'filterType'],
          {
            summary: "Use QUANTITATIVE_DATE filter for date ranges with measures",
            detail: "When filtering measures (QUANTITATIVE_NUMERICAL), date filters must use QUANTITATIVE_DATE with absolute dates (minDate/maxDate), not DATE with relative periods (periodType/dateRangeType)",
            action: "Replace DATE filter with QUANTITATIVE_DATE filter. Use minDate and maxDate with ISO date strings (YYYY-MM-DD) based on the user's question. Example: { filterType: 'QUANTITATIVE_DATE', field: { fieldCaption: 'Order Date' }, quantitativeFilterType: 'RANGE', minDate: '2026-01-01', maxDate: '2026-12-31' }"
          }
        );
      });
    }
  }

  // Add more query-level validations here as needed
  // Each validation adds an issue but doesn't stop - all errors are collected
})
.transform((data) => {
  // v204: After validation passes, strip the invalid fields
  // v273: Added "limit" to list of stripped fields
  // v278: Added "limits" to list of stripped fields
  // v283: Added "groupBy" to list of stripped fields
  // v352: Added TOP filter properties (filterType, howMany, fieldToMeasure, direction)
  // v415: Added "sort" to list of stripped fields (singular variation)
  const { sortDirection, sortPriority, sorts, sort, limit, limits, groupBy, filterType, howMany, fieldToMeasure, direction, ...rest } = data;
  return rest;
});

export type VdsQuery = z.infer<typeof VdsQuerySchema>;

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// QUERY-DATASOURCE ARGS SCHEMA (Top-level)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const QueryDatasourceArgsSchema = z.object({
  datasourceLuid: z.string().min(1, 'datasourceLuid is required and cannot be empty'),
  query: VdsQuerySchema,
}).refine(
  (data) => {
    // Validate that datasourceLuid looks like a UUID, not a human-readable name
    const luid = data.datasourceLuid;

    // UUID pattern: 8-4-4-4-12 hex digits (e.g., "550e8400-e29b-41d4-a716-446655440000")
    const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

    if (!uuidPattern.test(luid)) {
      return false;
    }
    return true;
  },
  {
    message: 'datasourceLuid must be a valid UUID (e.g., "550e8400-e29b-41d4-a716-446655440000"), NOT a datasource name. ' +
             'You passed a human-readable name instead of a LUID! ' +
             '\n\n**HOW TO FIX THIS ERROR:**\n' +
             '1. First, call list-datasources with a filter to find the datasource by name:\n' +
             '   Example: list-datasources with filter="name:eq:minimart" (exact match, case-insensitive)\n' +
             '   Or for multiple: filter="name:in:minimart,sales,hr" (match any of these names)\n' +
             '2. Extract the "luid" field from the response (it will be a UUID like "550e8400-e29b-41d4-a716-446655440000")\n' +
             '3. Then call query-datasource with that LUID as the datasourceLuid parameter\n\n' +
             'DO NOT randomly try different UUIDs. DO NOT reuse LUIDs from previous queries without checking. ' +
             'ALWAYS call list-datasources first to get the correct LUID for the datasource name the user mentioned.'
  }
);

export type QueryDatasourceArgs = z.infer<typeof QueryDatasourceArgsSchema>;
