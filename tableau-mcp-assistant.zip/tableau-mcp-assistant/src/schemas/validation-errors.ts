/**
 * v367: Standardized validation error framework
 * Provides structured error information for both UI display and LLM self-correction
 *
 * Each validation error includes:
 * - summary: Concise, user-friendly message for UI (Data Quality panel)
 * - detail: Detailed explanation for LLM context
 * - action: Specific fix instructions for LLM
 */

import { z } from 'zod';

/**
 * Structured validation error metadata
 */
export interface ValidationErrorMetadata {
  /** Concise, user-friendly error summary for UI display (max 80 chars) */
  summary: string;
  /** Detailed explanation of what went wrong (for LLM context) */
  detail: string;
  /** Specific action the LLM should take to fix this error */
  action: string;
}

/**
 * Helper to create Zod custom issue with structured error metadata
 *
 * @param ctx - Zod refinement context
 * @param path - Error path (e.g., ['query', 'sortDirection'])
 * @param metadata - Structured error information
 * @param fullMessage - Complete detailed message for LLM (will be prepended to detail+action)
 *
 * @example
 * addStructuredIssue(ctx, ['sortDirection'], {
 *   summary: "Sort properties misplaced",
 *   detail: "sortDirection and sortPriority must be inside field objects, not at query level",
 *   action: "Move sortDirection and sortPriority into the field object that should be sorted"
 * });
 */
export function addStructuredIssue(
  ctx: z.RefinementCtx,
  path: (string | number)[],
  metadata: ValidationErrorMetadata,
  fullMessage?: string
): void {
  const message = fullMessage || `${metadata.detail}\n\nACTION: ${metadata.action}`;

  ctx.addIssue({
    code: z.ZodIssueCode.custom,
    path,
    message,
    params: {
      // Attach structured metadata for extraction
      errorSummary: metadata.summary,
      errorDetail: metadata.detail,
      errorAction: metadata.action,
    },
  });
}

/**
 * Extract error summary from Zod error for UI display
 *
 * @param zodError - Zod validation error
 * @returns Array of concise error summaries for UI
 */
export function extractErrorSummaries(zodError: z.ZodError): string[] {
  const summaries: string[] = [];

  for (const issue of zodError.errors) {
    // Check if issue has structured metadata
    const params = (issue as any).params;
    if (params && params.errorSummary) {
      summaries.push(params.errorSummary);
    } else {
      // Fallback: use first line of message (legacy errors)
      const firstLine = issue.message.split('\n')[0].trim();
      summaries.push(firstLine.substring(0, 80));
    }
  }

  // Deduplicate and limit to 3
  return Array.from(new Set(summaries)).slice(0, 3);
}

/**
 * Extract detailed error information for LLM
 *
 * @param zodError - Zod validation error
 * @returns Formatted error message for LLM self-correction
 */
export function extractDetailedErrors(zodError: z.ZodError): string {
  let output = '❌ **VALIDATION ERROR**\n\n';

  for (const issue of zodError.errors) {
    const path = issue.path.join('.') || 'root';
    const params = (issue as any).params;

    if (params && params.errorDetail && params.errorAction) {
      // Structured error format
      output += `**Path:** ${path}\n`;
      output += `**Issue:** ${params.errorDetail}\n`;
      output += `**Action:** ${params.errorAction}\n\n`;
    } else {
      // Legacy format (fallback)
      output += `**Path:** ${path}\n`;
      output += `${issue.message}\n\n`;
    }
  }

  return output;
}
