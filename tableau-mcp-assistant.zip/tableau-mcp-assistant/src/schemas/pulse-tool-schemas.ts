/**
 * Runtime validation schemas for Pulse tool arguments
 * v302: Enforce required parameters in Pulse metric tool calls
 */

import { z } from 'zod';

/**
 * Schema for list-pulse-metric-definitions-from-definition-ids
 * Enforces DEFINITION_VIEW_FULL to retrieve metric names
 */
export const ListPulseMetricDefinitionsArgsSchema = z.object({
  metricDefinitionIds: z
    .array(z.string().uuid("Each metric definition ID must be a valid UUID"))
    .min(1, "Must provide at least one metric definition ID\n\n" +
           "⚠️ COMMON MISTAKE: Are you passing metric IDs instead of definition IDs?\n" +
           "If you called list-pulse-metrics-from-metric-ids, extract the 'definition_id' column (index 2), NOT the 'id' column (index 0)!\n" +
           "See pulse_planner_guidance.md Workflow 1, step 1.2 for details."),

  view: z
    .literal('DEFINITION_VIEW_FULL', {
      errorMap: () => ({
        message:
          "🚨 CRITICAL: view parameter MUST be 'DEFINITION_VIEW_FULL' to retrieve metric names.\n" +
          "Without this exact value, the API returns only IDs and you CANNOT display human-readable names to users.\n\n" +
          "REQUIRED FORMAT:\n" +
          "{\n" +
          "  \"metricDefinitionIds\": [\"uuid-1\", \"uuid-2\", ...],\n" +
          "  \"view\": \"DEFINITION_VIEW_FULL\"\n" +
          "}\n\n" +
          "AFTER calling this tool successfully:\n" +
          "- Extract definition.metadata.name from EACH result\n" +
          "- Display these human-readable names to the user\n" +
          "- See pulse_planner_guidance.md Workflow 1, step 1.4"
      })
    })
});

export type ListPulseMetricDefinitionsArgs = z.infer<typeof ListPulseMetricDefinitionsArgsSchema>;

/**
 * Schema for list-all-pulse-metric-definitions
 * Enforces view parameter to ensure consistent data retrieval
 */
export const ListAllPulseMetricDefinitionsArgsSchema = z.object({
  view: z
    .enum(['DEFINITION_VIEW_FULL', 'DEFINITION_VIEW_BASIC'], {
      errorMap: () => ({
        message: "view must be either 'DEFINITION_VIEW_FULL' or 'DEFINITION_VIEW_BASIC'"
      })
    })
    .optional()
    .default('DEFINITION_VIEW_BASIC')
}).strict(); // Strict mode to catch unexpected parameters

export type ListAllPulseMetricDefinitionsArgs = z.infer<typeof ListAllPulseMetricDefinitionsArgsSchema>;
