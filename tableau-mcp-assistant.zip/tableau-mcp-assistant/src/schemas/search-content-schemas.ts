/**
 * Zod schemas for search-content tool validation
 * Provides runtime validation for search-content tool arguments
 * v279: Initial implementation for search-content with contentTypes validation
 * v369: Use structured validation framework for concise error summaries
 */

import { z } from 'zod';
import { addStructuredIssue } from './validation-errors.js';

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// CONTENT TYPES VALIDATION
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Valid content types for Tableau search
 *
 * CRITICAL MAPPING:
 * - Dashboards → "view" (NOT "dashboard" - it doesn't exist!)
 * - Views → "view"
 * - Datasources → "datasource"
 * - Workbooks → "workbook"
 * - Flows → "flow"
 * - Projects → "project"
 */
const VALID_CONTENT_TYPES = [
  'lens',
  'datasource',
  'virtualconnection',
  'collection',
  'project',
  'flow',
  'datarole',
  'table',
  'database',
  'view',
  'workbook'
] as const;

/**
 * CRITICAL: "dashboard" is NOT a valid content type
 * Dashboards are represented as "view" in Tableau's API
 */
const INVALID_CONTENT_TYPE_DASHBOARD = 'dashboard';

export const ContentTypeSchema = z.enum(VALID_CONTENT_TYPES);

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// SEARCH FILTER SCHEMA
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const SearchFilterSchema = z.object({
  contentTypes: z.array(ContentTypeSchema).min(1, 'contentTypes array must contain at least one content type')
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// SEARCH-CONTENT ARGS SCHEMA
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const SearchContentArgsSchema = z.object({
  terms: z.string().min(1, 'Search terms are required and cannot be empty'),
  filter: z.any(), // Validate in superRefine for better error messages
  limit: z.number().int().positive('limit must be a positive integer').optional(),
})
.passthrough() // Allow unknown keys to pass through for refinement
.superRefine((data: any, ctx) => {
  // v369: Validate contentTypes with structured errors
  const contentTypes = data.filter?.contentTypes;

  if (!Array.isArray(contentTypes)) {
    addStructuredIssue(
      ctx,
      ['filter', 'contentTypes'],
      {
        summary: 'Missing contentTypes in filter',
        detail: 'search-content requires filter.contentTypes array to specify which content types to search',
        action: 'Add contentTypes to filter. Example: { filter: { contentTypes: ["view"] } }'
      }
    );
    return;
  }

  if (contentTypes.length === 0) {
    addStructuredIssue(
      ctx,
      ['filter', 'contentTypes'],
      {
        summary: 'contentTypes array is empty',
        detail: 'contentTypes array must contain at least one content type',
        action: 'Add at least one content type to filter.contentTypes array. Common: ["view"] for dashboards, ["datasource"] for datasources'
      }
    );
    return;
  }

  // Check each content type for validity
  for (let i = 0; i < contentTypes.length; i++) {
    const contentType = contentTypes[i];

    // Special case: "dashboard" is a common mistake
    if (contentType === INVALID_CONTENT_TYPE_DASHBOARD) {
      addStructuredIssue(
        ctx,
        ['filter', 'contentTypes', i],
        {
          summary: 'Use "view" instead of "dashboard"',
          detail: '"dashboard" is not a valid content type. Dashboards are represented as "view" in Tableau\'s API.',
          action: 'Replace "dashboard" with "view" in the contentTypes array. Example: { contentTypes: ["view"] }'
        }
      );
    } else if (!VALID_CONTENT_TYPES.includes(contentType as any)) {
      addStructuredIssue(
        ctx,
        ['filter', 'contentTypes', i],
        {
          summary: `Invalid content type: "${contentType}"`,
          detail: `"${contentType}" is not valid. Valid: view (dashboards), datasource, workbook, project, flow, lens, virtualconnection, collection, datarole, table, database`,
          action: `Replace "${contentType}" with a valid content type. Most common: "view" for dashboards/views, "datasource" for data sources`
        }
      );
    }
  }

  // v369: Check for "limits" field (similar to query-datasource validation)
  if (data.limits !== undefined) {
    addStructuredIssue(
      ctx,
      ['limits'],
      {
        summary: 'Use "limit" instead of "limits"',
        detail: 'The "limits" parameter is not supported. Use "limit" (singular) instead.',
        action: 'Change "limits" to "limit". Example: { limit: 10 }'
      }
    );
  }
})
.transform((data) => {
  // Strip any invalid fields that passed through
  const { limits, ...rest } = data;
  return rest;
});

export type SearchContentArgs = z.infer<typeof SearchContentArgsSchema>;

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// EXPORT CONTENT TYPES FOR USE IN OTHER MODULES
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export const CONTENT_TYPES = VALID_CONTENT_TYPES;
export type ContentType = z.infer<typeof ContentTypeSchema>;
