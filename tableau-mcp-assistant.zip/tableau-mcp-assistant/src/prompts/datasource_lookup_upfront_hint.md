
🚨 CRITICAL: User mentioned a datasource in their query

⚠️  MANDATORY WORKFLOW - You MUST follow these steps in order:

**STEP 1: Look up the datasource LUID**
  - Extract the datasource name from the user's question
  - Call: list-datasources({ filter: "name:eq:<datasource name>" })
  - Wait for the result and extract the LUID from it

**STEP 2: Use the LUID you just received**
  - get-datasource-metadata({ datasourceLuid: "<LUID from step 1>" })
  - query-datasource({ datasourceLuid: "<LUID from step 1>", query: {...} })

🔒 CRITICAL RULES:
  ❌ NEVER skip the list-datasources lookup step
  ❌ NEVER reuse a datasourceLuid from earlier in the conversation
  ❌ NEVER use a datasourceLuid without first calling list-datasources
  ✅ ALWAYS perform a fresh list-datasources lookup for EVERY datasource query
  ✅ Each new datasource query MUST start with list-datasources

⚠️  Even if you queried this datasource before, you MUST call list-datasources again
