
🚨 CRITICAL: User mentioned a workbook in their query

⚠️  MANDATORY WORKFLOW - You MUST follow these steps in order:

**STEP 1: Look up the workbook ID**
  - Extract the workbook name from the user's question
  - Call: list-workbooks({ filter: "name:eq:<workbook name>" })
  - Wait for the result and extract the workbook ID from it

**STEP 2: Use the workbook ID you just received**
  - get-workbook({ workbookId: "<ID from step 1>" })
  - list-views({ workbookId: "<ID from step 1>" })

🔒 CRITICAL RULES:
  ❌ NEVER skip the list-workbooks lookup step
  ❌ NEVER reuse a workbookId from earlier in the conversation
  ❌ NEVER use a workbookId without first calling list-workbooks
  ❌ NEVER make up or hallucinate workbook IDs
  ✅ ALWAYS perform a fresh list-workbooks lookup for EVERY workbook query
  ✅ Each new workbook query MUST start with list-workbooks

⚠️  Even if you queried this workbook before, you MUST call list-workbooks again
