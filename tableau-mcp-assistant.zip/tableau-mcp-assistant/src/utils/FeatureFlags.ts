/**
 * FeatureFlags - Gradual rollout system for new features
 *
 * This utility allows us to:
 * - Deploy new code with 0% traffic (shadow mode)
 * - Whitelist specific profiles for testing
 * - Gradually increase rollout percentage
 * - Instantly rollback by setting percentage to 0%
 *
 * Example usage:
 *   FeatureFlags.setRollout('USE_AGENT_EXECUTOR', 10); // Enable for 10% of traffic
 *   if (FeatureFlags.isEnabled('USE_AGENT_EXECUTOR', profileId)) {
 *     // Use new code path
 *   } else {
 *     // Use old code path
 *   }
 */

import { logger } from '../util/logger.js';
import crypto from 'crypto';

export class FeatureFlags {
  /**
   * Rollout percentages for each feature flag (0-100)
   * v377: Removed USE_AGENT_EXECUTOR and USE_AGENT_EXECUTOR_V3 - V3 is now the only code path
   */
  private static rolloutPercentages: Record<string, number> = {
    // Add future feature flags here
  };

  /**
   * Whitelist of profile IDs that should always see the feature
   * Format: { flagName: Set<profileId> }
   */
  private static whitelists: Record<string, Set<string>> = {
    // Add future feature flag whitelists here
  };

  /**
   * Check if a feature flag is enabled for a given profile
   *
   * Logic:
   * 1. If profile is whitelisted → return true
   * 2. Otherwise, use consistent hash-based rollout
   *    (same profile always gets same result for stability)
   */
  static isEnabled(flag: string, profileId?: string): boolean {
    const percentage = this.rolloutPercentages[flag] ?? 0;

    // Feature disabled globally
    if (percentage === 0) {
      return false;
    }

    // Feature enabled globally
    if (percentage === 100) {
      return true;
    }

    // Check whitelist
    if (profileId && this.isWhitelisted(flag, profileId)) {
      return true;
    }

    // Percentage-based rollout using consistent hashing
    const hash = this.hashProfileId(profileId || 'default');
    const enabled = (hash % 100) < percentage;

    return enabled;
  }

  /**
   * Set rollout percentage for a feature flag
   */
  static setRollout(flag: string, percentage: number): void {
    // Clamp to 0-100
    const clamped = Math.min(100, Math.max(0, percentage));

    this.rolloutPercentages[flag] = clamped;

    logger.info(`[FEATURE-FLAG] ${flag} rollout set to ${clamped}%`, {
      flag,
      percentage: clamped,
    });
  }

  /**
   * Get current rollout percentage for a flag
   */
  static getRollout(flag: string): number {
    return this.rolloutPercentages[flag] ?? 0;
  }

  /**
   * Add a profile to the whitelist for a feature
   */
  static addToWhitelist(flag: string, profileId: string): void {
    if (!this.whitelists[flag]) {
      this.whitelists[flag] = new Set<string>();
    }

    this.whitelists[flag].add(profileId);

    logger.info(`[FEATURE-FLAG] Added ${profileId} to ${flag} whitelist`, {
      flag,
      profileId,
    });
  }

  /**
   * Remove a profile from the whitelist
   */
  static removeFromWhitelist(flag: string, profileId: string): void {
    if (this.whitelists[flag]) {
      this.whitelists[flag].delete(profileId);

      logger.info(`[FEATURE-FLAG] Removed ${profileId} from ${flag} whitelist`, {
        flag,
        profileId,
      });
    }
  }

  /**
   * Check if a profile is whitelisted for a feature
   */
  static isWhitelisted(flag: string, profileId: string): boolean {
    return this.whitelists[flag]?.has(profileId) ?? false;
  }

  /**
   * Get all whitelisted profiles for a flag
   */
  static getWhitelist(flag: string): string[] {
    return Array.from(this.whitelists[flag] ?? []);
  }

  /**
   * Hash a profile ID to a consistent number 0-99
   * Same profile ID always produces the same hash
   */
  private static hashProfileId(profileId: string): number {
    const hash = crypto.createHash('md5').update(profileId).digest('hex');
    // Take first 8 characters and convert to number
    const num = parseInt(hash.substring(0, 8), 16);
    return num % 100;
  }

  /**
   * Get status of all feature flags
   */
  static getStatus(): Record<string, any> {
    const status: Record<string, any> = {};

    for (const [flag, percentage] of Object.entries(this.rolloutPercentages)) {
      status[flag] = {
        percentage,
        whitelist: this.getWhitelist(flag),
      };
    }

    return status;
  }

  /**
   * Expose a test method for checking hash distribution
   * (useful for verifying consistent hashing works correctly)
   */
  static _testHashDistribution(sampleSize: number = 1000): Record<number, number> {
    const distribution: Record<number, number> = {};

    for (let i = 0; i < sampleSize; i++) {
      const hash = this.hashProfileId(`test-profile-${i}`);
      distribution[hash] = (distribution[hash] || 0) + 1;
    }

    return distribution;
  }
}
