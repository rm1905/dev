/**
 * Runtime validation utilities for tool arguments
 * Provides type-safe validation with detailed error messages for LLM self-correction
 * v197: Initial implementation for query-datasource only
 * v367: Added structured error extraction for UI display
 */

import { z, ZodError } from 'zod';
import {
  QueryDatasourceArgsSchema,
  type QueryDatasourceArgs,
} from '../schemas/vds-schemas.js';
import {
  SearchContentArgsSchema,
  type SearchContentArgs,
} from '../schemas/search-content-schemas.js';
import {
  ListPulseMetricDefinitionsArgsSchema,
  type ListPulseMetricDefinitionsArgs,
  ListAllPulseMetricDefinitionsArgsSchema,
  type ListAllPulseMetricDefinitionsArgs,
} from '../schemas/pulse-tool-schemas.js';
import { extractErrorSummaries } from '../schemas/validation-errors.js';

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// VALIDATION ERROR CLASS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Custom error class for validation failures
 * Allows broker to distinguish validation errors from other errors
 * and trigger lightweight repair context instead of full context retry
 *
 * v367: Added errorSummaries for UI display
 */
export class ValidationError extends Error {
  constructor(
    message: string,
    public readonly errors: Array<{ path: string; message: string }>,
    public readonly invalidArgs: unknown,
    public readonly errorSummaries?: string[] // v367: Concise summaries for UI
  ) {
    super(message);
    this.name = 'ValidationError';
  }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// VALIDATION RESULT TYPE
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export type ValidationResult<T> =
  | {
      success: true;
      data: T;
    }
  | {
      success: false;
      errors: Array<{
        path: string;
        message: string;
      }>;
      summary: string; // Detailed error message for LLM
      errorSummaries: string[]; // v367: Concise summaries for UI display
      validationError: ValidationError;
    };

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// QUERY-DATASOURCE VALIDATION
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Validates query-datasource tool arguments at runtime
 *
 * Returns typed data if validation succeeds, or detailed errors for LLM self-correction
 *
 * @param args - Raw arguments from LLM tool call
 * @returns ValidationResult with typed data or detailed errors
 *
 * @example
 * const validation = validateQueryDatasourceArgs(args);
 * if (!validation.success) {
 *   // Send errors back to LLM for self-correction
 *   return { error: validation.summary };
 * }
 * // Use fully typed args
 * const { datasourceLuid, query } = validation.data;
 */
export function validateQueryDatasourceArgs(
  args: unknown
): ValidationResult<QueryDatasourceArgs> {
  try {
    // Parse and validate using Zod schema
    const validatedData = QueryDatasourceArgsSchema.parse(args);

    return {
      success: true,
      data: validatedData,
    };
  } catch (error) {
    if (error instanceof ZodError) {
      // Transform Zod errors into LLM-friendly format
      const errors = error.errors.map((err) => ({
        path: err.path.join('.') || 'root',
        message: err.message,
      }));

      // Enhanced error context for filter validation failures
      const argsObj = args as any;

      // Create a concise summary for LLM with enhanced context
      const summary = formatValidationErrorsForLLM(errors, argsObj);

      // v367: Extract concise error summaries for UI display
      const errorSummaries = extractErrorSummaries(error);

      // v367: Create ValidationError instance with errorSummaries for UI display
      const validationError = new ValidationError(summary, errors, args, errorSummaries);

      return {
        success: false,
        errors,
        summary,
        errorSummaries, // v367: Include structured summaries for UI
        validationError,
      };
    }

    // Unexpected error - re-throw
    throw error;
  }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ERROR FORMATTING FOR LLM
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Formats validation errors into LLM-friendly message for self-correction
 *
 * @param errors - Array of validation errors
 * @param args - Original args object for enhanced diagnostics
 * @returns Human-readable error summary with actionable guidance
 */
function formatValidationErrorsForLLM(
  errors: Array<{ path: string; message: string }>,
  args?: any
): string {
  const header = '❌ **VALIDATION ERROR** - Your query-datasource arguments are invalid:\n\n';

  // Enhanced diagnostics for filter, field, and query-level errors
  const filterErrors = errors.filter((err) => err.path.startsWith('query.filters.'));
  const fieldErrors = errors.filter((err) => err.path.startsWith('query.fields.'));
  const queryErrors = errors.filter((err) => err.path === 'query' && (err.message.includes('sortDirection') || err.message.includes('sortPriority')));
  const sortsArrayError = errors.find((err) => err.path === 'query.sorts');
  // v352: TOP filter at query level error
  const topFilterError = errors.find((err) => err.path === 'query.filterType' || (err.path === 'query' && err.message.includes('TOP filter properties')));
  let diagnostics = '';

  // Show "sorts" array error (common mistake)
  if (sortsArrayError) {
    diagnostics += '**🚨 CRITICAL ERROR - YOU CREATED A "sorts" ARRAY:**\n\n';
    diagnostics += `**ERROR:** ${sortsArrayError.message}\n\n`;
    diagnostics += '❌ **WRONG** (separate "sorts" array):\n';
    diagnostics += '```json\n';
    diagnostics += '{\n';
    diagnostics += '  "fields": [\n';
    diagnostics += '    { "fieldCaption": "Outstanding Amount" }\n';
    diagnostics += '  ],\n';
    diagnostics += '  "sorts": [\n';
    diagnostics += '    { "fieldCaption": "Outstanding Amount", "sortDirection": "DESC", "sortPriority": 1 }\n';
    diagnostics += '  ]\n';
    diagnostics += '}\n';
    diagnostics += '```\n\n';
    diagnostics += '✅ **CORRECT** (sort properties inside the EXISTING field object):\n';
    diagnostics += '```json\n';
    diagnostics += '{\n';
    diagnostics += '  "fields": [\n';
    diagnostics += '    { "fieldCaption": "Outstanding Amount", "sortDirection": "DESC", "sortPriority": 1 }\n';
    diagnostics += '  ]\n';
    diagnostics += '}\n';
    diagnostics += '```\n\n';
    diagnostics += '**KEY POINT:** Add sortDirection and sortPriority as PROPERTIES of the field object in the "fields" array.\n';
    diagnostics += 'Do NOT create a separate "sorts" array!\n\n';
  }

  // v352: Show TOP filter at query level error (common mistake)
  if (topFilterError) {
    diagnostics += '**🚨 CRITICAL ERROR - TOP FILTER PROPERTIES AT QUERY LEVEL:**\n\n';
    diagnostics += `**ERROR:** ${topFilterError.message}\n\n`;
  }

  // Show query-level errors (sorting schema)
  if (queryErrors.length > 0) {
    diagnostics += '**YOUR QUERY STRUCTURE IS INCORRECT:**\n\n';
    queryErrors.forEach((err) => {
      diagnostics += `**ERROR:** ${err.message}\n\n`;
      diagnostics += '❌ **WRONG** (sortDirection/sortPriority at query level):\n';
      diagnostics += '```json\n';
      diagnostics += '{\n';
      diagnostics += '  "fields": [\n';
      diagnostics += '    { "fieldCaption": "Invoice Date" },\n';
      diagnostics += '    { "fieldCaption": "Invoice Amount" }\n';
      diagnostics += '  ],\n';
      diagnostics += '  "sortDirection": "DESC",\n';
      diagnostics += '  "sortPriority": 1\n';
      diagnostics += '}\n';
      diagnostics += '```\n\n';
      diagnostics += '✅ **CORRECT** (sortDirection/sortPriority inside field objects):\n';
      diagnostics += '```json\n';
      diagnostics += '{\n';
      diagnostics += '  "fields": [\n';
      diagnostics += '    { "fieldCaption": "Invoice Date", "sortPriority": 1, "sortDirection": "DESC" },\n';
      diagnostics += '    { "fieldCaption": "Invoice Amount" }\n';
      diagnostics += '  ]\n';
      diagnostics += '}\n';
      diagnostics += '```\n\n';
    });
  }

  // Show field errors
  if (fieldErrors.length > 0 && args?.query?.fields) {
    diagnostics += '**YOUR FIELD(S) WITH ERRORS:**\n';
    fieldErrors.forEach((err) => {
      const match = err.path.match(/query\.fields\.(\d+)/);
      if (match) {
        const fieldIdx = parseInt(match[1], 10);
        const field = args.query.fields[fieldIdx];
        diagnostics += `\nField #${fieldIdx + 1} (INVALID):\n\`\`\`json\n${JSON.stringify(field, null, 2)}\n\`\`\`\n`;
        diagnostics += `**ERROR:** ${err.message}\n\n`;
      }
    });
    diagnostics += '\n';
  }

  // Show filter errors
  if (filterErrors.length > 0 && args?.query?.filters) {
    diagnostics += '**YOUR FILTER(S) WITH ERRORS:**\n';
    filterErrors.forEach((err) => {
      const match = err.path.match(/query\.filters\.(\d+)/);
      if (match) {
        const filterIdx = parseInt(match[1], 10);
        const filter = args.query.filters[filterIdx];
        diagnostics += `\nFilter #${filterIdx + 1} (INVALID):\n\`\`\`json\n${JSON.stringify(filter, null, 2)}\n\`\`\`\n`;

        // Diagnose what's wrong
        if (filter) {
          // v209.1: Pass errors context to detect pairing issues
          diagnostics += diagnoseFilterError(filter, errors, args);
        }
      }
    });
    diagnostics += '\n';
  }

  const errorList = errors
    .map((err) => {
      // Special handling for common error patterns
      if (err.path.includes('filterType')) {
        return `  • ${err.path}: ${err.message}\n    → Must be one of: SET, MATCH, QUANTITATIVE_NUMERICAL, QUANTITATIVE_DATE, DATE, TOP`;
      }

      if (err.path.includes('periodType') || err.path.includes('dateRangeType')) {
        return `  • ${err.path}: ${err.message}\n    → DATE filters REQUIRE both periodType and dateRangeType. For absolute date boundaries, use QUANTITATIVE_DATE filter type instead.`;
      }

      if (err.path.includes('field') && err.message.includes('either field or column')) {
        return `  • ${err.path}: ${err.message}\n    → Filters must have either 'field' or 'column' property`;
      }

      if (err.path.includes('fields') && err.message.includes('at least one')) {
        return `  • ${err.path}: ${err.message}\n    → Your query must include at least one field`;
      }

      // Default formatting
      return `  • ${err.path}: ${err.message}`;
    })
    .join('\n');

  // Build conditional footer based on error types
  let footer = '';

  // If there's a "sorts" array error, provide specific guidance
  if (sortsArrayError) {
    footer += `\n\n**🚨 CRITICAL - DELETE THE "sorts" ARRAY:**\n` +
      `1. Remove the entire "sorts" array from your query\n` +
      `2. Add sortDirection and sortPriority as properties to the field objects in the "fields" array\n` +
      `3. Review the CORRECT example above showing the field object with sort properties\n\n`;
  }

  // v352: If there's a TOP filter at query level error, provide specific guidance
  if (topFilterError) {
    footer += `\n\n**🚨 CRITICAL - MOVE TOP FILTER TO FILTERS ARRAY:**\n` +
      `1. Remove filterType, howMany, fieldToMeasure, direction from the query level\n` +
      `2. Create a new filter object inside the "filters" array\n` +
      `3. Add the "field" property specifying which dimension to filter\n` +
      `4. Move all TOP filter properties into this filter object\n` +
      `5. Review the CORRECT example above showing the proper filter structure\n\n`;
  }

  // If there are query-level sort errors, provide sort-specific guidance
  if (queryErrors.length > 0) {
    footer += `\n\n**🚨 CRITICAL - FIX YOUR SORTING FIRST:**\n` +
      `You MUST move sortDirection and sortPriority INSIDE the field objects.\n` +
      `Review the WRONG vs CORRECT examples above and fix your query structure.\n\n`;
  }

  // If there are filter errors, provide filter-specific guidance
  if (filterErrors.length > 0) {
    footer += `\n\n**ACTION REQUIRED FOR FILTERS:**\n` +
      `1. Review the filter structure above\n` +
      `2. Fix the filter to match one of the 6 valid filter types\n` +
      `3. Retry the tool call with corrected arguments\n\n` +
      `**VALID FILTER TYPES:**\n` +
      `• SET: { filterType: "SET", field: {...}, values: [...] }\n` +
      `• MATCH: { filterType: "MATCH", field: {...}, startsWith: "A", endsWith: "a", contains: "o" } (need at least one of: startsWith, endsWith, contains)\n` +
      `• QUANTITATIVE_NUMERICAL: { filterType: "QUANTITATIVE_NUMERICAL", field: { fieldCaption: "Sales", function: "SUM" }, quantitativeFilterType: "MIN", min: 10000 }\n` +
      `• QUANTITATIVE_DATE: { filterType: "QUANTITATIVE_DATE", field: {...}, quantitativeFilterType: "RANGE", minDate: "YYYY-MM-DD", maxDate: "YYYY-MM-DD" } (use with QUANTITATIVE_NUMERICAL; replace YYYY-MM-DD with actual dates from user's question)\n` +
      `• DATE: { filterType: "DATE", field: {...}, periodType: "YEARS", dateRangeType: "CURRENT" } (for relative date periods)\n` +
      `• TOP: { filterType: "TOP", field: {...}, howMany: 10, direction: "TOP", fieldToMeasure: {...} }`;
  }

  // If there are field errors, provide field-specific guidance
  if (fieldErrors.length > 0) {
    footer += `\n\n**ACTION REQUIRED FOR FIELDS:**\n` +
      `1. Review the field structure above\n` +
      `2. Fix the field properties according to the error messages\n` +
      `3. If adding sort properties, ensure sortDirection and sortPriority are:\n` +
      `   a) Inside field objects (NOT at query level)\n` +
      `   b) In the SPECIFIC field the user asked to sort by\n` +
      `   Example: User says "sort by outstanding amount" → Add sortDirection/sortPriority to the field with fieldCaption: "Outstanding Amount" (NOT to Invoice Date or any other field)`;
  }

  // If no specific errors were categorized, provide generic guidance
  if (footer === '') {
    footer = `\n\n**ACTION REQUIRED:**\n` +
      `1. Review the error messages above\n` +
      `2. Fix the issues according to the guidance provided\n` +
      `3. Retry the tool call with corrected arguments`;
  }

  return header + diagnostics + errorList + footer;
}

/**
 * Diagnose what's wrong with a filter that failed validation
 *
 * @param filter - The filter object that failed validation
 * @param errors - Array of all validation errors (to detect pairing issues)
 * @param args - Original args object (to check for QUANTITATIVE_NUMERICAL presence)
 */
function diagnoseFilterError(filter: any, errors?: Array<{ path: string; message: string }>, args?: any): string {
  let diagnosis = '**DIAGNOSIS:**\n';

  // Check filterType
  if (!filter.filterType) {
    diagnosis += '  ❌ Missing required field: filterType\n';
  } else if (!['SET', 'MATCH', 'QUANTITATIVE_NUMERICAL', 'QUANTITATIVE_DATE', 'DATE', 'TOP'].includes(filter.filterType)) {
    diagnosis += `  ❌ Invalid filterType: "${filter.filterType}" (must be one of: SET, MATCH, QUANTITATIVE_NUMERICAL, QUANTITATIVE_DATE, DATE, TOP)\n`;
  }

  // Check field/column
  if (!filter.field && !filter.column) {
    diagnosis += '  ❌ Missing field or column reference\n';
  }

  // Type-specific checks
  if (filter.filterType === 'QUANTITATIVE_DATE') {
    if (!filter.quantitativeFilterType) {
      diagnosis += '  ❌ QUANTITATIVE_DATE filter missing required field: quantitativeFilterType (must be "MIN", "MAX", or "RANGE")\n';
    }
    if (!filter.minDate && !filter.maxDate) {
      diagnosis += '  ❌ QUANTITATIVE_DATE filter missing required field: must have at least minDate or maxDate\n';
    }
    // v208: Check for RANGE type requirements
    if (filter.quantitativeFilterType === 'RANGE' && (!filter.minDate || !filter.maxDate)) {
      diagnosis += '  ❌ QUANTITATIVE_DATE with "RANGE" requires BOTH minDate and maxDate\n';
    }
    if (filter.periodType || filter.dateRangeType) {
      diagnosis += '  ❌ QUANTITATIVE_DATE filter has periodType/dateRangeType (these belong to DATE filter type instead)\n';
    }
  }

  if (filter.filterType === 'DATE') {
    if (!filter.periodType) {
      diagnosis += '  ❌ DATE filter missing required field: periodType\n';
    }
    if (!filter.dateRangeType) {
      diagnosis += '  ❌ DATE filter missing required field: dateRangeType\n';
    }
    if ((filter.dateRangeType === 'LASTN' || filter.dateRangeType === 'NEXTN') && !filter.rangeN) {
      diagnosis += '  ❌ LASTN/NEXTN requires rangeN field\n';
    }
    if (filter.minDate || filter.maxDate) {
      diagnosis += '  ❌ DATE filter has minDate/maxDate (these belong to QUANTITATIVE_DATE filter type instead)\n';
    }
  }

  if (filter.filterType === 'SET') {
    if (!filter.values || !Array.isArray(filter.values)) {
      diagnosis += '  ❌ SET filter missing required field: values (must be an array)\n';
    }
    // Check if SET filter is being used on a date field
    const fieldCaption = filter.field?.fieldCaption || filter.column?.fieldCaption;
    if (fieldCaption) {
      const fieldName = fieldCaption.toLowerCase();
      const isDateField = fieldName.includes('date') ||
                         fieldName.includes('datetime') ||
                         fieldName.includes('timestamp') ||
                         fieldName.includes('time') ||
                         fieldName === 'year' ||
                         fieldName === 'month' ||
                         fieldName === 'day';
      if (isDateField) {
        diagnosis += '  ❌ SET filter cannot be used on date fields\n';
        diagnosis += '  ⚠️  Date fields must use DATE or QUANTITATIVE_DATE filter types\n';
      }
    }
  }

  if (filter.filterType === 'MATCH') {
    if (!filter.startsWith && !filter.endsWith && !filter.contains) {
      diagnosis += '  ❌ MATCH filter requires at least one of: startsWith, endsWith, or contains\n';
    }
    // Check if MATCH filter is being used on a date field
    const fieldCaption = filter.field?.fieldCaption || filter.column?.fieldCaption;
    if (fieldCaption) {
      const fieldName = fieldCaption.toLowerCase();
      const isDateField = fieldName.includes('date') ||
                         fieldName.includes('datetime') ||
                         fieldName.includes('timestamp') ||
                         fieldName.includes('time') ||
                         fieldName === 'year' ||
                         fieldName === 'month' ||
                         fieldName === 'day';
      if (isDateField) {
        diagnosis += '  ❌ MATCH filter cannot be used on date fields\n';
        diagnosis += '  ⚠️  Date fields must use DATE or QUANTITATIVE_DATE filter types\n';
      }
    }
  }

  // v209: QUANTITATIVE_NUMERICAL filter checks (reverted to use field)
  if (filter.filterType === 'QUANTITATIVE_NUMERICAL') {
    // Check 1: Missing quantitativeFilterType
    if (!filter.quantitativeFilterType) {
      diagnosis += '  ❌ QUANTITATIVE_NUMERICAL filter missing required field: quantitativeFilterType (must be "MIN" or "MAX")\n';
    }

    // Check 2: Missing both min and max
    if (filter.min === undefined && filter.max === undefined) {
      diagnosis += '  ❌ QUANTITATIVE_NUMERICAL filter missing required field: must have at least min or max\n';
    }
  }

  if (filter.filterType === 'TOP' && !filter.howMany) {
    diagnosis += '  ❌ TOP filter missing required field: howMany\n';
  }

  diagnosis += '\n**FIX:**\n';

  // v209.1: Detect pairing errors - check if QUANTITATIVE_NUMERICAL is present in the query
  const isPairingError = errors?.some((err) =>
    err.message.includes('QUANTITATIVE_NUMERICAL') && err.message.includes('QUANTITATIVE_DATE')
  ) || args?.query?.filters?.some((f: any) => f.filterType === 'QUANTITATIVE_NUMERICAL');

  // Provide specific fix guidance
  const fieldCaption = filter.field?.fieldCaption || filter.column?.fieldCaption;
  const isDateField = fieldCaption && (
    fieldCaption.toLowerCase().includes('date') ||
    fieldCaption.toLowerCase().includes('datetime') ||
    fieldCaption.toLowerCase().includes('timestamp') ||
    fieldCaption.toLowerCase().includes('time') ||
    fieldCaption.toLowerCase() === 'year' ||
    fieldCaption.toLowerCase() === 'month' ||
    fieldCaption.toLowerCase() === 'day'
  );

  if ((filter.filterType === 'SET' || filter.filterType === 'MATCH') && isDateField) {
    diagnosis += '  ✅ For date fields, use DATE filter (relative/period-based):\n';
    diagnosis += '  ```json\n';
    diagnosis += '  {\n';
    diagnosis += `    "filterType": "DATE",\n`;
    diagnosis += `    "field": { "fieldCaption": "${fieldCaption}" },\n`;
    diagnosis += '    "periodType": "YEARS",\n';
    diagnosis += '    "dateRangeType": "CURRENT"\n';
    diagnosis += '  }\n';
    diagnosis += '  ```\n';
    diagnosis += '  ✅ Or use QUANTITATIVE_DATE filter (absolute date boundaries):\n';
    diagnosis += '  ```json\n';
    diagnosis += '  {\n';
    diagnosis += '    "filterType": "QUANTITATIVE_DATE",\n';
    diagnosis += `    "field": { "fieldCaption": "${fieldCaption}" },\n`;
    diagnosis += '    "quantitativeFilterType": "MAX",\n';
    diagnosis += '    "maxDate": "2020-04-01"\n';
    diagnosis += '  }\n';
    diagnosis += '  ```\n';
  } else if (filter.filterType === 'QUANTITATIVE_DATE') {
    diagnosis += '  ✅ For QUANTITATIVE_DATE filters (absolute date boundaries), use this structure:\n';
    diagnosis += '  ```json\n';
    diagnosis += '  {\n';
    diagnosis += '    "filterType": "QUANTITATIVE_DATE",\n';
    diagnosis += '    "field": { "fieldCaption": "Order Date" },\n';
    diagnosis += '    "quantitativeFilterType": "MAX",\n';
    diagnosis += '    "maxDate": "2020-04-01"\n';
    diagnosis += '  }\n';
    diagnosis += '  ```\n';
  } else if (filter.filterType === 'DATE') {
    // v209.1: Check for pairing error - show QUANTITATIVE_DATE guidance instead of DATE guidance
    if (isPairingError) {
      diagnosis += '  ✅ When using QUANTITATIVE_NUMERICAL filters, use QUANTITATIVE_DATE for date filters:\n';
      diagnosis += '  ```json\n';
      diagnosis += '  {\n';
      diagnosis += '    "filterType": "QUANTITATIVE_DATE",\n';
      diagnosis += `    "field": { "fieldCaption": "${fieldCaption || 'Order Date'}" },\n`;
      diagnosis += '    "quantitativeFilterType": "RANGE",\n';
      diagnosis += '    "minDate": "YYYY-MM-DD",\n';
      diagnosis += '    "maxDate": "YYYY-MM-DD"\n';
      diagnosis += '  }\n';
      diagnosis += '  ```\n';
      diagnosis += '  ⚠️  IMPORTANT: Replace YYYY-MM-DD with actual dates from the USER\'S ORIGINAL QUESTION (e.g., if user asked for "year 2026", use minDate: "2026-01-01", maxDate: "2026-12-31")\n';
      diagnosis += '  ⚠️  DO NOT use DATE filter (with periodType/dateRangeType) when filtering measures\n';
    } else {
      diagnosis += '  ✅ For DATE filters (relative/period-based), use this structure:\n';
      diagnosis += '  ```json\n';
      diagnosis += '  {\n';
      diagnosis += '    "filterType": "DATE",\n';
      diagnosis += '    "field": { "fieldCaption": "Order Date" },\n';
      diagnosis += '    "periodType": "YEARS",\n';
      diagnosis += '    "dateRangeType": "CURRENT"\n';
      diagnosis += '  }\n';
      diagnosis += '  ```\n';
      diagnosis += '  ✅ Or with rangeN for LASTN/NEXTN:\n';
      diagnosis += '  ```json\n';
      diagnosis += '  {\n';
      diagnosis += '    "filterType": "DATE",\n';
      diagnosis += '    "field": { "fieldCaption": "Order Date" },\n';
      diagnosis += '    "periodType": "MONTHS",\n';
      diagnosis += '    "dateRangeType": "LASTN",\n';
      diagnosis += '    "rangeN": 3\n';
      diagnosis += '  }\n';
      diagnosis += '  ```\n';
    }
  } else if (isDateField) {
    diagnosis += '  ✅ For DATE filters (relative/period-based), use this structure:\n';
    diagnosis += '  ```json\n';
    diagnosis += '  {\n';
    diagnosis += '    "filterType": "DATE",\n';
    diagnosis += '    "field": { "fieldCaption": "Order Date" },\n';
    diagnosis += '    "periodType": "YEARS",\n';
    diagnosis += '    "dateRangeType": "CURRENT"\n';
    diagnosis += '  }\n';
    diagnosis += '  ```\n';
  } else {
    diagnosis += `  ✅ Ensure your filter matches one of the 6 valid structures (see examples below)\n`;
  }

  return diagnosis;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// DATE FILTER ERROR RECOVERY HINT
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Build comprehensive recovery hint for DATE filter errors
 * Provides complete guidance when LLM fails with date queries
 *
 * @param errorInfo - Object containing safeForModel error and original args
 * @returns Recovery hint string or null if not a date filter error
 *
 * @example
 * const hint = buildDateFilterRecoveryHint({
 *   safeForModel: { status: 'error', error: 'Invalid date filter' },
 *   args: { datasourceLuid: '123', query: {...} }
 * });
 * if (hint) {
 *   // Send hint back to LLM for self-correction
 * }
 */
export function buildDateFilterRecoveryHint(errorInfo: {
  safeForModel: any;
  args: Record<string, unknown>;
}): string | null {
  const { safeForModel, args } = errorInfo || {};

  // Check if this is actually an error (support both formats)
  const isError = safeForModel &&
                  typeof safeForModel === 'object' &&
                  ((safeForModel as any).status === 'error' || (safeForModel as any).error);

  if (!isError) return null;

  // Extract error message from BOTH formats
  const errMsg = (safeForModel as any).error_message ||
                 (safeForModel as any).error ||
                 (typeof safeForModel === 'string' ? safeForModel : JSON.stringify(safeForModel));

  const datasourceId = (args as any)?.datasourceId ||
                       (args as any)?.datasourceLuid ||
                       'the same datasource';

  return [
    'Your previous call to query-datasource failed due to incorrect DATE filter syntax.',
    '',
    `Error message: ${errMsg}`,
    '',
    '🗓️ **COMPLETE DATE FILTER GUIDE FOR RECOVERY:**',
    '',
    '**CRITICAL: anchorDate Rules (MOST COMMON MISTAKE)**',
    '✅ USE anchorDate for: Historical/past periods (specific dates in the past)',
    '   - "Show me 2020" → anchorDate: "2020-01-01"',
    '   - "Q1 2023" → anchorDate: "2023-01-01"',
    '   - "November 2025" → anchorDate: "2025-11-01"',
    '',
    '❌ NEVER USE anchorDate for: Current or recent relative periods',
    '   - "Last year" → NO anchorDate (automatically uses last COMPLETE year)',
    '   - "This year" → NO anchorDate (automatically uses current year)',
    '   - "Last 30 days" → NO anchorDate (automatically counts back from today)',
    '   - "Year to date" → NO anchorDate (TODATE always starts from period start to today)',
    '',
    '**DATE Filter Types:**',
    '',
    '1️⃣ **RELATIVE DATE FILTERS** (Most Common)',
    '   Required fields:',
    '   - filterType: "DATE" (always required)',
    '   - field: {"fieldCaption": "Order Date"} (use actual date field name)',
    '   - periodType: MINUTES, HOURS, DAYS, WEEKS, MONTHS, QUARTERS, or YEARS',
    '   - dateRangeType: CURRENT, LAST, NEXT, LASTN, NEXTN, or TODATE',
    '',
    '   dateRangeType options:',
    '   - CURRENT: Current complete period (this year, this month, this week)',
    '   - LAST: Last COMPLETE period (last year, last month, last week) - NO rangeN needed',
    '   - NEXT: Next complete period (next year, next month, next week) - NO rangeN needed',
    '   - LASTN: Last N periods (last 30 days, last 6 months) - REQUIRES rangeN field',
    '   - NEXTN: Next N periods (next 7 days, next 3 months) - REQUIRES rangeN field',
    '   - TODATE: From start of period to today (year to date, month to date) - NEVER use anchorDate',
    '',
    '**VALIDATED WORKING EXAMPLES (USE THESE PATTERNS):**',
    '',
    '✅ Historical date range (Jan 1 2020 - Mar 1 2020):',
    '   { "filterType": "DATE", "field": {"fieldCaption": "Order Date"}, "periodType": "MONTHS", "dateRangeType": "NEXTN", "rangeN": 3, "anchorDate": "2020-01-01" }',
    '',
    '✅ Full historical year (All of 2020):',
    '   { "filterType": "DATE", "field": {"fieldCaption": "Order Date"}, "periodType": "YEARS", "dateRangeType": "CURRENT", "anchorDate": "2020-01-01" }',
    '',
    '✅ Historical month (November 2025):',
    '   { "filterType": "DATE", "field": {"fieldCaption": "Order Date"}, "periodType": "MONTHS", "dateRangeType": "CURRENT", "anchorDate": "2025-11-01" }',
    '',
    '✅ Historical quarter (Q1 2020):',
    '   { "filterType": "DATE", "field": {"fieldCaption": "Order Date"}, "periodType": "MONTHS", "dateRangeType": "NEXTN", "rangeN": 3, "anchorDate": "2020-01-01" }',
    '',
    '✅ Last 30 days (relative, no anchor):',
    '   { "filterType": "DATE", "field": {"fieldCaption": "Order Date"}, "periodType": "DAYS", "dateRangeType": "LASTN", "rangeN": 30 }',
    '',
    '✅ Last year (relative, no anchor):',
    '   { "filterType": "DATE", "field": {"fieldCaption": "Order Date"}, "periodType": "YEARS", "dateRangeType": "LAST" }',
    '',
    '✅ This year (relative, no anchor):',
    '   { "filterType": "DATE", "field": {"fieldCaption": "Order Date"}, "periodType": "YEARS", "dateRangeType": "CURRENT" }',
    '',
    '✅ Year to date (YTD, no anchor):',
    '   { "filterType": "DATE", "field": {"fieldCaption": "Order Date"}, "periodType": "YEARS", "dateRangeType": "TODATE" }',
    '',
    '**QUERY PATTERN MAPPING (Common User Queries):**',
    '',
    '📅 "Show me 2020" / "2020 data"',
    '   → { periodType: "YEARS", dateRangeType: "CURRENT", anchorDate: "2020-01-01" }',
    '',
    '📅 "Q1 2020" / "First quarter 2020"',
    '   → { periodType: "MONTHS", dateRangeType: "NEXTN", rangeN: 3, anchorDate: "2020-01-01" }',
    '',
    '📅 "November 2025" / "Nov 2025"',
    '   → { periodType: "MONTHS", dateRangeType: "CURRENT", anchorDate: "2025-11-01" }',
    '',
    '📅 "Last year" / "Previous year"',
    '   → { periodType: "YEARS", dateRangeType: "LAST" } (NO anchorDate)',
    '',
    '📅 "This year" / "Current year"',
    '   → { periodType: "YEARS", dateRangeType: "CURRENT" } (NO anchorDate)',
    '',
    '📅 "Last 30 days" / "Past 30 days"',
    '   → { periodType: "DAYS", dateRangeType: "LASTN", rangeN: 30 } (NO anchorDate)',
    '',
    '📅 "Last 6 months"',
    '   → { periodType: "MONTHS", dateRangeType: "LASTN", rangeN: 6 } (NO anchorDate)',
    '',
    '📅 "Year to date" / "YTD"',
    '   → { periodType: "YEARS", dateRangeType: "TODATE" } (NO anchorDate, NEVER use anchorDate with TODATE)',
    '',
    '📅 "Month to date" / "MTD"',
    '   → { periodType: "MONTHS", dateRangeType: "TODATE" } (NO anchorDate)',
    '',
    '📅 "January 1 to March 31, 2024" / "Q1 2024 specific dates"',
    '   → { periodType: "MONTHS", dateRangeType: "NEXTN", rangeN: 3, anchorDate: "2024-01-01" }',
    '',
    '**RECOVERY WORKFLOW:**',
    `1. Review the error message and identify which date filter fields were incorrect.`,
    `2. Determine if the user's query refers to a HISTORICAL period (specific past date) or RELATIVE period (relative to today).`,
    `3. Choose the correct pattern from the examples above based on the user's query.`,
    `4. Re-issue query-datasource for ${datasourceId} with the corrected DATE filter.`,
    `5. Only after successful query, answer the user with the results.`,
    '',
    'Do NOT stop with a failure message. Use the correct DATE filter pattern and retry.',
  ].join('\n');
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// SAFE PARSE HELPER (Non-throwing alternative)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Safe parse wrapper - never throws, always returns result
 * Alternative to validate* functions when you prefer explicit checking
 *
 * @example
 * const result = safeParseQueryDatasourceArgs(args);
 * if (result.success) {
 *   // Use result.data with full type safety
 * } else {
 *   // Handle result.errors
 * }
 */
export function safeParseQueryDatasourceArgs(
  args: unknown
): z.SafeParseReturnType<unknown, QueryDatasourceArgs> {
  return QueryDatasourceArgsSchema.safeParse(args);
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// SEARCH-CONTENT VALIDATION
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * Validates search-content tool arguments at runtime
 *
 * Returns typed data if validation succeeds, or detailed errors for LLM self-correction
 *
 * @param args - Raw arguments from LLM tool call
 * @returns ValidationResult with typed data or detailed errors
 *
 * @example
 * const validation = validateSearchContentArgs(args);
 * if (!validation.success) {
 *   // Send errors back to LLM for self-correction
 *   return { error: validation.summary };
 * }
 * // Use fully typed args
 * const { terms, filter, limit } = validation.data;
 */
export function validateSearchContentArgs(
  args: unknown
): ValidationResult<SearchContentArgs> {
  try {
    // Parse and validate using Zod schema
    const validatedData = SearchContentArgsSchema.parse(args);

    return {
      success: true,
      data: validatedData,
    };
  } catch (error) {
    if (error instanceof ZodError) {
      // Transform Zod errors into LLM-friendly format
      const errors = error.errors.map((err) => ({
        path: err.path.join('.') || 'root',
        message: err.message,
      }));

      // Create a concise summary for LLM with enhanced context
      const summary = formatSearchContentErrorsForLLM(errors, args as any);

      // v367: Extract concise error summaries for UI display
      const errorSummaries = extractErrorSummaries(error);

      // v367: Create ValidationError instance with errorSummaries for UI display
      const validationError = new ValidationError(summary, errors, args, errorSummaries);

      return {
        success: false,
        errors,
        summary,
        errorSummaries,
        validationError,
      };
    }

    // Unexpected error - re-throw
    throw error;
  }
}

/**
 * Formats search-content validation errors into LLM-friendly message for self-correction
 *
 * @param errors - Array of validation errors
 * @param args - Original args object for enhanced diagnostics
 * @returns Human-readable error summary with actionable guidance
 */
function formatSearchContentErrorsForLLM(
  errors: Array<{ path: string; message: string }>,
  args?: any
): string {
  const header = '❌ **VALIDATION ERROR** - Your search-content arguments are invalid:\n\n';

  // Check for specific common errors
  const contentTypesErrors = errors.filter((err) => err.path.includes('contentTypes'));
  const dashboardError = errors.find((err) => err.message.includes('dashboard'));
  const missingContentTypesError = errors.find((err) => err.message.includes('contentTypes filter is required'));
  const missingFilterError = errors.find((err) => err.path === 'filter' && err.message === 'Required');
  const limitsError = errors.find((err) => err.path === 'limits');

  let diagnostics = '';

  // Show dashboard content type error (most critical)
  if (dashboardError) {
    diagnostics += '**🚨 CRITICAL ERROR - INVALID CONTENT TYPE "dashboard":**\n\n';
    diagnostics += `${dashboardError.message}\n\n`;
  }

  // Show missing filter error (filter parameter not provided at all)
  if (missingFilterError) {
    diagnostics += '**🚨 CRITICAL ERROR - MISSING FILTER PARAMETER:**\n\n';
    diagnostics += '**The Problem:**\n';
    diagnostics += 'You did not provide the required "filter" parameter.\n\n';
    diagnostics += '**The Solution:**\n';
    diagnostics += 'The search-content tool REQUIRES a filter object with contentTypes array.\n\n';
    diagnostics += '❌ **WRONG**: search-content(terms: "sales", limit: 30)\n\n';
    diagnostics += '✅ **CORRECT**: search-content(terms: "sales", filter: { contentTypes: ["view"] }, limit: 30)\n\n';
    diagnostics += '**MANDATORY CONTENT TYPE MAPPINGS:**\n';
    diagnostics += '• User asks for "dashboard" or "dashboards" → USE: filter: { contentTypes: ["view"] }\n';
    diagnostics += '• User asks for "view" or "views" → USE: filter: { contentTypes: ["view"] }\n';
    diagnostics += '• User asks for "datasource" → USE: filter: { contentTypes: ["datasource"] }\n';
    diagnostics += '• User asks for "workbook" → USE: filter: { contentTypes: ["workbook"] }\n';
    diagnostics += '• User asks for "flow" → USE: filter: { contentTypes: ["flow"] }\n';
    diagnostics += '• User asks for "project" → USE: filter: { contentTypes: ["project"] }\n';
    diagnostics += '• Multiple types → USE: filter: { contentTypes: ["view", "workbook"] }\n\n';
    diagnostics += '🚨 REMEMBER: Dashboards are called "view" in Tableau\'s API, NOT "dashboard"!\n\n';
  }

  // Show missing contentTypes error
  if (missingContentTypesError) {
    diagnostics += '**🚨 CRITICAL ERROR - MISSING contentTypes FILTER:**\n\n';
    diagnostics += `${missingContentTypesError.message}\n\n`;
  }

  // Show "limits" error (singular vs plural)
  if (limitsError) {
    diagnostics += '**ERROR - INVALID "limits" PARAMETER:**\n\n';
    diagnostics += `${limitsError.message}\n\n`;
  }

  // Show all contentTypes errors if any remain
  if (contentTypesErrors.length > 0 && !dashboardError && !missingContentTypesError) {
    diagnostics += '**YOUR CONTENT TYPES WITH ERRORS:**\n\n';
    contentTypesErrors.forEach((err) => {
      diagnostics += `**Path:** ${err.path}\n`;
      diagnostics += `**Error:** ${err.message}\n\n`;
    });
  }

  // Show attempted values if available
  if (args?.filter?.contentTypes && Array.isArray(args.filter.contentTypes)) {
    diagnostics += `**YOUR ATTEMPTED contentTypes:**\n`;
    diagnostics += `\`\`\`json\n${JSON.stringify(args.filter.contentTypes, null, 2)}\n\`\`\`\n\n`;
  }

  const errorList = errors
    .map((err) => {
      // Special handling for common error patterns
      if (err.path.includes('contentTypes') && err.message.includes('Invalid enum')) {
        return `  • ${err.path}: ${err.message}`;
      }

      if (err.path === 'terms' && err.message.includes('required')) {
        return `  • ${err.path}: ${err.message}\n    → Search terms must be a non-empty string`;
      }

      if (err.path === 'filter' && err.message.includes('required')) {
        return `  • ${err.path}: ${err.message}\n    → Filter with contentTypes is required for search-content`;
      }

      // Default formatting
      return `  • ${err.path}: ${err.message}`;
    })
    .join('\n');

  // Build footer with specific guidance
  let footer = '';

  // If there's a dashboard error, provide specific guidance
  if (dashboardError) {
    footer += `\n\n**🚨 ACTION REQUIRED - FIX contentTypes:**\n` +
      `1. Replace "dashboard" with "view" in your contentTypes array\n` +
      `2. Remember: Dashboards are called "view" in Tableau's API\n` +
      `3. Retry the tool call with corrected contentTypes\n\n`;
  }

  // If filter is missing entirely, provide specific guidance
  if (missingFilterError) {
    footer += `\n\n**🚨 ACTION REQUIRED - ADD FILTER PARAMETER:**\n` +
      `1. Add the "filter" parameter with contentTypes array to your search-content call\n` +
      `2. Map user's request to correct content type (see mappings above)\n` +
      `3. Retry: search-content(terms: "sales", filter: { contentTypes: ["view"] }, limit: 30)\n\n`;
  }

  // If contentTypes is missing (but filter exists), provide specific guidance
  if (missingContentTypesError && !missingFilterError) {
    footer += `\n\n**🚨 ACTION REQUIRED - ADD contentTypes TO FILTER:**\n` +
      `1. Add contentTypes array inside your filter object\n` +
      `2. Choose appropriate content types based on user request\n` +
      `3. Example: search-content(terms: "sales", filter: { contentTypes: ["view"] }, limit: 30)\n\n`;
  }

  // If there are contentTypes errors, provide mapping guidance
  if (contentTypesErrors.length > 0) {
    footer += `\n\n**CONTENT TYPE MAPPING REFERENCE:**\n` +
      `• User asks for "dashboard" or "dashboards" → USE: contentTypes: ["view"]\n` +
      `• User asks for "view" or "views" → USE: contentTypes: ["view"]\n` +
      `• User asks for "datasource" → USE: contentTypes: ["datasource"]\n` +
      `• User asks for "workbook" → USE: contentTypes: ["workbook"]\n` +
      `• User asks for "flow" → USE: contentTypes: ["flow"]\n` +
      `• User asks for "project" → USE: contentTypes: ["project"]\n` +
      `• Multiple types → USE: contentTypes: ["view", "workbook"] (array with multiple values)\n\n` +
      `**Valid contentTypes:** lens, datasource, virtualconnection, collection, project, flow, datarole, table, database, view, workbook\n\n` +
      `**WORKING EXAMPLES:**\n` +
      `✅ search-content(terms: "sales", filter: { contentTypes: ["view"] }, limit: 30)\n` +
      `✅ search-content(terms: "revenue", filter: { contentTypes: ["datasource"] }, limit: 30)\n` +
      `✅ search-content(terms: "analytics", filter: { contentTypes: ["view", "datasource"] }, limit: 30)\n` +
      `❌ search-content(terms: "sales", filter: { contentTypes: ["dashboard"] }) // WRONG - use "view"\n` +
      `❌ search-content(terms: "sales", limit: 30) // WRONG - missing filter.contentTypes`;
  }

  // If no specific errors were categorized, provide generic guidance
  if (footer === '') {
    footer = `\n\n**ACTION REQUIRED:**\n` +
      `1. Review the error messages above\n` +
      `2. Fix the issues according to the guidance provided\n` +
      `3. Retry the tool call with corrected arguments`;
  }

  return header + diagnostics + errorList + footer;
}

/**
 * Safe parse wrapper for search-content - never throws, always returns result
 *
 * @example
 * const result = safeParseSearchContentArgs(args);
 * if (result.success) {
 *   // Use result.data with full type safety
 * } else {
 *   // Handle result.errors
 * }
 */
export function safeParseSearchContentArgs(
  args: unknown
): z.SafeParseReturnType<unknown, SearchContentArgs> {
  return SearchContentArgsSchema.safeParse(args);
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// PULSE TOOL VALIDATION (v302)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/**
 * v302: Validates list-pulse-metric-definitions-from-definition-ids tool arguments
 * Enforces DEFINITION_VIEW_FULL parameter to ensure metric names are retrieved
 *
 * @param args - Raw arguments from LLM tool call
 * @returns ValidationResult with typed data or detailed errors
 */
export function validatePulseMetricDefinitionsArgs(
  args: unknown
): ValidationResult<ListPulseMetricDefinitionsArgs> {
  try {
    const validatedData = ListPulseMetricDefinitionsArgsSchema.parse(args);

    return {
      success: true,
      data: validatedData,
    };
  } catch (error) {
    if (error instanceof ZodError) {
      const errors = error.errors.map((err) => ({
        path: err.path.join('.') || 'root',
        message: err.message,
      }));

      const summary = formatPulseMetricDefinitionsErrorsForLLM(errors, args);

      // v367: Extract concise error summaries for UI display
      const errorSummaries = extractErrorSummaries(error);

      return {
        success: false,
        errors,
        summary,
        errorSummaries,
        validationError: new ValidationError(
          summary, // v302 fix: Pass detailed summary as error message for LLM
          errors,
          args,
          errorSummaries // v367
        ),
      };
    }

    // Re-throw non-Zod errors
    throw error;
  }
}

/**
 * v302: Format Pulse metric definitions validation errors for LLM
 * Schema now includes detailed error messages, so we just need clean formatting
 */
function formatPulseMetricDefinitionsErrorsForLLM(
  errors: Array<{ path: string; message: string }>,
  args: any
): string {
  let output = '❌ **PULSE TOOL VALIDATION FAILED: list-pulse-metric-definitions-from-definition-ids**\n\n';

  // Add each error with its detailed message from schema
  errors.forEach((err, idx) => {
    output += `**Error ${idx + 1}: ${err.path}**\n${err.message}\n\n`;
  });

  // Add received args for context
  output += '**You provided:**\n';
  output += '```json\n' + JSON.stringify(args, null, 2) + '\n```\n\n';

  output += '**ACTION REQUIRED:**\n';
  output += 'Retry the tool call with the corrections specified above.';

  return output;
}

/**
 * v302: Validates list-all-pulse-metric-definitions tool arguments
 * Ensures view parameter is specified correctly
 *
 * @param args - Raw arguments from LLM tool call
 * @returns ValidationResult with typed data or detailed errors
 */
export function validateListAllPulseMetricDefinitionsArgs(
  args: unknown
): ValidationResult<ListAllPulseMetricDefinitionsArgs> {
  try {
    const validatedData = ListAllPulseMetricDefinitionsArgsSchema.parse(args);

    return {
      success: true,
      data: validatedData,
    };
  } catch (error) {
    if (error instanceof ZodError) {
      const errors = error.errors.map((err) => ({
        path: err.path.join('.') || 'root',
        message: err.message,
      }));

      const summary = '❌ **PULSE TOOL VALIDATION FAILED: list-all-pulse-metric-definitions**\n\n' +
        '**Errors Found:**\n' +
        errors.map((err, idx) => `${idx + 1}. **${err.path}**: ${err.message}`).join('\n') +
        '\n\n**Valid format:**\n' +
        '{ "view": "DEFINITION_VIEW_BASIC" } or { "view": "DEFINITION_VIEW_FULL" }';

      // v367: Extract concise error summaries for UI display
      const errorSummaries = extractErrorSummaries(error);

      return {
        success: false,
        errors,
        summary,
        errorSummaries,
        validationError: new ValidationError(
          summary, // v302 fix: Pass detailed summary as error message for LLM
          errors,
          args,
          errorSummaries // v367
        ),
      };
    }

    throw error;
  }
}
