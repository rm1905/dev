/**
 * Shared constants used across the application
 */

/**
 * Maximum number of rows to send to the LLM
 * Used for:
 * - get-view-data: Limit preview rows sent to model
 * - query-datasource: Limit preview rows sent to model
 * - evidence samples: Limit sample data in WebSocket messages
 * - search-content: Limit search results to 30 items
 * - list-datasources: Limit search results to 30 items
 * - list-workbooks: Limit search results to 30 items
 * - list-views: Limit search results to 30 items
 */
export const MAX_VIEW_ROWS_FOR_MODEL = 30;

/**
 * Maximum number of rows to display in UI preview
 * Used for:
 * - query-datasource: Show up to 100 rows in UI table
 * - get-view-data: Show up to 100 rows in UI table
 */
export const MAX_VIEW_ROWS_FOR_UI = 100;
