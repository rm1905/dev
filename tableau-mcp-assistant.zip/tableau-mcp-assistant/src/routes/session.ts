/**
 * Session management routes
 */

import { Router, Request, Response } from 'express';
import { SessionRequestSchema } from '../util/schema.js';
import { createSession } from '../ws/broker.js';
import { config } from '../util/env.js';
import { logger } from '../util/logger.js';
import { getDefaultModel } from '../llm/factory.js';

export const sessionRouter = Router();

sessionRouter.post('/session', async (req: Request, res: Response) => {
  try {
    // Validate request
    const parsed = SessionRequestSchema.parse(req.body);

    // Get settings for specified profile (or default)
    const profileName = parsed.profile || config.getDefaultProfile();
    const settings = await config.getSettings(profileName);

    // Determine LLM provider and model
    const provider = settings.LLM_PROVIDER || 'openai';
    const model = parsed.model || getDefaultModel(settings);

    logger.info(`Creating session with profile: ${profileName || 'default'}, provider: ${provider}, model: ${model}`);

    // Future: Add health checks for other providers here if needed

    // Create session with tableauUser (will be used only for Direct Trust auth)
    const sessionId = await createSession(
      model,
      parsed.temperature,
      parsed.system,
      profileName,
      parsed.tableauUser || null
    );

    logger.info(`Created session: ${sessionId} with profile: ${profileName || 'default'}`);

    return res.json({
      sessionId,
      wsUrl: `/broker/ws?sid=${sessionId}`,
      profile: profileName,
    });
  } catch (error) {
    logger.error('Session creation error', error);
    return res.status(400).json({
      error: error instanceof Error ? error.message : String(error),
    });
  }
});
