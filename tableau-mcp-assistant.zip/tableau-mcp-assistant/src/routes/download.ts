/**
 * Download routes - provides zip packages
 */

import { Router, Request, Response } from 'express';
import { readFileSync } from 'fs';
import { join } from 'path';
import archiver from 'archiver';
import { logger } from '../util/logger.js';

export const downloadRouter = Router();

// GET /download/tableau-extension - download extension package as zip
downloadRouter.get('/download/tableau-extension', (_req: Request, res: Response) => {
  try {
    logger.info('Tableau extension package download requested');

    // Set response headers for zip download
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="tableau-mcp-extension.zip"');

    // Create archiver instance
    const archive = archiver('zip', {
      zlib: { level: 9 } // Maximum compression
    });

    // Handle archiver errors
    archive.on('error', (err) => {
      logger.error('Archiver error', err);
      res.status(500).send({ error: 'Failed to create zip file' });
    });

    // Pipe archive data to response
    archive.pipe(res);

    // Add .trex file
    const trexPath = join(process.cwd(), 'src/public/tableau-mcp-extension.trex');
    const trexContent = readFileSync(trexPath, 'utf-8');
    archive.append(trexContent, { name: 'tableau-mcp-extension.trex' });
    logger.debug('Added .trex file to archive');

    // Add project README.md (always includes latest version)
    const readmePath = join(process.cwd(), 'README.md');
    const readmeContent = readFileSync(readmePath, 'utf-8');
    archive.append(readmeContent, { name: 'README.md' });
    logger.debug('Added README.md to archive');

    // Finalize the archive
    archive.finalize();
    logger.info('Tableau extension package download completed');

  } catch (error) {
    logger.error('Failed to generate download package', error);
    res.status(500).json({ error: 'Failed to generate download package' });
  }
});
