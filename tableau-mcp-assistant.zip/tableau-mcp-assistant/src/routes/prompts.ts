/**
 * Prompt Management API Routes
 * Provides REST API for managing system prompts
 */

import express, { Request, Response } from 'express';
import { promptManager } from '../util/PromptManager.js';
import { logger } from '../util/logger.js';
import { readFileSync } from 'fs';
import { join } from 'path';

export const promptsRouter = express.Router();

// Password check middleware for admin operations (v379)
function checkAdminPassword(_req: Request, res: Response, next: Function): void {
  const password = _req.body?.password || _req.query?.password;

  // Only admin password grants access to prompts management
  const adminPassword = 'AdminTableauMCP+';

  if (password === adminPassword) {
    (_req as any).isAdmin = true;
    next();
  } else {
    res.status(401).json({ error: 'Invalid password or insufficient permissions' });
    return;
  }
}

// GET /prompts - serve prompts UI page
promptsRouter.get('/prompts', (_req: Request, res: Response) => {
  try {
    const html = readFileSync(join(process.cwd(), 'src/public/prompts.html'), 'utf-8');
    res.setHeader('Content-Type', 'text/html');
    res.send(html);
  } catch (error) {
    logger.error('Failed to load prompts page', error);
    res.status(500).json({ error: 'Failed to load prompts page' });
  }
});

/**
 * POST /api/prompts/check-password - Validate password (v379)
 * Body: { password: string }
 * Accepts both admin and non-admin passwords
 */
promptsRouter.post('/api/prompts/check-password', async (req: Request, res: Response) => {
  try {
    const password = req.body?.password;
    const adminPassword = 'AdminTableauMCP+';
    const nonAdminPassword = 'TableauMCP2025!';

    if (password === adminPassword) {
      res.json({
        success: true,
        isAdmin: true,
        message: 'Admin access granted'
      });
    } else if (password === nonAdminPassword) {
      res.json({
        success: true,
        isAdmin: false,
        message: 'Access granted'
      });
    } else {
      res.status(401).json({
        success: false,
        isAdmin: false,
        error: 'Invalid password'
      });
    }
  } catch (error) {
    logger.error('[PromptAPI] Password check failed', error);
    res.status(500).json({
      success: false,
      error: 'Password check failed'
    });
  }
});

/**
 * GET /prompts - List all prompt sections
 */
promptsRouter.get('/api/prompts', async (_req, res) => {
  try {
    const sections = await promptManager.listSections();
    res.json({
      success: true,
      sections
    });
  } catch (error) {
    logger.error('[PromptAPI] Failed to list sections', error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to list sections'
    });
  }
});

/**
 * GET /prompts/variables - Get all variables
 * NOTE: Must come BEFORE /api/prompts/:name to avoid matching "variables" as a section name
 */
promptsRouter.get('/api/prompts/variables', async (_req, res) => {
  try {
    const variables = await promptManager.getVariables();

    res.json({
      success: true,
      variables
    });
  } catch (error) {
    logger.error('[PromptAPI] Failed to get variables', error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to get variables'
    });
  }
});

/**
 * POST /prompts/cache/invalidate - Invalidate cache
 * Body: { sectionName?: string }
 * NOTE: Must come BEFORE /api/prompts/:name
 */
promptsRouter.post('/api/prompts/cache/invalidate', async (req, res) => {
  try {
    const { sectionName } = req.body;

    promptManager.invalidateCache(sectionName);

    res.json({
      success: true,
      message: sectionName
        ? `Cache invalidated for section "${sectionName}"`
        : 'All cache invalidated'
    });
  } catch (error) {
    logger.error('[PromptAPI] Failed to invalidate cache', error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to invalidate cache'
    });
  }
});

/**
 * GET /prompts/cache/stats - Get cache statistics
 * NOTE: Must come BEFORE /api/prompts/:name
 */
promptsRouter.get('/api/prompts/cache/stats', async (_req, res) => {
  try {
    const stats = promptManager.getCacheStats();

    res.json({
      success: true,
      cache: stats
    });
  } catch (error) {
    logger.error('[PromptAPI] Failed to get cache stats', error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to get cache stats'
    });
  }
});

/**
 * GET /prompts/:name/preview - Get interpolated prompt (variables replaced with values)
 * NOTE: Must come BEFORE /api/prompts/:name to match more specific path first
 */
promptsRouter.get('/api/prompts/:name/preview', async (req, res) => {
  try {
    const { name } = req.params;
    const skipCache = req.query.skipCache === 'true';

    const interpolated = await promptManager.getSection(name, skipCache);

    res.json({
      success: true,
      section_name: name,
      interpolated,
      length: interpolated.length,
      cached: !skipCache
    });
  } catch (error) {
    logger.error(`[PromptAPI] Failed to preview section "${req.params.name}"`, error);
    res.status(404).json({
      success: false,
      error: error instanceof Error ? error.message : 'Section not found'
    });
  }
});

/**
 * GET /prompts/:name/versions - Get version history
 * NOTE: Must come BEFORE /api/prompts/:name
 */
promptsRouter.get('/api/prompts/:name/versions', async (req, res) => {
  try {
    const { name } = req.params;
    const limit = parseInt(req.query.limit as string) || 20;

    const versions = await promptManager.getVersionHistory(name, limit);

    res.json({
      success: true,
      section_name: name,
      versions
    });
  } catch (error) {
    logger.error(`[PromptAPI] Failed to get version history for "${req.params.name}"`, error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to get version history'
    });
  }
});

/**
 * POST /prompts/:name/rollback - Rollback to a previous version
 * Body: { version: number, createdBy?: string }
 * NOTE: Must come BEFORE /api/prompts/:name
 */
promptsRouter.post('/api/prompts/:name/rollback', async (req, res) => {
  try {
    const { name } = req.params;
    const { version, createdBy = 'admin' } = req.body;

    if (!version || typeof version !== 'number') {
      return res.status(400).json({
        success: false,
        error: 'Version number is required'
      });
    }

    await promptManager.rollbackToVersion(name, version, createdBy);

    return res.json({
      success: true,
      section_name: name,
      rolled_back_to: version,
      message: `Rolled back to version ${version}`
    });
  } catch (error) {
    logger.error(`[PromptAPI] Failed to rollback section "${req.params.name}"`, error);
    return res.status(400).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to rollback'
    });
  }
});

/**
 * DELETE /prompts/:name/versions/:version - Delete a specific version (v379)
 * Requires admin password
 * Body: { password: string }
 * NOTE: Must come BEFORE /api/prompts/:name
 */
promptsRouter.delete('/api/prompts/:name/versions/:version', checkAdminPassword, async (req, res) => {
  try {
    const { name } = req.params;
    const version = parseInt(req.params.version);

    if (!version || isNaN(version)) {
      return res.status(400).json({
        success: false,
        error: 'Valid version number is required'
      });
    }

    await promptManager.deleteVersion(name, version);

    return res.json({
      success: true,
      section_name: name,
      deleted_version: version,
      message: `Version ${version} deleted successfully`
    });
  } catch (error) {
    logger.error(`[PromptAPI] Failed to delete version ${req.params.version} of "${req.params.name}"`, error);
    return res.status(400).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to delete version'
    });
  }
});

/**
 * GET /prompts/:name - Get raw prompt content (with {{variables}} placeholders)
 * NOTE: This route should come AFTER all more specific routes to avoid catching them
 */
promptsRouter.get('/api/prompts/:name', async (req, res) => {
  try {
    const { name } = req.params;
    const section = await promptManager.getSectionRaw(name);

    res.json({
      success: true,
      section: {
        id: section.id,
        section_name: section.section_name,
        description: section.description,
        content: section.content,
        active_version: section.active_version,
        created_at: section.created_at,
        updated_at: section.updated_at
      }
    });
  } catch (error) {
    logger.error(`[PromptAPI] Failed to get section "${req.params.name}"`, error);
    res.status(404).json({
      success: false,
      error: error instanceof Error ? error.message : 'Section not found'
    });
  }
});

/**
 * PUT /prompts/:name - Update prompt content
 * Body: { content: string, createdBy?: string, changeSummary?: string }
 * NOTE: This route should come AFTER all more specific routes
 */
promptsRouter.put('/api/prompts/:name', async (req, res) => {
  try {
    const { name } = req.params;
    const { content, createdBy = 'admin', changeSummary = 'Updated via API' } = req.body;

    if (!content) {
      return res.status(400).json({
        success: false,
        error: 'Content is required'
      });
    }

    const newVersion = await promptManager.updateSection(name, content, createdBy, changeSummary);

    return res.json({
      success: true,
      section_name: name,
      version: newVersion,
      message: `Updated to version ${newVersion}`
    });
  } catch (error) {
    logger.error(`[PromptAPI] Failed to update section "${req.params.name}"`, error);
    return res.status(400).json({
      success: false,
      error: error instanceof Error ? error.message : 'Failed to update section'
    });
  }
});
