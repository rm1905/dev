/**
 * Settings management routes (password-protected)
 */

import { Router, Request, Response } from 'express';
import { readFileSync } from 'fs';
import { join } from 'path';
import { config } from '../util/env.js';
import { SettingsSchemaBase, SettingsSchema } from '../util/schema.js';
import { logger } from '../util/logger.js';
import { TableauValidator } from '../util/tableauValidator.js';

export const settingsRouter = Router();

// GET /settings/profiles - list profile names (public, no password required)
settingsRouter.get('/settings/profiles', async (_req: Request, res: Response) => {
  try {
    const profiles = await config.getProfiles();
    const defaultProfile = config.getDefaultProfile();

    // Return only profile names, no sensitive data
    res.json({
      profiles: profiles.map(p => p.name),
      defaultProfile,
    });
  } catch (error) {
    logger.error('Failed to list profile names', error);
    res.status(500).json({ error: 'Failed to list profile names' });
  }
});

// GET /settings/auth-info - get authentication type and JWT sub claim (public, no password required)
settingsRouter.get('/settings/auth-info', async (req: Request, res: Response) => {
  try {
    const profileName = req.query.profile as string | undefined;
    const settings = await config.getSettings(profileName);

    // Return only authentication metadata, no secrets
    res.json({
      authenticationType: settings.AUTHENTICATION_TYPE || 'pat',
      jwtSubClaim: settings.JWT_SUB_CLAIM || null,
    });
  } catch (error) {
    logger.error('Failed to get authentication info', error);
    res.status(500).json({ error: 'Failed to get authentication info' });
  }
});

// GET /settings/provider-info - get LLM provider and models (public, no password required)
settingsRouter.get('/settings/provider-info', async (req: Request, res: Response) => {
  try {
    const profileName = req.query.profile as string | undefined;
    const settings = await config.getSettings(profileName);

    // Return only LLM provider metadata, no secrets
    res.json({
      llmProvider: settings.LLM_PROVIDER || 'openai',
      openaiDefaultModel: settings.OPENAI_DEFAULT_MODEL || settings.DEFAULT_MODEL || 'gpt-4o-mini',
      localModel: settings.LOCAL_MODEL || '',
      localBaseUrl: settings.LOCAL_BASE_URL || '',
      bedrockRegion: settings.BEDROCK_REGION || '',
      bedrockModelId: settings.BEDROCK_MODEL_ID || '',
    });
  } catch (error) {
    logger.error('Failed to get provider info', error);
    res.status(500).json({ error: 'Failed to get provider info' });
  }
});

// Password check middleware with admin/non-admin detection
function checkPassword(_req: Request, res: Response, next: Function): void {
  const password = _req.body?.password || _req.query?.password;

  // Two valid passwords:
  // - "TableauMCP2025!" = non-admin (cannot edit profile named "default")
  // - "AdminTableauMCP+" = admin (can edit all profiles)
  const nonAdminPassword = 'TableauMCP2025!';
  const adminPassword = 'AdminTableauMCP+';

  if (password === adminPassword) {
    // Admin user - full access
    (_req as any).isAdmin = true;
    next();
  } else if (password === nonAdminPassword) {
    // Non-admin user - restricted access
    (_req as any).isAdmin = false;
    next();
  } else {
    // Invalid password
    res.status(401).json({ error: 'Invalid password' });
    return;
  }
}

// GET /settings - serve settings page
settingsRouter.get('/settings', (_req: Request, res: Response) => {
  try {
    const html = readFileSync(join(process.cwd(), 'src/public/settings.html'), 'utf-8');
    res.setHeader('Content-Type', 'text/html');
    res.send(html);
  } catch (error) {
    logger.error('Failed to load settings page', error);
    res.status(500).json({ error: 'Failed to load settings page' });
  }
});

// POST /settings/load - load current settings (password-protected)
settingsRouter.post('/settings/load', checkPassword, async (_req: Request, res: Response) => {
  try {
    const settings = await config.getSettings();

    // Mask sensitive values
    const masked = {
      ...settings,
      OPENAI_API_KEY: settings.OPENAI_API_KEY ? '***masked***' : '',
      TABLEAU_PAT_SECRET: settings.TABLEAU_PAT_SECRET ? '***masked***' : '',
      CONNECTED_APP_SECRET_ID: settings.CONNECTED_APP_SECRET_ID ? '***masked***' : '',
      CONNECTED_APP_SECRET_VALUE: settings.CONNECTED_APP_SECRET_VALUE ? '***masked***' : '',
    };

    res.json(masked);
  } catch (error) {
    logger.error('Failed to load settings', error);
    res.status(500).json({ error: 'Failed to load settings' });
  }
});

// POST /settings/save - save new settings (password-protected, backward compatibility)
settingsRouter.post('/settings/save', checkPassword, async (req: Request, res: Response) => {
  try {
    const { password, ...newSettings } = req.body;

    // Don't update if value is masked
    const filtered: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(newSettings)) {
      if (value !== '***masked***' && value !== '') {
        // Convert numeric fields from strings to numbers
        if (key === 'REQUEST_TIMEOUT_MS' || key === 'MAX_ROWS' || key === 'MAX_VIEW_ROWS_FOR_MODEL') {
          filtered[key] = typeof value === 'string' ? parseInt(value, 10) : value;
        } else {
          filtered[key] = value;
        }
      }
    }

    // Validate and save
    const validated = SettingsSchemaBase.partial().parse(filtered);
    await config.saveSettings(validated);

    logger.info('Settings saved successfully');
    res.json({ success: true, message: 'Settings saved successfully' });
  } catch (error) {
    logger.error('Failed to save settings', error);
    res.status(400).json({
      error: error instanceof Error ? error.message : String(error),
    });
  }
});

// GET /settings/profiles/list - list all profiles (password-protected)
settingsRouter.post('/settings/profiles/list', checkPassword, async (_req: Request, res: Response) => {
  try {
    const profiles = await config.getProfiles();
    const defaultProfile = config.getDefaultProfile();
    const isAdmin = (_req as any).isAdmin;

    // Filter out "default" profile for non-admin users
    const filteredProfiles = isAdmin
      ? profiles
      : profiles.filter(p => p.name !== 'default');

    // Mask sensitive values
    const maskedProfiles = filteredProfiles.map(profile => ({
      name: profile.name,
      settings: {
        ...profile.settings,
        OPENAI_API_KEY: profile.settings.OPENAI_API_KEY ? '***masked***' : '',
        TABLEAU_PAT_SECRET: profile.settings.TABLEAU_PAT_SECRET ? '***masked***' : '',
        CONNECTED_APP_SECRET_ID: profile.settings.CONNECTED_APP_SECRET_ID ? '***masked***' : '',
        CONNECTED_APP_SECRET_VALUE: profile.settings.CONNECTED_APP_SECRET_VALUE ? '***masked***' : '',
      },
    }));

    res.json({
      profiles: maskedProfiles,
      defaultProfile,
      isAdmin, // Send admin status to client
    });
  } catch (error) {
    logger.error('Failed to list profiles', error);
    res.status(500).json({ error: 'Failed to list profiles' });
  }
});

// POST /settings/profiles/save - create or update a profile (password-protected)
settingsRouter.post('/settings/profiles/save', checkPassword, async (req: Request, res: Response) => {
  try {
    const { password, profileName, ...newSettings } = req.body;
    const isAdmin = (req as any).isAdmin;

    if (!profileName || typeof profileName !== 'string' || profileName.trim() === '') {
      throw new Error('Profile name is required');
    }

    // Prevent non-admin users from editing "default" profile
    if (!isAdmin && profileName.trim() === 'default') {
      res.status(403).json({ error: 'Non-admin users cannot edit the "default" profile' });
      return;
    }

    // Don't update if value is masked, but keep empty strings for dropdowns that default to ""
    const filtered: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(newSettings)) {
      if (value !== '***masked***') {
        // Convert numeric fields from strings to numbers
        if (key === 'REQUEST_TIMEOUT_MS' || key === 'MAX_ROWS' || key === 'MAX_VIEW_ROWS_FOR_MODEL') {
          filtered[key] = typeof value === 'string' ? parseInt(value, 10) : value;
        } else {
          // Keep the value even if empty string (needed for dropdown validation)
          filtered[key] = value;
        }
      }
    }

    // Validate with full schema (includes refinements for provider-specific required fields)
    // Merge with existing profile settings to ensure validation has complete data
    const allProfiles = await config.getProfiles();
    const existingProfile = allProfiles.find(p => p.name === profileName.trim());
    const mergedSettings = existingProfile
      ? { ...existingProfile.settings, ...filtered }
      : filtered;

    // Use SettingsSchema for full validation (includes provider-specific refinements)
    const validated = SettingsSchema.parse(mergedSettings);

    // Save the validated settings
    await config.saveProfile(profileName.trim(), validated);

    logger.info(`Profile "${profileName}" saved successfully`);

    const response: any = {
      success: true,
      message: `Profile "${profileName}" saved successfully`,
    };

    // Add note about where profile is stored
    if (profileName.trim() === 'default') {
      response.persistenceNote = 'Settings for the "default" profile are automatically persisted to Heroku config vars and will survive deployments.';
    } else {
      response.persistenceNote = 'Settings for this profile are stored in the Heroku Postgres database and will persist across deployments.';
    }

    res.json(response);
  } catch (error) {
    logger.error('Failed to save profile', error);
    res.status(400).json({
      error: error instanceof Error ? error.message : String(error),
    });
  }
});

// POST /settings/profiles/delete - delete a profile (password-protected)
settingsRouter.post('/settings/profiles/delete', checkPassword, async (req: Request, res: Response) => {
  try {
    const { profileName } = req.body;

    if (!profileName || typeof profileName !== 'string') {
      throw new Error('Profile name is required');
    }

    // Prevent deletion of "default" profile for all users (including admins)
    // The system depends on "default" existing in config.json for synchronous operations
    if (profileName === 'default') {
      res.status(403).json({ error: 'Cannot delete the "default" profile. It is required for system operation.' });
      return;
    }

    await config.deleteProfile(profileName);

    logger.info(`Profile "${profileName}" deleted successfully`);
    res.json({ success: true, message: `Profile "${profileName}" deleted successfully` });
  } catch (error) {
    logger.error('Failed to delete profile', error);
    res.status(400).json({
      error: error instanceof Error ? error.message : String(error),
    });
  }
});

// POST /settings/profiles/set-default - set default profile (password-protected)
settingsRouter.post('/settings/profiles/set-default', checkPassword, async (req: Request, res: Response) => {
  try {
    const { profileName } = req.body;

    if (!profileName || typeof profileName !== 'string') {
      throw new Error('Profile name is required');
    }

    await config.setDefaultProfile(profileName);

    logger.info(`Default profile set to "${profileName}"`);
    res.json({ success: true, message: `Default profile set to "${profileName}"` });
  } catch (error) {
    logger.error('Failed to set default profile', error);
    res.status(400).json({
      error: error instanceof Error ? error.message : String(error),
    });
  }
});

// POST /settings/profiles/validate - validate Tableau configuration (password-protected)
settingsRouter.post('/settings/profiles/validate', checkPassword, async (req: Request, res: Response) => {
  try {
    const { profileName } = req.body;

    if (!profileName || typeof profileName !== 'string') {
      throw new Error('Profile name is required');
    }

    logger.info(`Validating configuration for profile: ${profileName}`);

    // Get profile settings
    const settings = await config.getSettings(profileName);

    // Run validation
    const validationResult = await TableauValidator.validateConfiguration(settings, profileName);

    if (validationResult.valid) {
      logger.info(`✅ Validation successful for profile: ${profileName}`);
      res.json({
        success: true,
        valid: true,
        message: '✅ Configuration is valid! Successfully connected and authenticated with Tableau Server.',
        warnings: validationResult.warnings,
      });
    } else {
      logger.warn(`❌ Validation failed for profile: ${profileName}`, validationResult.errors);
      res.status(400).json({
        success: false,
        valid: false,
        message: '❌ Configuration validation failed. Please fix the errors below.',
        errors: validationResult.errors,
        warnings: validationResult.warnings,
      });
    }
  } catch (error) {
    logger.error('Failed to validate profile', error);
    res.status(500).json({
      success: false,
      valid: false,
      error: error instanceof Error ? error.message : String(error),
      message: 'An unexpected error occurred during validation.',
    });
  }
});
