# Configuration Examples

This directory contains example configuration files for different use cases. Choose the example that best matches your setup and copy it to `config.json`.

## Quick Start

1. Choose an example configuration below
2. Copy it to `config.json`:
   ```bash
   cp config.json.example.pat.openai config.json
   ```
3. Edit `config.json` with your actual credentials
4. Start the application

## Available Examples

### 1. `config.json.example.pat.openai` (OpenAI + PAT)
**Use this if:** You're using OpenAI GPT models and Tableau PAT authentication

**Features:**
- LLM Provider: OpenAI (gpt-4o-mini)
- Tableau Auth: Personal Access Token (PAT)

**Best for:** Quick setup, simple authentication, single-user scenarios

```bash
cp config.json.example.pat.openai config.json
```

**⚠️ PAT Limitation:** Personal Access Tokens cannot be used concurrently. Only one active session at a time.

---

### 2. `config.json.example.direct-trust.bedrock` (AWS Bedrock + Direct Trust)
**Use this if:** You're using AWS Bedrock Claude models with Tableau Connected App (Direct Trust/JWT)

**Features:**
- LLM Provider: AWS Bedrock (Claude Sonnet 4.6)
- Tableau Auth: Connected App with JWT (Direct Trust)
- AWS Auth: SSO Profile (recommended)

**Best for:** AWS-native deployments, Claude models, enterprise SSO, concurrent users

```bash
cp config.json.example.direct-trust.bedrock config.json
```

**AWS Credentials Required:** Configure via:
- AWS SSO Profile (recommended): Set `BEDROCK_PROFILE` to your profile name from `~/.aws/config`
- Explicit credentials: Set `BEDROCK_ACCESS_KEY_ID` and `BEDROCK_SECRET_ACCESS_KEY`
- Default credential chain: Leave auth fields empty to use environment/EC2 role

**Supported Regions:**
- us-east-1 (N. Virginia)
- us-west-2 (Oregon)
- eu-west-1 (Ireland)
- ap-southeast-1 (Singapore)
- See AWS Bedrock documentation for complete list

---

### 3. `config.json.example.direct-trust.local-llm` (Local LLM + Direct Trust)
**Use this if:** You're using a local LLM (Ollama, LM Studio) with Tableau Connected App (Direct Trust/JWT)

**Features:**
- LLM Provider: Local LLM (Ollama with qwen2.5:14b)
- Tableau Auth: Connected App with JWT (Direct Trust)

**Best for:** Development, testing, cost savings, on-premise deployments, air-gapped environments

```bash
cp config.json.example.direct-trust.local-llm config.json
```

**⚠️ Model Compatibility:** Only `qwen2.5:14b` or `qwen2.5:32b` are verified to work properly with tool calling. Other models (llama3.1, mistral, etc.) may not support the required function calling features.

**Common Local LLM URLs:**
- Ollama: `http://localhost:11434/v1`
- LM Studio: `http://localhost:1234/v1`
- LocalAI: `http://localhost:8080/v1`

---

## Configuration Fields Reference

### LLM Provider Fields

#### OpenAI Configuration
| Field | Required | Description | Example |
|-------|----------|-------------|---------|
| `LLM_PROVIDER` | Yes | Set to `"openai"` | `"openai"` |
| `OPENAI_API_KEY` | Yes | OpenAI API key | `"sk-..."` |
| `OPENAI_DEFAULT_MODEL` | Yes | OpenAI model to use | `"gpt-4o-mini"`, `"gpt-4o"`, `"gpt-4-turbo"` |
| `DEFAULT_MODEL` | Optional | Legacy field (same as OPENAI_DEFAULT_MODEL) | `"gpt-4o-mini"` |

#### AWS Bedrock Configuration
| Field | Required | Description | Example |
|-------|----------|-------------|---------|
| `LLM_PROVIDER` | Yes | Set to `"bedrock"` | `"bedrock"` |
| `BEDROCK_REGION` | Yes | AWS region | `"us-east-1"` |
| `BEDROCK_MODEL_ID` | Yes | Bedrock model ID | `"us.anthropic.claude-sonnet-4-6"` |
| `BEDROCK_PROFILE` | Optional | AWS profile name | `"my-sso-profile"` |
| `BEDROCK_ACCESS_KEY_ID` | Optional | AWS access key | `"AKIA..."` |
| `BEDROCK_SECRET_ACCESS_KEY` | Optional | AWS secret key | Secret value |

**Available Bedrock Models:**
- `us.anthropic.claude-sonnet-4-6` - Claude Sonnet 4.6 (recommended)
- `anthropic.claude-3-5-sonnet-20241022-v2:0` - Claude 3.5 Sonnet (legacy)
- Other Claude models available in Bedrock

#### Local LLM Configuration
| Field | Required | Description | Example |
|-------|----------|-------------|---------|
| `LLM_PROVIDER` | Yes | Set to `"local"` | `"local"` |
| `LOCAL_BASE_URL` | Yes | Local LLM endpoint | `"http://localhost:11434/v1"` |
| `LOCAL_MODEL` | Yes | Local model name | `"qwen2.5:14b"` |
| `LOCAL_API_KEY` | Optional | API key for local LLM | Usually empty |

### Tableau Authentication Fields

#### Common Fields (All Auth Types)
| Field | Required | Description | Example |
|-------|----------|-------------|---------|
| `TABLEAU_BASE_URL` | Yes | Tableau server URL | `"https://prod-apsoutheast-b.online.tableau.com"` |
| `TABLEAU_SITE_CONTENT_URL` | Yes | Site content URL | `"my-site"` or `""` for default |
| `AUTHENTICATION_TYPE` | Yes | Auth method | `"pat"` or `"direct-trust"` |

#### PAT Authentication Fields (`AUTHENTICATION_TYPE: "pat"`)
| Field | Required | Description | Example |
|-------|----------|-------------|---------|
| `TABLEAU_PAT_NAME` | Yes | PAT token name | `"my-token"` |
| `TABLEAU_PAT_SECRET` | Yes | PAT token secret | Secret value |

#### Direct Trust Authentication Fields (`AUTHENTICATION_TYPE: "direct-trust"`)
| Field | Required | Description | Example |
|-------|----------|-------------|---------|
| `JWT_SUB_CLAIM` | Yes | Username for JWT | `"user@company.com"` |
| `CONNECTED_APP_CLIENT_ID` | Yes | Connected App client ID | UUID |
| `CONNECTED_APP_SECRET_ID` | Yes | Connected App secret ID | UUID |
| `CONNECTED_APP_SECRET_VALUE` | Yes | Connected App secret value | Secret value |
| `JWT_ADDITIONAL_PAYLOAD` | Optional | Additional JWT claims | `""` or JSON string |

### Application Settings

| Field | Required | Default | Description |
|-------|----------|---------|-------------|
| `ALLOWED_ORIGINS` | No | `""` | CORS allowed origins (comma-separated) |
| `REQUEST_TIMEOUT_MS` | No | `60000` | API request timeout (milliseconds) |
| `MAX_ROWS` | No | `500` | Max rows returned by Tableau queries |
| `MAX_VIEW_ROWS_FOR_MODEL` | No | `30` | Max rows sent to LLM for analysis |

---

## PAT vs Direct Trust - Which Should I Use?

### Personal Access Token (PAT)
✅ **Pros:**
- Simpler setup - no Connected App required
- Good for single-user scenarios
- Quick to get started

❌ **Cons:**
- **Cannot be used concurrently** - only one session at a time
- Not suitable for Tableau Extensions with multiple users
- Less secure for production deployments

**Use PAT if:** You're the only user, doing development/testing, or need quick setup.

### Direct Trust (Connected App with JWT)
✅ **Pros:**
- **Supports concurrent users** - multiple sessions simultaneously
- Better for production deployments
- Can embed user identity in JWT
- More secure for multi-user scenarios
- Required for Tableau Extensions with concurrent access

❌ **Cons:**
- Requires Connected App setup in Tableau Server
- More complex initial configuration
- Need to manage secrets and keys

**Use Direct Trust if:** You're deploying to production, have multiple users, building a Tableau Extension, or need concurrent access.

---

## Multi-Profile Setup

While the examples above show single-profile configurations, you can manage multiple profiles:

1. **The "default" profile** is stored in `config.json` (this file)
2. **Additional profiles** can be created via the `/settings` UI
3. Additional profiles are stored in the PostgreSQL database
4. Switch between profiles in the `/settings` interface

**Example use cases for multiple profiles:**
- Development, staging, and production environments
- Different Tableau servers or sites
- Testing different LLM providers
- Different user accounts or permissions

**To add more profiles:**
1. Start with one of these examples as your "default" profile
2. Visit `http://localhost:3000/settings` 
3. Click "New Profile" to add additional configurations
4. Select which profile to use as default

---

## Environment Variable Overrides

For Heroku or other cloud deployments where the filesystem is ephemeral, you can override any setting in the "default" profile using environment variables with the `DEFAULT_PROFILE_` prefix.

**Examples:**
```bash
# Override OpenAI settings
DEFAULT_PROFILE_OPENAI_API_KEY=sk-prod-key
DEFAULT_PROFILE_OPENAI_DEFAULT_MODEL=gpt-4o

# Override Tableau settings
DEFAULT_PROFILE_TABLEAU_BASE_URL=https://prod-server.tableau.com
DEFAULT_PROFILE_TABLEAU_SITE_CONTENT_URL=prod-site

# Override to use Bedrock
DEFAULT_PROFILE_LLM_PROVIDER=bedrock
DEFAULT_PROFILE_BEDROCK_REGION=us-east-1
DEFAULT_PROFILE_BEDROCK_MODEL_ID=us.anthropic.claude-sonnet-4-6
DEFAULT_PROFILE_BEDROCK_PROFILE=prod-aws-profile

# Override to use Local LLM
DEFAULT_PROFILE_LLM_PROVIDER=local
DEFAULT_PROFILE_LOCAL_BASE_URL=http://localhost:11434/v1
DEFAULT_PROFILE_LOCAL_MODEL=qwen2.5:14b

# Override auth settings
DEFAULT_PROFILE_AUTHENTICATION_TYPE=direct-trust
DEFAULT_PROFILE_JWT_SUB_CLAIM=prod.user@company.com
DEFAULT_PROFILE_CONNECTED_APP_CLIENT_ID=prod-client-id
DEFAULT_PROFILE_CONNECTED_APP_SECRET_ID=prod-secret-id
DEFAULT_PROFILE_CONNECTED_APP_SECRET_VALUE=prod-secret-value

# Override application settings
DEFAULT_PROFILE_ALLOWED_ORIGINS=https://example.com
DEFAULT_PROFILE_REQUEST_TIMEOUT_MS=60000
DEFAULT_PROFILE_MAX_ROWS=500
DEFAULT_PROFILE_MAX_VIEW_ROWS_FOR_MODEL=30
```

See `.env.example` in the root directory for the complete list of override variables.

**Note:** Environment variables take precedence over `config.json` settings.

---

## Security Best Practices

1. **Never commit `config.json`** to version control
   - Already in `.gitignore`
   - Use examples as templates only
   - Keep credentials separate

2. **Rotate credentials regularly**
   - PAT tokens should be rotated every 90 days
   - Connected App secrets should be rotated annually
   - AWS credentials should follow your organization's policy

3. **Use environment variables in production**
   - Leverage `DEFAULT_PROFILE_*` variables
   - Keep secrets in Heroku Config Vars, AWS Secrets Manager, or similar
   - Never hardcode secrets in config files

4. **Limit CORS origins in production**
   - Set `ALLOWED_ORIGINS` to specific domains
   - Empty string = allow all (development only!)
   - Use comma-separated list for multiple origins

5. **Use AWS SSO for Bedrock** (recommended)
   - More secure than explicit credentials
   - Easier to rotate and manage
   - Supports temporary credentials
   - Better audit trail

6. **Connected App Security**
   - Limit token scopes to minimum required
   - Use domain restrictions where possible
   - Monitor usage logs
   - Rotate secrets on schedule

---

## Troubleshooting

### "Default profile not found in config.json"
**Solution:**
- Make sure you've copied an example to `config.json`
- Ensure the file has a profile named "default"
- Check JSON syntax is valid

### "Invalid password" when accessing /settings
**Passwords:**
- Admin password: `AdminTableauMCP+` (can edit "default" profile)
- Non-admin password: `TableauMCP2025!` (cannot edit "default" profile)

### AWS Bedrock authentication errors
**Solutions:**
- Verify AWS credentials are configured correctly
- Check `~/.aws/config` for SSO profiles
- Run `aws sso login --profile your-profile` if using SSO
- Ensure your IAM role/user has Bedrock permissions
- Verify the region supports your chosen model

### Local LLM tool calling not working
**Solutions:**
- Only `qwen2.5:14b` and `qwen2.5:32b` are verified to work
- Other models may not support function calling properly
- Ensure your local LLM server is running
- Check the BASE_URL is correct (must end with `/v1`)
- Verify the model is downloaded: `ollama list`

### PAT "concurrent usage" errors
**Problem:** PATs cannot be used by multiple users simultaneously

**Solution:** Switch to Direct Trust authentication (Connected App)

### Tableau Connected App errors
**Solutions:**
- Verify Connected App is enabled in Tableau Server
- Check Client ID, Secret ID, and Secret Value are correct
- Ensure username in JWT_SUB_CLAIM exists in Tableau
- Verify Connected App domain restrictions (if set)

### Configuration validation errors
**Solution:** Visit `http://localhost:3000/settings` and use the "Validate" button to test your configuration

---

## Need More Help?

- **Local Development:** See `LOCAL_DEVELOPMENT.md` for detailed setup
- **AWS Bedrock Setup:** See `BEDROCK_SETUP.md` for AWS configuration
- **Settings UI:** Visit `/settings` to validate and manage configurations
- **Health Check:** Visit `/healthz` to verify server status
- **API Documentation:** Visit `/ui/` for API explorer

---

## File Structure

```
config/
├── README.md                                    # This file
├── config.json                                  # Your actual config (not in git)
├── config.json.example.pat.openai              # OpenAI + PAT example
├── config.json.example.direct-trust.bedrock    # Bedrock + Direct Trust example
└── config.json.example.direct-trust.local-llm  # Local LLM + Direct Trust example
```

**Remember:** Only `config.json` is used by the application. The `.example` files are templates.
