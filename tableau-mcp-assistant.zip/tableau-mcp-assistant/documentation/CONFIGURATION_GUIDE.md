# Configuration Guide

This document explains the different ways to configure the Tableau MCP Assistant.

> **🔐 Note:** For information about passwords and authentication, see [PASSWORDS.md](PASSWORDS.md)

## Configuration Methods

The application supports multiple configuration methods with the following priority:

1. **Environment Variables** (.env file) - **HIGHEST PRIORITY**
2. **Config File** (config/config.json) - Optional
3. **Database** (PostgreSQL) - For non-default profiles

---

## Local Development (Recommended)

### ✅ Use .env File Only

**This is the simplest and most secure approach for local development.**

1. Copy the template:
   ```bash
   cp .env.example .env
   ```

2. Edit `.env` with your credentials:
   ```env
   # Basic
   CONFIG_PASSWORD=your-password
   DATABASE_URL=postgresql://localhost/tableau_mcp
   # Note: All database tables auto-create on first run
   
   # OpenAI
   OPENAI_API_KEY=sk-your-key-here
   DEFAULT_MODEL=gpt-4o-mini
   
   # Tableau
   TABLEAU_BASE_URL=https://your-instance.online.tableau.com
   TABLEAU_SITE_CONTENT_URL=your-site-name
   
   # Auth (PAT example)
   AUTHENTICATION_TYPE=pat
   TABLEAU_PAT_NAME=your-token-name
   TABLEAU_PAT_SECRET=your-token-secret
   ```

3. Start the app:
   ```bash
   npm run dev
   ```

**Benefits:**
- ✅ Single source of truth
- ✅ Already in .gitignore (secure by default)
- ✅ Standard Node.js development practice
- ✅ No file management needed
- ✅ Simple to share (via .env.example)

**No config.json needed!** The app will load everything from environment variables.

---

## Production Deployment (Heroku)

### Use Heroku Config Vars

For production deployments on Heroku, use config vars instead of .env:

```bash
# Set config vars
heroku config:set CONFIG_PASSWORD=your-password
heroku config:set OPENAI_API_KEY=sk-your-key
heroku config:set TABLEAU_BASE_URL=https://your-instance.online.tableau.com
# ... etc

# Or use DEFAULT_PROFILE_ prefix to sync with config.json
heroku config:set DEFAULT_PROFILE_OPENAI_API_KEY=sk-your-key
```

**Note:** Using `DEFAULT_PROFILE_*` prefix will write values back to `config.json` on the Heroku filesystem (ephemeral).

---

## Alternative: Web UI Configuration

If you prefer using the web interface:

1. Start the app with minimal .env:
   ```env
   CONFIG_PASSWORD=your-password
   DATABASE_URL=postgresql://localhost/tableau_mcp
   ```

2. Visit: http://localhost:3000/settings

3. Configure via the web UI - this will create `config/config.json`

**Note:** 
- `config.json` is in .gitignore (won't be committed)
- Environment variables still override config.json values
- This approach is useful if you want to manage multiple profiles

---

## Multi-Profile Support

The application supports multiple profiles for different environments or users:

### Default Profile
- Stored in `config/config.json` (if using config file)
- Can be configured via environment variables
- Loaded automatically at startup

### Additional Profiles
- Stored in PostgreSQL database
- Created/managed via `/settings` web UI
- Selected via URL parameter: `?profile=PROFILE_NAME`
- Useful for embedding in Tableau dashboards

**Example:** Dashboard-scoped mode with specific profile:
```
https://your-app.herokuapp.com/ui/?profile=production&scope=dashboard
```

---

## Web UI Authentication

The application uses **hardcoded passwords** to protect the Settings and Prompts management pages.

### Access Passwords

| Password | Access Level | Permissions |
|----------|-------------|-------------|
| `AdminTableauMCP+` | **Admin** | Full access to /settings and /prompts<br>• Can edit "default" profile<br>• Can delete prompt versions<br>• Can manage all profiles |
| `TableauMCP2025!` | **Non-Admin** | Limited access to /settings and /prompts<br>• Cannot edit "default" profile<br>• Cannot delete prompt versions<br>• Can manage non-default profiles |

### Where to Use These Passwords

- **Settings Page** (`http://localhost:3000/settings`)
  - Manage application profiles
  - Configure OpenAI and Tableau credentials
  - Test Tableau connections

- **Prompts Page** (`http://localhost:3000/prompts`)
  - Edit system prompts
  - Manage prompt versions
  - Delete outdated versions (admin only)

### Important Notes

1. **CONFIG_PASSWORD is NOT used:** The `CONFIG_PASSWORD` environment variable is required by the schema but does NOT control access to the web UI. It can be set to any value.

2. **Passwords are hardcoded:** The authentication passwords (`AdminTableauMCP+` and `TableauMCP2025!`) are hardcoded in:
   - `src/routes/settings.ts`
   - `src/routes/prompts.ts`

3. **No main UI password:** The main application UI at `/ui/` does not require a password.

4. **Production security:** For production deployments, consider modifying the source code to use stronger passwords or implement OAuth/SSO.

---

## Environment Variable Reference

### Basic Configuration
| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `PORT` | No | 3000 | Server port |
| `NODE_ENV` | No | production | Environment mode |
| `CONFIG_PASSWORD` | **Yes** | - | Required by schema (not used for auth) * |
| `LOG_LEVEL` | No | info | Logging level |
| `DATABASE_URL` | **Yes** | - | PostgreSQL connection |

**\* Important Note about CONFIG_PASSWORD:**
- This variable is **required by the app schema** but is **NOT used for actual authentication**
- Set it to any value to satisfy schema validation: `CONFIG_PASSWORD=schema-required-not-used`
- Web UI authentication uses hardcoded passwords (see below)

### OpenAI Configuration
| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `OPENAI_API_KEY` | **Yes** | - | OpenAI API key |
| `DEFAULT_MODEL` | No | gpt-4o-mini | Default LLM model |

### Tableau Configuration
| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `TABLEAU_BASE_URL` | **Yes** | - | Tableau instance URL |
| `TABLEAU_SITE_CONTENT_URL` | No | "" | Site name (empty for default) |

### Authentication (PAT)
| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `AUTHENTICATION_TYPE` | **Yes** | pat | Auth method (pat or direct-trust) |
| `TABLEAU_PAT_NAME` | If PAT | - | PAT token name |
| `TABLEAU_PAT_SECRET` | If PAT | - | PAT token secret |

### Authentication (Direct Trust)
| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `AUTHENTICATION_TYPE` | **Yes** | - | Must be "direct-trust" |
| `JWT_SUB_CLAIM` | If Direct Trust | - | Username or {OAUTH_USERNAME} |
| `CONNECTED_APP_CLIENT_ID` | If Direct Trust | - | Connected App client ID |
| `CONNECTED_APP_SECRET_ID` | If Direct Trust | - | Connected App secret ID |
| `CONNECTED_APP_SECRET_VALUE` | If Direct Trust | - | Connected App secret value |
| `JWT_ADDITIONAL_PAYLOAD` | No | - | Additional JWT claims (JSON) |

### Application Settings
| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `ALLOWED_ORIGINS` | No | "" | CORS origins (comma-separated) |
| `REQUEST_TIMEOUT_MS` | No | 60000 | Request timeout in ms |
| `MAX_ROWS` | No | 500 | Max rows returned by MCP queries (query-datasource, etc.) |
| `MAX_VIEW_ROWS_FOR_MODEL` | No | 30 | Max preview rows sent to LLM (reduces token usage) |

---

## Configuration Files

### .env (Recommended for Local Dev)
- Located in project root
- Loaded by Node.js at startup
- Already in .gitignore
- Use `.env.example` as template

### config/config.json (Optional)
- Located in `config/` directory
- Created by web UI at `/settings`
- Stores default profile settings
- In .gitignore (not committed)
- Environment variables override this file

### config/config.json.example
- Template for config.json
- Safe to commit (no credentials)
- Shows expected structure

---

## Security Checklist

- [x] `.env` is in .gitignore
- [x] `config/config.json` is in .gitignore
- [x] Use strong `CONFIG_PASSWORD`
- [x] Never commit API keys or credentials
- [x] Rotate Tableau PAT tokens regularly
- [x] Use environment variables for production
- [x] Set `ALLOWED_ORIGINS` to restrict CORS
- [x] Monitor OpenAI API usage

---

## Migration Guide

### From config.json to .env

If you currently use `config/config.json`:

1. Copy values to `.env`:
   ```bash
   # Create .env from your config.json values
   cp .env.example .env
   # Edit .env with values from config.json
   ```

2. Test the configuration:
   ```bash
   npm run dev
   ```

3. (Optional) Remove or backup config.json:
   ```bash
   mv config/config.json config/config.json.backup
   ```

### From Heroku to Local

1. Export Heroku config:
   ```bash
   heroku config -s > .env
   ```

2. Edit `.env` to remove Heroku-specific vars:
   - Remove `DATABASE_URL` (use local PostgreSQL)
   - Keep your application variables

3. Start locally:
   ```bash
   npm run dev
   ```

---

## Troubleshooting

### "Missing required configuration"
**Solution:** Check that all required environment variables are set in `.env`:
- `CONFIG_PASSWORD` (set to any value, e.g., `schema-required-not-used`)
- `DATABASE_URL`
- `OPENAI_API_KEY`
- `TABLEAU_BASE_URL`
- Authentication credentials (PAT or Direct Trust)

### "Invalid password" when accessing /settings or /prompts
**Solution:** Use the correct hardcoded passwords:
- For admin access: `AdminTableauMCP+`
- For non-admin access: `TableauMCP2025!`

The `CONFIG_PASSWORD` environment variable is NOT used for web UI authentication.

### Environment variables not loading
**Solution:**
1. Ensure `.env` is in project root directory
2. Restart the application after editing `.env`
3. Check for syntax errors in `.env` (no spaces around `=`)
4. Verify Node.js is loading environment variables

### Config.json vs .env conflicts
**Solution:**
- Environment variables always take precedence
- If both exist, .env values override config.json
- For simplicity, use .env only (remove config.json)

---

## Best Practices

1. **Local Development:**
   - Use `.env` file only
   - Never commit `.env` to git
   - Share `.env.example` with team

2. **Production Deployment:**
   - Use Heroku config vars
   - Never hardcode credentials
   - Use different credentials for dev/prod

3. **Security:**
   - Rotate credentials regularly
   - Use strong passwords
   - Monitor API usage
   - Review audit logs

4. **Team Collaboration:**
   - Document required environment variables
   - Keep `.env.example` up to date
   - Use descriptive variable names
   - Comment complex configurations

---

For detailed setup instructions, see [LOCAL_DEVELOPMENT.md](LOCAL_DEVELOPMENT.md)
