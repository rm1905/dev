# Local Development Setup Guide

This guide will help you set up and run the Tableau MCP Assistant locally on your machine.

## ⚠️ HTTPS Requirement for Tableau Extensions

**IMPORTANT:** Tableau dashboard extensions **require HTTPS connections**. When running locally, you must use Caddy (or another reverse proxy) to provide HTTPS support.

- ❌ `http://localhost:3000` - Will NOT work with Tableau extensions
- ✅ `https://localhost` - Required for Tableau extensions

This guide includes instructions for setting up Caddy to provide HTTPS on localhost.

## Quick Start (TL;DR)

```bash
# 1. Install Caddy (REQUIRED for Tableau extensions)
brew install caddy  # macOS
# OR: sudo apt install caddy  # Linux
# OR: Download from https://caddyserver.com/download

# 2. Copy and configure environment variables
cp .env.example .env
# Edit .env with your credentials (OpenAI API key, Tableau credentials)

# 3. Create database
createdb tableau_mcp

# 4. Install and build
npm install
npm run build

# 5. Run the app (database tables auto-create on first run)
npm run dev

# 6. In a separate terminal, run Caddy (requires sudo for port 443 and you will be prompted your OS login password)
sudo caddy reverse-proxy --from localhost:443 --to localhost:3000

# 7. Open browser with HTTPS
open https://localhost/ui/
```

**Note:** For local development, use `.env` file ONLY. No need for `config.json`.

**Automatic Database Setup:**
- All required database tables are created automatically on first run
- Prompts are automatically seeded from `src/prompts/*.md` files
- No manual migrations or seed scripts needed!
- Includes: `profiles`, `prompt_sections`, `prompt_versions`, `prompt_variables`

**Accessing Web UI:**
- Settings page (`/settings`): Use password `AdminTableauMCP+` or `TableauMCP2025!`
- Prompts page (`/prompts`): Use password `AdminTableauMCP+` or `TableauMCP2025!`

---

## Prerequisites

Before you begin, ensure you have the following installed:

- **Node.js 20+** (24.x recommended)
- **PostgreSQL** (for database)
- **Caddy** (for HTTPS support - **REQUIRED for Tableau extensions**)
- **Git**
- **OpenAI API Key** (for LLM functionality)
- **Tableau credentials** (PAT or Connected App)

## Step 1: Install Caddy (HTTPS Reverse Proxy)

**Why Caddy?** Tableau dashboard extensions require HTTPS connections. Caddy automatically generates and manages SSL certificates for localhost.

### macOS (using Homebrew)
```bash
brew install caddy

# Verify installation
caddy version
```

### Linux (Ubuntu/Debian)
```bash
# Install dependencies
sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https curl

# Add Caddy repository
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | sudo tee /etc/apt/sources.list.d/caddy-stable.list

# Install Caddy
sudo apt update
sudo apt install caddy

# Verify installation
caddy version
```

### Windows
Download the installer from [Caddy Downloads](https://caddyserver.com/download) or use Chocolatey:
```powershell
choco install caddy
```

### Alternative: Download Binary
Download the latest release from [GitHub Releases](https://github.com/caddyserver/caddy/releases)

## Step 2: Install PostgreSQL

### macOS (using Homebrew)
```bash
brew install postgresql@14
brew services start postgresql@14
```

### Linux (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

### Windows
Download and install from [PostgreSQL Downloads](https://www.postgresql.org/download/windows/)

## Step 7: Create Database

```bash
# Create the database
createdb tableau_mcp

# Verify it was created
psql -l | grep tableau_mcp
```

**Note:** Database tables will be created automatically when you first start the application.

## Step 7: Clone and Install Dependencies

```bash
# Navigate to the project directory
cd /path/to/tableau-mcp-assistant

# Install npm dependencies
npm install
```

## Step 7: Configure Environment Variables

**For local development, use `.env` file only** (no config.json needed):

1. Copy the example file:
   ```bash
   cp .env.example .env
   ```

2. Edit `.env` and fill in your actual credentials:
   ```bash
   # Basic Configuration
   CONFIG_PASSWORD=your-secure-password
   DATABASE_URL=postgresql://localhost/tableau_mcp
   PORT=3000
   NODE_ENV=development
   LOG_LEVEL=debug

   # OpenAI
   OPENAI_API_KEY=sk-your-actual-key-here
   DEFAULT_MODEL=gpt-4o-mini

   # Tableau
   TABLEAU_BASE_URL=https://your-instance.online.tableau.com
   TABLEAU_SITE_CONTENT_URL=your-site-name

   # Authentication (choose PAT or Direct Trust)
   AUTHENTICATION_TYPE=pat
   TABLEAU_PAT_NAME=your-token-name
   TABLEAU_PAT_SECRET=your-token-secret
   ```

**Note:** 
- The `config/config.json` file is optional for local development
- If you prefer using the web UI at `/settings`, the app will create config.json automatically
- For local dev, .env is simpler and more secure (already in .gitignore)

### Important: About CONFIG_PASSWORD

The `CONFIG_PASSWORD` environment variable is **required by the app schema** but is **NOT actually used** for authentication. You can set it to any value:

```env
CONFIG_PASSWORD=schema-required-not-used
```

**Actual passwords for web UI access:**

| Password | Access Level | Permissions |
|----------|-------------|-------------|
| `AdminTableauMCP+` | Admin | Full access - can edit "default" profile, delete prompt versions |
| `TableauMCP2025!` | Non-Admin | Limited access - cannot edit "default" profile or delete |

These hardcoded passwords are used to access:
- Settings page: `https://localhost/settings` (via Caddy)
- Prompts page: `https://localhost/prompts` (via Caddy)

## Step 7: Build the TypeScript Code

```bash
npm run build
```

This compiles the TypeScript source files in `src/` to JavaScript in `dist/`

## Step 8: Run the Application

### Development Mode (with hot reload)
```bash
npm run dev
```

This uses `tsx` to watch for file changes and automatically restart the server.

### Production Mode
```bash
npm start
```

This runs the compiled JavaScript from `dist/`

**Note:** The app will run on `http://localhost:3000`, but you **cannot access it directly** for Tableau extensions. You must use Caddy (next step) to access via HTTPS.

## Step 9: Run Caddy for HTTPS Support

**CRITICAL for Tableau Extensions:** Tableau dashboard extensions require HTTPS. Caddy provides automatic HTTPS for localhost.

### Start Caddy (in a separate terminal)

```bash
# Simple reverse proxy from HTTPS (port 443) to HTTP (port 3000)
# Requires sudo because port 443 is a privileged port (< 1024)
sudo caddy reverse-proxy --from localhost:443 --to localhost:3000
```

**What this does:**
- Listens on `https://localhost` (port 443)
- Automatically generates a self-signed SSL certificate for localhost
- Forwards all requests to your app running on `http://localhost:3000`

### First-Time Setup: Trust the Certificate

When you first run Caddy, it will generate a self-signed certificate. Your browser will show a security warning. You need to trust this certificate:

#### macOS
1. When you see "Your connection is not private", click **"Advanced"**
2. Click **"Proceed to localhost (unsafe)"**
3. Or add Caddy's root certificate to your keychain:
   ```bash
   # Find Caddy's data directory
   caddy trust
   ```

#### Linux
```bash
# Add Caddy's root CA to system trust store
# Note: Caddy must be run with sudo first to generate the certificate
sudo caddy trust
```

#### Windows
1. Click **"Advanced"** on the security warning
2. Click **"Continue to localhost (unsafe)"**

### Alternative: Caddyfile Configuration

For a more permanent setup, use the provided `Caddyfile` in the project root:

```bash
# Run Caddy with the Caddyfile (requires sudo for port 443)
sudo caddy run

# Or run in background
sudo caddy start

# Stop background Caddy
sudo caddy stop
```

The `Caddyfile` contains:
```
localhost {
    reverse_proxy localhost:3000
}
```

### Verify Caddy is Running

```bash
# In your browser, open:
https://localhost

# You should see the app loading (you may need to accept the certificate first)

# Check Caddy logs for any errors
# (Caddy will print logs to the terminal where you ran it)
```

## Step 10: Access the Application via HTTPS

Once Caddy is running, you can access the application:

- **Main UI**: https://localhost/ui/ ✅ (HTTPS - works with Tableau)
- **Settings Page**: https://localhost/settings ✅
- **Prompts Management**: https://localhost/prompts ✅
- **Health Check**: https://localhost/healthz ✅

**⚠️ Do NOT use `http://localhost:3000` for Tableau extensions** - it will not work. Always use `https://localhost` via Caddy.

### For Development: Running Both Services

You'll need **two terminal windows**:

**Terminal 1 - Run the App:**
```bash
npm run dev
```

**Terminal 2 - Run Caddy:**
```bash
# Requires sudo for port 443 access
sudo caddy reverse-proxy --from localhost:443 --to localhost:3000
```

**Note:** You'll be prompted for your OS password because port 443 is a privileged port.

## Configuration Options

### Authentication Methods

#### PAT (Personal Access Token)
```env
AUTHENTICATION_TYPE=pat
TABLEAU_PAT_NAME=your-token-name
TABLEAU_PAT_SECRET=your-token-secret
```

#### Direct Trust (Connected App)
```env
AUTHENTICATION_TYPE=direct-trust
JWT_SUB_CLAIM=your-email@company.com
CONNECTED_APP_CLIENT_ID=your-client-id
CONNECTED_APP_SECRET_ID=your-secret-id
CONNECTED_APP_SECRET_VALUE=your-secret-value
```

### Application Settings

| Setting | Default | Description |
|---------|---------|-------------|
| `PORT` | 3000 | Server port |
| `NODE_ENV` | production | Environment (development/production/test) |
| `LOG_LEVEL` | info | Logging level (debug/info/warn/error) |
| `REQUEST_TIMEOUT_MS` | 60000 | Request timeout in milliseconds |
| `MAX_ROWS` | 500 | Maximum rows returned from MCP queries |
| `MAX_VIEW_ROWS_FOR_MODEL` | 30 | Maximum preview rows sent to LLM (token optimization) |
| `ALLOWED_ORIGINS` | "" | CORS origins (empty = allow all) |

## Troubleshooting

### Database Connection Error
```
Error: connect ECONNREFUSED 127.0.0.1:5432
```

**Solution:** Ensure PostgreSQL is running:
```bash
# macOS
brew services list | grep postgresql
brew services start postgresql@14

# Linux
sudo systemctl status postgresql
sudo systemctl start postgresql

# Check if database exists
psql -l | grep tableau_mcp
```

### Port Already in Use
```
Error: listen EADDRINUSE: address already in use :::3000
```

**Solution:** Change the port in `.env`:
```env
PORT=3001
```

Or kill the process using port 3000:
```bash
# Find process
lsof -i :3000

# Kill process
kill -9 <PID>
```

### TypeScript Compilation Errors

**Solution:** Clean and rebuild:
```bash
npm run clean
npm run build
```

### Missing Environment Variables

**Solution:** Ensure all required variables are set in `.env`:
- `CONFIG_PASSWORD` (required by schema, set to any value)
- `DATABASE_URL`
- `OPENAI_API_KEY`
- `TABLEAU_BASE_URL`
- `AUTHENTICATION_TYPE`
- Authentication credentials (PAT or Direct Trust)

### Cannot Access Settings or Prompts Page

**Error:** "Invalid password" when trying to access `/settings` or `/prompts`

**Solution:** Use the correct hardcoded passwords:
- Admin access: `AdminTableauMCP+`
- Non-admin access: `TableauMCP2025!`

**Note:** The `CONFIG_PASSWORD` environment variable is NOT used for web UI authentication.

### Caddy Not Running

**Error:** "This site can't be reached" when accessing `https://localhost`

**Solution:** Ensure Caddy is running:
```bash
# Check if Caddy is running
ps aux | grep caddy

# Start Caddy in a separate terminal (requires sudo)
sudo caddy reverse-proxy --from localhost:443 --to localhost:3000
```

### Certificate Errors in Browser

**Error:** "Your connection is not private" / "NET::ERR_CERT_AUTHORITY_INVALID"

**Solution:** This is expected for localhost certificates. You have two options:

**Option 1: Click "Advanced" and proceed** (recommended for development)
- Chrome/Edge: Click "Advanced" → "Proceed to localhost (unsafe)"
- Firefox: Click "Advanced" → "Accept the Risk and Continue"
- Safari: Click "Show Details" → "visit this website"

**Option 2: Trust Caddy's root certificate** (one-time setup)
```bash
# macOS/Linux (run after starting Caddy at least once)
sudo caddy trust

# This adds Caddy's root CA to your system's trust store
# After this, you won't see certificate warnings for localhost
# Note: Caddy must have been run at least once to generate the certificate
```

### Port 443 Already in Use

**Error:** `bind: address already in use`

**Solution:**
```bash
# Find process using port 443
sudo lsof -i :443

# Kill the process (if safe to do so)
sudo kill -9 <PID>

# Or use a different port with Caddy (still requires sudo for ports < 1024)
sudo caddy reverse-proxy --from localhost:8443 --to localhost:3000
# Then access via https://localhost:8443
```

### Sudo Password Required

**Why:** Caddy needs to bind to port 443, which is a privileged port (< 1024). On Unix-like systems (macOS, Linux), only root can bind to ports below 1024.

**Alternatives:**
1. **Use port 443 with sudo** (recommended - standard HTTPS port):
   ```bash
   sudo caddy reverse-proxy --from localhost:443 --to localhost:3000
   ```

2. **Use a non-privileged port** (e.g., 8443 - no sudo needed):
   ```bash
   caddy reverse-proxy --from localhost:8443 --to localhost:3000
   # Access via https://localhost:8443
   # Note: You'll need to update your Tableau extension URL
   ```

3. **Run Caddy as a system service** (one-time setup, runs on boot):
   ```bash
   # macOS
   sudo brew services start caddy
   
   # Linux (systemd)
   sudo systemctl enable caddy
   sudo systemctl start caddy
   ```

### App Runs but Tableau Extension Won't Connect

**Checklist:**
- ✅ Caddy is running: `ps aux | grep caddy`
- ✅ Accessing via HTTPS: `https://localhost` (not `http://localhost:3000`)
- ✅ Certificate is trusted (or you clicked "proceed anyway")
- ✅ App is running: Check `npm run dev` terminal for errors
- ✅ Ports are correct: App on 3000, Caddy proxying from 443 to 3000

## Development Tips

### Running Both Services Together

For active development, you need **two terminal windows**:

**Terminal 1 - Application (with hot reload):**
```bash
npm run dev
```

**Terminal 2 - Caddy (HTTPS proxy):**
```bash
# Requires sudo for port 443
sudo caddy reverse-proxy --from localhost:443 --to localhost:3000
```

**Tip:** Use a terminal multiplexer like `tmux` or `screen` to manage both:
```bash
# Using tmux
tmux new-session -s dev
# Ctrl+B, then " to split horizontally
# Run npm run dev in top pane
# Run caddy in bottom pane
# Ctrl+B, then arrow keys to switch panes
```

### Hot Reload Development
```bash
# Run with automatic restart on file changes
npm run dev

# Changes to TypeScript files will trigger rebuild and restart
# Caddy continues running - no restart needed
```

### View Logs
```bash
# Set log level to debug in .env
LOG_LEVEL=debug

# Or set when running
LOG_LEVEL=debug npm run dev
```

### Clean Build
```bash
# Remove compiled files
npm run clean

# Rebuild
npm run build
```

### Database Management

```bash
# Connect to database
psql tableau_mcp

# List tables
\dt

# View prompts table
SELECT * FROM prompts LIMIT 10;

# View profiles table
SELECT * FROM profiles;

# Exit
\q
```

## Project Structure

```
tableau-mcp-assistant/
├── src/                    # TypeScript source files
│   ├── server.ts          # Main Express server
│   ├── routes/            # API routes
│   ├── ws/                # WebSocket handlers
│   ├── util/              # Utility functions
│   └── mcp/               # MCP client/server
├── dist/                   # Compiled JavaScript (generated)
├── config/
│   ├── config.json        # Profile settings (optional, gitignored)
│   └── config.json.example # Template
├── public/                 # Static web files
├── .env                    # Environment variables (gitignored, use this!)
├── .env.example           # Environment template
└── package.json           # npm dependencies
```

## Security Best Practices

1. **Never commit credentials:**
   - `.env` is in `.gitignore` ✅
   - `config/config.json` is in `.gitignore` ✅
   - Only commit `.env.example` and `config.json.example`
   - For local dev, use `.env` only (simpler and secure)

2. **Use strong passwords:**
   - Set a strong `CONFIG_PASSWORD`
   - Rotate Tableau PAT tokens regularly

3. **Limit access:**
   - Run locally only when needed
   - Don't expose port 3000 to the internet
   - Use `ALLOWED_ORIGINS` to restrict CORS

4. **Monitor API usage:**
   - Check OpenAI usage dashboard
   - Set spending limits in OpenAI account

5. **Config file notes:**
   - `config.json` is optional for local development
   - If created (via web UI), it's automatically in `.gitignore`
   - Never commit `config.json` with real credentials

## Quick Reference

### URLs

| Service | URL | Notes |
|---------|-----|-------|
| **Main UI** | `https://localhost/ui/` | Use this for Tableau extensions |
| **Settings** | `https://localhost/settings` | Password: `AdminTableauMCP+` or `TableauMCP2025!` |
| **Prompts** | `https://localhost/prompts` | Password: `AdminTableauMCP+` or `TableauMCP2025!` |
| **Health Check** | `https://localhost/healthz` | No authentication required |
| **Direct Access** | `http://localhost:3000` | ⚠️ Does NOT work with Tableau extensions |

### Commands

```bash
# Start the application
npm run dev

# Start Caddy (in separate terminal - requires sudo)
sudo caddy reverse-proxy --from localhost:443 --to localhost:3000

# Check if services are running
ps aux | grep "node"    # App should be running
ps aux | grep "caddy"   # Caddy should be running

# Stop services
# App: Ctrl+C in the npm terminal
# Caddy: Ctrl+C in the Caddy terminal
```

### Passwords

| Password | Access Level | Use For |
|----------|-------------|---------|
| `AdminTableauMCP+` | Admin | Full access to Settings and Prompts pages |
| `TableauMCP2025!` | Non-Admin | Limited access to Settings and Prompts pages |

## Next Steps

- Read the [README.md](../README.md) for full feature documentation
- Explore the Settings UI at `https://localhost/settings`
- Try example queries in the UI at `https://localhost/ui/`
- Customize system prompts at `https://localhost/prompts`

## Getting Help

If you encounter issues:

1. Check Heroku logs: `heroku logs --tail` (if deploying to Heroku)
2. Check local console output for error messages
3. Verify all environment variables are set correctly
4. Ensure PostgreSQL is running and accessible
5. Check that all dependencies are installed: `npm install`

---

**Happy developing! 🚀**
