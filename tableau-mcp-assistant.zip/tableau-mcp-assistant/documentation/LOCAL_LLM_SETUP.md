# Local LLM Setup Guide

This guide shows you how to use local LLMs (Ollama, LM Studio, etc.) with the Tableau MCP Assistant instead of OpenAI.

## ⚠️ IMPORTANT: Verified Model

**After extensive testing, only ONE model works reliably with Tableau MCP Assistant:**

### ✅ **Qwen 2.5 14B** - RECOMMENDED

```bash
ollama pull qwen2.5:14b
```

**Tested and verified on Apple M4 Pro (9 models tested):**
- ✅ **Qwen 2.5 14B** - Good accuracy, reasonable speed ← **USE THIS**
- ⚠️ **Qwen 2.5 32B** - Better accuracy but too slow (impractical)
- ❌ **Qwen 2.5 7B** - Fast but inaccurate results
- ❌ **Gemma 2 27B** - No tool calling support (Google model)
- ❌ **Phi-3 14B** - No tool calling support (Microsoft model)
- ❌ **Llama 3.1 8B** - Poor parameter accuracy
- ❌ **Llama 3.1 70B** - GPU memory crash (needs 48GB+)
- ❌ **Mistral 7B** - No tool calling support
- ❌ **Hermes variants** - Tool calling not enabled in Ollama

**Result:** Only the Qwen 2.5 family supports tool calling properly. Use 14B variant or stick with OpenAI.

---

## Why Use Local LLMs?

- ✅ **Privacy** - Your data never leaves your machine
- ✅ **Cost** - No API fees (after hardware investment)
- ✅ **Offline** - Works without internet
- ⚠️ **Limitation** - Only Qwen 2.5 14B verified to work
- ⚠️ **Trade-off** - Slower than OpenAI, requires 12GB+ RAM

---

## Option 1: Ollama (Recommended - Easiest)

### 1. Install Ollama

**macOS:**
```bash
brew install ollama
```

**Linux:**
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

**Windows:**
Download from https://ollama.com/download

### 2. Start Ollama

```bash
# Start Ollama server (runs on port 11434)
ollama serve
```

### 3. Pull a Model

**✅ RECOMMENDED: Qwen 2.5 14B (Verified Working)**
```bash
# Best option for M4 Pro / Apple Silicon (needs ~12GB RAM)
ollama pull qwen2.5:14b
```

**⚠️ Alternative (Not Recommended):**
```bash
# Requires 48GB+ unified memory - will crash on most M4 Pro laptops
ollama pull llama3.1:70b

# Poor tool calling accuracy - NOT RECOMMENDED
# ollama pull llama3.1:8b
```

**❌ Models That DON'T Work:**
- `mistral:7b` - No tool calling support
- `adrienbrault/nous-hermes2theta-llama3-8b:f16` - Tool calling not enabled in Ollama
- `llama3.1:8b` - Inaccurate parameters, wrong answers

### 4. Configure in Tableau MCP Assistant

**Via Web UI** (http://localhost:3000/settings):
1. Select **LLM Provider**: `Local LLM (Ollama, LM Studio, etc.)`
2. **Base URL**: `http://localhost:11434/v1`
3. **Model Name**: `qwen2.5:14b`
4. **API Key**: Leave empty
5. Click **Save**

**Or via `.env` file:**
```env
LLM_PROVIDER=local
LOCAL_BASE_URL=http://localhost:11434/v1
LOCAL_MODEL=qwen2.5:14b
LOCAL_API_KEY=
```

### 5. Test It

```bash
# In another terminal, verify Ollama is working
curl http://localhost:11434/v1/models

# Start your app
npm run dev

# Open browser
open http://localhost:3000/ui/
```

---

## Option 2: LM Studio (GUI-Friendly)

### 1. Install LM Studio

Download from: https://lmstudio.ai

### 2. Download a Model

1. Open LM Studio
2. Click **"Search"** tab
3. Search for: `qwen2.5-14b-instruct`
4. Click **Download**

**✅ Verified model for tool calling:**
- `Qwen/Qwen2.5-14B-Instruct-GGUF` (Q4 or Q5 quantization)

**⚠️ Not tested with LM Studio:**
- Other models may or may not work - use at your own risk

### 3. Start Local Server

1. Click **"Local Server"** tab (left sidebar)
2. Select your model
3. Click **"Start Server"**
4. Server runs on `http://localhost:1234`

### 4. Configure in Tableau MCP Assistant

**Via Web UI:**
- **LLM Provider**: `Local LLM`
- **Base URL**: `http://localhost:1234/v1`
- **Model Name**: (copy from LM Studio - e.g., `llama-3.1-8b-instruct`)
- **API Key**: Leave empty

---

## Option 3: LocalAI (Advanced)

### Using Docker:

```bash
# Start LocalAI
docker run -p 8080:8080 \
  -v $PWD/models:/models \
  localai/localai:latest

# Pull a model
curl http://localhost:8080/models/apply \
  -H "Content-Type: application/json" \
  -d '{"id": "TheBloke/Llama-3.1-8B-Instruct-GGUF"}'
```

**Configure:**
- **Base URL**: `http://localhost:8080/v1`
- **Model Name**: Check available models at `http://localhost:8080/v1/models`

---

## Verified Models for Tool Calling

**✅ = Tested and verified to work with Tableau MCP Assistant**

| Model | Size | RAM Needed | Tool Calling | Accuracy | Speed | Status |
|-------|------|------------|--------------|----------|-------|--------|
| **Qwen 2.5 14B** | ~10GB | 12GB | ✅ Excellent | Very Good | ⚡⚡ Medium | ✅ **ONLY PRACTICAL OPTION** |
| Qwen 2.5 32B | ~20GB | 24GB | ✅ Excellent | Excellent | ⚡ Slow | ⚠️ Works but too slow |
| ~~Qwen 2.5 7B~~ | ~6GB | 8GB | ⚠️ Works | ❌ Poor | ⚡⚡⚡ Fast | ❌ Inaccurate results |
| ~~Gemma 2 27B~~ | ~18GB | 20GB | ❌ No support | N/A | N/A | ❌ No tool calling |
| ~~Phi-3 14B~~ | ~10GB | 12GB | ❌ No support | N/A | N/A | ❌ No tool calling |
| ~~Llama 3.1 70B~~ | ~40GB | 48GB+ | Unknown | Unknown | Unknown | ⚠️ GPU memory error on M4 Pro |
| ~~Llama 3.1 8B~~ | ~5GB | 8GB | ❌ Poor | Inaccurate | Fast | ❌ Wrong parameters |
| ~~Hermes variants~~ | ~5GB | 8GB | ❌ Not enabled | N/A | N/A | ❌ Doesn't work in Ollama |
| ~~Mistral 7B~~ | ~4GB | 6GB | ❌ No support | N/A | N/A | ❌ No tool calling |

### Download Verified Model

**Ollama (Recommended):**
```bash
# Only practical model for M4 Pro / Apple Silicon
ollama pull qwen2.5:14b
```

---

## Why Other Models Don't Work

**Based on real testing on Apple M4 Pro:**

### ❌ **Qwen 2.5 7B** - Too Small
**Problem:** Inaccurate tool parameters
- Calls tools but gets parameters wrong
- Returns incorrect results
- Not smart enough for complex Tableau queries

### ❌ **Qwen 2.5 32B** - Too Slow
**Problem:** Takes too long to respond
- Correct results but 3-5x slower than 14B
- Unusable for interactive queries
- Only viable for batch processing

### ❌ **Gemma 2 27B** - No Tool Support
**Problem:** Google's model doesn't support OpenAI-style tool calling
- Model loads fine (uses ~20GB RAM)
- Cannot call MCP tools
- Returns error on tool-based queries

### ❌ **Phi-3 14B** - No Tool Support
**Problem:** Doesn't support OpenAI-style tool calling
- Model loads fine
- But cannot call MCP tools
- Fails immediately on first query

### ❌ **Llama 3.1 8B** - Poor Accuracy
**Problem:** Frequently passes wrong parameters
- Inconsistent tool calling
- JSON formatting errors
- Mixed up parameter types

### ❌ **Mistral 7B** - No Tool Calling
**Problem:** Model doesn't support function calling at all
- Returns 400 error: "does not support tools"
- Not trained for tool use

### ❌ **Hermes Variants** - Not Enabled
**Problem:** Tool calling not enabled in Ollama version
- Model exists but lacks tool calling metadata
- Returns 400 error even though base model supports it

### ❌ **Llama 3.1 70B** - Out of Memory
**Problem:** GPU crashes during model load
- Error: `kIOGPUCommandBufferCallbackErrorOutOfMemory`
- Needs 40-50GB unified memory
- M4 Pro (18-24GB) can't handle it

---

## Testing Tool Calling

Once configured, test if your local LLM can call tools:

1. Open http://localhost:3000/ui/
2. Try a query: "Show me all datasources"
3. **Expected:** LLM calls `list-datasources` tool
4. **If it doesn't work:** Your model may not support tool calling well

### Signs of Good Tool Calling:
- ✅ LLM calls tools without being prompted
- ✅ Correct tool arguments
- ✅ Follows multi-step workflows

### Signs of Poor Tool Calling:
- ❌ LLM describes what it *would* do instead of calling tools
- ❌ Invalid JSON in tool arguments
- ❌ Skips available tools

---

## Troubleshooting

### Issue: "Connection refused"
**Solution:** Check if your local LLM server is running:
```bash
# For Ollama
curl http://localhost:11434/v1/models

# For LM Studio
curl http://localhost:1234/v1/models

# For LocalAI
curl http://localhost:8080/v1/models
```

### Issue: "Tool calling not working"
**Possible causes:**
1. Model doesn't support tool calling → **Use `qwen2.5:14b`** (only verified model)
2. Wrong model format → Ensure using instruct/chat model
3. Temperature too high → Try lower temperature (0.1-0.3)
4. Using unsupported model → Avoid llama3.1:8b, mistral:7b, hermes variants

### Issue: Slow responses
**Solutions:**
- Use smaller model (8B instead of 70B)
- Enable GPU acceleration (check your LLM server settings)
- Reduce `max_tokens` in requests

### Issue: Out of memory / GPU error
**Error message:** `Metal) Execution of the command buffer was aborted due to an error during execution. Insufficient Memory`

**Solution:**
- **Your GPU doesn't have enough memory** for the 70B model
- Switch to `qwen2.5:14b` (needs only ~12GB)
- Remove large models: `ollama rm llama3.1:70b`

---

## Performance Comparison (Verified Results)

| Setup | Speed | Quality | Cost | Privacy | Verified? |
|-------|-------|---------|------|---------|-----------|
| **OpenAI GPT-4o mini** | Very Fast | Excellent | $ | No | ✅ |
| **Local Qwen 2.5 14B** | Medium | Very Good | Free | Yes | ✅ |
| **Local Llama 3.1 70B** | Slow | Excellent | Free | Yes | ⚠️ Needs 48GB+ RAM |
| ~~Local Llama 3.1 8B~~ | Fast | Poor | Free | Yes | ❌ Inaccurate |
| ~~Local Hermes/Mistral~~ | Fast | N/A | Free | Yes | ❌ Doesn't work |

---

## Next Steps

1. **Install Qwen 2.5 14B** - `ollama pull qwen2.5:14b`
2. **Configure profile** - Set model to `qwen2.5:14b` in settings
3. **Test basic queries** - Verify connection works
4. **Test tool calling** - Try "What datasources are available?"
5. **Tune temperature** - Lower values (0.1-0.3) work better for tool calling
6. **Monitor performance** - Check response times on your hardware

---

## Useful Commands

```bash
# Ollama - List downloaded models
ollama list

# Ollama - Remove a model
ollama rm llama3.1:8b

# Ollama - Check running models and memory usage
ollama ps

# Test OpenAI-compatible API with verified model
curl http://localhost:11434/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "qwen2.5:14b",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```

---

## Conclusion

**After extensive testing, here's the reality:**

### ✅ **For Production Use:**
**Use OpenAI (default profile)** - It's faster, more reliable, and costs ~$0.15 per 1M tokens (very cheap).

### ✅ **For Privacy/Offline Use:**
**Use Qwen 2.5 14B** - It's the ONLY local model that works reliably on consumer hardware (M4 Pro).

### ❌ **Don't Bother Testing:**
- Other 7-8B models (too inaccurate)
- Other 14B models (no tool support)  
- 32B+ models (too slow for interactive use)
- 70B models (need 48GB+ RAM, crash on M4 Pro)

**Bottom line:** Qwen 2.5 14B is a happy accident - it's one of the few open-source models that:
1. Fits in consumer laptop memory (12GB)
2. Supports OpenAI-style tool calling
3. Has decent parameter accuracy
4. Runs at reasonable speed

If you need better performance, just use OpenAI. If you need privacy, use Qwen 2.5 14B. There's no practical middle ground.

---

## Resources

- [Ollama Documentation](https://github.com/ollama/ollama)
- [Qwen 2.5 Model Card](https://huggingface.co/Qwen/Qwen2.5-14B-Instruct)
- [LM Studio](https://lmstudio.ai)
- [LocalAI](https://localai.io)
- [Function Calling with Open Source LLMs](https://gorilla.cs.berkeley.edu/blogs/8_berkeley_function_calling_leaderboard.html)

---

**Last Updated:** 2026-04-08  
**Testing Platform:** Apple M4 Pro (24GB unified memory)  
**Models Tested:** 9 models across multiple families (Qwen, Llama, Gemma, Phi, Mistral, Hermes)  
**Result:** Only Qwen 2.5 14B is practical for interactive use
