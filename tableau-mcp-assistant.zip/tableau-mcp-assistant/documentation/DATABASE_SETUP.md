# Database Setup Guide

This document explains how the Tableau MCP Assistant handles database initialization.

## Automatic Database Setup ✅

**Good news!** All database tables are created automatically on first run. No manual migrations needed!

## What Happens on First Run

When you start the application for the first time, it automatically creates:

### 1. Profiles Table
**Created by:** `src/util/db.ts`

Stores application configuration profiles (for multi-user scenarios).

```sql
CREATE TABLE IF NOT EXISTS profiles (
  name VARCHAR(255) PRIMARY KEY,
  settings JSONB NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
```

### 2. Prompt Management Tables
**Created by:** `src/util/PromptManager.ts`

Stores system prompts with version control:

#### prompt_sections
Stores active prompt content
```sql
CREATE TABLE IF NOT EXISTS prompt_sections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  section_name VARCHAR(100) UNIQUE NOT NULL,
  description TEXT,
  content TEXT NOT NULL,
  active_version INT NOT NULL DEFAULT 1,
  conditional_rule JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

#### prompt_versions
Version history for rollback capability
```sql
CREATE TABLE IF NOT EXISTS prompt_versions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  section_id UUID NOT NULL REFERENCES prompt_sections(id) ON DELETE CASCADE,
  version INT NOT NULL,
  content TEXT NOT NULL,
  created_by VARCHAR(100),
  change_summary TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(section_id, version)
);
```

#### prompt_variables
Runtime variable interpolation
```sql
CREATE TABLE IF NOT EXISTS prompt_variables (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  variable_name VARCHAR(100) UNIQUE NOT NULL,
  value TEXT NOT NULL,
  data_type VARCHAR(20) DEFAULT 'string',
  description TEXT,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### 3. Database Functions & Triggers

Automatically creates:
- Version increment trigger for prompts
- Indexes for performance
- Initial variables (e.g., `MAX_VIEW_ROWS_FOR_MODEL`)

## Quick Start

```bash
# 1. Create empty database
createdb tableau_mcp

# 2. Set DATABASE_URL in .env
echo "DATABASE_URL=postgresql://localhost/tableau_mcp" >> .env

# 3. Run the app - tables auto-create!
npm run dev
```

## What You'll See in Logs

```
[Database] Database connection pool initialized
[Database] Database schema initialized successfully
[PromptManager] Database connection pool initialized
[PromptManager] Database schema initialized successfully
[PromptManager] Loaded 1 variables
[PromptManager] Initialized successfully
[Startup] PromptManager initialized successfully
Server listening on port 3000
```

## Migration Files (Optional)

The `migrations/` directory contains optional SQL files:
- ~~`001_add_prompt_management.sql`~~ - ❌ DELETED (schema auto-creates)
- `002_seed_core_prompt.sql` - ⚠️ OPTIONAL (seeds prompt data for /prompts UI)

**You don't need to run these!** The application code creates all tables automatically.

The `002_seed_core_prompt.sql` file is only needed if you want to:
- Use the `/prompts` management web UI
- Edit prompts through the browser instead of files

See [migrations/README.md](../migrations/README.md) for details.

## Database Schema Diagram

```
┌─────────────────────┐
│     profiles        │
├─────────────────────┤
│ name (PK)           │
│ settings (JSONB)    │
│ created_at          │
│ updated_at          │
└─────────────────────┘

┌─────────────────────┐
│  prompt_sections    │
├─────────────────────┤
│ id (PK)             │
│ section_name (UQ)   │
│ description         │
│ content             │
│ active_version      │
│ conditional_rule    │
│ created_at          │
│ updated_at          │
└─────────┬───────────┘
          │
          │ 1:N
          ▼
┌─────────────────────┐
│  prompt_versions    │
├─────────────────────┤
│ id (PK)             │
│ section_id (FK)     │
│ version             │
│ content             │
│ created_by          │
│ change_summary      │
│ created_at          │
└─────────────────────┘

┌─────────────────────┐
│ prompt_variables    │
├─────────────────────┤
│ id (PK)             │
│ variable_name (UQ)  │
│ value               │
│ data_type           │
│ description         │
│ updated_at          │
└─────────────────────┘
```

## Verifying Database Setup

After starting the app, you can verify the tables were created:

```bash
# Connect to database
psql tableau_mcp

# List all tables
\dt

# Expected output:
#  Schema |       Name        | Type  |  Owner
# --------+-------------------+-------+---------
#  public | profiles          | table | your_user
#  public | prompt_sections   | table | your_user
#  public | prompt_variables  | table | your_user
#  public | prompt_versions   | table | your_user

# Check table schemas
\d profiles
\d prompt_sections
\d prompt_versions
\d prompt_variables

# Exit
\q
```

## Troubleshooting

### "Database connection pool initialized" but tables not created

**Problem:** Tables don't exist after starting app

**Solution:**
1. Check PostgreSQL is running: `pg_isready`
2. Verify DATABASE_URL is correct in `.env`
3. Check app logs for errors
4. Manually test connection: `psql $DATABASE_URL`

### "relation 'prompt_sections' does not exist"

**Problem:** Prompt tables weren't created

**Solution:**
1. Check that PromptManager initialized successfully in logs
2. If it failed, check for SQL syntax errors in logs
3. Try deleting and recreating database:
   ```bash
   dropdb tableau_mcp
   createdb tableau_mcp
   npm run dev
   ```

### Permission denied errors

**Problem:** User doesn't have permission to create tables

**Solution:**
```bash
# Grant permissions to your user
psql tableau_mcp -c "GRANT ALL PRIVILEGES ON DATABASE tableau_mcp TO your_username;"

# Or connect as superuser
psql -U postgres tableau_mcp
```

### Tables exist but app fails to start

**Problem:** Schema mismatch or corrupted data

**Solution:**
```bash
# Option 1: Drop and recreate specific tables
psql tableau_mcp -c "DROP TABLE IF EXISTS prompt_versions CASCADE;"
psql tableau_mcp -c "DROP TABLE IF EXISTS prompt_sections CASCADE;"
psql tableau_mcp -c "DROP TABLE IF EXISTS prompt_variables CASCADE;"
psql tableau_mcp -c "DROP TABLE IF EXISTS profiles CASCADE;"
# Then restart app - tables will auto-recreate

# Option 2: Fresh database
dropdb tableau_mcp
createdb tableau_mcp
npm run dev
```

## For Heroku Deployment

Heroku automatically provisions PostgreSQL and sets `DATABASE_URL`. Tables auto-create on first dyno start:

```bash
# Add Postgres addon
heroku addons:create heroku-postgresql:essential-0

# Deploy app
git push heroku main

# Check logs to verify table creation
heroku logs --tail | grep "Database schema initialized"
```

## Benefits of Auto-Creation

✅ **Zero configuration** - No manual SQL to run
✅ **Idempotent** - Safe to run multiple times
✅ **Version controlled** - Schema is in code, not separate files
✅ **Dev/prod parity** - Same setup process everywhere
✅ **Fast onboarding** - New developers can start immediately

---

**Related Documentation:**
- [Local Development Setup](LOCAL_DEVELOPMENT.md)
- [Configuration Guide](CONFIGURATION_GUIDE.md)
- [README](../README.md)
