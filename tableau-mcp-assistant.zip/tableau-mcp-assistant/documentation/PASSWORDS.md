# Password Authentication Guide

This document clarifies how passwords work in the Tableau MCP Assistant application.

## Important: CONFIG_PASSWORD is NOT Used

### What is CONFIG_PASSWORD?

`CONFIG_PASSWORD` is an **environment variable** that:
- ✅ **IS required** by the application schema (app won't start without it)
- ❌ **IS NOT used** for any authentication
- ✅ **CAN be set to any value**

**Example:**
```env
CONFIG_PASSWORD=schema-required-not-used
```

This is a legacy/unused configuration field that remains in the codebase for backward compatibility.

---

## Actual Web UI Passwords

The application uses **hardcoded passwords** to protect the Settings and Prompts management interfaces.

### Password Tiers

| Password | Access Level | Where Used | Permissions |
|----------|-------------|------------|-------------|
| `AdminTableauMCP+` | **Admin** | `/settings`<br>`/prompts` | • Edit all profiles (including "default")<br>• Delete prompt versions<br>• Full configuration access |
| `TableauMCP2025!` | **Non-Admin** | `/settings`<br>`/prompts` | • Edit non-default profiles only<br>• Cannot delete prompt versions<br>• Limited configuration access |

### Where to Use These Passwords

#### Settings Page (`/settings`)
Access profile configuration, manage credentials, and test connections.

**When prompted for password, use:**
- `AdminTableauMCP+` - for full administrative access
- `TableauMCP2025!` - for limited profile management

#### Prompts Page (`/prompts`)
Edit system prompts, manage versions, and customize AI behavior.

**When prompted for password, use:**
- `AdminTableauMCP+` - for full access including deletion
- `TableauMCP2025!` - for read/edit access (cannot delete)

#### Main UI (`/ui/`)
**No password required** - accessible to all users.

---

## Where Are These Passwords Defined?

The hardcoded passwords are defined in the source code:

### src/routes/settings.ts
```typescript
function checkPassword(_req: Request, res: Response, next: Function): void {
  const password = _req.body?.password || _req.query?.password;

  const nonAdminPassword = 'TableauMCP2025!';
  const adminPassword = 'AdminTableauMCP+';

  if (password === adminPassword) {
    (_req as any).isAdmin = true;
    next();
  } else if (password === nonAdminPassword) {
    (_req as any).isAdmin = false;
    next();
  } else {
    res.status(401).json({ error: 'Invalid password' });
    return;
  }
}
```

### src/routes/prompts.ts
```typescript
function checkAdminPassword(_req: Request, res: Response, next: Function): void {
  const password = _req.body?.password || _req.query?.password;

  const adminPassword = 'AdminTableauMCP+';

  if (password === adminPassword) {
    (_req as any).isAdmin = true;
    next();
  } else {
    res.status(401).json({ error: 'Invalid password or insufficient permissions' });
    return;
  }
}
```

---

## Security Implications

### Current State
- ⚠️ **Passwords are hardcoded** in the source code
- ⚠️ **Same passwords for all users** (no per-user authentication)
- ⚠️ **No password rotation** mechanism
- ⚠️ **Visible in source code** (not environment variables)

### Recommendations for Production

If you're deploying this application to production, consider:

1. **Move passwords to environment variables:**
   ```typescript
   const adminPassword = process.env.ADMIN_PASSWORD;
   const nonAdminPassword = process.env.NON_ADMIN_PASSWORD;
   ```

2. **Implement proper authentication:**
   - OAuth 2.0 / SSO (Google, Azure AD, Okta)
   - JWT tokens with expiration
   - Session management
   - User-specific credentials

3. **Add role-based access control (RBAC):**
   - Define roles (admin, editor, viewer)
   - Store user permissions in database
   - Implement middleware for route protection

4. **Use strong password requirements:**
   - Minimum length (12+ characters)
   - Complexity requirements
   - Password expiration
   - Account lockout after failed attempts

---

## Quick Reference

### For Local Development

```bash
# .env file
CONFIG_PASSWORD=not-used-set-anything  # Required but not used

# Web UI access
Settings page: http://localhost:3000/settings
Password: AdminTableauMCP+ or TableauMCP2025!

Prompts page: http://localhost:3000/prompts  
Password: AdminTableauMCP+ or TableauMCP2025!

Main UI: http://localhost:3000/ui/
Password: None required
```

### For Heroku Deployment

```bash
# Set config var (required by schema)
heroku config:set CONFIG_PASSWORD=schema-required-not-used

# Web UI access remains the same
Settings: https://your-app.herokuapp.com/settings
Password: AdminTableauMCP+ or TableauMCP2025!

Prompts: https://your-app.herokuapp.com/prompts
Password: AdminTableauMCP+ or TableauMCP2025!
```

---

## Troubleshooting

### "Invalid password" error

**Problem:** You're trying to access `/settings` or `/prompts` but getting "Invalid password" error.

**Solution:** Ensure you're using the correct hardcoded passwords:
- `AdminTableauMCP+` (admin access)
- `TableauMCP2025!` (non-admin access)

**Note:** Do NOT use the value from `CONFIG_PASSWORD` environment variable - it's not used for authentication.

### "Missing required configuration" error

**Problem:** App won't start, showing "Missing required configuration" error.

**Solution:** Set `CONFIG_PASSWORD` in your `.env` file (any value works):
```env
CONFIG_PASSWORD=schema-required-not-used
```

### "Non-admin users cannot edit the 'default' profile"

**Problem:** You're using `TableauMCP2025!` password but can't edit the default profile.

**Solution:** Use the admin password instead:
- Password: `AdminTableauMCP+`

---

## Summary

| Item | Status | Details |
|------|--------|---------|
| `CONFIG_PASSWORD` env var | Required but unused | Set to any value |
| `AdminTableauMCP+` | Active admin password | Hardcoded in source |
| `TableauMCP2025!` | Active non-admin password | Hardcoded in source |
| Main UI (`/ui/`) | No authentication | Public access |
| Settings UI (`/settings`) | Password protected | Uses hardcoded passwords |
| Prompts UI (`/prompts`) | Password protected | Uses hardcoded passwords |

---

**For more information, see:**
- [Configuration Guide](CONFIGURATION_GUIDE.md)
- [Local Development Setup](LOCAL_DEVELOPMENT.md)
- [README](../README.md)
