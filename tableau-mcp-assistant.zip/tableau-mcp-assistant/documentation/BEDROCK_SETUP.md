# AWS Bedrock Integration

This application supports AWS Bedrock as an LLM provider, allowing you to use Claude Sonnet 4.6 directly from AWS Bedrock with full streaming and tool calling support.

## Quick Start

1. **Configure AWS SSO Profile** (see detailed steps below)
2. **Enable Claude model access** in AWS Bedrock Console
3. **Create a Bedrock profile** in Settings UI
4. **Start chatting** with Claude via AWS Bedrock

---

## Step-by-Step Setup

### Step 1: Configure AWS SSO Profile

**Prerequisites:**
- AWS CLI installed (`aws --version` to check)
- Access to your organization's AWS SSO portal

**Configuration Steps:**

1. **Run the AWS SSO configuration command:**
   ```bash
   aws configure sso
   ```

2. **Answer the prompts:**
   ```
   SSO session name (Recommended): my-sso-session
   SSO start URL [None]: https://your-company.awsapps.com/start
   SSO region [None]: us-east-1
   SSO registration scopes [sso:account:access]: sso:account:access
   ```
   
   The CLI will open a browser window for you to authenticate with your SSO credentials.

3. **After authentication, select your AWS account and role:**
   ```
   There are N AWS accounts available to you.
   > Your-Account-Name, your-account@company.com (123456789012)
   
   Using the account ID 123456789012
   There are N roles available to you.
   > YourRoleName
   
   CLI default client Region [None]: us-east-1
   CLI default output format [None]: json
   CLI profile name [YourRoleName-123456789012]: my-bedrock-profile
   ```
   
   **IMPORTANT:** Remember the profile name you choose (e.g., `my-bedrock-profile`). You'll use this in the Settings page.

4. **Verify your AWS SSO configuration:**
   ```bash
   aws sts get-caller-identity --profile my-bedrock-profile
   ```
   
   You should see output like:
   ```json
   {
     "UserId": "AROA...:your.email@company.com",
     "Account": "123456789012",
     "Arn": "arn:aws:sts::123456789012:assumed-role/YourRoleName/your.email@company.com"
   }
   ```

5. **Your `~/.aws/config` will now contain:**
   ```ini
   [profile my-bedrock-profile]
   sso_session = my-sso-session
   sso_account_id = 123456789012
   sso_role_name = YourRoleName
   region = us-east-1
   output = json

   [sso-session my-sso-session]
   sso_start_url = https://your-company.awsapps.com/start
   sso_region = us-east-1
   sso_registration_scopes = sso:account:access
   ```

**SSO Session Management:**

Your SSO session will expire after several hours (typically 1-12 hours). When it expires, you'll need to re-authenticate:

```bash
aws sso login --profile my-bedrock-profile
```

This will open a browser for re-authentication.

---

### Step 2: Enable Claude Model Access in AWS Bedrock

1. **Go to AWS Bedrock Console:**
   - Navigate to [AWS Bedrock Console](https://console.aws.amazon.com/bedrock)
   - Select your region (e.g., us-east-1)

2. **Enable Model Access:**
   - Click **"Model access"** in the left sidebar
   - Click **"Enable specific models"** or **"Manage model access"**
   - Find **"Claude"** in the list
   - Check the box for **Anthropic Claude models**
   - Click **"Request model access"** or **"Save changes"**
   
   ⏱️ Model access is typically granted within seconds for Claude models.

3. **Verify Model Access:**
   - The status for Claude models should show **"Access granted"**
   - Note the **Inference profile ID** column - you'll see IDs like `us.anthropic.claude-sonnet-4-6`

---

### Step 3: Configure Bedrock Profile in Settings UI

1. **Open Settings Page:**
   - Navigate to [http://localhost:3000/settings](http://localhost:3000/settings)

2. **Create New Profile:**
   - Enter a profile name (e.g., `AWS-Bedrock`)
   - Click **"Create New Profile"**

3. **Configure Profile Settings:**

   | Field | Value | Description |
   |-------|-------|-------------|
   | **LLM Provider** | `AWS Bedrock` | Select from dropdown |
   | **AWS Region** | `us-east-1` | Region for Bedrock API endpoint (required) |
   | **Model ID** | `Claude Sonnet 4.6` | Only confirmed working model |
   | **AWS Profile Name** | `my-bedrock-profile` | The profile name from Step 1 |
   | **Access Key ID** | *(leave blank)* | Not needed when using profile |
   | **Secret Access Key** | *(leave blank)* | Not needed when using profile |

4. **Configure Tableau Settings:**
   - Fill in your Tableau server details (Base URL, Site, PAT credentials)
   - These are the same as your other profiles

5. **Save Profile:**
   - Click **"Save Profile"** button at the bottom
   - You should see a success message

---

### Step 4: Start Using Bedrock

1. **Open Main UI:**
   - Navigate to [http://localhost:3000/ui/](http://localhost:3000/ui/)

2. **Select Your Profile:**
   - Choose your `AWS-Bedrock` profile from the dropdown
   - The model should automatically select `Claude Sonnet 4.6`

3. **Start a Session:**
   - Click **"Start"** button
   - You should see "Session started successfully"

4. **Start Chatting:**
   - Type a message and press Enter or click Send
   - Claude Sonnet 4.6 will respond via AWS Bedrock

---

## Configuration Reference

### Required Settings

| Setting | Required | Description | Example |
|---------|----------|-------------|---------|
| **BEDROCK_REGION** | ✅ Yes | AWS region for Bedrock API endpoint | `us-east-1` |
| **BEDROCK_MODEL_ID** | ✅ Yes | Model inference profile ID | `us.anthropic.claude-sonnet-4-6` |
| **BEDROCK_PROFILE** | ⚠️ One of three | AWS SSO/CLI profile name (recommended) | `my-bedrock-profile` |
| **Default Credential Chain** | ⚠️ One of three | Leave all fields blank to use default | *(no config needed)* |
| **Explicit Keys** | ⚠️ One of three | Access key ID + secret (not recommended) | See below |

**Credential Priority (in order):**
1. Explicit credentials (BEDROCK_ACCESS_KEY_ID + BEDROCK_SECRET_ACCESS_KEY)
2. Named profile (BEDROCK_PROFILE)
3. Default credential chain (~/.aws/credentials, environment variables, EC2 instance profile)

### AWS Region

**Why is region required even when using AWS Profile?**

The AWS profile handles **authentication** (who you are), but the region specifies **which Bedrock endpoint to connect to** (where to send requests). These are two separate concerns:

- **Profile**: Provides credentials → `bedrock-runtime.{region}.amazonaws.com`
- **Region**: Determines the API endpoint → `us-east-1`, `us-west-2`, etc.

Even with cross-region inference (models with `us.` prefix), you still need to specify which regional endpoint to call.

**Available Regions:**
- `us-east-1` (N. Virginia) - Most common
- `us-west-2` (Oregon)
- `us-east-2` (Ohio)
- `eu-west-1` (Ireland)
- `eu-west-2` (London)
- `eu-central-1` (Frankfurt)
- `ap-southeast-1` (Singapore)
- `ap-southeast-2` (Sydney)
- `ap-northeast-1` (Tokyo)
- `ap-south-1` (Mumbai)
- `ca-central-1` (Canada)
- `sa-east-1` (São Paulo)

---

## Available Models

### Confirmed Working Model

**Claude Sonnet 4.6** - `us.anthropic.claude-sonnet-4-6`
- ✅ Confirmed working with inference profile ID
- ✅ Full streaming support
- ✅ Tool calling support
- ✅ Token usage tracking
- ✅ Works from any region (cross-region inference)

### Why Only One Model?

AWS Bedrock uses two types of model identifiers:

1. **Inference Profile IDs** (format: `us.anthropic.claude-*`)
   - ✅ Works with on-demand throughput (pay-per-use)
   - ✅ Cross-region routing
   - Only Claude Sonnet 4.6 confirmed working: `us.anthropic.claude-sonnet-4-6`

2. **Direct Model IDs** (format: `anthropic.claude-*-YYYYMMDD-v1:0`)
   - ❌ Requires provisioned throughput (capacity reservation)
   - ❌ Error: "Invocation of model ID ... with on-demand throughput isn't supported"

Model availability varies by AWS account and region. If you want to use other Claude models, check your AWS Bedrock Console → Model access for available inference profile IDs.

---

## Alternative Authentication Methods

### Option A: AWS SSO Profile (Recommended) ⭐

**Best for:** Organizations using AWS SSO/Identity Center

```json
{
  "AWS-Bedrock": {
    "LLM_PROVIDER": "bedrock",
    "BEDROCK_REGION": "us-east-1",
    "BEDROCK_MODEL_ID": "us.anthropic.claude-sonnet-4-6",
    "BEDROCK_PROFILE": "my-bedrock-profile",
    
    "TABLEAU_BASE_URL": "https://your-tableau-server.com",
    "TABLEAU_SITE_CONTENT_URL": "your-site",
    "AUTHENTICATION_TYPE": "pat",
    "TABLEAU_PAT_NAME": "your-pat-name",
    "TABLEAU_PAT_SECRET": "your-pat-secret"
  }
}
```

### Option B: Default Credential Chain

**Best for:** Using existing `~/.aws/credentials` or environment variables

```json
{
  "AWS-Bedrock": {
    "LLM_PROVIDER": "bedrock",
    "BEDROCK_REGION": "us-east-1",
    "BEDROCK_MODEL_ID": "us.anthropic.claude-sonnet-4-6",
    
    "TABLEAU_BASE_URL": "https://your-tableau-server.com",
    "TABLEAU_SITE_CONTENT_URL": "your-site",
    "AUTHENTICATION_TYPE": "pat",
    "TABLEAU_PAT_NAME": "your-pat-name",
    "TABLEAU_PAT_SECRET": "your-pat-secret"
  }
}
```

Your `~/.aws/credentials` should contain:
```ini
[default]
aws_access_key_id = YOUR_ACCESS_KEY
aws_secret_access_key = YOUR_SECRET_KEY
```

### Option C: Explicit Credentials (Not Recommended)

**Best for:** Testing only - not recommended for production

```json
{
  "AWS-Bedrock": {
    "LLM_PROVIDER": "bedrock",
    "BEDROCK_REGION": "us-east-1",
    "BEDROCK_MODEL_ID": "us.anthropic.claude-sonnet-4-6",
    "BEDROCK_ACCESS_KEY_ID": "AKIAIOSFODNN7EXAMPLE",
    "BEDROCK_SECRET_ACCESS_KEY": "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
    
    "TABLEAU_BASE_URL": "https://your-tableau-server.com",
    "TABLEAU_SITE_CONTENT_URL": "your-site",
    "AUTHENTICATION_TYPE": "pat",
    "TABLEAU_PAT_NAME": "your-pat-name",
    "TABLEAU_PAT_SECRET": "your-pat-secret"
  }
}
```

⚠️ **Warning:** Never commit credentials to git. Use AWS Secrets Manager or Parameter Store for production.

---

## Troubleshooting

### SSO Authentication Errors

**Error:** `The security token included in the request is invalid`

**Solutions:**
1. Your SSO session expired - log in again:
   ```bash
   aws sso login --profile my-bedrock-profile
   ```

2. Verify your profile name is correct:
   ```bash
   cat ~/.aws/config | grep "profile"
   ```

3. Test your credentials:
   ```bash
   aws sts get-caller-identity --profile my-bedrock-profile
   ```

**Error:** `Token has expired and refresh failed`

**Solution:** SSO tokens typically expire after 1-12 hours. Run:
```bash
aws sso login --profile my-bedrock-profile
```

**Error:** `Profile not found: my-bedrock-profile`

**Solution:** 
1. Check your profile name in `~/.aws/config`
2. Make sure you're using the exact same name in the Settings page
3. Re-run `aws configure sso` if needed

---

### Model Access Errors

**Error:** `The provided model identifier is invalid`

**Solutions:**
1. Make sure you're using the inference profile ID: `us.anthropic.claude-sonnet-4-6`
2. Verify model access is enabled in AWS Bedrock Console → Model access
3. Check that Claude models show "Access granted" status

**Error:** `Invocation of model ID ... with on-demand throughput isn't supported`

**Solution:** You're using a direct model ID (with date) instead of an inference profile ID.
- ❌ Wrong: `anthropic.claude-haiku-4-5-20251001-v1:0`
- ✅ Correct: `us.anthropic.claude-sonnet-4-6`

**Error:** `ValidationException: The requested model is not available`

**Solutions:**
1. Enable Claude model access in AWS Bedrock Console → Model access
2. Wait a few seconds after enabling (usually instant)
3. Verify you're in the correct AWS region

---

### Region Errors

**Error:** `Could not resolve endpoint`

**Solutions:**
1. Verify region format is correct: `us-east-1` (not `us-east-1a`)
2. Check Bedrock is available in your selected region
3. Try `us-east-1` or `us-west-2` (most reliable)

---

### Profile Configuration Errors

**Error in Settings:** `Missing required fields for selected LLM provider`

**Solutions:**
1. Make sure **AWS Region** is selected
2. Make sure **Model ID** is selected (Claude Sonnet 4.6)
3. Make sure at least one authentication method is configured:
   - AWS Profile Name filled in, OR
   - All fields blank (for default credential chain), OR
   - Access Key ID + Secret Access Key filled in

---

## IAM Permissions Required

Your AWS IAM user or role needs these permissions to use Bedrock:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "BedrockInvokeModel",
      "Effect": "Allow",
      "Action": [
        "bedrock:InvokeModel",
        "bedrock:InvokeModelWithResponseStream"
      ],
      "Resource": "arn:aws:bedrock:*::foundation-model/*"
    }
  ]
}
```

**How to verify permissions:**
```bash
aws iam get-user --profile my-bedrock-profile
aws iam list-attached-user-policies --user-name YourUserName --profile my-bedrock-profile
```

---

## Features

- ✅ **Full streaming support** - Real-time response generation
- ✅ **Tool/function calling** - Uses Tableau MCP tools
- ✅ **Token usage tracking** - See input/output token counts
- ✅ **AWS SSO integration** - Seamless SSO authentication
- ✅ **Multi-region support** - Works from any AWS region
- ✅ **Cross-region inference** - Model routing handled automatically

---

## Pricing

AWS Bedrock pricing is pay-per-use based on input/output tokens.

**Claude Sonnet 4.6 Pricing (as of 2025):**
- Input: ~$3.00 per million tokens
- Output: ~$15.00 per million tokens

**Example Cost:**
- 10,000 input tokens = $0.03
- 5,000 output tokens = $0.075
- **Total: ~$0.10 per conversation**

💡 **Tip:** Monitor costs in AWS Cost Explorer or set up billing alerts.

Check the [AWS Bedrock pricing page](https://aws.amazon.com/bedrock/pricing/) for current rates in your region.

---

## Comparison with OpenAI Provider

| Feature | OpenAI | AWS Bedrock |
|---------|--------|-------------|
| **Streaming** | ✅ | ✅ |
| **Tool Calling** | ✅ | ✅ |
| **Token Usage** | ✅ | ✅ |
| **Setup Complexity** | Low | Medium |
| **Authentication** | API Key | AWS IAM/SSO |
| **Data Residency** | OpenAI servers | Your AWS region |
| **Pricing** | Per-token | Per-token (AWS billing) |
| **Model Selection** | Multiple models | Claude Sonnet 4.6 |
| **Enterprise Features** | Limited | Full AWS integration |

---

## Security Best Practices

1. **Use AWS SSO** instead of long-term access keys
2. **Enable AWS CloudTrail** to audit Bedrock API calls
3. **Use IAM roles** for EC2/ECS deployments (no keys needed)
4. **Rotate credentials** regularly if using access keys
5. **Never commit credentials** to git repositories
6. **Use AWS Secrets Manager** for production credential storage
7. **Apply least privilege** IAM policies (only bedrock:InvokeModel permissions)
8. **Monitor costs** with AWS Cost Explorer and billing alerts

---

## Getting Help

**If you encounter issues:**

1. Check the Troubleshooting section above
2. Verify AWS SSO login: `aws sso login --profile your-profile`
3. Test AWS credentials: `aws sts get-caller-identity --profile your-profile`
4. Check model access in AWS Bedrock Console
5. Review application logs for detailed error messages

**Useful AWS CLI Commands:**

```bash
# List all AWS profiles
cat ~/.aws/config | grep "profile"

# Verify current credentials
aws sts get-caller-identity --profile my-bedrock-profile

# Login to AWS SSO
aws sso login --profile my-bedrock-profile

# Logout from AWS SSO
aws sso logout

# Test Bedrock access (requires aws bedrock-runtime)
aws bedrock list-foundation-models --region us-east-1 --profile my-bedrock-profile
```
