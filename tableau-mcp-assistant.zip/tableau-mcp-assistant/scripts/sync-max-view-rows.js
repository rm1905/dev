/**
 * Sync MAX_VIEW_ROWS_FOR_MODEL in database with broker.ts constant
 * v275: Update from 20 to 30
 */
const { Client } = require('pg');

async function syncMaxViewRows() {
  const client = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.NODE_ENV === 'production' ? {
      rejectUnauthorized: false
    } : false,
  });

  try {
    await client.connect();
    console.log('Connected to database');

    // Update the variable value from "20" to "30"
    const result = await client.query(
      `UPDATE prompt_variables
       SET value = $1, updated_at = CURRENT_TIMESTAMP
       WHERE variable_name = $2`,
      ['30', 'MAX_VIEW_ROWS_FOR_MODEL']
    );

    if (result.rowCount === 0) {
      console.error('ERROR: MAX_VIEW_ROWS_FOR_MODEL variable not found in prompt_variables table');
      process.exit(1);
    }

    console.log('✅ Successfully updated MAX_VIEW_ROWS_FOR_MODEL from 20 to 30');

    // Verify the update
    const verify = await client.query(
      'SELECT variable_name, value, data_type, description FROM prompt_variables WHERE variable_name = $1',
      ['MAX_VIEW_ROWS_FOR_MODEL']
    );

    console.log('\nVerification:');
    console.log(JSON.stringify(verify.rows[0], null, 2));

    await client.end();
  } catch (err) {
    console.error('Database Error:', err.message);
    process.exit(1);
  }
}

syncMaxViewRows();
