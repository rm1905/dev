const fs = require('fs');
const path = require('path');

const PROMPTS_DIR = path.join(__dirname, '..', 'src', 'prompts');
const OUTPUT_FILE = path.join(__dirname, '..', 'SYSTEM_PROMPT.md');

const sections = [
  {
    file: 'core_prompt.md',
    title: 'Core System Prompt',
    description: 'Always included. Contains technical guardrails, validation requirements, workflow protocols.',
    condition: 'Always included'
  },
  {
    file: 'scope_section_dashboard.md',
    title: 'Dashboard Scope Mode',
    description: 'Scope-specific operation guidance for dashboard-scoped questions.',
    condition: 'toolProfile = "dashboard_qna"'
  },
  {
    file: 'scope_section_global.md',
    title: 'Global Access Mode',
    description: 'Scope-specific operation guidance for site-wide questions.',
    condition: 'toolProfile = "global_qna"'
  },
  {
    file: 'scope_rules_both_modes.md',
    title: 'Scope Rules',
    description: 'Scope rules that apply to both modes.',
    condition: 'Always included'
  },
  {
    file: 'datasource_query_guidance.md',
    title: 'Datasource Query Guidance',
    description: 'Detailed guidance for query-datasource tool.',
    condition: 'intent = "datasource_query" OR "unknown"'
  },
  {
    file: 'content_discovery_guidance.md',
    title: 'Content Discovery Guidance',
    description: 'Guidance for listing and searching for content.',
    condition: 'intent = "content_discovery" OR "unknown"'
  },
  {
    file: 'search_content_guidance.md',
    title: 'Search Content Tool Guidance',
    description: 'Specific guidance for search-content tool.',
    condition: 'toolProfile = "global_qna"'
  },
  {
    file: 'pulse_planner_guidance.md',
    title: 'Pulse Planner Guidance',
    description: 'Guidance for Pulse metric planning and insight generation.',
    condition: '(intent = "pulse_query" OR "unknown") AND toolProfile = "global_qna"'
  },
  {
    file: 'pulse_presentation_guidance.md',
    title: 'Pulse Presentation Guidance',
    description: 'Presentation standards specific to Pulse insights.',
    condition: '(intent = "pulse_query" OR "unknown") AND toolProfile = "global_qna"'
  }
];

function buildSystemPrompt() {
  let output = [];
  output.push('# Tableau MCP Extension - System Prompt\n');
  output.push('> **Auto-generated from /src/prompts/*.md**');
  output.push('> Last updated: ' + new Date().toISOString());
  output.push('> Run `node scripts/sync-system-prompt.cjs` to regenerate\n');
  output.push('## Table of Contents\n');
  sections.forEach((section, idx) => {
    const num = idx + 1;
    const anchor = section.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    output.push(num + '. [' + section.title + '](#' + anchor + ')');
  });
  output.push('\n---\n');

  sections.forEach((section, index) => {
    const num = index + 1;
    output.push('## ' + num + '. ' + section.title + '\n');
    output.push('**File**: `src/prompts/' + section.file + '`');
    output.push('**Condition**: ' + section.condition);
    output.push('**Description**: ' + section.description + '\n');
    output.push('```markdown');

    const sectionPath = path.join(PROMPTS_DIR, section.file);
    try {
      const content = fs.readFileSync(sectionPath, 'utf-8');
      output.push(content.trim());
    } catch (error) {
      output.push('ERROR: Could not read ' + section.file);
      console.error('Error reading ' + section.file + ':', error.message);
    }

    output.push('```\n\n---\n');
  });

  return output.join('\n');
}

console.log('Syncing SYSTEM_PROMPT.md from prompt files...\n');
const content = buildSystemPrompt();
fs.writeFileSync(OUTPUT_FILE, content);
console.log('Successfully generated SYSTEM_PROMPT.md');
console.log('Location: ' + OUTPUT_FILE);
console.log('Size: ' + content.length + ' chars\n');
console.log('Summary:');
sections.forEach(section => {
  const filePath = path.join(PROMPTS_DIR, section.file);
  try {
    const stats = fs.statSync(filePath);
    const sizeStr = stats.size.toLocaleString().padStart(6);
    console.log('   OK ' + section.file.padEnd(40) + sizeStr + ' bytes');
  } catch (error) {
    console.log('   !! ' + section.file.padEnd(40) + ' MISSING');
  }
});
